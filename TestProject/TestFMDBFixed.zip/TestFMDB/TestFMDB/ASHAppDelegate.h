//
//  ASHAppDelegate.h
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import <UIKit/UIKit.h>

@class ASHViewController;

@interface ASHAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) ASHViewController *viewController;

@property (strong,nonatomic) UINavigationController *navigationController;

@end
