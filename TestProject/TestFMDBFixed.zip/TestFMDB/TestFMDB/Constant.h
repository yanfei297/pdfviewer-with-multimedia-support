//
//  Constant.h
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>

#define DBPATH @"DB.sqlite"
#define FRIEND_TABLE_NAME @"friendlist"
#define FACEBOOK_FRIEND_DATA @"data"

#pragma mark Facebook Keys

#define FACEBOOK_FRIEND_NAME @"name"
#define FACEBOOK_FRIEND_ID @"id"
#define FACEBOOK_ID @"fid"
#define FACEBOOK_FRIEND_USERNAME @"username"
#define FACEBOOK_FRIEND_FIRST_NAME @"first_name"
#define FACEBOOK_FRIEND_LAST_NAME @"last_name"
#define FACEBOOK_FRIEND_PICTURE @"picture"
#define FRIEND_TABLE_ID @"ID"

