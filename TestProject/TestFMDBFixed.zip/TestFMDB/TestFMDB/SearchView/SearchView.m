//
//  SearchView.m
//  TestContacts
//
//  Created by Sayan on 13/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SearchView.h"


@interface SearchView ()

@property (nonatomic,retain) NSMutableArray *searchResults;
@property (nonatomic,retain) UITextField *searchField;
@end

@implementation SearchView

@synthesize searchContent;
@synthesize searchResults;
@synthesize searchField;
@synthesize delegate;

- (id) initWithCoder:(NSCoder *)aDecoder{
    self = [super initWithCoder:aDecoder];
    if (self) {
        // Initialization code
        //self.searchContent = content;
        self.searchContent = [NSMutableArray array];
        self.searchResults = [NSMutableArray array];
        searching = NO;
        [self createSearchView];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame andSearchContent:(NSArray *)content
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.searchContent = content;
        self.searchResults = [NSMutableArray array];
        searching = NO;
        [self createSearchView];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    
    
}

- (void) createSearchView{
    self.frame = CGRectMake(0, 0, 320, 44);
    self.backgroundColor = [UIColor clearColor];
	
	UIImageView *backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"searchbar.png"]];
	backgroundView.frame = CGRectMake(0, 0, 320, 44);
	[self addSubview:backgroundView];
    backgroundView.autoresizesSubviews = YES;
    backgroundView.autoresizingMask = UIViewAutoresizingFlexibleWidth ;//| UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin;// | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin;
	[backgroundView release];
	
	UIImageView *backView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"searchfield.png"]];
    backView.autoresizesSubviews = YES;
    backView.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	backView.frame = CGRectMake(6, 6, 308, 33);
	[self addSubview:backView];
	[backView release];
	
	
	UIImageView *searchLogo = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"searchicon.png"]];
	searchLogo.frame = CGRectMake(12, 12, 19, 19);
	[self addSubview:searchLogo];
	[searchLogo release];
    
    self.searchField = [[UITextField alloc]initWithFrame:CGRectMake(32,6,280,33)];
    self.searchField.autocorrectionType = UITextAutocorrectionTypeNo;
	self.searchField.placeholder = @"Search String";
    self.searchField.borderStyle = UITextBorderStyleNone;
    self.searchField.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.searchField.contentHorizontalAlignment=UIControlContentHorizontalAlignmentCenter;
    self.searchField.contentVerticalAlignment = UIControlContentVerticalAlignmentCenter;
    self.searchField.font = [UIFont boldSystemFontOfSize:14];
    searchField.userInteractionEnabled = YES;
	[self addSubview:searchField];
	[self.searchField addTarget:self action:@selector(didSearchText) forControlEvents:UIControlEventEditingChanged];
    self.searchField.delegate = self;
    
    
}

#pragma mark - Search 

-(void)didSearchText{
	[searchResults removeAllObjects];
	if([searchField.text length] > 0)
	{
		searching = YES;
		[self search];
	}
	else 
	{
		searching = NO;
	}
	//[searchTableView reloadData];
	if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didSearchFindResults:searching:)]) {
            [self.delegate didSearchFindResults:searchResults searching:searching];
        }
    }
}

-(void)search
{
	NSString *searchText = searchField.text;
	NSInteger len=searchText.length;
	NSMutableArray *searchArray = [[NSMutableArray alloc] init];
	for(int i=0;i<[searchContent count];i++)
	{
		[searchArray addObject:[searchContent objectAtIndex:i]];
	}
	for(int i=0;i<[searchArray count];i++)
	{
		NSString *name= [searchArray objectAtIndex:i];
		if(name.length<len)
		{
			continue;
		}
		NSString *str=[name substringToIndex:len];
		if([searchText caseInsensitiveCompare:str]==0)
		{
			[searchResults addObject:[searchArray objectAtIndex:i]];
		}
	}
	[searchArray release];
	searchArray = nil;
}



#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
	[textField resignFirstResponder];
	return YES;
}

@end
