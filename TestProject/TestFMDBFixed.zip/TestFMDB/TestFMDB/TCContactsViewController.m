//
//  TCContactsViewController.m
//  TestContacts
//
//  Created by Sayan on 13/08/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TCContactsViewController.h"
#import "DataAccessor.h"
#import <AddressBook/AddressBook.h>


@interface TCContactsViewController ()
@property (nonatomic,retain) UIBarButtonItem *editButton;
@end

@implementation TCContactsViewController

@synthesize contactList = _contactList;
@synthesize contacts;
@synthesize sectionContents;
@synthesize searchResults;
@synthesize editButton;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.contacts = [NSArray array];
        searching = NO;
        editing = NO;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationController.navigationBar.tintColor = [UIColor blackColor];
    self.title = @"Contacts";
    self.navigationItem.hidesBackButton = YES;
    //self.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addNewContacts:)];
    self.editButton = [[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStylePlain target:self action:@selector(editContacts:)];
    self.navigationItem.rightBarButtonItem = self.editButton;
    [self reloadContacts];
    
    SearchView *searchView = [[SearchView alloc] initWithFrame:CGRectMake(0, 0, 320, 44) andSearchContent:contacts];//(SearchView *)[self.view viewWithTag:101];
    searchView.delegate = self;
    searchView.searchContent = contacts;
    [self.view addSubview: searchView];
    [searchView release];
}

- (void)viewDidUnload
{
    [self setContactList:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return YES;
    //(interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)dealloc {
    [_contactList release];
    [super dealloc];
}

#pragma mark - AdressBook

- (IBAction)addNewContacts:(id)sender{
    ABNewPersonViewController *picker = [[ABNewPersonViewController alloc] init];
    picker.newPersonViewDelegate = self;
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:picker];
    [self presentModalViewController:navigation animated:YES];
    
    [picker release];
    [navigation release];  
}

- (IBAction)editContacts:(id)sender{
    /*
    if (editing) {
        self.editButton.title = @"Edit";
        editing = NO;
    }
    else {
        self.editButton.title = @"Done";
        editing = YES;
    }
    [self.contactList setEditing:editing];
     */
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) getAllFaceBookContatcs{
    self.contacts = [[[DataAccessor sharedDataAccess] getAllFaceBookFriendsName] sortedArrayUsingSelector:@selector(localizedCaseInsensitiveCompare:)];
    self.sectionContents = [NSMutableArray array];;
    for(char c = 'A'; c <= 'Z'; c++){
        NSMutableArray *tempArr =[NSMutableArray array];
        for (int i=0; i < [contacts count]; i++) {
            NSString *str=[[contacts objectAtIndex:i]substringToIndex:1];
            if ([str isEqualToString:[NSString stringWithFormat:@"%c",c]]) {
                [tempArr addObject:[contacts objectAtIndex:i]];
            }
            
        }
        [sectionContents addObject:tempArr];
    }
}

- (void) getAllConatacts{
    ABAddressBookRef addressBook = ABAddressBookCreate();
    CFArrayRef addressBookData = ABAddressBookCopyArrayOfAllPeople(addressBook);
    
    CFIndex count = CFArrayGetCount(addressBookData);
    
    NSMutableArray *contactsArray = [NSMutableArray array];
    
    for (CFIndex idx = 0; idx < count; idx++) {
        ABRecordRef person = CFArrayGetValueAtIndex(addressBookData, idx);
        
        NSString *firstName = /*(__bridge_transfer NSString *)*/ABRecordCopyValue(person, kABPersonFirstNameProperty);
        NSString *lastName = ABRecordCopyValue(person, kABPersonLastNameProperty);
        
        if (firstName && lastName) {
//            NSDictionary *dict = [NSDictionary dictionaryWithObject:firstName forKey:@"name"];
//            [contactsArray addObject:dict];
            [contactsArray addObject:[NSString stringWithFormat:@"%@ %@",firstName,lastName]];
        }
        
    }
    CFRelease(addressBook);
    CFRelease(addressBookData);
    self.contacts = (NSArray *)contactsArray;
}

- (ABRecordRef) personForIndex:(NSUInteger)index{
    ABAddressBookRef addressBook = ABAddressBookCreate();
    CFArrayRef addressBookData = ABAddressBookCopyArrayOfAllPeople(addressBook);
    ABRecordRef person = CFArrayGetValueAtIndex(addressBookData, index);
    return person;
}

- (void) reloadContacts{
    //[self getAllConatacts];
    [self getAllFaceBookContatcs];
    [self.contactList reloadData];
}

#pragma mark - ABNewPersonViewControllerDelegate

- (void)newPersonViewController:(ABNewPersonViewController *)newPersonView didCompleteWithNewPerson:(ABRecordRef)person{
    [self reloadContacts];
    ((SearchView *)[self.view viewWithTag:101]).searchContent = contacts;
    [self dismissModalViewControllerAnimated:YES];
}

#pragma mark - ABUnknownPersonViewControllerDelegate

- (void)unknownPersonViewController:(ABUnknownPersonViewController *)unknownCardViewController didResolveToPerson:(ABRecordRef)person{
    //[self reloadContacts];
    //((SearchView *)[self.view viewWithTag:101]).searchContent = contacts;
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma mark - UITableViewDataSource

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (searching) {
        return 1;
    }
    return [sectionContents count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (searching) {
        return [searchResults count];
    }
    else {
        return [[sectionContents objectAtIndex:section]count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellID = @"Cell";
    static NSString *nilCellID = @"nilCell";
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellID] autorelease];
    }
    else {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellID] autorelease];
    }
    
    if (searching) {
        cell.textLabel.text = [searchResults objectAtIndex:indexPath.row];
    }
    else {
        cell.textLabel.text = [[sectionContents objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    }
    return cell;
}

/*
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (searching) {
        return [searchResults count];
    }
    else {
        return [contacts count];
    }
}*/

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        ABAddressBookRef addressbook = ABAddressBookCreate();
        ABAddressBookRemoveRecord(addressbook, [self personForIndex:indexPath.row], nil);
        ABAddressBookSave(addressbook, nil);
        CFRelease(addressbook);
        [self reloadContacts];
        ((SearchView *)[self.view viewWithTag:101]).searchContent = contacts;
    }
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    if (searching) {
        return nil;
    }
    return [NSArray arrayWithObjects:@"A",@"B",@"B",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z", nil];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
	if (searching) {
		return [NSString stringWithString:@""];	
	}
    else if ([[sectionContents objectAtIndex:section] count] == 0) {
        return @"";
    }
    else{
		return [[NSArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z", nil] objectAtIndex:section];
	}
    
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index {
    
    if(searching)
        return -1;
    
    return index ;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
//    ABUnknownPersonViewController *picker = [[ABUnknownPersonViewController alloc] init];
//    picker.unknownPersonViewDelegate = self;
//    picker.allowsAddingToAddressBook = NO;
//    picker.displayedPerson = [self personForIndex:indexPath.row];
//    [self.navigationController pushViewController:picker animated:YES];
//    [picker release];
    int i = 0;
    for (NSString *friendName in [[DataAccessor sharedDataAccess] getAllFaceBookFriendsName]) {
        if (NSOrderedSame == [friendName caseInsensitiveCompare:[[sectionContents objectAtIndex:indexPath.section] objectAtIndex:indexPath.row]]) {
            break;
        }
        i++;
    }
    NSLog(@"FRIEND : %@",[[DataAccessor sharedDataAccess] getSelectedFaceBookFriendForSeletedIndex:i]);
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}

- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

#pragma mark - SearchDelegate

- (void) didSearchFindResults:(NSArray *)results searching:(BOOL)search{
    searching = search;
    self.searchResults = results;
    [self.contactList reloadData];
}

@end
