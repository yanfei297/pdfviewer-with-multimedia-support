//
//  ASHViewController.m
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import "ASHViewController.h"
#import <FacebookSDK/FacebookSDK.h>
#import "Constant.h"
#import "SBJson.h"
#import "DataAccessor.h"
#import "Utility.h"
#import "BusyIndicatorView.h"
#import "TCContactsViewController.h"

@interface ASHViewController (Private)
-(void)handleResponseArray:(NSArray *)arrayOfFriends;

@end

@implementation ASHViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (void)getFacebookFriends {
    
    
    //[self.requestConnection cancel];    
    //self.requestConnection = connection;  
    
    
}

- (IBAction)login:(id)sender {
    [[BusyIndicatorView defaultLoadingViewWithText:@"Logging in...."] startLoading];
    [FBSession openActiveSessionWithPermissions:[NSArray arrayWithObjects:@"offline_access",@"email",@"user_location",@"read_friendlists", nil] allowLoginUI:YES completionHandler:^(FBSession *session, FBSessionState status, NSError *error)
    {
        if (session.isOpen) {
            FBRequest *me = [FBRequest requestForMe];
            [me startWithCompletionHandler: ^(FBRequestConnection *connection, NSDictionary<FBGraphUser> *my, NSError *error)
            {
                
                FBRequest *friends = [FBRequest requestForGraphPath:[NSString stringWithFormat:@"%@/friends?fields=id,name,username,first_name,last_name,picture&format=json&access_token=%@",my.id, session.accessToken]];
                [friends startWithCompletionHandler:^(FBRequestConnection *conn, id result, NSError *error )
                 {
                     //[self handleResponseArray:[(NSDictionary *)result objectForKey:FACEBOOK_FRIEND_DATA]];
                     [[BusyIndicatorView defaultLoadingViewWithText:@""] stopLoading];
                     [[DataAccessor sharedDataAccess] saveFriendDetails:[(NSDictionary *)result objectForKey:FACEBOOK_FRIEND_DATA]];
                     [self.navigationController pushViewController:[[[TCContactsViewController alloc]initWithNibName:@"TCContactsViewController" bundle:nil]autorelease] animated:YES];
                 }];
                
                /*
                //selecting friends email
                //my id 100001439295909
                NSString *fql = [NSString stringWithFormat:@"SELECT uid, first_name, last_name, email FROM user WHERE "
                                 //use this to check for same app
                                 //is_app_user = 1 AND  
                    "uid IN (SELECT uid2 FROM friend WHERE uid1 = %@)",my.id];
                NSMutableDictionary * params = [NSMutableDictionary dictionaryWithObjectsAndKeys:fql, @"query",nil];
                
                FBRequestConnection *connection2 = [[FBRequestConnection alloc] initWithTimeout:120];
                
                FBRequestHandler handler =
                ^(FBRequestConnection *connection2, id result, NSError *error) {        
                    //Process the result or the error
                    NSLog(@"FREINDS : %@", result);
                };
                
                FBRequest *request = [[FBRequest alloc] initWithSession:FBSession.activeSession restMethod:@"fql.query"  parameters:[params mutableCopy] HTTPMethod:@"GET"];
                
                [connection2 addRequest:request completionHandler:handler];
                [connection2 start];  
                 */
            }];
        }
    }];
}

-(void)handleResponseArray:(NSArray *)arrayOfFriends
{    
    
}
@end
