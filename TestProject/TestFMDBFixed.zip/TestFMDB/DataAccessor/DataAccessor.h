//
//  DataAccessor.h
//  BigGameRegs
//
//  Created by Sayan Chatterjee on 06/07/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import <Foundation/Foundation.h>

@class FMDatabase;
@class FMDatabaseQueue;
@class FriendDetails;

@interface DataAccessor : NSObject {

	FMDatabase* database;
    NSString *activeDBName;
    FMDatabaseQueue *databaseQueue;
}

+ (DataAccessor *) sharedDataAccess;
- (void) saveFriendDetails:(NSArray *)friends;
- (NSArray *) getAllFaceBookFriendsName;
- (NSArray *) getAllFaceBookFriends;
- (FriendDetails *) getSelectedFaceBookFriendForSeletedIndex:(NSUInteger )index;

@end
