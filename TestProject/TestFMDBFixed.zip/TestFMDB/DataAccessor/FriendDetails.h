//
//  FriendDetails.h
//  TestFMDB
//
//  Created by Sayan on 05/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface FriendDetails : NSObject
@property (nonatomic,strong) NSString *name;
@property (nonatomic,strong) NSString *firstName;
@property (nonatomic,strong) NSString *lastName;
@property (nonatomic,strong) NSString *facebookid;
@property (nonatomic,strong) NSString *userName;
@property (nonatomic,strong) NSString *pictureURLString;
@end
