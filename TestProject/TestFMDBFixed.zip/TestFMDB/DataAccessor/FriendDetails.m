//
//  FriendDetails.m
//  TestFMDB
//
//  Created by Sayan on 05/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import "FriendDetails.h"

@implementation FriendDetails

@synthesize name;
@synthesize firstName;
@synthesize lastName;
@synthesize userName;
@synthesize facebookid;
@synthesize pictureURLString;

- (id) init{
    if (self = [super init]) {
        self.name = @"";
        self.firstName = @"";
        self.lastName = @"";
        self.userName = @"";
        self.facebookid = @"";
        self.pictureURLString = @"";
    }
    return self;
} 
 
- (NSString *) description{
    return [NSString stringWithFormat:@"%@-%@-%@-%@-%@-%@",self.facebookid,self.userName,self.name,self.firstName,self.lastName,self.pictureURLString];
}

@end
