//
//  DataAccessor.m
//  BigGameRegs
//
//  Created by Sayan Chatterjee on 06/07/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//
/*   Documentation:
        This class is implemented as a singleton
        The class is smart enough that it takes care of changes that need to happen
        when state changes in the application.  It relies on the database path
        being set correctly.  
        The first time it is referenced it will open the database connection.
        If the path is changed to the database then it will close the connection and
        open a new connection to the now currently referenced database.
 
        todo  if the connectionto the database fails we currently default to the 
        demo database.  if this is the case then we also need to change the html paths
        set dirty flags and basically get it back to being able to handle things.
        there should be a method in BigGameSettings that will enable us to set to a regulation.
        Use this
*/
#import "DataAccessor.h"
#import "Constant.h"
#import "FMDatabase.h"
#import "FMResultSet.h"
#import "FMDatabaseQueue.h"
#import "FriendDetails.h"

@interface DataAccessor()

@property (nonatomic,retain) FMDatabase* database;

- (void) initializeSharedInstance;
- (void) openCurrentDB;
- (BOOL) isCurrentActiveDB;
- (void) closeActiveDB;
- (NSString *)databasePath;
- (NSString *) createFriendTable;
- (NSString *) friendDataInsertion;
- (NSString *) getAllFriends;
- (NSString *) getSelectedFriendForSelectedIndex:(NSUInteger)index;
- (BOOL) insertFriendsDataToDatabase:(NSDictionary *)friendData;
- (FriendDetails *) getFriendDetailsFromresultset:(FMResultSet *)rs;
- (BOOL) createFacebookFriendTable;

@end

@implementation DataAccessor

@synthesize database;

static DataAccessor *sharedInstance_ = nil;


#pragma mark -
#pragma mark objectlifecycle

+ (DataAccessor *) sharedDataAccess {
	@synchronized(self){
		if (sharedInstance_ == nil) {
			sharedInstance_ = [[self alloc] init];
            
			[sharedInstance_ initializeSharedInstance];
            
            return sharedInstance_;
		}
        
//        if ([sharedInstance_  isCurrentActiveDB]) {
//            return sharedInstance_;
//        }
//        [sharedInstance_ closeActiveDB];
//        [sharedInstance_ openCurrentDB];
        return sharedInstance_;
	}
}

#pragma mark -
#pragma mark classmethods

- (void) saveFriendDetails:(NSArray *)friends{
    [databaseQueue inDatabase:^(FMDatabase *db)
     {
         for (NSDictionary *friend in friends) {
             if ([self insertFriendsDataToDatabase:friend]) {
                 //NSLog(@"Sucessfully inserted");
             }
             else {
                 NSLog(@"Insertion Error..Rolling Back!!");
             }
         }
     }];
    
}

- (NSArray *) getAllFaceBookFriendsName{
    NSMutableArray *toReturn = [NSMutableArray array];
    for (FriendDetails *friend in [self getAllFaceBookFriends]) {
        [toReturn addObject:friend.name];
    }
    return toReturn;
}


- (NSArray *) getAllFaceBookFriends
{
	   
    FMResultSet* rs = [database executeQuery:[self getAllFriends]];
	
	NSMutableArray* toReturn = [[NSMutableArray alloc] init];
	
	while ([rs next])
	{
		[toReturn addObject:[sharedInstance_ getFriendDetailsFromresultset:rs]];
	}
	
	[rs close];
	return ((NSArray *)[toReturn autorelease]);
}

- (FriendDetails *) getSelectedFaceBookFriendForSeletedIndex:(NSUInteger )index{
    FMResultSet *rs = [database executeQuery:[self getSelectedFriendForSelectedIndex:index]];
    FriendDetails *friend = [[[FriendDetails alloc] init] autorelease];
	
	// There should only be one but need to get rs
	while ([rs next])
	{
		friend = [sharedInstance_ getFriendDetailsFromresultset:rs];
	}
	
	[rs close];
    return friend;
}

#pragma mark - DBRelated

- (NSString *)databasePath
{
    NSString *str = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) lastObject];
    return [str stringByAppendingFormat:@"/%@", DBPATH];
}

- (void) initializeSharedInstance{
    
	// initialize any additional things and open currentDB
    
    [sharedInstance_ openCurrentDB];
    
}

//----------------------------------------------------------------

- (void) openCurrentDB {
    
    //allocate and initialize    currentDBPath
	//NSLog(@"currentdbpath = %@", [BigGameSettings appSettings] currentDBPath]);
    
	activeDBName = [[self databasePath] retain];
	
	NSLog(@"ActiveDBName to open : %@",activeDBName);
	
	BOOL success;
	NSFileManager *fileManager = [NSFileManager defaultManager];
	//NSError *error;
	success = [fileManager fileExistsAtPath:activeDBName];
	
	if (!success)
	{
        NSLog(@"Failed to find writable database %@....Creating Database....", activeDBName);
	}
    
	
	self.database = [FMDatabase databaseWithPath:activeDBName] ;
	[database setLogsErrors:TRUE];
	[database setTraceExecution:FALSE];
    
    
	
	if (![database open])
	{
		NSLog(@"Could not open db."); 
		
	}
	else
	{
		NSLog(@"oooooooohooo. DB Open....%@",activeDBName);
        databaseQueue = [[FMDatabaseQueue databaseQueueWithPath:[self databasePath]] retain];
        [databaseQueue inDatabase:^(FMDatabase *db){
            if ([self createFacebookFriendTable]) {
                NSLog(@"Friend Table Cretaed");
            }
            else {
                NSLog(@"Table Creation Failed!!!! Rolling Back....");
            }
        }];
        
	}
	
}

//----------------------------------------------------------------

- (BOOL) isCurrentActiveDB {
	
    if ([activeDBName isEqualToString:[self databasePath]]) {
        
        return YES;
    }
    
    return NO;
    
}
//----------------------------------------------------------------

- (void) closeActiveDB {
    
    [database close];
    
}

#pragma mark - Queries

- (NSString *)createFriendTable
{
    return [NSString stringWithFormat:@"CREATE TABLE IF NOT EXISTS %@ (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,fid TEXT UNIQUE ON CONFLICT IGNORE, username TEXT,first_name TEXT, last_name TEXT, picture TEXT)",FRIEND_TABLE_NAME];
    //return @"CREATE TABLE IF NOT EXISTS friendList(ID INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT,fid TEXT UNIQUEKEY fid NOT NULL, username TEXT,first_name TEXT, last_name TEXT, picture TEXT)";//,email TEXT UNIQUEKEY)";
}

- (NSString *) friendDataInsertion{
    return @"INSERT  into friendList(name, fid, username, first_name, last_name, picture) values(?, ?, ?,?, ?, ?) ";
}

- (NSString *) getAllFriends{
    return [NSString stringWithFormat:@"SELECT * FROM %@",FRIEND_TABLE_NAME];
}

- (NSString *) getSelectedFriendForSelectedIndex:(NSUInteger)index{
    return [NSString stringWithFormat:@"SELECT * FROM %@ WHERE %@ = %d",FRIEND_TABLE_NAME,FRIEND_TABLE_ID,index];
}

#pragma mark - DBMethods

- (BOOL) createFacebookFriendTable{
    return [database executeUpdate:[self createFriendTable]];
}

- (BOOL) insertFriendsDataToDatabase:(NSDictionary *)friendData{
    
    return [database executeUpdate:[self friendDataInsertion], [friendData valueForKey:FACEBOOK_FRIEND_NAME], [friendData valueForKey:FACEBOOK_FRIEND_ID], [friendData valueForKey:FACEBOOK_FRIEND_USERNAME], [friendData valueForKey:FACEBOOK_FRIEND_FIRST_NAME], [friendData valueForKey:FACEBOOK_FRIEND_LAST_NAME], [[[friendData valueForKey:FACEBOOK_FRIEND_PICTURE] objectForKey:@"data"]objectForKey:@"url"]];
}    


- (FriendDetails *) getFriendDetailsFromresultset:(FMResultSet *)rs
{
	
	FriendDetails* friend = [[FriendDetails alloc] init];
	
    friend.name = [rs stringForColumn:FACEBOOK_FRIEND_NAME];
    friend.userName = [rs stringForColumn:FACEBOOK_FRIEND_USERNAME];
    friend.firstName = [rs stringForColumn:FACEBOOK_FRIEND_FIRST_NAME];
    friend.lastName = [rs stringForColumn:FACEBOOK_FRIEND_LAST_NAME];
    friend.facebookid = [rs stringForColumn:FACEBOOK_ID];
    friend.pictureURLString = [rs stringForColumn:FACEBOOK_FRIEND_PICTURE];
    
	return [friend autorelease];
}

@end

