//
//  ASHViewController.m
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import "ASHViewController.h"
#import <FacebookSDK/FacebookSDK.h>
#import "Constant.h"
#import "SBJson.h"
#import "FMDatabase.h"
#import "FMDatabaseQueue.h"
#import "Utility.h"

@interface ASHViewController (Private)
-(void)handleResponseArray:(NSArray *)arrayOfFriends;

@end

@implementation ASHViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.    
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (IBAction)login:(id)sender {
    [FBSession openActiveSessionWithPermissions:nil allowLoginUI:YES
                              completionHandler:^(FBSession *session,
                                                  FBSessionState status,
                                                  NSError *error)
    {
        if (session.isOpen) {
            FBRequest *me = [FBRequest requestForMe];
            [me startWithCompletionHandler: ^(FBRequestConnection *connection,
                                              NSDictionary<FBGraphUser> *my,
                                              NSError *error)
            {
                FBRequest *friends = [FBRequest requestForGraphPath:[NSString stringWithFormat:@"%@/friends?fields=id,name,username,first_name,last_name,picture&format=json&access_token=%@",my.id, session.accessToken]];
                [friends startWithCompletionHandler:^(FBRequestConnection *conn, id result, NSError *error )
                 {
                     [self handleResponseArray:[(NSDictionary *)result objectForKey:FACEBOOK_FRIEND_DATA]];
                 }];
            }];
        }
    }];
}

-(void)handleResponseArray:(NSArray *)arrayOfFriends
{    
    FMDatabaseQueue *dbque = [FMDatabaseQueue databaseQueueWithPath:[Utility DatabasePath]];
    [dbque inTransaction:^(FMDatabase *db, BOOL *rollback)
    {
        for(NSDictionary *tempDict in arrayOfFriends)
        {
            BOOL sucess = [db executeUpdate:@"INSERT OR REPLACE into friendList(name, fid, username, first_name, last_name, picture) values(?, ?, ?,?, ?, ?)", [tempDict valueForKey:FACEBOOK_FRIEND_NAME], [tempDict valueForKey:FACEBOOK_FRIEND_ID], [tempDict valueForKey:FACEBOOK_FRIEND_USERNAME], [tempDict valueForKey:FACEBOOK_FRIEND_FIRST_NAME], [tempDict valueForKey:FACEBOOK_FRIEND_LAST_NAME], [tempDict valueForKey:FACEBOOK_FRIEND_PICTURE]];
            if(!sucess)
            {
                NSLog(@"Not Sucess in update value");
            }
        }
    }];
}
@end
