//
//  ASHViewController.h
//  TestFMDB
//
//  Created by Ashim Samanta on 04/09/12.
//  Copyright (c) 2012 Objectsol. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ASHViewController : UIViewController
- (IBAction)login:(id)sender;

@end
