//
//  RAHotSpotListCell.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAHotSpotListCell.h"
#import "RAUtils.h"
#import "RAGlobal.h"
#import "AsyncImageView.h"

@implementation RAHotSpotListCell

@synthesize profileImage;
@synthesize clubName;
@synthesize clubCity;
@synthesize clubCountry;
@synthesize clubState;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andClubDetails:(NSDictionary *)details{
    
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        self.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        self.autoresizesSubviews = YES;
        
        [self.contentView addSubview: [RAUtils imageViewWithImageName:@"table_arrow.png" x:1 y:1]];
        
        //[self addSubview:[RAUtils imageViewWithImageName:@"default_img.png" x:15  y:15]];
        NSString *club_name = @"";
        NSString *club_city = @"";
        NSString *club_state = @"";
        NSString *club_country = @"";
        NSString *imageUrl = @"";
        
        AsyncImageView *profileImageView = [[[AsyncImageView alloc] initWithFrame:CGRectMake(15, 7, 35, 35)] autorelease];
        [self autoresizeView:profileImageView];
        if ([RAUtils validString:[details objectForKey:JSON_RESPONSE_CLUB_HAS_PROFILE_IMAGE_KEY]]) {
            if ([[details objectForKey:JSON_RESPONSE_CLUB_HAS_PROFILE_IMAGE_KEY] isEqualToString:@"Y"]) {
                imageUrl = [details objectForKey:JSON_RESPONSE_CLUB_PROFILE_IMAGE_KEY];
                if ([RAUtils validString:imageUrl]) {
                    [profileImageView loadImageFromURL:[NSURL URLWithString:imageUrl]];
                    
                }
                else {
                    [profileImageView loadDefaultImage:[UIImage imageNamed:@"default_img.png"]];
                }
            }
            else {
                [profileImageView loadDefaultImage:[UIImage imageNamed:@"default_img.png"]];
            }
            
            [self.contentView addSubview:profileImageView];
            
            if ([RAUtils validString:[details objectForKey:JSON_RESPONSE_CLUB_NAME_KEY]]) {
                club_name = [details objectForKey:JSON_RESPONSE_CLUB_NAME_KEY];
            }
            
            if ([RAUtils validString:[details objectForKey:JSON_RESPONSE_CLUB_CITY_KEY]]) {
                club_city = [details objectForKey:JSON_RESPONSE_CLUB_CITY_KEY];
            }
            
            if ([RAUtils validString:[details objectForKey:JSON_RESPONSE_CLUB_STATE_KEY]]) {
                club_state = [details objectForKey:JSON_RESPONSE_CLUB_STATE_KEY];
            }
            
            if ([RAUtils validString:[details objectForKey:JSON_RESPONSE_CLUB_COUNTRY_KEY]]) {
                club_country = [details objectForKey:JSON_RESPONSE_CLUB_COUNTRY_KEY];
            }
            
            //dynamic height for Lables
            float delHeightName = [RAUtils getHeightForString:club_name forFontName:@"Helvetica"  andSize:16.0];
            float delHeightCity = [RAUtils getHeightForString:club_city forFontName:@"Helvetica"  andSize:14.0];
            float delHeightState = [RAUtils getHeightForString:club_state forFontName:@"Helvetica"  andSize:14.0];
            float delHeightCountry = [RAUtils getHeightForString:club_country forFontName:@"Helvetica"  andSize:14.0];
            
            float totalHeight = delHeightName + delHeightCity + delHeightState + delHeightCountry;
            float startY = (HOTSPOT_CELL_HEIGHT - 10.0 - totalHeight) / 2;
            startY = 7;
            float startX = 55;
            float width = 225;
            NSString *fontName = @"Helvetica";
            UIColor *color = [UIColor blackColor];
            
            UILabel *labName = [RAUtils labelWithFrame:CGRectMake(startX, startY, width, delHeightName) text:club_name textColor:color fontName:fontName fontSize:16.0];
            [self.contentView addSubview:labName];
            self.clubName = labName;
            [self autoresizeView:labName];
        }
        
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];
    
    // Configure the view for the selected state
}

- (void) autoresizeView:(UIView *)view{
    view.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    view.autoresizesSubviews = YES;
}

- (void) dealloc{
    self.clubName = nil;
    self.clubCity = nil;
    self.clubState = nil;
    self.clubCountry = nil;
    [super dealloc];
}

@end
