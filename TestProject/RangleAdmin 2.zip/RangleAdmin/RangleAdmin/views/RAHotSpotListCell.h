//
//  RAHotSpotListCell.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class AsyncImageView;

@interface RAHotSpotListCell : UITableViewCell

@property (strong,nonatomic) AsyncImageView *profileImage;

@property (strong,nonatomic) UILabel *clubName;

@property (strong,nonatomic) UILabel *clubCity;

@property (strong,nonatomic) UILabel *clubState;

@property (strong,nonatomic) UILabel *clubCountry;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier andClubDetails:(NSDictionary *)details;

@end
