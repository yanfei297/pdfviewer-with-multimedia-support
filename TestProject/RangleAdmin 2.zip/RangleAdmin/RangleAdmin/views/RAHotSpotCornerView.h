//
//  RAHotSpotCornerView.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RAHotSpotCornerView : UIView{
    id actionTarget;
}

@end
