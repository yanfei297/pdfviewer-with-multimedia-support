//
//  RAHotSpotCornerView.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAHotSpotCornerView.h"
#import "RAUtils.h"
#import "RAGlobal.h"

@implementation RAHotSpotCornerView

- (id)initWithFrame:(CGRect)frame initWithPointDetails:(NSDictionary *)details andTarget:(id)target
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
