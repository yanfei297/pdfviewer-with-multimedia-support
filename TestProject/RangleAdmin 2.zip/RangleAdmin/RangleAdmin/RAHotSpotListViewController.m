//
//  RAHotSpotListViewController.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAHotSpotListViewController.h"
#import "RAHotSpotListCell.h"
#import "RAGlobal.h"
#import "RAUtils.h"
#import "RAHotSpotEditViewController.h"

@interface RAHotSpotListViewController ()

@end

@implementation RAHotSpotListViewController

@synthesize hotSpotList;
@synthesize clubid;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.hotSpotList = (NSArray *)[RAAppManager defaultManager].hotSpotList;
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.navigationItem.hidesBackButton = YES;
    
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Logout" style:UIBarButtonItemStyleDone target:self action:@selector(logout)] autorelease];
    
    UITableView *list = ((UITableView *)[self.view viewWithTag:100]);
    list.backgroundColor = [UIColor clearColor];
    list.separatorColor = [UIColor clearColor];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return UIDeviceOrientationIsPortrait(interfaceOrientation);
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return [hotSpotList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    static NSString *nilCellIdentifier = @"nil";
    RAHotSpotListCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	    
	if (cell == nil) {
		cell = [[[RAHotSpotListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier andClubDetails:[hotSpotList objectAtIndex:indexPath.section]] autorelease];
		//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		//cell.selectionStyle = UITableViewCellSelectionStyleBlue;
	}
    else{
        cell = [[[RAHotSpotListCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier andClubDetails:[hotSpotList objectAtIndex:indexPath.section]] autorelease];
		//cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		//cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return HOTSPOT_CELL_HEIGHT;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.0f;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.clubid = [[hotSpotList objectAtIndex:indexPath.section] objectForKey:JSON_RESPONSE_CLUB_ID_KEY];
    if (![RAUtils validString:clubid]) {
        [[[[UIAlertView alloc] initWithTitle:@"Error" message:@"Can Not Find Details For This Club" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
        return;
    }
    //[[RAAppManager defaultManager] getClubLocation:clubid];
    [RAAppManager defaultManager].action = UPDATE_CLUB_LOCATION_ACTION;
    [[RAAppManager defaultManager] checkForLoginStatus];
    [RAAppManager defaultManager].delegate = self;
}

#pragma mark - RAManagerDelegate

- (void) adminLoggedIn{
    if ([RAAppManager defaultManager].action == LOGOUT_ACTION) {
        [[RAAppManager defaultManager] userWillLogOut];
        [RAAppManager defaultManager].delegate = self;
    }
    if ([RAAppManager defaultManager].action == UPDATE_CLUB_LOCATION_ACTION) {
        [[RAAppManager defaultManager] getClubLocation:clubid];
        [RAAppManager defaultManager].delegate = self;
    }
    
}

- (void) adminLoggedOut:(NSString *)msg{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Session Expire" message:msg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

- (void) userDidLogoutSuccessfully:(NSString *)logoutMsg{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Success" message:logoutMsg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 500;
    [alert show];
    [alert release];
}

- (void) userDidGetClubLocations:(NSDictionary *)clubLocations{
    [self.navigationController pushViewController:[[[RAHotSpotEditViewController alloc] initWithNibName:@"RAHotSpotEditViewController" bundle:nil andClubLocations:clubLocations] autorelease] animated:YES];
}

- (void) userDidEncounterWithAnError:(NSString *)errorDetails{
    [[[[UIAlertView alloc] initWithTitle:@"Error" message:errorDetails delegate:nil cancelButtonTitle:@"Try Again" otherButtonTitles:nil] autorelease] show];
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag = 500) {
        [self.navigationController popViewControllerAnimated:YES];
    }
    if (alertView.tag = 501) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}

#pragma mark -ClassMethods

- (void)logout{
    //[[RAAppManager defaultManager] userWillLogOut];
    [RAAppManager defaultManager].action = LOGOUT_ACTION;;
    [[RAAppManager defaultManager] checkForLoginStatus];
    [RAAppManager defaultManager].delegate = self;
}

#pragma mark - Memory

- (void) dealloc{
    [RAAppManager defaultManager].delegate = nil;
    self.hotSpotList = nil;
    [super dealloc];
}

@end
