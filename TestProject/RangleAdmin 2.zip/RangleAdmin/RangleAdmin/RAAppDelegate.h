//
//  RAAppDelegate.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class RAViewController;

@interface RAAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) RAViewController *viewController;

@property (strong,nonatomic) UINavigationController *navigationController;

@end
