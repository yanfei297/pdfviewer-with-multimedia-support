//
//  RAHotSpotListViewController.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RAAppManager.h"

@interface RAHotSpotListViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,RAManagerDelegate,UIAlertViewDelegate>{
    NSArray *hotSpotList;
    NSString *clubid;
}

@property (strong,nonatomic) NSArray *hotSpotList;
@property (strong,nonatomic) NSString *clubid;

@end
