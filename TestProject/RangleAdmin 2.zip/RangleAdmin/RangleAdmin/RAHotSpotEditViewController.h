//
//  RAHotSpotEditViewController.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RAAppManager.h"

@interface RAHotSpotEditViewController : UIViewController<RAManagerDelegate>{
    NSMutableDictionary *locationsPoints;
    int buttonIndex;
}

@property (nonatomic,retain) NSMutableDictionary *locationsPoints;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andClubLocations:(NSDictionary *)clubLocations;
- (IBAction)leftFront:(id)sender;
- (IBAction)rightFront:(id)sender;
- (IBAction)leftBack:(id)sender;
- (IBAction)rightBack:(id)sender;
@end
