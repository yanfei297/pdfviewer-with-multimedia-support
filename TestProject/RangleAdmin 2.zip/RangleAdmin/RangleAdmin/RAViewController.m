//
//  RAViewController.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAViewController.h"
#import "RAGlobal.h"
#import "RAUtils.h"
#import "RAHotSpotListViewController.h"

@interface RAViewController ()

@end

@implementation RAViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    UITextField *email = ((UITextField *)[self.view viewWithTag:10]);
    [email setValue:TEXT_COLOR forKeyPath:@"_placeholderLabel.textColor"];
    email.textColor = TEXT_COLOR;
    
    UITextField *passw = ((UITextField *)[self.view viewWithTag:11]);
    [passw setValue:TEXT_COLOR forKeyPath:@"_placeholderLabel.textColor"];
    passw.textColor = TEXT_COLOR;
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    return UIDeviceOrientationIsPortrait(interfaceOrientation);
}

#pragma mark - UITextFieldDelegate

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField{
    self.view.frame = CGRectMake(0, -100, 320, 480);
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    self.view.frame = CGRectMake(0, 0, 320, 480);
    if (textField.tag == 10) {
        [((UITextField *)[self.view viewWithTag:11]) becomeFirstResponder];
    }
    [textField resignFirstResponder];
    return YES;
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 501) {
        [((UITextField *)[self.view viewWithTag:10]) becomeFirstResponder];
    }
    if (alertView.tag == 502) {
        [((UITextField *)[self.view viewWithTag:11]) becomeFirstResponder];
    }
}

#pragma mark - RAManagerDelegate

- (void) userDidLoginSuccessfully{
    [self.navigationController pushViewController:[[[RAHotSpotListViewController alloc]initWithNibName:@"RAHotSpotListViewController" bundle:nil]autorelease] animated:YES];
}

- (void) userDidEncounterWithAnError:(NSString *)errorDetails{
     [[[[UIAlertView alloc] initWithTitle:@"Error" message:errorDetails delegate:nil cancelButtonTitle:@"Try Again" otherButtonTitles:nil] autorelease] show];
}

#pragma mark - Class Methods

- (IBAction)logMeIn:(UIButton *)sender {
    [[[UIApplication sharedApplication] keyWindow] endEditing:YES];
    self.view.frame = CGRectMake(0, 0, 320, 480);
    NSString *email = ((UITextField *)[self.view viewWithTag:10]).text;
    NSString *pass = ((UITextField *)[self.view viewWithTag:11]).text;
    if (![RAUtils validateEmail:email] || email.length == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry!" message:@"Invalid Email" delegate:self cancelButtonTitle:@"Try Again" otherButtonTitles:nil];
        alert.tag = 501;
        [alert show];
        [alert release];
        return;
    }
    if (pass.length == 0) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Sorry!" message:@"Invalid Password" delegate:self cancelButtonTitle:@"Try Again" otherButtonTitles:nil];
        alert.tag = 502;
        [alert show];
        [alert release];
        return;
    }
    [[RAAppManager defaultManager] userWillLoggedIn:[NSArray arrayWithObjects:email.length > 0 ? email : @"greja@objectsol.in",pass.length > 0 ? pass : @"Pass1234", nil]];
    [RAAppManager defaultManager].action = LOGIN_ACTION;
    [RAAppManager defaultManager].delegate = self;
    
}
@end
