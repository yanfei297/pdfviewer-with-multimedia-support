//
//  RAViewController.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RAAppManager.h"

@interface RAViewController : UIViewController<UIAlertViewDelegate,UITextFieldDelegate,RAManagerDelegate>
- (IBAction)logMeIn:(UIButton *)sender;

@end
