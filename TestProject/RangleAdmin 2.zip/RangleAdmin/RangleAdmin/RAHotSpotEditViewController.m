//
//  RAHotSpotEditViewController.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAHotSpotEditViewController.h"
#import "RAUtils.h"
#import "RAGlobal.h"


@interface RAHotSpotEditViewController ()

@end

@implementation RAHotSpotEditViewController

@synthesize locationsPoints;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andClubLocations:(NSDictionary *)clubLocations
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.locationsPoints = [NSMutableDictionary dictionaryWithDictionary:clubLocations];
        
    }
    return self;
}

- (IBAction)leftFront:(id)sender {
    [[RAAppManager defaultManager] getUserLocation];
    [RAAppManager defaultManager].delegate = self;
    buttonIndex = 1;
}

- (IBAction)rightFront:(id)sender {
    [[RAAppManager defaultManager] getUserLocation];
    [RAAppManager defaultManager].delegate = self;
    buttonIndex = 2;
}

- (IBAction)leftBack:(id)sender {
    [[RAAppManager defaultManager] getUserLocation];
    [RAAppManager defaultManager].delegate = self;
    buttonIndex = 3;
}

- (IBAction)rightBack:(id)sender {
    [[RAAppManager defaultManager] getUserLocation];
    [RAAppManager defaultManager].delegate = self;
    buttonIndex = 4;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIButton *backButton = [RAUtils buttonWithNormalImageNamed:@"back_inactive.png" pressedImageName:@"back_active.png" actionTarget:self selector:@selector(backItem) x:7 y:7];
    self.navigationItem.hidesBackButton = YES;
    UIBarButtonItem *backButtonItem = [[UIBarButtonItem alloc] initWithCustomView:backButton] ;
    self.navigationItem.leftBarButtonItem = backButtonItem;
    
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Save" style:UIBarButtonItemStyleDone target:self action:@selector(updateLocations)] autorelease];
    [self designUI];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    //return (interfaceOrientation == UIInterfaceOrientationPortrait);
    return UIDeviceOrientationIsPortrait(interfaceOrientation);
}

- (void) designUI{
    //NSLog(@"Points ; %@",locationsPoints);
    ((UILabel *)[self.view viewWithTag:11]).text = [NSString stringWithFormat:@"Lat : %@",[locationsPoints objectForKey:FRONT_LEFT_LATITUDE_KEY]];
    ((UILabel *)[self.view viewWithTag:12]).text = [NSString stringWithFormat:@"Long : %@",[locationsPoints objectForKey:FRONT_LEFT_LONGITUDE_KEY]];
    
    ((UILabel *)[self.view viewWithTag:13]).text = [NSString stringWithFormat:@"Lat : %@",[locationsPoints objectForKey:FRONT_RIGHT_LATITUDE_KEY]];
    ((UILabel *)[self.view viewWithTag:14]).text = [NSString stringWithFormat:@"Long : %@",[locationsPoints objectForKey:FRONT_RIGHT_LONGITUDE_KEY]];
    
    ((UILabel *)[self.view viewWithTag:15]).text = [NSString stringWithFormat:@"Lat : %@",[locationsPoints objectForKey:BACK_LEFT_LATITUDE_KEY]];
    ((UILabel *)[self.view viewWithTag:16]).text = [NSString stringWithFormat:@"Long : %@",[locationsPoints objectForKey:BACK_LEFT_LONGITUDE_KEY]];
    
    ((UILabel *)[self.view viewWithTag:17]).text = [NSString stringWithFormat:@"Lat : %@",[locationsPoints objectForKey:BACK_RIGHT_LATITUDE_KEY]];
    ((UILabel *)[self.view viewWithTag:18]).text = [NSString stringWithFormat:@"Long : %@",[locationsPoints objectForKey:BACK_RIGHT_LONGITUDE_KEY]];
}

- (void) backItem{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) updateLocations{
    [[RAAppManager defaultManager] checkForLoginStatus];
    [RAAppManager defaultManager].delegate = self;
}

#pragma mark - RAManagerDelegate

- (void) adminLoggedIn{
    //NSString *clubid = [locationsPoints objectForKey:CLUB_ID_KEY];
    [[RAAppManager defaultManager] updateClubLocations:locationsPoints forClub:[locationsPoints objectForKey:CLUB_ID_KEY]];
    [[RAAppManager defaultManager] setDelegate:self];
}

- (void) adminLoggedOut:(NSString *)msg{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Session Expire" message:msg delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

- (void) clubLocationsUpdated:(NSString *)updationMsg{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Location Updated" message:updationMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 502;
    [alert show];
    [alert release];
}

- (void) getCurrentLatitude:(NSString *)latitude andLongitude:(NSString *)longitude{
    switch (buttonIndex) {
        case 1:
            [locationsPoints setValue:latitude forKey:FRONT_LEFT_LATITUDE_KEY];
            [locationsPoints setValue:longitude forKey:FRONT_LEFT_LONGITUDE_KEY];
            break;
        case 2:
            [locationsPoints setValue:latitude forKey:FRONT_RIGHT_LATITUDE_KEY];
            [locationsPoints setValue:longitude forKey:FRONT_RIGHT_LONGITUDE_KEY];
            break;
        case 3:
            [locationsPoints setValue:latitude forKey:BACK_LEFT_LATITUDE_KEY];
            [locationsPoints setValue:longitude forKey:BACK_LEFT_LONGITUDE_KEY];
            break;
        case 4:
            [locationsPoints setValue:latitude forKey:BACK_RIGHT_LATITUDE_KEY];
            [locationsPoints setValue:longitude forKey:BACK_RIGHT_LONGITUDE_KEY];
            break;            
        default:
            break;
    }
    [self designUI];
}

- (void) locationError:(NSString *)errorMsg{
    UIAlertView *alert = [[UIAlertView alloc]initWithTitle:@"Error" message:errorMsg delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 502;
    [alert show];
    [alert release];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag = 501) {
        [self.navigationController popToRootViewControllerAnimated:YES];
    }
}

@end
