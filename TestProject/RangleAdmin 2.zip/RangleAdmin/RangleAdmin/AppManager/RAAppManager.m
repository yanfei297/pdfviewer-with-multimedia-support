//
//  RAAppManager.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAAppManager.h"
#import "RAGlobal.h"
#import "ASIFormDataRequest.h"
#import "XMLRequester.h"
#import "BusyIndicatorView.h"
#import "JSON.h"



@interface RAAppManager (Private)
- (void) initializeSharedInstance;
@end

@implementation RAAppManager(Private)
- (void) initializeSharedInstance{
    loadingView = [BusyIndicatorView defaultLoadingViewWithText:@""];
    addminid = @"";
    passkey = @"";
    self.action = LOGIN_ACTION;
    NSMutableArray *arr = [NSMutableArray new];
    self.hotSpotList = arr;
    [arr release];
}
@end

@implementation RAAppManager

@synthesize hotSpotList ;
@synthesize delegate;
@synthesize addminid;
@synthesize passkey;
//@synthesize currentLocation;
@synthesize action;

static RAAppManager *_sharedInstance;

+ (RAAppManager *) defaultManager{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] init];
        [_sharedInstance initializeSharedInstance];
    }
    
    return _sharedInstance;
}



#pragma mark - Location Methods

- (void) getUserLocation{
    UserCurrentLocation *currentLoc = [[UserCurrentLocation alloc] init] ;
    currentLoc.delegate = self;
    [currentLoc getCurrentLocation];
}

-(void)locationFoundWithLatitude:(NSString *)latitude andLongitude:(NSString *)longitude{
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(getCurrentLatitude:andLongitude:)]) {
            [self.delegate getCurrentLatitude:latitude andLongitude:longitude];
        }
    }
}

-(void)locationError:(NSString *)errormsg{
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(locationError:)]) {
            [self.delegate locationError:errormsg];
        }
    }
}

/*
-(void) start {
    [locationManager startUpdatingLocation];
    [loadingView setText:@"Getting Location"];
    [loadingView startLoading];
}

-(void) stop {
    [locationManager stopUpdatingLocation];
    [loadingView setText:@""];
    [loadingView stopLoading];
}

-(BOOL) locationKnown { 
    if (round(currentLocation.speed) == -1) return NO; else return YES; 
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation {
    //if the time interval returned from core location is more than two minutes we ignore it because it might be from an old session
    if ( abs([newLocation.timestamp timeIntervalSinceDate: [NSDate date]]) < 120) {     
        self.currentLocation = newLocation;
    }
    
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(getCurrentLatitude:andLongitude:)]) {
            [self.delegate getCurrentLatitude:[NSString stringWithFormat:@"%f",currentLocation.coordinate.latitude] andLongitude:[NSString stringWithFormat:@"%f",currentLocation.coordinate.longitude]];
        }
    }
    [self stop];
}

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error {
//    UIAlertView *alert;
//    alert = [[UIAlertView alloc] initWithTitle:@"Error" message:[error description] delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
//    [alert show];
//    [alert release];
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(locationError:)]) {
            [self.delegate locationError:error.localizedDescription];
        }
    }
    [self stop];
}
 */



#pragma mark - WebServiceRequest

- (void) userWillLoggedIn:(NSArray *)userDetails{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"   Logging in"];
    [loadingView startLoading];
    
    NSDictionary *loginParams = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,LOGIN_ACTION_VALUE,FORMAT_VALUE,[userDetails objectAtIndex:0],[userDetails objectAtIndex:1], nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,USER_NAME_KEY,PASSWORD_KEY, nil]];
    [request getASIFormDataRequestWithPostBody:loginParams DidFinishSelector:@selector(userDidLoginSuccessfully:)];
}

- (void) fetchClubList{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"   Fetching List"];
    [loadingView startLoading];
    
    NSDictionary *fecthListParams = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,CLUB_LIST_ACTION_VALUE,FORMAT_VALUE,passkey,addminid, PROFILE_IMAGE_SMALL_VALUE,nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,PASS_KEY,ADMIN_ID_KEY, PROFILE_IMAGE_KEY,nil]];
    //NSLog(@"PARAMS : %@",fecthListParams);
    [request getASIFormDataRequestWithPostBody:fecthListParams DidFinishSelector:@selector(clubListFetchedSuccessfully:)];
}

- (void) userWillLogOut{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"  Logging Out"];
    [loadingView startLoading];
    
    NSDictionary *logoutParams = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,LOGOUT_ACTION_VALUES,FORMAT_VALUE,passkey,addminid, nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,PASS_KEY,ADMIN_ID_KEY,nil]];
    //NSLog(@"PARAMS : %@",fecthListParams);
    [request getASIFormDataRequestWithPostBody:logoutParams DidFinishSelector:@selector(userDidLogoutSuccessfully:)];
}

- (void) checkForLoginStatus{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"Checking Status"];
    [loadingView startLoading];
    
    NSDictionary *statustParams = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,LOGIN_STATUS_ACTION_VALUE,FORMAT_VALUE,passkey,addminid, nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,PASS_KEY,ADMIN_ID_KEY,nil]];
    
    [request getASIFormDataRequestWithPostBody:statustParams DidFinishSelector:@selector(loginStausCheck:)];
}

- (void) getClubLocation:(NSString *)clubid{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"Getting Locations"];
    [loadingView startLoading];
    
    NSDictionary *locationParams = [NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,GET_CLUB_LOCATION_ACTION_VALUE,FORMAT_VALUE,passkey,addminid, clubid,nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,PASS_KEY,ADMIN_ID_KEY,CLUB_ID_KEY,nil]];
    
    //NSLog(@"PArams : %@",locationParams);
    
    [request getASIFormDataRequestWithPostBody:locationParams DidFinishSelector:@selector(didGetClubLocation:)];
}

- (void) updateClubLocations:(NSDictionary *)locations forClub:(NSString *)clubid{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:SERVER_URL actionTarget:self];
    [loadingView setText:@"Saving Locations"];
    [loadingView startLoading];
    
      
    NSMutableDictionary *locationParams = [NSMutableDictionary new];
    //[locationParams setDictionary:[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:API_VERSION_VALUE,CLUB_LIST_ACTION_VALUE,FORMAT_VALUE,passkey,addminid, clubid,nil] forKeys:[NSArray arrayWithObjects:API_VERSION_KEY,TO_DO_ACTION_KEY,FORMAT_KEY,PASS_KEY,ADMIN_ID_KEY,CLUB_ID_KEY,nil]]];
    
    [locationParams setValue:API_VERSION_VALUE forKey:API_VERSION_KEY];
    [locationParams setValue:UPDATE_CLUB_LOCATION_ALL_ACTION_VALUE forKey:TO_DO_ACTION_KEY];
    [locationParams setValue:FORMAT_VALUE forKey:FORMAT_KEY];
    [locationParams setValue:passkey forKey:PASS_KEY];
    [locationParams setValue:addminid forKey:ADMIN_ID_KEY];
    [locationParams setValue:clubid forKey:CLUB_ID_KEY];
    
    [locationParams setValue:[locations objectForKey:FRONT_LEFT_LATITUDE_KEY] forKey:FRONT_LEFT_LATITUDE_KEY];
    [locationParams setValue:[locations objectForKey:FRONT_LEFT_LONGITUDE_KEY] forKey:FRONT_LEFT_LONGITUDE_KEY];
    
    [locationParams setValue:[locations objectForKey:FRONT_RIGHT_LATITUDE_KEY] forKey:FRONT_RIGHT_LATITUDE_KEY];
    [locationParams setValue:[locations objectForKey:FRONT_RIGHT_LONGITUDE_KEY] forKey:FRONT_RIGHT_LONGITUDE_KEY];
    
    [locationParams setValue:[locations objectForKey:BACK_LEFT_LATITUDE_KEY] forKey:BACK_LEFT_LATITUDE_KEY];
    [locationParams setValue:[locations objectForKey:BACK_LEFT_LONGITUDE_KEY] forKey:BACK_LEFT_LONGITUDE_KEY];
    
    [locationParams setValue:[locations objectForKey:BACK_RIGHT_LATITUDE_KEY] forKey:BACK_RIGHT_LATITUDE_KEY];
    [locationParams setValue:[locations objectForKey:BACK_RIGHT_LONGITUDE_KEY] forKey:BACK_RIGHT_LONGITUDE_KEY];
        
    //NSLog(@"PARAMS : %@",locationParams);
    [request getASIFormDataRequestWithPostBody:[locationParams autorelease]DidFinishSelector:@selector(didUpdateClubLocations:)];
}

#pragma mark - ASIFormDataRequest Actions

- (void) userDidLoginSuccessfully:(ASIFormDataRequest *)request{
    //NSLog(@"Response : %@",request.responseString);
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_LOGIN_STATUS] isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        self.addminid = [[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_DATASET] objectForKey:JSON_RESPONSE_ADMINID];
        self.passkey = [[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_DATASET] objectForKey:JSON_RESPONSE_PASSKEY];
        self.action = FETCH_CLUBLIST_ACTION;
        [self fetchClubList];
    }
    else{
        if (delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounterWithAnError:)]) {
                [self.delegate userDidEncounterWithAnError: [[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_ERROR_MSG]];
            }
        }
    }
    
}

- (void) clubListFetchedSuccessfully:(ASIFormDataRequest *)request{
    //NSLog(@"Response : %@",request.responseString);
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_FETCH_STATUS]isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidLoginSuccessfully)]) {
                //self.hotSpotList = nil;
                if ([hotSpotList count] > 0) {
                    [hotSpotList removeAllObjects];
                }
                NSMutableArray *clubList = [NSMutableArray arrayWithArray:[[jsonDict objectForKey:JSON_RESPONSE_RAWS]  objectForKey:JSON_RESPONSE_DATASET]];
                for (NSDictionary *dict in clubList) {
                    [hotSpotList addObject:dict];
                }
                //NSLog(@"HOTSPOTS : %@",self.hotSpotList);
                [self.delegate userDidLoginSuccessfully];
            }
        }
    }
    else{
        if (delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounterWithAnError)]) {
                [self.delegate userDidEncounterWithAnError:request.error.localizedDescription];
            }
        }
    }
}

- (void) userDidLogoutSuccessfully:(ASIFormDataRequest *)request{
    //NSLog(@"Response : %@",request.responseString);
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_LOGOUT_STATUS] isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        self.addminid = @"";
        self.passkey = @"";
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidLogoutSuccessfully:) ]) {
                [self.delegate userDidLogoutSuccessfully:[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_SUCCESS_MSG]];
            }
        }
    }
    else{
        if (delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounterWithAnError)]) {
                [self.delegate userDidEncounterWithAnError:request.error.localizedDescription];
            }
        }
    }
}

- (void) loginStausCheck:(ASIFormDataRequest *)request{
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_LOGIN_STATUS] isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(adminLoggedIn)]) {
                [self.delegate adminLoggedIn];
            }
        }
    }
    else {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(adminLoggedOut:)]) {
                [self.delegate adminLoggedOut:[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_ERROR_MSG] ];
            }
        }
    }
}

- (void) didGetClubLocation:(ASIFormDataRequest *)request{
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_FETCH_STATUS] isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidGetClubLocations:)]) {
                [self.delegate userDidGetClubLocations:[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_DATASET]];
            }
        }
    }
    else{
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(adminLoggedOut:)]) {
                [self.delegate adminLoggedOut:[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_ERROR_MSG] ];
            }
        }
    }
}

- (void) didUpdateClubLocations:(ASIFormDataRequest *)request{
    [loadingView setText:@""];
    [loadingView stopLoading];
    NSDictionary *jsonDict = [request.responseString JSONValue];
    if ([[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_UPDATE_LOCATION_STATUS] isEqualToString:JSON_RESPONSE_STATUS_CODE_SUCCESS]) {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(clubLocationsUpdated:)]) {
                [self.delegate clubLocationsUpdated:[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_SUCCESS_MSG]];
            }
        }
    }
    else {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(adminLoggedOut:)]) {
                [self.delegate adminLoggedOut:[[[jsonDict objectForKey:JSON_RESPONSE_RAWS] objectForKey:JSON_RESPONSE_STATUS] objectForKey:JSON_RESPONSE_ERROR_MSG] ];
            }
        }
    }
    
}

#pragma mark - ASIFormDataRequestDelegate

-(void)requestStarted:(ASIFormDataRequest *)request{
    //NSLog(@"STATUS : %d",request.responseStatusCode);
    //NSLog(@"REQUEST URL : %@",request.originalURL);
    //NSLog(@"Request Headers: %@",request.requestHeaders);
}

- (void)request:(ASIFormDataRequest *)request didReceiveResponseHeaders:(NSDictionary *)responseHeaders{
    NSLog(@"STATUS : %d",request.responseStatusCode);
       
}

- (void)request:(ASIFormDataRequest *)request willRedirectToURL:(NSURL *)newURL{
    //NSLog(@"NEW URL : %@",newURL.absoluteString);
}

- (void)requestFailed:(ASIFormDataRequest *)request{
    //NSLog(@"Error : %@",request.error);
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
    if ([loadingView isAnimating]) {
        [loadingView stopLoading];
    }
    //[[[[UIAlertView alloc] initWithTitle:@"Error!" message:request.error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease] show];
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(userDidEncounterWithAnError:)]) {
            [self.delegate userDidEncounterWithAnError:request.error.localizedDescription];
        }
    }
}


@end
