//
//  RAUtils.m
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "RAUtils.h"

@implementation RAUtils

+ (BOOL) validString:(NSString *)string{
    if (string) {
        if (string.length > 0) {
            return YES;
        }
    }
    return NO;
}

//clear subviews

+ (void)clearSubviewsfromView:(UIView *)view{
    for(UIView *subview in [view subviews]){
        [subview removeFromSuperview];
    }
}

//getting a view if is it on the superview

+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview{
    for (UIView *view in [superview subviews]) {
        if (view.tag == tag) {
            return YES;
        }
    }
    return NO;
}

//rounded  croner view

+ (void) getRoundedCornerForView:(UIView *)view withCornerRadius:(float)radius{
    // create round corners
    [view.layer setCornerRadius:radius];
    [view.layer setMasksToBounds:YES];
    [view.layer setBorderColor:[UIColor colorWithRed:102.0/255.0 green:17.0/255.0 blue:75.0/255.0 alpha:1.0].CGColor];
    [view.layer setBorderWidth:1.0];
    view.clipsToBounds = YES;
}

+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName andSize:(float)size{
    CGSize maximumSize = CGSizeMake(300, 1000);
    UIFont *selectedFont = [UIFont fontWithName:fontName size:size];
    CGSize stringSize = [str sizeWithFont:selectedFont 
                        constrainedToSize:maximumSize 
                            lineBreakMode:UILineBreakModeWordWrap];
    return stringSize.height;
}


@end
