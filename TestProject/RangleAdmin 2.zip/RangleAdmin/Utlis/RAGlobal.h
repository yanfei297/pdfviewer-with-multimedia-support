//
//  RAGlobal.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#define TEXT_COLOR [UIColor colorWithRed:122.0 / 255.0 green:15.0 / 255.0 blue:111.0 / 255.0 alpha:1.0]

#define HOTSPOT_CELL_HEIGHT 52.0

#define SERVER_URL @"http://www.rangleapp.com/raws/ws_admin.php"

#pragma mark - Post Data keys and values

#define API_VERSION_KEY @"api_version"
#define TO_DO_ACTION_KEY @"todoaction"
#define FORMAT_KEY @"format"

#define API_VERSION_VALUE @"1.0.0"
#define LOGIN_ACTION_VALUE @"do_admin_login"
#define FORMAT_VALUE @"JSON"

#pragma mark - Login keys

#define USER_NAME_KEY @"user_name"
#define PASSWORD_KEY @"user_password"

#pragma mark - club list keys 

#define PASS_KEY @"pass_key"
#define ADMIN_ID_KEY @"admin_id"
#define PROFILE_IMAGE_KEY @"image_size"
#define CLUB_LIST_ACTION_VALUE @"get_club_list"
#define PROFILE_IMAGE_SMALL_VALUE @"S"
#define PROFILE_IMAGE_MEDIUM_VALUE @"M"

#pragma mark - Logout keys

#define LOGOUT_ACTION_VALUES @"do_admin_logout"

#pragma mark - Login Status keys

#define LOGIN_STATUS_ACTION_VALUE @"admin_login_check"

#pragma mark - Get Club Locations 

#define GET_CLUB_LOCATION_ACTION_VALUE @"get_club_location"
#define CLUB_ID_KEY @"club_id"

#pragma mark - Upate Club location All

#define UPDATE_CLUB_LOCATION_ALL_ACTION_VALUE @"set_club_all4coordinates"

#define FRONT_LEFT_LATITUDE_KEY @"front_left_latitude"
#define FRONT_LEFT_LONGITUDE_KEY @"front_left_longitude"

#define FRONT_RIGHT_LATITUDE_KEY @"front_right_latitude"
#define FRONT_RIGHT_LONGITUDE_KEY @"front_right_longitude"

#define BACK_LEFT_LATITUDE_KEY @"back_left_latitude"
#define BACK_LEFT_LONGITUDE_KEY @"back_left_longitude"

#define BACK_RIGHT_LATITUDE_KEY @"back_right_latitude"
#define BACK_RIGHT_LONGITUDE_KEY @"back_right_longitude"

#pragma mark - RESPONSE KEYS

#define  JSON_RESPONSE_RAWS @"raws"
#define JSON_RESPONSE_STATUS @"status"
#define JSON_RESPONSE_STATUS_CODE_SUCCESS @"true"
#define JSON_RESPONSE_DATASET @"dataset"
#define JSON_RESPONSE_ERROR_MSG @"err_msg"
#define JSON_RESPONSE_SUCCESS_MSG @"success_msg"

#pragma mark - LOGIN RESPONSE KEYS

#define JSON_RESPONSE_ADMINID @"admin_id"
#define JSON_RESPONSE_PASSKEY @"pass_key"
#define JSON_RESPONSE_LOGIN_STATUS @"login_status"

#pragma FETCH RESPONSE KEYS

#define JSON_RESPONSE_FETCH_STATUS @"fetch_status"

#pragma mark - Logout response keys

#define JSON_RESPONSE_LOGOUT_STATUS @"logout_status"


#pragma mark - Location Update Response keys

#define JSON_RESPONSE_UPDATE_LOCATION_STATUS @"location_update_status"

#pragma mark - Hotspot Keys

#define JSON_RESPONSE_CLUB_ID_KEY @"id"

#define JSON_RESPONSE_CLUB_NAME_KEY @"club_name"

#define JSON_RESPONSE_CLUB_CITY_KEY @"club_city"

#define JSON_RESPONSE_CLUB_STATE_KEY @"club_state"

#define JSON_RESPONSE_CLUB_COUNTRY_KEY @"club_country"

#define JSON_RESPONSE_CLUB_PROFILE_IMAGE_KEY @"profile_image_url"

#define JSON_RESPONSE_CLUB_HAS_PROFILE_IMAGE_KEY @"has_profile_picture"



