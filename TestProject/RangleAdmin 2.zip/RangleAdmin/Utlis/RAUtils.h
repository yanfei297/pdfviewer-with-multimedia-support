//
//  RAUtils.h
//  RangleAdmin
//
//  Created by Sayan on 25/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utils.h"

@interface RAUtils : Utils
+ (BOOL) validString:(NSString *)string;
+ (void)clearSubviewsfromView:(UIView *)view;
+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview;
+ (void) getRoundedCornerForView:(UIView *)view withCornerRadius:(float)radius;
+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName andSize:(float)size;
@end
