#import "AsyncImageView.h"
#import "UIImage+Resize.h"
#import "RAUtils.h"

@implementation AsyncImageView

- (id) initWithFrame:(CGRect)frame{
    if (self = [super initWithFrame:frame]) {
        ;
    }
    return self;
}

- (void)dealloc
{
	[connection cancel]; 
	[connection release];
	[data release]; 
    [super dealloc];
}


- (void)loadImageFromURL:(NSURL*)url
{
    //NSLog(@"IMAGE URL : %@",url);
	if (connection!=nil) 
	{ 
		[connection release]; 
	} 
	if (data!=nil)
	{ 
		[data release];
	}
	spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
	[spinner setCenter:CGPointMake(self.frame.size.width/2.0, self.frame.size.height/2.0)]; 
	[self addSubview:spinner];
	NSURLRequest* request = [NSURLRequest requestWithURL:url cachePolicy:NSURLRequestUseProtocolCachePolicy timeoutInterval:60.0];
	connection = [[NSURLConnection alloc] initWithRequest:request delegate:self]; 
}

+ (BOOL) displayImageFromURL:(NSString *)urlString{
    AsyncImageView *imageView = [[[self alloc] init] autorelease];
    if ([urlString isEqualToString:@"nil"] || urlString.length < 1) {
        return NO;
    }
    [imageView loadImageFromURL:[NSURL URLWithString:urlString]];
    return YES;
}

- (void)connection:(NSURLConnection *)theConnection didReceiveData:(NSData *)incrementalData
{
	[spinner startAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
	if (data==nil)
	{
		data = [[NSMutableData alloc] initWithCapacity:2048];
	} 
	[data appendData:incrementalData];
}

- (void)connectionDidFinishLoading:(NSURLConnection*)theConnection 
{
	[connection release];
	connection=nil;
	if ([[self subviews] count]>0)
	{
		[[[self subviews] objectAtIndex:0] removeFromSuperview];
	}
    
    if (data) {
        UIImageView* imageView = [[[UIImageView alloc] initWithImage:[UIImage imageWithData:data]] autorelease];
        
        
        if (imageView.image.size.width == 0 || imageView.image.size.height == 0) {
            [self loadDefaultImage:[UIImage imageNamed:@"default_img.png"]];
            return;
        }
        //if (imageView.image.size.width != 70 || imageView.image.size.height != 70) {
        imageView.image = [imageView.image returnPoportainalScaledIamge:CGSizeMake(35, 35)];
            
        //}
        [RAUtils getRoundedCornerForView:imageView withCornerRadius:5];
        [self addSubview:imageView];
        imageView.frame = CGRectMake(0, 0, 35, 35);//self.bounds;
        [imageView setNeedsLayout];
        [self setNeedsLayout];
       // NSLog(@"SIZE : %f,%f",imageView.image.size.width,imageView.image.size.height);
        //NSLog(@"Frame : %f,%f,%f,%f",imageView.frame.origin.x,imageView.frame.origin.y,imageView.frame.size.width,imageView.frame.size.height);
        [data release];
        data=nil;
    }
    else{
        [self loadDefaultImage:[UIImage imageNamed:@"default_img.png"]];
    }
	
	[spinner stopAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    [self loadDefaultImage:[UIImage imageNamed:@"default_img.png"]];
    [spinner stopAnimating];
    [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
}

//in case we want a local image
- (void)loadDefaultImage:(UIImage *)defaultImage {
    
	if ([[self subviews] count]>0) {
		//then this must be another image, the old one is still in subviews
		[[[self subviews] objectAtIndex:0] removeFromSuperview]; //so remove it (releases it also)
	}
	
	//make an image view for the image
	UIImageView* imageView = [[[UIImageView alloc] initWithImage:defaultImage] autorelease];
	//make sizing choices based on your needs, experiment with these. maybe not all the calls below are needed.
	imageView.contentMode = UIViewContentModeScaleAspectFit;
	imageView.autoresizingMask =  UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight ;
	[self addSubview:imageView];
	imageView.frame = self.bounds;
	[imageView setNeedsLayout];
	[self setNeedsLayout];
	
}

- (UIImage*) image 
{
    UIImageView *iv = nil;
    for (UIView *view in [self subviews]) {
        if ([view isKindOfClass:[UIImageView class]]) {
            iv = (UIImageView *)view;
        }
    }
	if (iv) {
        return [iv image];
    }
    else{
        return nil;
    }
	
}

@end