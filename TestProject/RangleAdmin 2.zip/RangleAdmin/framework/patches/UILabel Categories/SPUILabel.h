//
//  SPUILabel.h
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 15/09/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum VerticalAlignment {
    VerticalAlignmentTop,
    VerticalAlignmentMiddle,
    VerticalAlignmentBottom,
} VerticalAlignment;

@interface SPUILabel : UILabel
{
@private
    VerticalAlignment verticalAlignment_;
}
@property (nonatomic, assign) VerticalAlignment verticalAlignment;
@end
