//
//  UILabel+VerticalAlign.h
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/21/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UILabel(VerticalAlign)
- (void)alignTop;
- (void)alignBottom;
@end
