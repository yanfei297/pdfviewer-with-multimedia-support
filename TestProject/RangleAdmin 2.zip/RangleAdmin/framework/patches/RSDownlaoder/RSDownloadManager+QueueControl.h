//
//  RSDownloadManager+QueueControl.h
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/12/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface RSDownloadManager(QueueControl)

+(void)queueDownload:(RSDownload*)dload;

+(void)destroyDownload:(RSDownload*)dload;

+(void)pauseDownload:(RSDownload*)dload;

+(void)resumeDownload:(RSDownload *)dload;

+(void)downloadFinished:(RSDownload*)dload;

+(void)waitForNetworkReconnection;

+(void)retryAfterTimeout;

+(void)onNetworkConnectionReturn;


@end
