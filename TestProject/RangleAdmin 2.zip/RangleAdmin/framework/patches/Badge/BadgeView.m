//
//  BadgeView.m
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/26/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "BadgeView.h"
#import "Utils.h"


@implementation BadgeView


- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
    }
    return self;
}

-(int)count {
    return count;
}

-(UIImageView*)badgeBG {
    return badgeBG;
}

-(void)setCount:(int)c {
    countLabel.text = [NSString stringWithFormat:@"%i", c];
    
    //If the new number is greater than 10 and the previous isn't, change the background and sizes
    if((c / 10 >= 1) && !(count / 10 >= 1)) {
        [badgeBG removeFromSuperview];
        [badgeBG release];
        badgeBG = [[Utils imageViewWithImageName:@"badge2.png"] retain];
        [Utils view:self setWidth:badgeBG.frame.size.width];
        [self addSubview:badgeBG];
        
        countLabel.frame = self.frame;
        
    //If the new number is less than 10 and the previous isn't, change the background and sizes
    } else if((c / 10 < 1) && !(count / 10 < 1)) {
        [badgeBG removeFromSuperview];
        [badgeBG release];
        badgeBG = [[Utils imageViewWithImageName:@"badge1.png"] retain];
        [Utils view:self setWidth:badgeBG.frame.size.width];
        [self addSubview:badgeBG];
        
        countLabel.frame = self.frame;
    }
}
        

-(id) init {
    if((self = [super init])) {
        badgeBG = [[Utils imageViewWithImageName:@"badge1.png"] retain];
        self.frame = badgeBG.frame;
        [self addSubview: badgeBG];
    
        countLabel = [[UILabel alloc] init];
        countLabel.frame = self.frame;
        [Utils view:countLabel setY:-3];
        countLabel.backgroundColor = [UIColor clearColor];
        countLabel.textAlignment = UITextAlignmentCenter;
        countLabel.font = [UIFont fontWithName:@"Helvetica-Bold" size:16];
        countLabel.textColor = [UIColor whiteColor];
        [self addSubview:countLabel];
    
        self.count = 0;
    }
    
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)dealloc {
    [badgeBG release];
    [countLabel release];
    [super dealloc];
}


@end
