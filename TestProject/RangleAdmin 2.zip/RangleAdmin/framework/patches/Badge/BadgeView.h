//
//  BadgeView.h
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/26/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BadgeView : UIView {
    UIImageView *badgeBG;
    UILabel *countLabel;
    
    int count;
}

@property (readwrite) int count;
@property (readonly) UIImageView *badgeBG;

@end
