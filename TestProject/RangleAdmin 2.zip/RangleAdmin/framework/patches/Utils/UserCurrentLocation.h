//
//  UserCurrentLocation.h
//  SKIIP
//
//  Created by Sayan Chatterjee on 25/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@protocol CurrentLocationDelegate
	@optional
-(void)locationFoundWithLatitude:(NSString *)latitude andLongitude:(NSString *)longitude;
-(void)locationError:(NSString *)errormsg;
@end

@interface UserCurrentLocation : NSObject<CLLocationManagerDelegate> {
	NSString	 *lat;
	NSString *long_;
	CLLocationManager *locationManager;
	id<CurrentLocationDelegate>	delegate;
}

@property (nonatomic,assign) 	id<CurrentLocationDelegate>	delegate;

-(void)getCurrentLocation;

@end
