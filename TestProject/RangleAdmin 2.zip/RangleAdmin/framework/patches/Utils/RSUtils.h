//
//  RSUtils.h
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 04/10/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utils.h"

#define ApplicationWillEnterBackgroundNotification @"ApplicationWillEnterBackgroundNotification"
#define ApplicationWillEnterForegroundNotification @"ApplicationWillEnterForegroundNotification"

@interface RSUtils : Utils {

}
+(UIButton *)createRoundedButtonWithFrame:(CGRect)frame 
								    title:(NSString *)title
								   target:(id)target
								   action:(SEL)action;

+(NSString *)podcastDir;

+(NSString*)finishedDownloadsFile;

+(NSString*)pausedDownloadsFile;

+(NSString*)failedDownloadsFile;

+(NSString*)notificationsFile;

+(NSString *)timeInMin:(NSString *)strTime;

+(NSString *)timeInMinuteSecondFormat:(NSString *)strTime;

+(NSString *)fileSizeInMb:(NSString *)strSize;

+(UIColor *)addTracksCellBGColor;

+(UIImageView*)bottomAddTracksBar;

+(UIImageView*)bottomBackToPlistBar;

@end
