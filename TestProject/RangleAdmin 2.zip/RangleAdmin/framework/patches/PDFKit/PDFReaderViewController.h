//
//  PDFReaderViewController.h
//  TestPDF
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MessageUI/MessageUI.h>
#import "PDFDocument.h"
#import "PDFReaderContentView.h"
#import "PDFReaderConfig.h"
#import "PDFReaderTopToolbar.h"
#import "PDFReaderBottomToolbar.h"
#import "ReaderMainPagebar.h"
#import "ThumbsViewController.h"


@class PDFReaderViewController;
@protocol PDFReaderViewControllerDelegate <NSObject>

@optional // Delegate protocols

- (void)dismissPDFReaderViewController:(PDFReaderViewController *)viewController;

@end

@interface PDFReaderViewController : UIViewController <UIScrollViewDelegate, UIGestureRecognizerDelegate, MFMailComposeViewControllerDelegate, PDFReaderContentViewDelegate, PDFReaderTopToolbarDelegate, PDFReaderBottomToolbarDelegate, ReaderMainPagebarDelegate, ThumbsViewControllerDelegate, UIImagePickerControllerDelegate, UIPopoverControllerDelegate, UIActionSheetDelegate> {
@private // Instance variables
	
	PDFDocument *document;
	
	UIScrollView *theScrollView;
	
	PDFReaderTopToolbar *topToolbar;
	
	PDFReaderBottomToolbar *bottomToolbar;
	
	ReaderMainPagebar *mainPagebar;
	
	NSMutableDictionary *contentViews;
	
	#if (READER_ENABLE_PRINT == TRUE)
	UIPrintInteractionController *printInteraction;
	#endif
	
	NSInteger currentPage;
	
	CGSize lastAppearSize;
	
	NSDate *lastHideTime;
	
	BOOL isVisible;
	
	//BOOL multimediaPlaying;
	
	UIPopoverController *pop;
	
	UIImageView *photoImg;
	
	//SMB:Zoom
	CGFloat pageZoomScale;
}

@property (nonatomic, assign, readwrite) id <PDFReaderViewControllerDelegate> delegate;


- (id)initWithPDFDocument:(PDFDocument *)object;
- (void)handleRequest:(NSURL*)url;
- (void)PickImage;
@end
