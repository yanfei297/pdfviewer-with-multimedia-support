//
//  SMBMediaPlayer.h
//  SMBPDFKit
//
//  Created by SMB on 24/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MediaPlayer/MediaPlayer.h>
#import "PlayerConfig.h"

@class SMBMediaPlayer;

@protocol SMBMediaPlayerDelegate <NSObject>

//@required
- (void) playbackDidStartInMediaPlayer:(SMBMediaPlayer*)player;
- (void) playbackDidStopInMediaPlayer:(SMBMediaPlayer*)player;
- (void) playbackDidPauseInMediaPlayer:(SMBMediaPlayer*)player;

@optional
- (void) playbackDidFinishInMediaPlayer:(SMBMediaPlayer*)player;

@end


@interface SMBMediaPlayer : UIViewController {
	
	id<SMBMediaPlayerDelegate> delegate;
	int tag;
	
	BOOL _local;
	NSURL *mediaURL;
	CGRect mediaFrame;
	
	
	MPMoviePlayerController *moviePlayer;
	
	UILabel *label;
	UIButton *playBut;
}
@property (nonatomic, retain) id<SMBMediaPlayerDelegate> delegate;
@property (nonatomic, assign) int tag;

-(id)initWithFrame:(CGRect)frame urlString:(NSString*)urlString isLocal:(BOOL)local;
-(void)initializeMediaPlayer;
-(void)showPlayButton;
@end
