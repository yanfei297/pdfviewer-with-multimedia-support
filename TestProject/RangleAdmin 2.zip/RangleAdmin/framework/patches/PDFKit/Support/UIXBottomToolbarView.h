//
//  UIXbottomToolbarView.h
//  SMBPDFKit
//
//  Created by SMB on 11/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UIXBottomToolbarView : UIView {

}

@end

#pragma mark -

//
//	UIXBottomToolbarShadow class interface
//

@interface UIXBottomToolbarShadow : UIView
{
@private // Instance variables
}

@end
