//
//  UIXBottomToolbarView.m
//  SMBPDFKit
//
//  Created by SMB on 11/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "UIXBottomToolbarView.h"
#import "PDFReaderConfig.h"
#import <QuartzCore/QuartzCore.h>

@implementation UIXBottomToolbarView

#pragma mark UIXBottomToolbarView class methods

+ (Class)layerClass
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	return [CAGradientLayer class];
}

#pragma mark UIXBottomToolbarView instance methods

- (id)initWithFrame:(CGRect)frame
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if ((self = [super initWithFrame:frame]))
	{
		self.autoresizesSubviews = YES;
		self.userInteractionEnabled = YES;
		self.contentMode = UIViewContentModeRedraw;
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
		self.backgroundColor = [UIColor clearColor];
		
		CAGradientLayer *layer = (CAGradientLayer *)self.layer;
		CGColorRef liteColor = TOOLBAR_LIGHTCOLOR.CGColor;
		CGColorRef darkColor = TOOLBAR_DARKCOLOR.CGColor;
		layer.colors = [NSArray arrayWithObjects:(id)liteColor, (id)darkColor, nil];
		
		CGRect shadowRect = self.bounds; shadowRect.origin.y = 0.0f; shadowRect.size.height = 4.0f;
		
		UIXBottomToolbarShadow *shadowView = [[UIXBottomToolbarShadow alloc] initWithFrame:shadowRect];
		
		[self addSubview:shadowView]; [shadowView release];
	}
	
	return self;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	[super dealloc];
}

@end

#pragma mark -

//
//	UIXBotoomToolbarShadow class implementation
//

@implementation UIXBottomToolbarShadow


#pragma mark UIXBottomToolbarShadow class methods

+ (Class)layerClass
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	return [CAGradientLayer class];
}

#pragma mark UIXBottomToolbarShadow instance methods

- (id)initWithFrame:(CGRect)frame
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if ((self = [super initWithFrame:frame]))
	{
		self.autoresizesSubviews = NO;
		self.userInteractionEnabled = NO;
		self.contentMode = UIViewContentModeRedraw;
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
		self.backgroundColor = [UIColor clearColor];
		
		CAGradientLayer *layer = (CAGradientLayer *)self.layer;
		CGColorRef blackColor = [UIColor colorWithWhite:0.24f alpha:1.0f].CGColor;
		CGColorRef clearColor = [UIColor colorWithWhite:0.24f alpha:0.0f].CGColor;
		layer.colors = [NSArray arrayWithObjects:(id)blackColor, (id)clearColor, nil];
	}
	
	return self;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	[super dealloc];
}

@end
