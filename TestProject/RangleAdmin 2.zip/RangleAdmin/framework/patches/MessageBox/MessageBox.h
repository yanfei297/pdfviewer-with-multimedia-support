//
//  MessageBox.h
//  TrivPals
//
//  Created by Sayan on 21/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageBox : UIView{
    UILabel *messageLabel;
    BOOL isNavBar;
}
- (id)initWithSuperview:(UIView *)superview hasNavigationBar:(BOOL)navbar;
- (void)showMessage:(NSString *)message;
- (void)hideMessage;
@end
