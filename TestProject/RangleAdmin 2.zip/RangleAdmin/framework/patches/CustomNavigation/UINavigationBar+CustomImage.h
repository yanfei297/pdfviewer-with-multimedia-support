//
//  UINavigationBar+CustomImage.h
//  TrivPals
//
//  Created by Sayan on 11/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


#define r (152.0 / 255.0)
#define g (56.0 / 255.0)
#define b (143.0 / 255.0)

#define NAVBAR_TINT_COLOR  [UIColor colorWithRed:r green:g blue:b alpha:1.0]

@interface UINavigationBar (CustomImage)

@end
