//
//  TreemoGridViewRow.h
//
//  Created by Phil Nelson on 6/16/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "TreemoGridViewItem.h"
#import "TreemoGridViewProtocol.h"

@interface TreemoGridViewRow : UIScrollView {
	
	// Needed for subviewLayout
	TreemoGridView* grid;
	
	NSInteger height;
	NSInteger numItems;

	NSInteger row;
	NSInteger section;
	
	NSInteger itemWidth;
	NSMutableArray* itemList;
	
	BOOL rowVisible;
	
	BOOL layoutComplete;
}

@property (nonatomic, readonly) NSInteger height;  // Should be readonly
@property (nonatomic, readonly) NSInteger numItems;
@property (nonatomic, assign) NSInteger row;
@property (nonatomic, assign) NSInteger section;

-(void) buildRow:(NSInteger) rowIndex inSection:(NSInteger) sectionIndex forGrid:(TreemoGridView*) grid;

-(void) layoutRowForGrid:(TreemoGridView*) grid;

-(void) invisibleRow;

- (TreemoGridViewItem*) viewForItemAtIndexPath:(NSIndexPath *)indexPath;

@end
