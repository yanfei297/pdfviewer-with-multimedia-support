//
//  TreemoGridViewItem.h
//
//  Created by Phil Nelson on 6/22/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TreemoGridViewItem : UIView {
	NSString*  reuseIdentifier;
}

@property (nonatomic,retain) NSString* reuseIdentifier;

- (id)initWithFrame: (CGRect)frame withReuseIdentifier: (NSString*)identifier;

@end
