//
//  TreemoGridViewSection.m
//
//  Created by Phil Nelson on 6/16/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import "TreemoGridView.h"

@implementation TreemoGridViewSection

@synthesize headView;
@synthesize headSize;
@synthesize numberOfRows;
@synthesize height;
@synthesize section;
@synthesize needsBuild;
@synthesize isVisible;

- (id)init {
	if (self = [super init]) {
		headView = nil;	
		rows = nil;
		height = -1;
		section = 0;
		needsBuild = YES;
		isVisible = NO;
		headSize = 0;
	}
	return self;
}

- (id)initWithFrame: (CGRect) Frame
{
	if (self = [super initWithFrame: Frame]) {
		headView = nil;	
		rows = nil;
		height = -1;
		section = 0;
		needsBuild = YES;
		isVisible = NO;
		headSize = 0;
	}
	return self;
}

- (void)dealloc
{
	//NSLog(@"Section Released");
	[rows release];
	[super dealloc];
}

// Prepare for building a section ... gets the heights of the headView and
// every row.  Prepares data storage.  No views are requested or displayed.

-(void) setHeight:(NSInteger) sectionIndex forGrid:(TreemoGridView*) grid
{
	self->section = sectionIndex;
	self->needsBuild = true;
	
	// Get information about the section  --  ask again if already asked.
	if ([[grid delegate] respondsToSelector:@selector(gridView:viewForHeaderInSection:)]) {
		[headView release];
		headView = [[[grid delegate] gridView:grid viewForHeaderInSection:section] retain];
	} else {
		headView = nil;
	}
	if (headView != nil) {
		headSize = height = headView.frame.size.height + grid.rowSeparation;
	} else {
		headSize = height = 0;
	}

	numberOfRows = [[grid delegate] gridView:grid numberOfRowsInSection:section];
	
	unsigned ix2[2];
	ix2[0] = sectionIndex;
	
	for (unsigned row = 0; row < numberOfRows; row++) {
		ix2[1] = row;
		height += [[grid delegate] gridView: grid 
						itemSizeAtIndexPath:[NSIndexPath indexPathWithIndexes:ix2 length: 2]].height
		       + grid.rowSeparation;  
	}
	height -= grid.rowSeparation;  // for last separation that isn't a separator.
	self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, self.frame.size.width, height);
}

-(void) buildSection:(NSInteger) sectionIndex forGrid:(TreemoGridView *) grid
{
	unsigned offset;
	
	// Don't do anything if we don't need to build this section.
	if (!needsBuild)
		return;

	offset = headSize;

	// Make sure we have the correct number of rows
	if (rows == nil) {
		// Allocate the row array
		rows = [[NSMutableArray arrayWithCapacity:numberOfRows] retain];
	}
    if ([rows count] < numberOfRows) {
		for (unsigned i = 0; i < numberOfRows; i++) {
			[rows addObject:[NSNull null]];
		}
	} else {
		// Remove extra rows
		while ([rows count] > numberOfRows) {
			// Need to do anything here?
			[rows removeObjectAtIndex:numberOfRows];
		}
	}
	
	// Build the rows
	
	CGRect newFrame;
	for (unsigned i=0; i < numberOfRows; i++) {
		TreemoGridViewRow * thisRow = [rows objectAtIndex:i];
		if ([NSNull null] == (NSNull*)thisRow) {
			thisRow = [[[TreemoGridViewRow alloc] init] autorelease];
			[rows insertObject:thisRow atIndex:i];
		}
		[thisRow buildRow:i inSection:sectionIndex forGrid:grid];
		newFrame = thisRow.frame;
		newFrame.origin.y = offset;
		thisRow.frame = newFrame;
		offset += thisRow.height + grid.rowSeparation;
	}
	
	// Now build our view
	if (headView != nil) {
		[self addSubview:headView];
	}
	for (unsigned i = 0; i < numberOfRows; i++) {
		[self addSubview:[rows objectAtIndex:i]];
	}
	needsBuild = false;
}

-(void) layoutSectionForGrid:(TreemoGridView*)grid
{
	//NSLog(@"layoutSectionForGrid: section %d\n", self.section);

	self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, grid.frame.size.width, height);
	
	if (self.frame.origin.y + headSize > grid.contentOffset.y-grid.boundarySize
		&& self.frame.origin.y < grid.contentSize.height+grid.frame.size.height+grid.boundarySize) {
		//NSLog(@"Head view visible for section %d.\n", self.section	);
		if (headSize > 0) {
			if (headView == nil) {
				headView = [[[grid delegate] gridView:grid viewForHeaderInSection:section] retain];
				[self addSubview:headView];
			}
			headView.frame = CGRectMake(headView.frame.origin.x, headView.frame.origin.y, grid.frame.size.width, 
										headView.frame.size.height);
			// Make sure this is sent 
			[headView layoutSubviews];
		}
	}
	//NSLog(@"Section: %@",self);
	for (unsigned i = 0; i < numberOfRows; i++) {
		TreemoGridViewRow* thisRow = [rows objectAtIndex:i];
	//	//NSLog(@"	Row #:%d",i);
		if (self.frame.origin.y + thisRow.frame.origin.y + thisRow.height > grid.contentOffset.y-grid.boundarySize
			&& self.frame.origin.y + thisRow.frame.origin.y < grid.contentOffset.y+grid.frame.size.height+grid.boundarySize) {
			[thisRow layoutRowForGrid:grid];
		}
		else 
		{
			[thisRow invisibleRow];
		}
	}
	isVisible = YES;
}

-(void) invisibleSectionForGrid:(TreemoGridView*) grid
{
	//NSLog(@"invisibleForGrid called section %d\n", section);
	if (!isVisible) {
		return;
	}
	if (grid.reuseSectionHeaders && headView != nil) {
		// Reuse head
		//NSLog(@"headview reused. reuseId=%@\n", headView.reuseIdentifier);
		[headView removeFromSuperview];
		[grid enqueueResuableItem:headView];
		headView = nil;
	}
	if (!needsBuild) {
		// release any thing needed ....
		for (unsigned i = 0; i < numberOfRows; i++) {
			[[rows objectAtIndex:i] invisibleRow];
		}
	}
	needsBuild = YES;
	isVisible = NO;
}

- (UIView*) viewForItemAtIndexPath:(NSIndexPath *)indexPath
{
	int ix1 = [indexPath indexAtPosition:1];
	if (ix1 < 0 || ix1 > numberOfRows)
		return nil;
	return [[rows objectAtIndex:ix1] viewForItemAtIndexPath:indexPath];
}

@end
