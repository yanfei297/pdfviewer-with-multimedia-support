//
//  TreemoGridViewProtocol.h
//
//  Created by Phil Nelson on 6/16/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#include "TreemoGridViewItem.h"

@class TreemoGridView;

@protocol TreemoGridViewDelegate<NSObject>

@required

- (NSInteger) gridView: (TreemoGridView*)gridView numberOfRowsInSection:    (NSInteger)     section;

// Section, row for indexPath 
- (NSInteger) gridView: (TreemoGridView*)gridView numberOfItemsAtIndexPath: (NSIndexPath*) indexPath;
- (CGSize)    gridView: (TreemoGridView*)gridView itemSizeAtIndexPath:      (NSIndexPath*) indexPath;

// Section, row, item for indexPath
- (TreemoGridViewItem*) gridView: (TreemoGridView*)gridView viewForItemAtIndexPath:   (NSIndexPath*) indexPath;

@optional

- (TreemoGridViewItem*) gridView: (TreemoGridView*)gridView  viewForHeaderInSection:  (NSInteger) section;

// Default for numberOfSectionsInGridView is 1 if not implemented
- (NSInteger) numberOfSectionsInGridView: (TreemoGridView*)gridView;
    

@end

