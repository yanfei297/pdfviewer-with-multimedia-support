//
//  TreemoGridViewSection.h
//
//  Created by Phil Nelson on 6/16/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TreemoGridViewRow.h"
#import "TreemoGridViewItem.h"
#import "TreemoGridViewProtocol.h"

@interface TreemoGridViewSection : UIView {
	TreemoGridViewItem* headView;
	CGFloat headSize;
	NSInteger numberOfRows;
	NSMutableArray* rows;
	CGFloat height;
	NSInteger section;
	BOOL needsBuild;
	BOOL isVisible;
}

@property(nonatomic,readonly) TreemoGridViewItem* headView;
@property(nonatomic,readonly) CGFloat headSize;
@property(nonatomic,readonly) NSInteger numberOfRows;
@property(nonatomic,readonly) CGFloat height;
@property(nonatomic,readonly) NSInteger section;
@property(nonatomic,readonly) BOOL needsBuild;
@property(nonatomic,readonly) BOOL isVisible;


// Called to set the height of the section and get it ready to build it.
// It sets needsBuild as part of setting the height.

-(void) setHeight:(NSInteger) i forGrid:(TreemoGridView*) grid;

-(void) buildSection:(NSInteger) i forGrid:(TreemoGridView*) grid;

-(void) layoutSectionForGrid:(TreemoGridView*) grid;

-(void) invisibleSectionForGrid:(TreemoGridView*) grid;

- (TreemoGridViewItem*) viewForItemAtIndexPath:(NSIndexPath *)indexPath;

@end
