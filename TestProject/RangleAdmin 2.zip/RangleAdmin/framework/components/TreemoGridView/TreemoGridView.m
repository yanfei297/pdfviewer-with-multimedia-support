//
//  TreemoGridView.m
//
//  Created by Phil Nelson on 6/15/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import "TreemoGridView.h"

@implementation TreemoGridView

@synthesize delegate;
@synthesize numberOfSections;
@synthesize sectionSeparation;
@synthesize rowSeparation;
@synthesize itemSeparation;
@synthesize boundarySize;
@synthesize reuseSectionHeaders;

-(id)init
{
	if ((self = [super init])) {
        // Initialization code
		numberOfSections = 1;
		sectionSeparation = 0;
		rowSeparation = 0;
		itemSeparation = 0;
		boundarySize = 100;
		reuseSectionHeaders = YES;
		dataLoaded = NO;
		gridSections = [[NSMutableArray alloc] init];
		[gridSections addObject:[NSNull null]];
		reuseQueue = [[NSMutableArray alloc] init];
		// Autosizechanging
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	}
	return self;
}

- (id)initWithFrame:(CGRect)frame 
{
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		numberOfSections = 1;
		sectionSeparation = 0;
		rowSeparation = 0;
		itemSeparation = 0;
		boundarySize = 100;
		reuseSectionHeaders = YES;
		dataLoaded = NO;
		gridSections = [[NSMutableArray alloc] init];
		[gridSections addObject:[NSNull null]];
		reuseQueue = [[NSMutableArray alloc] init];
		// Autosizechanging
		self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
    }
    return self;
}

- (void)dealloc 
{
	[reuseQueue release]; 
	[gridSections release];
	//NSLog(@"GridView Released<<<<<<<<<<<<<<<<<<");
	[super dealloc];
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect 
{
    // Drawing code
}
*/


// Used for initial loading of data or any reload of the full grid.
- (void)loadData	
{
	//NSLog(@"GridView loadData called.\n");
	// Get number of sections
	if ([self.delegate respondsToSelector:@selector(numberOfSectionsInGridView:)]) {
		numberOfSections = [self.delegate numberOfSectionsInGridView:self];
	} else {
		numberOfSections = 1;
	}

	// Adjust array to proper size
	unsigned gridSize = [gridSections count];
	if (gridSize < numberOfSections) {
		for (unsigned i = gridSize; i < numberOfSections; i++) {
			[gridSections addObject:[NSNull	null]];
		}
	} else {
		for (unsigned i = gridSize; i > numberOfSections; i--) {
			[gridSections removeObjectAtIndex:i-1];
		}
	}

	// Load Data for each section ... we will never release a section, just rows and items
	NSInteger totalHeight = 0;
	for (unsigned i=0; i < numberOfSections; i++) {
		TreemoGridViewSection* thisSection = [gridSections objectAtIndex:i];
		if ((NSNull*)thisSection == [NSNull null]) {
			thisSection = [[[TreemoGridViewSection alloc] initWithFrame:CGRectMake(0, totalHeight, self.frame.size.width, 20)] autorelease] ; //autorelease] ;
			[gridSections replaceObjectAtIndex:i withObject:thisSection];
		}

		[thisSection setHeight: i forGrid:self];
		totalHeight += thisSection.height + sectionSeparation;
	}
	// Remove last separation size
	totalHeight -= sectionSeparation;
	
	// Set properties of UIScrollView self.
	self.contentSize = CGSizeMake(self.frame.size.width, totalHeight);
	self.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
	for (unsigned i=0; i < numberOfSections; i++) {
		[self addSubview: [gridSections objectAtIndex:i]];
	}
	self.scrollEnabled = YES;
	
	// Build the visible part of the scroll view
	for (unsigned i = 0; i < numberOfSections; i++) {
		TreemoGridViewSection* thisSection = [gridSections objectAtIndex:i];
			  
		if ([thisSection frame].origin.y + thisSection.height > self.contentOffset.y - boundarySize
			&& [thisSection frame].origin.y < self.contentOffset.y + self.frame.size.height + boundarySize) {
			//NSLog(@"loadData: Calling [thisSection buildSection: %d forGrid:self]\n", i);
			[thisSection buildSection: i forGrid:self];
		}
	}
	
	dataLoaded = YES;
}

- (void) reloadData
{
	// Get rid of current views ...
	if (dataLoaded) {
		for (unsigned i=0; i < numberOfSections; i++) {
			[[gridSections objectAtIndex:i] invisibleSectionForGrid:self];
		}
	}
	// Reload it
	[self loadData];
}

// Used by the delegate to acquire an already allocated view, in lieu of allocating a new one.
- (TreemoGridViewItem*)dequeueReusableItemWithIdentifier:(NSString*)identifier
{
	for (unsigned i = 0; i < [reuseQueue count]; i++) {
		TreemoGridViewItem* item;
		item = [reuseQueue objectAtIndex:i];
		if ([[item reuseIdentifier] compare: identifier] == NSOrderedSame) {
			[reuseQueue removeObjectAtIndex:i];
			return item;
		}
	}
	return nil;
}

- (void) enqueueResuableItem: (TreemoGridViewItem*) item
{
	[reuseQueue addObject:item];
	//NSLog(@"enqueueResuableItem id=%@, count is %d\n", item.reuseIdentifier, [reuseQueue count]);
}

- (void) clearReuseQueue 
{ 
	[reuseQueue removeAllObjects];
}

// Acessing 
- (UIView*) viewForItemAtIndexPath:(NSIndexPath *)indexPath
{
	if (indexPath.length != 3)
		return nil;
	int ix0 = [indexPath indexAtPosition:0];
	if (ix0 < 0 || ix0 >= numberOfSections)
		return nil;
	return [[gridSections objectAtIndex:ix0] viewForItemAtIndexPath:indexPath];
}

- (void) layoutSubviews
{
	//NSLog(@"Layout Subviews: %@", NSStringFromCGRect(self.frame));
	
	if (!dataLoaded)
		return;
	
	for (unsigned i=0; i < numberOfSections; i++) {
		TreemoGridViewSection* thisSection = [gridSections objectAtIndex:i];

		if (thisSection.frame.origin.y + thisSection.height > self.contentOffset.y - boundarySize
			&& thisSection.frame.origin.y < self.contentOffset.y + self.frame.size.height +boundarySize ) {

			// In the visible section
			if (thisSection.needsBuild) {
				//NSLog(@"Calling [thisSection buildSection: %d forGrid:self]\n", i);
				[thisSection buildSection: i forGrid:self];
			}
			[thisSection layoutSectionForGrid:self];

		} else {
			[thisSection invisibleSectionForGrid:self];
		}
	}
}

@end
