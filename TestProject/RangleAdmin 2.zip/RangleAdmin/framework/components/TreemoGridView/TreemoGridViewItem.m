//
//  TreemoGridViewItem.m
//
//  Created by Phil Nelson on 6/22/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import "TreemoGridViewItem.h"

@implementation TreemoGridViewItem

@synthesize reuseIdentifier;

- (id)initWithFrame: (CGRect)frame withReuseIdentifier: (NSString*)identifier {
	//NSLog(@"GridViewItem initWithFrame:withResueIdentifier %@\n", identifier);
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		reuseIdentifier = identifier;
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame  {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
		reuseIdentifier = nil;
    }
    return self;
}

- (void) layoutSubviews
{
	[super layoutSubviews];
	//NSLog(@"Layout Subviews invoked");
}

- (void)dealloc {
    [super dealloc];
}


@end
