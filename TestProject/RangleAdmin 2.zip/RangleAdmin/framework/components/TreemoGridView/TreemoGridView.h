//
//  TreemoGridView.h
//
//  Created by Phil Nelson on 6/15/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TreemoGridViewSection.h"
#import "TreemoGridViewRow.h"
#import "TreemoGridViewItem.h"
#import "TreemoGridViewProtocol.h"

@interface TreemoGridView : UIScrollView {
	
	id <TreemoGridViewDelegate> delegate;
	NSMutableArray* gridSections;
	
	NSInteger numberOfSections;
	
	// properties to control the grid view
	NSInteger sectionSeparation;
	NSInteger rowSeparation;
	NSInteger itemSeparation;

	// number of pixels around the grid to have views loaded, default 100
	NSInteger boundarySize;
	BOOL reuseSectionHeaders;
	
	// Reuse Queue
	NSMutableArray* reuseQueue;
	
	// Protection from layoutSubviews
	BOOL dataLoaded;
}

@property(nonatomic,assign) id <TreemoGridViewDelegate> delegate;
@property(nonatomic,readonly) NSInteger numberOfSections;


// Separation of items in points -- must be set before calling loadData to 
@property(nonatomic,assign) NSInteger sectionSeparation;
@property(nonatomic,assign) NSInteger rowSeparation;
@property(nonatomic,assign) NSInteger itemSeparation;
@property(nonatomic,assign) NSInteger boundarySize;
@property(nonatomic,assign) BOOL reuseSectionHeaders;

// Called to do initial load of data and to reload data
- (void)loadData;
- (void)reloadData;

// Used by the delegate to acquire an already allocated view, in lieu of allocating a new one.
- (TreemoGridViewItem*)dequeueReusableItemWithIdentifier: (NSString*)identifier;

// Acessing 
- (UIView*) viewForItemAtIndexPath: (NSIndexPath*)indexPath;

// Should be private ...

- (void) enqueueResuableItem: (TreemoGridViewItem*) item;
- (void) clearReuseQueue;

@end


