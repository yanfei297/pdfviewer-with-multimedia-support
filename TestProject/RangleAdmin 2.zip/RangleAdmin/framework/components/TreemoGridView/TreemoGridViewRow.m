//
//  TreemoGridViewRow.m
//
//  Created by Phil Nelson on 6/16/10.
//  Copyright 2010 Treemo Labs Inc. All rights reserved.
//

#import "TreemoGridView.h"

@implementation TreemoGridViewRow

@synthesize height;
@synthesize numItems;
@synthesize row;
@synthesize section;

- (id) init
{
	self = [super init];
    height = 0;
	numItems = 0;
	itemList = nil;
	rowVisible = NO;
	return self;
}

- (void) dealloc
{
	[itemList release];
	[super dealloc];
}

-(void) buildRow:(NSInteger) rowIndex inSection:(NSInteger) sectionIndex  forGrid:(TreemoGridView *)Grid
{
	NSUInteger ix3[3];
	CGSize rowItemSize;
	section = ix3[0] = sectionIndex;
	row = ix3[1] = rowIndex;
	grid = Grid;

	numItems = [[grid delegate] gridView: grid
				      numberOfItemsAtIndexPath: [NSIndexPath indexPathWithIndexes: ix3 length: 2]];
	rowItemSize = [[grid delegate] gridView: grid 
						 itemSizeAtIndexPath: [NSIndexPath indexPathWithIndexes: ix3 length: 2]];
	height = rowItemSize.height;
	itemWidth = rowItemSize.width;
	
	if (itemList == nil) {
		itemList = [[NSMutableArray arrayWithCapacity:numItems] retain];
	}
	if ([itemList count] < numItems) {
		for (unsigned i = 0; i < numItems; i++) {
			// XXX clean up these items?
			[itemList addObject:[NSNull null]];
		}
	} else {
		// Remove extra rows
		while ([itemList count] > numItems) {
			// XXX Do something?
			[itemList removeObjectAtIndex:numItems];
		}
	}
	
	self.frame = CGRectMake(0,0,[grid frame].size.width, height);
	self.contentSize = CGSizeMake((itemWidth+grid.itemSeparation)*numItems-grid.itemSeparation, height);
	self.autoresizingMask = UIViewAutoresizingFlexibleWidth;
	
	//NSLog(@"Build Row: Frame [%.0f,%.0f,%.0f,%.0f], CS [%.0f,%.0f] section: %d,%d\n", self.frame.origin.x, self.frame.origin.y,
	//	  self.frame.size.width, self.frame.size.height, self.contentSize.width, self.contentSize.height, sectionIndex, rowIndex);
}

-(void) layoutRowForGrid:(TreemoGridView*)Grid
{
	
	//NSLog(@"layoutRowForGrid: section %d, row %d visible\n", section, row);

	// Set the current frame size.
	self.frame = CGRectMake(self.frame.origin.x, self.frame.origin.y, Grid.frame.size.width, self.frame.size.height);
//	//NSLog(@"		Row Frame: %@",NSStringFromCGRect(self.frame));
	rowVisible = YES;
	[self layoutSubviews];
	//NSLog(@"Layout subviews");
}

-(void) layoutSubviews
{
	NSUInteger ix3[3];
	TreemoGridViewItem* itemView;
	
	//NSLog(@"GridViewRow: layoutSubviews: rowVisible = %@\n", (rowVisible?@"Yes":@"No"));
	if (!rowVisible)
		return;
	
	ix3[0] = section;
	ix3[1] = row;
	
	for (unsigned i = 0; i < numItems; i++) {
		ix3[2] = i;
		itemView = [itemList objectAtIndex:i];
		if ((itemWidth+grid.itemSeparation)*i > self.contentOffset.x - grid.boundarySize 
			&& (itemWidth+grid.itemSeparation)*(i+1) < self.contentOffset.x + self.frame.size.width + grid.boundarySize) {
			if ((NSNull*)itemView == [NSNull null]) {
				//NSLog(@"Populating item at section %d, row %d, item %d\n", section, row, i);
				itemView = [[grid delegate] gridView: grid
							  viewForItemAtIndexPath: [NSIndexPath indexPathWithIndexes: ix3 length: 3]];
				itemView.frame = CGRectMake((itemWidth+grid.itemSeparation)*i, 0, itemWidth, height);
				[itemList replaceObjectAtIndex:i withObject:itemView];
				[self addSubview:itemView];
			}
		} else {
			// Item is not visible
			if ((NSNull *)itemView != [NSNull null]) {
				// put on reuse queue
				//NSLog(@"Removing item at  section %d, row %d, item %d\n", section, row, i);
				[itemView removeFromSuperview];
				[grid enqueueResuableItem:itemView];
				[itemList replaceObjectAtIndex: i withObject: [NSNull null]];
			}
		}
	}
	
}

-(void) invisibleRow
{
	TreemoGridViewItem* itemView;
	if (!rowVisible)
		return;
	//NSLog(@"invisibleRow: row %d, section %d\n", row, section);
	for (unsigned i=0; i < numItems; i++) {
		itemView = [itemList objectAtIndex:i];		
		if ((NSNull *)itemView != [NSNull null]) {
			// put on reuse queue
			[itemView removeFromSuperview];
			[grid enqueueResuableItem:itemView];
			[itemList replaceObjectAtIndex: i withObject: [NSNull null]];
		}
	}
	rowVisible = NO;
}

- (UIView*) viewForItemAtIndexPath:(NSIndexPath *)indexPath
{
	int ix2 = [indexPath indexAtPosition:2];
	if (ix2 < 0 || ix2 >= numItems)
		return nil;
	return [itemList objectAtIndex:ix2];
}

@end
