//
//  TreemoSegmentControl.h
//  Qwiket
//
//  Created by steve on 8/20/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "fontnames.h"

typedef enum {
	TreemoTabControlTabLeft,
    TreemoTabControlTabRight,
} TreemoTabControlTab;

@interface TreemoTabControl : UIView 
{
	UIImageView* leftSideSelected;
	UIImageView* leftSide;
	UIImageView* rightSide;
	UIImageView* rightSideSelected;
	UIImageView* background;
	UIImageView* seperator; //optional
	
	UILabel* leftLabel;
	UILabel* rightLabel;
	
	//CGRect frame;
	TreemoTabControlTab selectedTab;
	NSInteger split_point;
	
	id actionTarget;
	SEL onSelectLeft;
	SEL onSelectRight;
	
	UIColor* selectedTextColor;
	UIColor* normalTextColor;
}

- (id) init;

- (id) initWithFrame:(CGRect)frame
		   leftImage:(UIImageView*)leftImage
		  rightImage:(UIImageView*)rightImage
   leftImageSelected:(UIImageView*)leftImageSelected
  rightImageSelected:(UIImageView*)rightImageSelected;

//::Public

@property(assign) TreemoTabControlTab selectedTab;

@property(assign) id actionTarget; 
@property(assign) SEL onSelectLeft;   // - (void) onTapLeft;
@property(assign) SEL onSelectRight;  // - (void) onTapRight;

@property(assign) NSString* leftLabelText;
@property(assign) NSString* rightLabelText;
@property(assign) UILabel* leftLabel;
@property(assign) UILabel* rightLabel;
@property (retain) UIColor* selectedTextColor;
@property (retain) UIColor* normalTextColor;

//::Private
- (void) onSelectRightTab;
- (void) onSelectLeftTab;

@end
