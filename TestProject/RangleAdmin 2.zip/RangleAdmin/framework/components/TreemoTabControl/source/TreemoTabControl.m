//
//  TreemoSegmentControl.m
//  Qwiket
//
//  Created by steve on 8/20/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "TreemoTabControl.h"


@implementation TreemoTabControl
@synthesize actionTarget, onSelectLeft, onSelectRight, selectedTextColor, normalTextColor;
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
    }
    return self;
}

- (id) init
{
	self.clipsToBounds = YES;
	leftSideSelected = [Utils imageViewWithImageName:@"left-button-press.png"];
	rightSide = [Utils imageViewWithImageName:@"rigt-button-off.png"];
	rightSideSelected = [Utils imageViewWithImageName:@"right-button-press.png"];
	leftSide = [Utils imageViewWithImageName:@"leftbutton-off.png"]; 
	background = [Utils imageViewWithImageName:@"button-bg.png"];
	[Utils view:leftSide setX:5 setY:0];
	[Utils view:leftSideSelected setX:5 setY:0];
	[Utils view:rightSide setX:(leftSide.frame.origin.x + 155) setY:0];
	[Utils view:rightSideSelected setX:(leftSide.frame.origin.x + 155) setY:0];
	//////NSLog(@"Initilaizing TreemoSegmentControl");
	//////NSLog(@"Background information: %@",background);
	if(self = [self initWithFrame:CGRectMake(0, 0, background.frame.size.width, background.frame.size.height)])
	{
		[self addSubview:background];
		[self addSubview:leftSideSelected];
		[self addSubview:rightSide];
		[self addSubview:leftSide];
		[self addSubview:rightSideSelected];
		rightSideSelected.hidden = YES;
		leftSide.hidden = YES;
		
		selectedTab = TreemoTabControlTabLeft; 
		split_point = self.frame.size.width/2;
		
		self.selectedTextColor = [UIColor blackColor];
		self.normalTextColor = [UIColor whiteColor];
		leftLabel = [Utils labelWithFrame:CGRectMake(15, 0, 130, 30)
									 text:@"" 
								textColor:selectedTextColor 
								 fontName:FONTNAME_helveticaBold 
								 fontSize:14 
									 bold:NO];
		leftLabel.textAlignment = UITextAlignmentCenter;
		rightLabel = [Utils labelWithFrame:CGRectMake(170, 0, 130, 30)
									  text:@"" 
								 textColor:normalTextColor 
								  fontName:FONTNAME_helveticaBold 
								  fontSize:14 
									  bold:NO];
		rightLabel.textAlignment = UITextAlignmentCenter;
		[self addSubview:leftLabel];
		[self addSubview:rightLabel];
	}
	return self;
}
- (id) initWithFrame:(CGRect)frame
			 leftImage:(UIImageView*)leftImage
			rightImage:(UIImageView*)rightImage
	 leftImageSelected:(UIImageView*)leftImageSelected
	rightImageSelected:(UIImageView*)rightImageSelected
{
	if(self = [self initWithFrame:frame])
	{
		leftSideSelected = [leftImageSelected retain];
		leftSide = [leftImage retain];
		rightSide = [rightImage retain];
		rightSideSelected = [rightImageSelected retain];
		[self addSubview:leftSideSelected];
		[self addSubview:rightSide];
		[self addSubview:leftSide];
		[self addSubview:rightSideSelected];
		[Utils view:rightSide setX:leftSideSelected.frame.size.width + leftSideSelected.frame.origin.x];
		[Utils view:rightSideSelected setX:leftSide.frame.size.width + leftSide.frame.origin.x];
		rightSideSelected.hidden = YES;
		leftSide.hidden = YES;

		selectedTab = TreemoTabControlTabLeft; 
		split_point = self.frame.size.width/2;

	}
	return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}



- (NSInteger) selectedTab
{
	return selectedTab;
}
- (void) setSelectedTab:(TreemoTabControlTab)tab
{
	if(selectedTab == tab)
	{
		return;
	}
	else
	{
		
		//[apirh.target performSelector:apirh.failure withObject:error_msg];
		selectedTab = tab;
		
		if(selectedTab == TreemoTabControlTabLeft)
		{
			[self onSelectLeftTab];
		}
		else
		{
			[self onSelectRightTab];
		}
	}
	
	
}
- (UILabel*) leftLabel
{
	return leftLabel;
}
-(UILabel*) rightLabel
{
	return rightLabel;
}
- (void) setLeftLabel:(UILabel *)_label
{
	leftLabel = _label;
	[self addSubview:leftLabel];
}
- (void) setRightLabel:(UILabel *)_label
{
	rightLabel = _label;
	[self addSubview:rightLabel];
}
- (void) setLeftLabelText:(NSString*)str
{
	leftLabel.text = str;
}

- (NSString*)leftLabelText
{
	return leftLabel.text;
}

- (void) setRightLabelText:(NSString*)str
{
	rightLabel.text = str;
}
- (NSString*)rightLabelText
{
	return rightLabel.text;
}

- (void) onSelectRightTab
{
	[self selectRight];
	[actionTarget performSelector:onSelectRight];
}

- (void) onSelectLeftTab
{
	[self selectLeft];
	[actionTarget performSelector:onSelectLeft];
	
}

- (void) selectRight
{
	rightSideSelected.hidden = NO;
	rightSide.hidden = YES;
	leftSide.hidden = NO;
	leftSideSelected.hidden = YES;
	leftLabel.textColor = normalTextColor;
	rightLabel.textColor = selectedTextColor;
}

- (void) selectLeft
{
	

	leftSideSelected.hidden = NO;
	leftSide.hidden = YES;
	rightSide.hidden = NO;
	rightSideSelected.hidden = YES;
	
	leftLabel.textColor = selectedTextColor;
	rightLabel.textColor = normalTextColor;
}


- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	UITouch* touch = [touches anyObject];
	CGPoint location = [touch locationInView:self];
	[super touchesBegan:touches	withEvent:event];
	self.selectedTab = ((location.x > split_point)? TreemoTabControlTabRight : TreemoTabControlTabLeft); 
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesMoved:touches withEvent:event];
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesEnded:touches withEvent:event];
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesCancelled:touches withEvent:event];
}


- (void)dealloc 
{
	[leftSideSelected release];
	[leftSide release];
	[rightSide release];
	[rightSideSelected release];

	
	[selectedTextColor release];
	[normalTextColor release];	
	
    [super dealloc];
}





@end

