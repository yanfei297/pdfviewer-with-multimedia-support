//
//  CustomSwitch.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 7/6/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "CustomSwitch.h"


@implementation CustomSwitch

- (_SwitchSlider *) slider
{ 
	return [[self subviews] lastObject]; 
}

- (UIView *) textHolder 
{ 
	return [[[self slider] subviews] objectAtIndex:2]; 
}

- (UILabel *) leftLabel 
{ 
	return [[[self textHolder] subviews] objectAtIndex:0]; 
}

- (UILabel *) rightLabel 
{ 
	return [[[self textHolder] subviews] objectAtIndex:1]; 
}

- (void) setLeftLabelText: (NSString *) labelText 
{ 
	[[self leftLabel] setText:labelText]; 
}

- (void) setRightLabelText: (NSString *) labelText 
{ 
	[[self rightLabel] setText:labelText]; 
}
@end
