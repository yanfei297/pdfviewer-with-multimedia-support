

#import <UIKit/UIKit.h>
#import "CarouselMenuItem.h"

@interface CarouselMenuTray : UIScrollView <UIScrollViewDelegate>
{
	BOOL dragBegan;
	UIImageView* trackView;
	NSMutableArray* menuItems;
	NSMutableDictionary* menuItemByLabel;
	
	float nextItemX;
	float whiteSpaceWidth;
	float itemOffsetY;
	
	id actionTarget;
	SEL onSelectMenuItem;

}


//::Public
@property(assign) id actionTarget;

@property(assign) SEL onSelectMenuItem; // - (void) onSelectMenuItem:(MenuItem*)mi;

- (void) addMenuItem:(CarouselMenuItem*)menuItem;

- (CarouselMenuItem*) itemForLabel:(NSString*)labelText;
- (void) deselectAll;
- (void) pageBackward;
- (void) pageForward;

@property (assign) BOOL backEnabled;
@property (assign) BOOL forwardEnabled;

- (void) selectMenuItem:(CarouselMenuItem*)mi;
//::Private
- (void) _selectMenuItem:(CarouselMenuItem*)mi;
- (void) selectItem:(CarouselMenuItem*)mi;
@end
