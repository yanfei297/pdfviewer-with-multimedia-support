

#import "CarouselMenuItem.h"



@implementation CarouselMenuItem


- (id)initWithFrame:(CGRect)frame 
{
	if (self = [super initWithFrame:frame]) 
	{
		self.backgroundColor = [UIColor clearColor];
	}
	return self;
}

-(id)initWithLabel:(NSString*)labelText extra:(id)extraObj
{	
	return [self initWithLabel:labelText
				backgroundName:@"carousel_selected.png"
							 x:0
							 y:0
						  font:[UIFont fontWithName:FONTNAME_helveticaBold size:12]
				  labelOffsetX:10
				  labelOffsetY:6 // should not be less than 1 
			 backgroundOffsetY:-5
						 extra:extraObj];
}

-(id)initWithLabel:(NSString*)labelText
	backgroundName:(NSString*)selectedBackgroundImageName
				 x:(int)x
				 y:(int)y
			  font:(UIFont*)f 
	  labelOffsetX:(float)labelOffsetX
	  labelOffsetY:(float)labelOffsetY
 backgroundOffsetY:(float)backgroundOffsetY
			 extra:(id)extraObj
{	
	labelLeftOffset = labelOffsetX;
	labelTopOffset = labelOffsetY;
	selectedBackgroundEdgeExtent = labelLeftOffset * 2;
	selectedBackgroundTopOffset  = backgroundOffsetY + 6;
	
	CGSize textSize = [labelText sizeWithFont:f];
	[self initWithFrame:CGRectMake(x, y, textSize.width + labelLeftOffset * 2, textSize.height + labelTopOffset * 2)];
	
	// Image could be a static variable
	//////////NSLog(@"CarouselMenuItem created with textSize (%f, %f) with font %@", textSize.width, textSize.height, label.font);

	UIImage* temp_img = [Utils imageViewWithImageName:selectedBackgroundImageName].image;
	// background images must have an odd number of pixels
	// 2*capwidth + 1 center line so we take the floor by stuffing width/2 in an int
	int widthFloor = temp_img.size.width/2; 
	
	UIImage* selectedBackground_img = [temp_img stretchableImageWithLeftCapWidth:(float)widthFloor topCapHeight:0];
	
	selectedBackground = [[UIImageView alloc] initWithImage:selectedBackground_img];
	selectedBackground.frame = CGRectMake(0, selectedBackgroundTopOffset, 
										  textSize.width + selectedBackgroundEdgeExtent, 
										  selectedBackground_img.size.height);
	
	
	
	NSString* selectedOvergroundImageNameOrNil = @"carousel_spinner-highlight.png";
	/*
	if(selectedOvergroundImageNameOrNil)
	{
		NSString* selectedOvergroundImageName = selectedOvergroundImageNameOrNil;
		UIImage* temp_img =  [UIImage imageNamed:selectedOvergroundImageName];
		UIImage* selectedOverground_img = [temp_img stretchableImageWithLeftCapWidth:1 topCapHeight:0];
		selectedOverground = [[UIImageView alloc] initWithImage:selectedOverground_img];
		selectedOverground.frame = CGRectMake(3, selectedBackgroundTopOffset, 
											   textSize.width + selectedBackgroundEdgeExtent - 6, 
											   selectedOverground_img.size.height);
	}
	 */
	
	label = [[UILabel alloc] initWithFrame:CGRectMake(labelLeftOffset, 
													  labelTopOffset, 
													  textSize.width, 
												  textSize.height)];
	label.textColor = [UIColor whiteColor];
	
	
	UIImageView* separator = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"carousel_spinner-seperator.png"]] autorelease];
	separator.frame = CGRectMake(self.frame.size.width + 4, labelOffsetY, separator.frame.size.width, separator.frame.size.height);
	[self addSubview:separator];
	label.font = f;
	//label.textColor = [UIColor whiteColor];
	label.backgroundColor = [UIColor clearColor];
	[self addSubview:label];
	label.text =  labelText;
	label.textAlignment = UITextAlignmentCenter;
	extra = [extraObj retain];
	
	return self;
}

@synthesize extra;

- (NSString*) labelText
{
	return [label text];
}
- (void) setSelected:(BOOL)value
{
	if(value)
	{
		label.textColor = [Utils colorFromHex:CAROUSEL_TEXT_SELECTED];
		[self insertSubview:selectedBackground belowSubview:label];
		if(selectedOverground)
		{
			//////////NSLog(@"Inserted Selected Overground");
			[self insertSubview:selectedOverground aboveSubview:label];
		}
		else
		{
			////////NSLog(@"Failed to insert selected overground");
		}
	}
	else
	{
		label.textColor = [Utils colorFromHex:CAROUSEL_TEXT_UNSELECTED];
		[selectedBackground removeFromSuperview];
		[selectedOverground removeFromSuperview];
	}
}

- (float)width
{
	return self.frame.size.width;
}
- (float)height
{
	return self.frame.size.height;
}

-(float)x
{
	return self.frame.origin.x;
}
-(void) setX:(float)x
{
	self.frame = CGRectMake(x, self.frame.origin.y,  self.frame.size.width, self.frame.size.height);
}

-(float)y
{
	return self.frame.origin.y;
}
-(void) setY:(float)y
{
	self.frame = CGRectMake(self.frame.origin.x, y, self.frame.size.width, self.frame.size.height);
}

- (void)drawRect:(CGRect)rect
{
	// Drawing code
}
- (void)dealloc 
{
	[extra release];
	[super dealloc];
}


@end
