

#import <UIKit/UIKit.h>
#import "CategoryItem.h"
#import "constants.h"
#import "fontnames.h"
#import "Utils.h"

#define INTERACTIVE_AREA_OFFSET_Y 0

#ifndef CAROUSEL_TEXT_SELECTED
#define CAROUSEL_TEXT_SELECTED 0xFFFFFF
#endif

#ifndef CAROUSEL_TEXT_UNSELECTED
#define CAROUSEL_TEXT_UNSELECTED 0x606270
#endif

#ifndef CAROUSEL_LEFT
#define CAROUSEL_LEFT @"carousel_left-arrow.png"
#define CAROUSEL_RIGHT @"carousel_right-arrow.png"
#endif

@interface CarouselMenuItem : UIView 
{	
	UILabel* label;
	
	UIImageView* selectedBackground;
	UIImageView* selectedOverground;
	//Make this setable when needed
	float labelTopOffset;
	float labelLeftOffset;
	float selectedBackgroundEdgeExtent;
	float selectedBackgroundTopOffset;
	id extra;
}

//::Public
- (id) initWithLabel:(NSString*)labelText extra:(id)extra;

-(id)initWithLabel:(NSString*)labelText
	backgroundName:(NSString*)selectedBackgroundImageName
				 x:(int)x
				 y:(int)y
			  font:(UIFont*)f 
	  labelOffsetX:(float)labelOffsetX
	  labelOffsetY:(float)labelOffsetY
 backgroundOffsetY:(float)backgroundOffsetY
			 extra:(id)extraObj;

- (void) setSelected:(BOOL)value;

@property (readonly) float width;
@property (readonly) float height;
@property (readonly) NSString* labelText;
@property (assign) float x;
@property (assign) float y;
@property (retain) id extra;


//::Private



@end