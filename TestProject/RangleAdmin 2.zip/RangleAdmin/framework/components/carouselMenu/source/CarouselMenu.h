

#import <UIKit/UIKit.h>

#import "CarouselMenuTray.h"
#import "Utils.h"
#import "CarouselMenuItem.h"
@interface CarouselMenu : UIControl <UIScrollViewDelegate> 
{
	CarouselMenuTray* tray;
	BOOL fixedMode;
	BOOL backEnabled;
	BOOL forwardEnabled;
	
	UIImageView* backward;
	UIImageView* forward;
	
	
	id actionTarget;
	SEL onSelectMenuItem;
	

}

//::Public
@property(assign) id  actionTarget;
@property(assign) SEL onSelectMenuItem; // - (void) onSelectMenuItem:(CarouselMenuItem*)mi;

@property (assign) BOOL backEnabled;
@property (assign) BOOL forwardEnabled;
@property (assign) BOOL fixedMode;

- (void) addMenuItem:(CarouselMenuItem*)menuItem;
- (CarouselMenuItem*) itemForLabel:(NSString*)labelText;
- (CarouselMenuItem*) selectMenuItemWithLabel:(NSString*)labelText;
- (void) deselectAll;



//::Private
- (void) onScrollUpdate;

@end
