#import "CarouselMenu.h"
#define BUTTON_OFFSET_Y 5



@implementation CarouselMenu
@synthesize actionTarget, onSelectMenuItem;

- (id) init
{
	return [self initWithFrame:CGRectMake(0, 0, 320, 35)];
}
- (id)initWithFrame:(CGRect)frame 
{
	if (self = [super initWithFrame:frame]) 
	{
		self.backgroundColor = [UIColor clearColor];
		UIImageView* backgroundView = [Utils imageViewWithImageName:@""];
		[self addSubview:backgroundView];

		tray = [[CarouselMenuTray alloc] initWithFrame:CGRectMake(5, 0, 310, 41)];
		tray.actionTarget = self;
		tray.bounces = NO;
		tray.onSelectMenuItem = @selector(onSelectMenuItem:);
		tray.delegate = self;
		[self addSubview:tray];
		
		forward = [Utils imageViewWithImageName:CAROUSEL_RIGHT x:245 y:1];
		
		[self addSubview:forward];
		
		backward = [Utils imageViewWithImageName:CAROUSEL_LEFT x:0 y:1];
		[self addSubview:backward];
		[backward setHidden:YES];
		[self addSubview:[Utils imageViewWithImageName:@"carousel_spinner-highlight.png" x:0 y:0]];
	}
	
	return self;
}

/////////////////////////////// Back Forward Buttons Visiblity Handlers
/*
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	if(!decelerate)
	{
		[self onScrollStop];
	}
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
	[self onScrollStop];
}
*/

- (void) setFixedMode:(BOOL)value
{
	fixedMode = value;
	[backward setHidden:YES];
	[forward setHidden:YES];
	tray.scrollEnabled = NO;
}

- (BOOL) fixedMode
{
	return fixedMode;
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	[self onScrollUpdate];
}


- (void)onScrollUpdate
{
	float trayContentWidth = tray.contentSize.width;
	float trayContentX = tray.contentOffset.x;
	float trayWidth = tray.frame.size.width;
	//////////NSLog(@"View did scroll");
	
	if(trayContentX == 0)
	{
		self.backEnabled = NO;
	}
	else
	{
		self.backEnabled = YES;
	}
	
	if( trayContentX == (trayContentWidth - trayWidth) )
	{
		self.forwardEnabled = NO;
	}
	else
	{
		self.forwardEnabled = YES;
	}
	
}


- (void) setBackEnabled:(BOOL)value
{
	if(value == backEnabled) return;
	////////NSLog(@"Back enabled");
	backEnabled = value;
	[backward setHidden:!backEnabled];
	/*
	 
	 if(value)
	 {
	 backDisabled.hidden = YES;
	 back_btn.hidden = NO;
	 }
	 else
	 {
	 backDisabled.hidden = NO;
	 back_btn.hidden = YES;
	 }
	 */
}

- (BOOL) backEnabled
{
	return backEnabled;
}


- (void) setForwardEnabled:(BOOL)value
{
	
	if(value == forwardEnabled) return;
	////////NSLog(@"Forward enabled");
	
	 forwardEnabled = value;
	[forward setHidden:!forwardEnabled];
	/*
	if(value)
	 {
	 //forwardDisabled.hidden = YES;
	 //forward_btn.hidden = NO;
	 }
	 else
	 {
	 //forwardDisabled.hidden = NO;
	 //forward_btn.hidden = YES;
	 }
	 */
	
}

- (BOOL) forwardEnabled
{
	return forwardEnabled;
}
////////////////////////////////*/

- (void) onSelectMenuItem:(CarouselMenuItem*)mi
{
	[actionTarget performSelector:onSelectMenuItem withObject:mi];
}

- (CarouselMenuItem*) selectMenuItemWithLabel:(NSString*)labelText
{
	CarouselMenuItem* mi = [tray itemForLabel:labelText];
	//////NSLog(@"Found item %@ for label %@", mi, labelText);
	[tray selectMenuItem:mi];
	return mi;
}

- (void) deselectAll
{
	[tray deselectAll];
}

- (void) addMenuItem:(CarouselMenuItem*)menuItem
{
	[tray addMenuItem:menuItem];
	[menuItem setSelected:NO];
}

- (CarouselMenuItem*) itemForLabel:(NSString*)labelText
{
	return [tray itemForLabel:labelText];
}


- (void)drawRect:(CGRect)rect {
	// Drawing code
}


- (void)dealloc {
	[super dealloc];
}


@end
