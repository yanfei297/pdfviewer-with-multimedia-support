//
//  GlideMenu.h
//  GlideMenu
//
//  Create by Andrew Paul Simmons on 10/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GlideMenuTray.h"
#import "Utils.h"
#import "MenuItem.h"
@interface GlideMenu : UIControl <UIScrollViewDelegate> 
{
	GlideMenuTray* tray;
	
	BOOL backEnabled;
	BOOL forwardEnabled;
	
	UIButton* back_btn;
	UIButton* forward_btn;
	
	UIImageView* forwardDisabled;
	UIImageView* backDisabled;
	
	id actionTarget;
	SEL onSelectMenuItem;
}

//::Public
@property(assign) id  actionTarget;
@property(assign) SEL onSelectMenuItem; // - (void) onSelectMenuItem:(MenuItem*)mi;

@property (assign) BOOL backEnabled;
@property (assign) BOOL forwardEnabled;
- (void) addMenuItem:(MenuItem*)menuItem;
- (MenuItem*) itemForLabel:(NSString*)labelText;
- (void) selectMenuItemWithLabel:(NSString*)labelText;
- (void) deselectAll;
//::Private

@end
