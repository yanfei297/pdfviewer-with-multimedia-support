//
//  GlideMenuView.h
//  GlideMenu
//
//  Create by Andrew Paul Simmons on 10/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MenuItem.h"

@interface GlideMenuTray : UIScrollView 
{
	BOOL dragBegan;
	UIImageView* trackView;
	NSMutableArray* menuItems;
	NSMutableDictionary* menuItemByLabel;
	float nextItemX;
	float whiteSpaceWidth;
	float itemOffsetY;
	
	id actionTarget;
	SEL onSelectMenuItem;
}


//::Public
@property(assign) id actionTarget;

@property(assign) SEL onSelectMenuItem; // - (void) onSelectMenuItem:(MenuItem*)mi;

- (void) addMenuItem:(MenuItem*)menuItem;

- (MenuItem*) itemForLabel:(NSString*)labelText;
- (void) deselectAll;
- (void) pageBackward;
- (void) pageForward;
- (void) selectMenuItem:(MenuItem*)mi;
//::Private
- (void) _selectMenuItem:(MenuItem*)mi;
- (void) selectItem:(MenuItem*)mi;
@end
