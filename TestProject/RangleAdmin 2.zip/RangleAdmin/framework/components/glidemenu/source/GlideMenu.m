//
//  GlideMenu.m
//  GlideMenu
//
//  Create by Andrew Paul Simmons on 10/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "GlideMenu.h"

#define BUTTON_OFFSET_Y 15
#define INTERACTIVE_AREA_OFFSET_Y 5

@implementation GlideMenu
@synthesize actionTarget, onSelectMenuItem;

- (id) init
{
	return [self initWithFrame:CGRectMake(0, 0, 320, 46)];
}
- (id)initWithFrame:(CGRect)frame 
{
	if (self = [super initWithFrame:frame]) 
	{
		UIImage* background = [UIImage imageNamed:@"bg-spinner-area.png"];
		UIImageView* backgroundView = [[UIImageView alloc] initWithImage:background] ;
	
		
		UIImage* trayBackground = [UIImage imageNamed:@"spinner-bg.png"];
		UIImageView* trayBackgroundView = [[UIImageView alloc] initWithImage:trayBackground];
		trayBackgroundView.frame = CGRectMake(5.0f, INTERACTIVE_AREA_OFFSET_Y, trayBackgroundView.frame.size.width,  
																				trayBackgroundView.frame.size.height);
		[self addSubview:trayBackgroundView];
		
		tray = [[GlideMenuTray alloc] initWithFrame:CGRectMake(5, 7, 310, 41)];
		tray.actionTarget = self;
		tray.onSelectMenuItem = @selector(onSelectMenuItem:);
		
		[self addSubview:tray];
		
		UIImage* trayOverlay = [UIImage imageNamed:@"spinner-shadow-stroke.png"];
		UIImageView* trayOverlayView = [[UIImageView alloc] initWithImage:trayOverlay];
		trayOverlayView.frame = CGRectMake(5.0f, INTERACTIVE_AREA_OFFSET_Y, trayOverlayView.frame.size.width,  
																					trayOverlayView.frame.size.height);
		[self addSubview:trayOverlayView];
		 
		tray.delegate = self;
		self.backgroundColor = [UIColor clearColor];
		[self addSubview:backgroundView];
		
		/*
		UIImage* back_img = [UIImage imageNamed:@"prev.png"];
		UIImage* backDown_img = [UIImage imageNamed:@"prev-down.png"];
		
		CGRect frame = CGRectMake(5, BUTTON_OFFSET_Y, back_img.size.width, back_img.size.height);
		back_btn = [Utils buttonWithTitle:@""
								   target:self
								 selector:@selector(pageBackward:)
									frame:frame
									image:back_img
							 imagePressed:backDown_img
						darkTextColor:YES];		
		
		back_btn.hidden = YES;
		[self addSubview:back_btn];
		UIImage* backDisabled_img = [UIImage imageNamed:@"prev-off.png"];
		backDisabled = [[UIImageView alloc] initWithImage:backDisabled_img];
		[self addSubview:backDisabled];
		backDisabled.frame = frame;
		UIImage* forward_img = [UIImage imageNamed:@"next.png"];
		UIImage* forwardDown_img = [UIImage imageNamed:@"next-down.png"];
		float forwardImageX = tray.frame.size.width + tray.frame.origin.x + 5;
		frame = CGRectMake(forwardImageX, BUTTON_OFFSET_Y, forward_img.size.width, forward_img.size.height);
		forward_btn = [Utils buttonWithTitle:@""
								   target:self
									selector:@selector(pageForward:)
									frame:frame
									image:forward_img
							 imagePressed:forwardDown_img
							darkTextColor:YES];	
		
		forwardEnabled = YES;
		UIImage* forwardDisabled_img = [UIImage imageNamed:@"next-off.png"];
		forwardDisabled = [[UIImageView alloc] initWithImage:forwardDisabled_img];
		forwardDisabled.frame = CGRectMake(forwardImageX, BUTTON_OFFSET_Y, forwardDisabled_img.size.width, 
													forwardDisabled_img.size.height);
		forwardDisabled.hidden = YES;
		
		[self addSubview:forward_btn];
		[self addSubview:forwardDisabled];
		*/
		
	}
	
	return self;
}
 
 - (void) onSelectMenuItem:(MenuItem*)mi
{
	[actionTarget performSelector:onSelectMenuItem withObject:mi];
}

- (void) selectMenuItemWithLabel:(NSString*)labelText
{
	[tray selectMenuItem:[tray itemForLabel:labelText]];
}

- (void) deselectAll
{
	[tray deselectAll];
}

- (void) addMenuItem:(MenuItem*)menuItem
{
	[tray addMenuItem:menuItem];
}

- (MenuItem*) itemForLabel:(NSString*)labelText
{
	return [tray itemForLabel:labelText];
}
/*
- (void) pageForward:(id)sender
{
	[tray pageForward];
	return;
	printf("Paging forward\n");
	float trayContentWidth = tray.contentSize.width;
	float trayContentX = tray.contentOffset.x;
	float trayWidth = tray.frame.size.width;
	float newContentOffsetX = trayWidth + trayContentX;
	self.backEnabled = YES;
	if(newContentOffsetX > trayContentWidth - trayWidth)
	{
		self.forwardEnabled = NO;
		newContentOffsetX = trayContentWidth - trayWidth;
	}
	[tray flashScrollIndicators];
	
	[tray setContentOffset:CGPointMake(newContentOffsetX,0)  animated:YES];
	
}

- (void) pageBackward:(id)sender
{
	[tray pageBackward];
	return;
	float trayContentX = tray.contentOffset.x;
	float trayWidth = tray.frame.size.width;
	float newContentOffsetX = -trayWidth + trayContentX;
	self.forwardEnabled = YES;
	if(newContentOffsetX < 0)
	{
		self.backEnabled = NO;
		newContentOffsetX = 0;
	}
	//[tray flashScrollIndicators];
	
	[tray setContentOffset:CGPointMake(newContentOffsetX, 0)  animated:YES];
}

- (void) setBackEnabled:(BOOL)value
{
	if(value == backEnabled) return;
	backEnabled = value;
	if(value)
	{
		backDisabled.hidden = YES;
		back_btn.hidden = NO;
	}
	else
	{
		backDisabled.hidden = NO;
		back_btn.hidden = YES;
	}
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	float trayContentWidth = tray.contentSize.width;
	float trayContentX = tray.contentOffset.x;
	float trayWidth = tray.frame.size.width;
	

	if(trayContentX == 0)
	{
		self.backEnabled = NO;
	}
	else
	{
		self.backEnabled = YES;
	}
	
	if( trayContentX == (trayContentWidth - trayWidth) )
	{
		self.forwardEnabled = NO;
	}
	else
	{
		self.forwardEnabled = YES;
	}
	
}

- (BOOL) backEnabled
{
	return backEnabled;
}


- (void) setForwardEnabled:(BOOL)value
{
	
	if(value == forwardEnabled) return;
	forwardEnabled = value;
	if(value)
	{
		//forwardDisabled.hidden = YES;
		//forward_btn.hidden = NO;
	}
	else
	{
		//forwardDisabled.hidden = NO;
		//forward_btn.hidden = YES;
	}
	 
}

- (BOOL) forwardEnabled
{
	return forwardEnabled;
}
*/

/*
- (void) addItem
{
	
}
*/

- (void)drawRect:(CGRect)rect {
	// Drawing code
}


- (void)dealloc {
	[super dealloc];
}


@end
