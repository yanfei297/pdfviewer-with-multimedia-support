//
//  MenuItem.h
//  GlideMenu
//
//  Create by Andrew Paul Simmons on 10/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CategoryItem.h"

@interface MenuItem : UIView 
{	
	UILabel* label;
	
	UIImageView* selectedBackground;
	UIImageView* selectedOverground;
	//Make this setable when needed
	float labelTopOffset;
	float labelLeftOffset;
	float selectedBackgroundEdgeExtent;
	float selectedBackgroundTopOffset;
	id extra;
}

//::Public
- (id) initWithLabel:(NSString*)labelText extra:(id)extra;

-(id)initWithLabel:(NSString*)labelText
	backgroundName:(NSString*)selectedBackgroundImageName
				 x:(int)x
				 y:(int)y
			  font:(UIFont*)f 
	  labelOffsetX:(float)labelOffsetX
	  labelOffsetY:(float)labelOffsetY
 backgroundOffsetY:(float)backgroundOffsetY
			 extra:(id)extraObj;

- (void) setSelected:(BOOL)value;

@property (readonly) float width;
@property (readonly) float height;
@property (readonly) NSString* labelText;
@property (assign) float x;
@property (assign) float y;
@property (assign) id extra;


//::Private
@end