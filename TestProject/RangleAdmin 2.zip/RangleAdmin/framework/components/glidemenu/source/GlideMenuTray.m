//
//  GlideMenuView.m
//  GlideMenu
//
//  Create by Andrew Paul Simmons on 10/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "GlideMenuTray.h"


@implementation GlideMenuTray

@synthesize actionTarget, onSelectMenuItem;

- (id)initWithFrame:(CGRect)frame 
{
	if (self = [super initWithFrame:frame])
	{
		menuItems = [[NSMutableArray alloc] initWithCapacity:8];
		menuItemByLabel  = [[NSMutableDictionary alloc] initWithCapacity:8];
		nextItemX = 5;
		itemOffsetY = 5;
		whiteSpaceWidth = 10;
		
		//Track background goes here
		//UIImage* track_img = [UIImage imageNamed:@"tray.png"];
		//trackView = [[UIImageView alloc] initWithImage:track_img];
		//[self addSubview:trackView];
		
		// We shall update the content size as more items are added 
		self.contentSize = frame.size;
		self.bounces = YES;
		UIEdgeInsets indicatorInsets;
		//indicatorInsets.left = 20;
		//indicatorInsets.right = 20;
		self.scrollIndicatorInsets = indicatorInsets;
		self.backgroundColor = [UIColor clearColor];
		self.delaysContentTouches = YES;
	}
	return self;
}



- (void) addMenuItem:(MenuItem*)menuItem
{
	[menuItems addObject:menuItem];
	[menuItemByLabel setObject:menuItem forKey:menuItem.labelText];
	menuItem.x = nextItemX;
	menuItem.y = itemOffsetY;
	
	nextItemX += menuItem.width + whiteSpaceWidth;
	float newMenuContentWidth = nextItemX;
	self.contentSize = CGSizeMake(newMenuContentWidth, menuItem.height);
	[self addSubview:menuItem];
}

- (MenuItem*) itemForLabel:(NSString*)labelText
{
	return (MenuItem*)[menuItemByLabel objectForKey:labelText];
}

- (void) pageForward
{
	float contentWidth = self.contentSize.width;
	float contentX = self.contentOffset.x;
	float viewWidth = self.frame.size.width;
	
	int itemsLength = [menuItems count];
	for(int i = 0; i < itemsLength; i++)
	{
		MenuItem* item = (MenuItem*)[menuItems objectAtIndex:i];
		float itemViewX = item.x - contentX;
		if(itemViewX + item.width > viewWidth)
		{
			printf("contentX:%f, viewWidth:%f, itemViewX:%f\n", contentX, viewWidth, itemViewX);
			float newContentOffsetX = contentX + itemViewX; 
			if(newContentOffsetX > contentWidth - viewWidth)
			{
				newContentOffsetX = contentWidth - viewWidth;
			}
			[self setContentOffset:CGPointMake(newContentOffsetX,0)  animated:YES];
			return;
		}
		printf("Item View x: %f\n", itemViewX); 
	}
	
}

- (void) pageBackward
{
	float contentX = self.contentOffset.x;
	float viewWidth = self.frame.size.width;
	int itemsLength = [menuItems count];
	
	for(int i = 0; i < itemsLength; i++)
	{
		MenuItem* item = (MenuItem*)[menuItems objectAtIndex:i];
		float itemViewX = item.x - contentX;
		if(itemViewX + item.width > 0)
		{
			//printf("contentX:%f, viewWidth:%f, itemViewX:%f\n", contentX, viewWidth, itemViewX);
			float newContentOffsetX =  contentX + (itemViewX + item.width - viewWidth); 
			if(newContentOffsetX < 0)
			{
				newContentOffsetX = 0;
			}
			[self setContentOffset:CGPointMake(newContentOffsetX, 0)  animated:YES];
			return;
		}
		printf("Item View x: %f\n", itemViewX); 
	}
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	//[self flashScrollIndicators];
	[super touchesBegan:touches withEvent:event];	
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	dragBegan = true;	
	[super touchesMoved:touches withEvent:event];
}

- (void)touchesEnded:(NSSet*)touches withEvent:(UIEvent *)event
{
	
	//////////NSLog(@"Touches Ended");
	if(!dragBegan)
	{
		//printf("select correct button");
		UITouch* touch = [touches anyObject];
		
		//////////NSLog(@"touch.view: %@", touch.view);
		//[touch locationInView:
		
		CGPoint p = [touch locationInView:self];
		//////////NSLog(@"Location in view (%f, %f).", p.x, p.y);
		
		for(int i = 0; i < [menuItems count]; i++)
		{
			
			MenuItem* mi = (MenuItem*)[menuItems objectAtIndex:i];
			//////////NSLog(@"test against view frame (%f,%f,%f,%f)", mi.frame.origin.x, mi.frame.origin.y, mi.frame.size.width, mi.frame.size.height);
	
			id viewToSelect = [mi hitTest:[mi convertPoint:p fromView:self] withEvent:nil];
			if(viewToSelect)
			{
				//////////NSLog(@"___matched against view frame (%f,%f,%f,%f)", mi.frame.origin.x, mi.frame.origin.y, mi.frame.size.width, mi.frame.size.height);
				[self deselectAll];
				[self _selectMenuItem:mi];
				return;
			}
			else
			{
				//////////NSLog(@"___matched against view frame (%f,%f,%f,%f)", mi.frame.origin.x, mi.frame.origin.y, mi.frame.size.width, mi.frame.size.height);
			}
		}
	}
	else
	{
		[super touchesEnded:touches withEvent:event];
		dragBegan = false;
	}
	
	
}

- (void) _selectMenuItem:(MenuItem*)mi
{

	[self selectMenuItem:mi];
	[actionTarget performSelector:onSelectMenuItem withObject:mi];
}

- (void) selectMenuItem:(MenuItem*)mi
{
	float contentWidth = self.contentSize.width;
	float viewWidth = self.frame.size.width;
	
	float newOffsetX = mi.x - (viewWidth - mi.width)/2;
	if(newOffsetX > contentWidth - viewWidth)
	{
		newOffsetX = contentWidth - viewWidth;
	}
	else if(newOffsetX < 0)
	{
		newOffsetX = 0;
	}
	
	[self setContentOffset:CGPointMake(newOffsetX, 0)  animated:YES];
	
	[self selectItem:mi];
}

- (void) selectItem:(MenuItem*)mi
{
	[self deselectAll];
	[mi setSelected:YES];
}


- (void) deselectAll
{
	
	for(int i = 0; i < [menuItems count]; i++)
	{
		[(MenuItem*)[menuItems objectAtIndex:i] setSelected:NO];
	}
}

- (void)drawRect:(CGRect)rect 
{
	// Drawing code
}


- (void)dealloc 
{
	[super dealloc];
}


@end
