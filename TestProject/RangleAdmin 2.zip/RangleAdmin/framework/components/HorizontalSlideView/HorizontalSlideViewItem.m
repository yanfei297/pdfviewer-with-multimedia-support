//
//  HorizontalSlideViewItem.m
//  Andrew_CBSNews
//
//  Created by andrew on 4/27/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import "HorizontalSlideViewItem.h"
#import "SafeDictionary.h"
#import "APSWebImageWidget.h"
#import "Utils.h"
#import "fontnames.h"
#import "HitAreaView.h"

@implementation HorizontalSlideViewItem

@synthesize itemTitle, imageURL,actionTarget, onTapItem_cb;

- (id)initWithFrame:(CGRect)frame 
				  data:(SafeDictionary*)data
		  showTitle:(BOOL)showTitle
		 loadImageNext:(BOOL)loadImageNext
{
    if(self = [super initWithFrame:frame]) 
	{
		itemData = [data retain];
		[self addSubview:[Utils imageViewWithImageName:@"image-holder.png"]];
		
		imageWidget = [[[APSWebImageWidget alloc]  initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height )] autorelease];
		[imageWidget setBackgroundImageByName:@"default_370x278.png"];
		//imageWidget.progressBarBottomOffset = 0;
		
		//[Utils view:imageWidget setX:7.0f setY:4.0f];
		//imageWidget.backgroundColor = [UIColor purpleColor];

		[self addSubview:imageWidget];
		self.imageURL = [data stringForKey:@"mainImage"];
		[self addSubview:[Utils imageViewWithImageName:@"video-bar.png" x:7.0f y:197.0f]];
		
		////NSLog(@"title %@", [data mutableDictionary]);
	
		NSString* title = [data stringForKey:@"title"];
		itemTitle = title;
		if(showTitle)
		{
			UILabel* label = [Utils labelWithFrame:CGRectMake(5, 205, 290, 30) 
										  text:title 
									 textColor:[UIColor whiteColor] 
									  fontName:FONTNAME_helveticaBold
									  fontSize:14 
										  bold:NO];
		
			label.textAlignment = UITextAlignmentCenter;
			[self addSubview:label];
		}
		
		
		
		NSString* type = [itemData stringForKey:@"type"];
		
		if([type isEqualToString:@"video"] )
		{
			[self addSubview:[Utils imageViewWithImageName:@"video-arrow.png" x:293 y:211]]; 
		}
		else 
		{
			[self addSubview:[Utils imageViewWithImageName:@"arrow.png" x:300 y:213.7]];
		}
		
		
		HitAreaView* hitArea = [[[HitAreaView alloc] initWithFrame:CGRectMake(7.0f, 0, 326.0f, 241.0f)] autorelease];
		hitArea.actionTarget = self;
		hitArea.onRelease = @selector(onTap);
		
		[self addSubview:hitArea];
    }
	
    return self;
}

+ (HorizontalSlideViewItem*) itemWithFrame:(CGRect)frame 
										 data:(SafeDictionary*)data
								 showTitle:(BOOL)showTitle
								loadImageNext:(BOOL)loadImageNext
{
	return [[[HorizontalSlideViewItem alloc] initWithFrame:frame 
														 data:data 
												 showTitle:showTitle
												loadImageNext:loadImageNext] autorelease];
}


- (void) onTap
{
	////NSLog(@"----------Tapped item [%@]", [itemData mutableDictionary] );
	
	[self.actionTarget performSelector:onTapItem_cb withObject:itemData];
}

- (void)loadImage
{
	if(!loadRequested)
	{
		loadRequested = YES;
		[imageWidget loadAndCacheImageWithStringURL:self.imageURL loadNext:YES];
	}
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (void)dealloc 
{
	[itemData release];
	[imageWidget cancel];
    [super dealloc];
}


@end
