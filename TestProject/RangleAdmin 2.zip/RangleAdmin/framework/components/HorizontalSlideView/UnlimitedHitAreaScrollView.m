//
//  UnlimitedHitAreaScrollView.m
//  Andrew_CBSNews
//
//  Created by andrew on 5/10/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import "UnlimitedHitAreaScrollView.h"


@implementation UnlimitedHitAreaScrollView


- (id)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        // Initialization code
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

- (BOOL)pointInside:(CGPoint)point withEvent:(UIEvent *)event {
	////NSLog(@"Point test");
    return YES; //[super pointInside:CGPointMake(0, point.y) withEvent:event];
}

- (void)dealloc {
    [super dealloc];
}


@end
