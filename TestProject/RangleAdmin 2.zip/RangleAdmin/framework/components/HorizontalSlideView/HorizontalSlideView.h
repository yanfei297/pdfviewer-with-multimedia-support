//
//  HorizontalSlideView.h
//  Andrew_CBSNews
//
//  Created by andrew on 4/26/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SafeArray.h"
#import "UpdatingView.h"

@interface HorizontalSlideView : UIView <UIScrollViewDelegate>
{

	UIScrollView* scrollView;
	SafeArray* itemDatas;
	NSArray* items;
	int numItems;
	int spaceBetweenPages;
	float itemWidth;
	float itemSpacing;
	UIPageControl* pageControl;
	
	id actionTarget;
	SEL onSelectItem_cb;
	
	UIView* contentView;
	
	int pageLoaded[10];
	CGSize itemSize;
	NSMutableArray* itemViews;
	UpdatingView* updatingListView;
	
	BOOL titlesEnabled;
	
	UILabel* displayTitle;
	
	
}


- (id) initWithFrame:(CGRect)frame 
			itemSize:(CGSize)theItemSize 
		contentItems:(SafeArray*)theItemDatas 
		actionTarget:(id)target 
		onSelectItem:(SEL)onSelectItem;

- (id) initWithFrame:(CGRect)frame 
		contentItems:(SafeArray*)theItemDatas 
		actionTarget:(id)target
		onSelectItem:(SEL)onSelectItem;

- (void) updateWithContentList:(SafeArray*)theItemDatas;


//::Private
- (void) setDisplayTitle:(NSString*)displayTitleText;
- (void) removeDistantViewsFromViewAtIndex:(int)index;
- (void) scrollViewDidScroll:(UIScrollView*)sender;
- (void) loadScrollViewWithPage:(int)page;
- (void)removeAllItems;
- (void)loadAllItems;

@property(readonly) UIScrollView* scrollView;
@property(assign) BOOL titlesEnabled;


@end