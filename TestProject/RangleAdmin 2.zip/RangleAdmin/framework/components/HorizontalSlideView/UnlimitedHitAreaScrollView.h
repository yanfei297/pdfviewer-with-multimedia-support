//
//  UnlimitedHitAreaScrollView.h
//  Andrew_CBSNews
//
//  Created by andrew on 5/10/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UnlimitedHitAreaScrollView : UIScrollView {

}

@end
