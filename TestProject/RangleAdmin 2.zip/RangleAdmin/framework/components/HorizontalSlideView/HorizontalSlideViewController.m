//
//  HorizontalSlideViewController.m
//  Andrew_CBSNews
//
//  Created by andrew on 4/23/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import "HorizontalSlideViewController.h"

BOOL displayOnRotateToHorizontal = YES;
SafeArray* contentList;

BOOL initialized;

UIView* horizontalSlideView;
UIView* contentView;

NSTimer* orientationChangeTimer;

UIView* backgroundColorView;

id actionTarget;
SEL onSelectItem_cb;

BOOL slideViewPesent;
BOOL slideViewEnabled;

//UINavigationController

@implementation HorizontalSlideViewController

+ (void) initialize
{
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	
	[[NSNotificationCenter defaultCenter] addObserver:self
											 selector:@selector(didRotate:)
												 name:@"UIDeviceOrientationDidChangeNotification" object:nil];
	
	//self.view.backgroundImage = [UIColor colorWithPatternImage:[Utils imageViewWithImageName:@"main-slider-bg.png"].image];
}


+ (void)setSlideViewEnabled:(BOOL)enabled
{
	if(enabled)
	{
		//cannot enabled with fewer than 5 image items
		if([contentList count] < 5) return;
	}
	else
	{
		contentList = nil;
	}
	slideViewEnabled = enabled;
}


+ (void) setContentList:(SafeArray*)aContentList 
		   actionTarget:target 
		   onSelectItem:(SEL)onSelectItem
{
	actionTarget = target;
	onSelectItem_cb = onSelectItem;
	if(contentList == aContentList) return;
	[contentList release];
	contentList = [aContentList retain];
	
	//NSLog(@"Set COntent List to %@", contentList);

	for(int i = 0; i < [contentList count]; i++)
	{
		SafeDictionary* sd = [contentList safeDictionaryAtIndex:i];
		if([[sd stringForKey:@"mainImage"] length] < 1)
		{
			//NSLog(@"removing non image item");
			[contentList removeObjectAtIndex:i];
		}
	}
	
	if([contentList count] > 4 && slideViewPesent)
	{
		[horizontalSlideView updateWithContentList:contentList];
	}
}


/*
+ (void) activateWithActionTarget:(id)target onSelectItem:(SEL)onSelectItem
{
	//NSLog(@"Attempting to activate slide view");
	if(activated) return;
	
	actionTarget = target;
	onSelectItem_cb = onSelectItem;
	
	activated = YES;

	
	[self initializeSlideViewWithActionTarget:self onSelectItem:@selector(onSelectItem:)];
}
*/


+ (void) onSelectItem:(SafeDictionary*)itemData
{
	//NSLog(@"Controller did select item %@", itemData);
	
	[Utils recordToAnimate];
	horizontalSlideView.transform = CGAffineTransformMakeRotation(0);
	[Utils view:horizontalSlideView setY:45];
	[Utils animate];
	
	[self removeSlideView];
	[actionTarget performSelector:onSelectItem_cb withObject:itemData];
	
}

/*
+ (void) deactivate
{	
	if(!activated) return;
	activated = NO;
	[[UIDevice currentDevice] endGeneratingDeviceOrientationNotifications];
	[[NSNotificationCenter defaultCenter] removeObserver:self];
}
*/

/*
+ (void) initializeSlideViewWithActionTarget:(id)actionTarget onSelectItem:(SEL)onSelectItem_cb;
{

	

	
}
*/

+ (void) didRotate:(NSNotification *)notification
{	
	
	//UIPageControl
	[orientationChangeTimer invalidate];
	orientationChangeTimer = [NSTimer scheduledTimerWithTimeInterval:0.3 target:self selector:@selector(performRotation) userInfo:nil repeats:NO];
}

+ (void) performRotation
{
	orientationChangeTimer = nil;
	
	UIDeviceOrientation orientation = [[UIDevice currentDevice] orientation];
		//NSLog(@"UIDeviceOrientation %i", orientation);
	if (orientation == UIDeviceOrientationLandscapeLeft)
	{
		//[[UIApplication sharedApplication] setStatusBarOrientation:orientation];
	
	
		[self createAndShowSlideViewWithRotationLeft:YES];
		
	}
	else if(orientation == UIDeviceOrientationLandscapeRight)
	{

	
		[self createAndShowSlideViewWithRotationLeft:NO];
	}
	else 
	{
		[self removeSlideView];
		/*
		//[[UIApplication sharedApplication] setStatusBarOrientation:1 animated:NO];
		[[UIApplication sharedApplication] setStatusBarHidden:NO];
		[Utils recordToAnimateWithDuration:0.9];
		horizontalSlideView.alpha = 0;
		[Utils animate];
		
		[horizontalSlideView performSelector:@selector(removeFromSuperview)
								  withObject:nil 
								  afterDelay:1.0];
		
		//[self deactivate];
	
		//[self performSelector:@selector(removeSlideView)  withObject:nil afterDelay:1];
		 */
		
	}
}


+ (void)createAndShowSlideViewWithRotationLeft:(BOOL)rotationLeft
{
	if(!slideViewEnabled || slideViewPesent) return;
	
	[[UIApplication sharedApplication] setStatusBarHidden:YES];
	
		
	horizontalSlideView = [[[HorizontalSlideView alloc] initWithContentItems:contentList 
															   actionTarget:self
															   onSelectItem:@selector(onSelectItem:)] autorelease];

	slideViewPesent = YES;
	
	//NSLog(@"Landscape Left!");
	UIWindow* window = [UIApplication sharedApplication].keyWindow;
	if (!window) 
	{
		window = [[UIApplication sharedApplication].windows objectAtIndex:0];
	}
	
	window.backgroundColor = [UIColor blackColor];
	horizontalSlideView.alpha = 0;
	
	if (rotationLeft) 
	{
		horizontalSlideView.transform = CGAffineTransformMakeRotation(3.14159265f/2.0f);
	}
	else 
	{
		horizontalSlideView.transform = CGAffineTransformMakeRotation(-3.14159265f/2.0f);
	}

	backgroundColorView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 320,480)] autorelease];
	backgroundColorView.backgroundColor =[Utils colorFromHex: 0xF2C802];
	backgroundColorView.center = CGPointMake(160, 240);
	backgroundColorView.alpha = 0;
	[window addSubview:backgroundColorView];
	[window addSubview:horizontalSlideView];
	[Utils recordToAnimateWithDuration:0.9];
	horizontalSlideView.alpha = 1;
	backgroundColorView.alpha = 1.0f;
	[Utils animate];	
}


+ (void) removeSlideView
{
	[[UIApplication sharedApplication] setStatusBarHidden:NO];
	[Utils recordToAnimateWithDuration:0.9];
	horizontalSlideView.alpha = 0;
	backgroundColorView.alpha = 0;
	[Utils animate];
	
	[backgroundColorView performSelector:@selector(removeFromSuperview)
							  withObject:nil 
							  afterDelay:1.0];
	
	[horizontalSlideView performSelector:@selector(removeFromSuperview)
							  withObject:nil 
							  afterDelay:1.0];
	
	horizontalSlideView = nil;
	backgroundColorView = nil;
	slideViewPesent = NO;
	
}


@end
