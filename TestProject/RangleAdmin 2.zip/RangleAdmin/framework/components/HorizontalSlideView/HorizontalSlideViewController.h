//
//  HorizontalSlideViewController.h
//  Andrew_CBSNews
//
//  Created by andrew on 4/23/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "HorizontalSlideView.h"
#import "SafeArray.h"
#import "Utils.h"

@interface HorizontalSlideViewController : NSObject 
{

}


+ (void) initializeSlideView;
+ (void) startObservers;
+ (void) activate;
+ (void) deactivate;

@end
