//
//  CBSNewsUpdatingNewsListView.h
//  Andrew_CBSNews
//
//  Created by Bryce Buchanan on 2/22/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UpdatingView : UIView {
	UIView* updatingViewBox;
	UIView* updatingView;	
	UIActivityIndicatorView* updatingCache_ai;
	BOOL isUpdating;

}


//::Public
- (id) initWithPosition:(CGPoint)position;
- (void) stopUpdating;
- (void) startUpdating;


//::Private 
- (void) doInit;


@end
