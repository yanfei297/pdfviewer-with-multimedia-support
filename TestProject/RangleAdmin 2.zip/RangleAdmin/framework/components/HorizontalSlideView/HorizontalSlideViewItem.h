//
//  HorizontalSlideViewItem.h
//  Andrew_CBSNews
//
//  Created by andrew on 4/27/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SafeDictionary.h"
#import "APSWebImageWidget.h"

@interface HorizontalSlideViewItem : UIView 
{
	NSString* imageURL;
	APSWebImageWidget* imageWidget;
	SafeDictionary* itemData;
	id actionTarget;
	SEL onTapItem_cb;
	BOOL loadRequested;
	NSString* itemTitle;
}


//::Public
@property(copy) NSString* imageURL;
@property(assign) id actionTarget;
@property(assign) SEL onTapItem_cb;
@property(readonly) NSString* itemTitle;



+ (HorizontalSlideViewItem*) itemWithFrame:(CGRect)frame 
									  data:(SafeDictionary*)data
								 showTitle:(BOOL)showTitle
							 loadImageNext:(BOOL)loadImageNext;

- (id)initWithFrame:(CGRect)frame 
			   data:(SafeDictionary*)data
		  showTitle:(BOOL)showTitle
	  loadImageNext:(BOOL)loadImageNext;

- (void)loadImage;


//::Private


@end
