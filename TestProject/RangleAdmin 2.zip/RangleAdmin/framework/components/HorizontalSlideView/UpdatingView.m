//
//  CBSNewsUpdatingNewsListView.m
//  Andrew_CBSNews
//
//  Created by Bryce Buchanan on 2/22/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "UpdatingView.h"
#import "Utils.h"
#import "fontnames.h"

@implementation UpdatingView



- (id) initWithPosition:(CGPoint)position
{
	if( self = [super initWithFrame:CGRectMake(position.x, position.y, 100, 20)])
	{
		[self doInit];
	}
	return self;
}



- (void) doInit
{
	updatingCache_ai = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhite];
	updatingCache_ai.frame = CGRectMake(80, 2, 15, 15);
	updatingCache_ai.hidesWhenStopped = YES;
	//updatingViewBox = [[UIView alloc] initWithFrame:
	self.clipsToBounds = YES;
	self.backgroundColor = [UIColor clearColor];
	updatingView = [[UIView alloc] initWithFrame:CGRectMake(0,-20, 100, 20)];
	[updatingView addSubview:[Utils imageViewWithImageName:@"loading-bg.png"]];
	updatingView.backgroundColor = [UIColor clearColor];
	[self addSubview:updatingView];
	UILabel* updatingViewText = [[UILabel alloc] initWithFrame:CGRectMake(5,2,75,15)];
	updatingViewText.textColor = [UIColor whiteColor];
	updatingViewText.font = [UIFont fontWithName:FONTNAME_helvetica size:10];
	updatingViewText.text = @"Updating List...";
	updatingViewText.backgroundColor = [UIColor clearColor];
	[updatingView addSubview:updatingViewText];
    [updatingViewText release];
	[updatingView addSubview:updatingCache_ai];
}
- (void)drawRect:(CGRect)rect {
    // Drawing code
}


- (void)dealloc {
    [super dealloc];
}

- (void) startUpdating
{
	if (!isUpdating) 
	{
		isUpdating = YES;
		[updatingCache_ai startAnimating];
		[Utils recordToAnimateWithDuration:0.2];
		[Utils view:updatingView setY:updatingView.frame.origin.y + 20];
		[Utils animate];
	}
}

- (void) stopUpdating
{
	if (isUpdating)
	{
		isUpdating= NO;
		[updatingCache_ai stopAnimating];
		[Utils recordToAnimateWithDuration:0.2];
		[Utils view:updatingView setY:updatingView.frame.origin.y - 20];
		[Utils animate];
	}
}
@end
