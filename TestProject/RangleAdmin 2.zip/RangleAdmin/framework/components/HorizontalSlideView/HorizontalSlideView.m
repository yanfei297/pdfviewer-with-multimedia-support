//
//  HorizontalSlideView.m
//  Andrew_CBSNews
//
//  Created by andrew on 4/26/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import "HorizontalSlideView.h"
#import "HorizontalSlideViewItem.h"
#import "UnlimitedHitAreaScrollView.h"
#import "UpdatingView.h"
#import "fontnames.h"
@implementation HorizontalSlideView

@synthesize scrollView, titlesEnabled;


- (id) initWithFrame:(CGRect)frame 
			itemSize:(CGSize)theItemSize 
		contentItems:(SafeArray*)theItemDatas 
		actionTarget:(id)target 
		onSelectItem:(SEL)onSelectItem
{
	if(self = [super initWithFrame:frame])
	{
		itemSize = theItemSize;
		actionTarget = target;
		onSelectItem_cb = onSelectItem;
		itemViews = [[NSMutableArray alloc] initWithCapacity:10];
		itemWidth = theItemSize.width;
		itemSpacing = 23;
		float scrollViewWidth = theItemSize.width + itemSpacing;
		
		
		scrollView = [[[UnlimitedHitAreaScrollView alloc] initWithFrame:CGRectMake((frame.size.width - scrollViewWidth)/2 + 10, 0, scrollViewWidth, 260)] autorelease];
		
		scrollView.clipsToBounds = NO;
		scrollView.delegate = self;
		//scrollView.backgroundColor = [UIColor blueColor];
	
		
		[scrollView setShowsHorizontalScrollIndicator:NO];
		//scrollView.backgroundColor = [UIColor redColor];
		//self.backgroundColor = [UIColor blackColor];
		
		//self.center = CGPointMake(160, 240);
	
		[self addSubview:self.scrollView];
		
		[self addSubview:[Utils imageViewWithImageName:@"left-fade.png"]];
		[self addSubview:[Utils imageViewWithImageName:@"fade-right.png" x:330  y:0]];
		
		itemDatas = [theItemDatas retain];
		//self.scrollView.backgroundColor = [UIColor clearColor];
		self.scrollView.pagingEnabled = YES;
	//	//NSLog(@"self.view.frame.origin.x %f", self.frame.origin.x);
		//self.backgroundColor = [Utils colorFromImageName:@"slider-bg.png"];
	
		//pageControl = [[[UIPageControl alloc] initWithFrame:CGRectMake(0, 300, 768, 10)] autorelease];
		
		UIImageView* sliderTextOverlay = [Utils imageViewWithImageName:@"slider-txt-bg.png" x:0 y:255];
		[self addSubview:sliderTextOverlay];
		
		float titleWidth = 400;
		displayTitle = [Utils labelWithFrame:CGRectMake((768 - titleWidth)/2, 268, titleWidth, 80) 
										text:@"" 
								   textColor:[UIColor whiteColor] 
									fontName:FONTNAME_timesNewRoman
									fontSize:18];
		displayTitle.numberOfLines = 0;
		displayTitle.textAlignment = UITextAlignmentCenter;
									
		[self addSubview:displayTitle];
		pageControl.userInteractionEnabled = NO;
		[self addSubview:pageControl];
		
		

	
	
		[self loadAllItems];
		
		updatingListView = [[[UpdatingView alloc] initWithPosition:CGPointMake((768-100)/2, 0)] autorelease];
		
		//updatingListView.backgroundColor = [UIColor redColor];
		updatingListView.hidden = NO;
		[self addSubview:updatingListView];
		
		
		
		//imageWidth = 
		////NSLog(@"self.view.frame.origin.x %f", self.frame.origin.x);
	}
	return self;
}


- (void) updateWithContentList:(SafeArray*)theItemDatas
{

	//test to see if updates brings new content
	
	////NSLog(@"Going to count itemDatas:[%@]", itemDatas);
	int numNewItemDatas = [theItemDatas count];
	
	if(numNewItemDatas == [itemDatas count])
	{
		BOOL allItemsMatch = YES;
		
		for(int i = 0; i < numNewItemDatas; i++)
		{
			SafeDictionary* oldItemData = [itemDatas safeDictionaryAtIndex:i];
			SafeDictionary* newItemData = [theItemDatas safeDictionaryAtIndex:i];
			
			NSString* oldItemTitle = [oldItemData stringForKey:@"title"];
			NSString* newItemTitle = [newItemData stringForKey:@"title"];
			
			////NSLog(@"Old Item Title=\"%@\"  |    New Item Title=\"%@\"", oldItemTitle, newItemTitle);
			
			if (![oldItemTitle isEqualToString:newItemTitle]) 
			{
				allItemsMatch = NO;
				break;
			}
			
		}
		
		if(allItemsMatch)
		{ 
			////NSLog(@"Horizontal Slide View: All New Content Matched old Content.  No Update");
			return; // no need to update
		}
	}
	
	[updatingListView startUpdating];
	[self bringSubviewToFront:updatingListView];
	

	
	[updatingListView performSelector:@selector(stopUpdating) withObject:nil afterDelay:3];
	[self removeAllItems];
	
	[itemDatas release];
	itemDatas = [theItemDatas retain];
	[self loadAllItems];
}

/*
 switch (i) 
 {
 case 0:
 sd = [contentList safeDictionaryAtIndex:8];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:8];
 }
 break;
 case 1:
 sd = [contentList safeDictionaryAtIndex:6];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:6];
 }
 break;
 case 2:
 sd = [contentList safeDictionaryAtIndex:4];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:4];
 }
 break;
 case 3:
 sd = [contentList safeDictionaryAtIndex:2];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:2];
 }
 break;
 case 4:
 sd = [contentList safeDictionaryAtIndex:0];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:0];
 }
 break;
 case 5:
 sd = [contentList safeDictionaryAtIndex:1];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:1];
 }
 break;
 case 6:
 sd = [contentList safeDictionaryAtIndex:3];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:3];
 }
 break;
 case 7:
 sd = [contentList safeDictionaryAtIndex:5];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:5];
 }
 break;
 case 8:
 sd = [contentList safeDictionaryAtIndex:7];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:7];
 }
 break;
 default:
 sd = [contentList safeDictionaryAtIndex:i];
 if([[sd stringForKey:@"mainImage"] length] < 1)
 {
 //NSLog(@"removing non image item");
 [contentList removeObjectAtIndex:i];
 }
 break;
 
 }
 */


- (void)loadAllItems
{

	numItems = [itemDatas count];
	if(numItems > 9) numItems = 9;
	//int middleItem = (int)numItems/2;
	
	for(int l = 0; l < numItems; l++)
	{
		CGRect itemFrame;
		itemFrame.size = itemSize;
		itemFrame.origin = CGPointMake(l*(itemWidth+itemSpacing), 0);
		int w;
		switch (l) {
			case 0:
				w = 8;
				break;
			case 1:
				w = 6;
				break;
			case 2:
				w = 4;
				break;
			case 3:
				w = 2;
				break;
			case 4:
				w = 0;
				break;
			case 5:
				w = 1;
				break;
			case 6:
				w = 3;
				break;
			case 7:
				w = 5;
				break;
			case 8:
				w = 7;
				break;
			default:
				break;
		}
		HorizontalSlideViewItem* item = [HorizontalSlideViewItem 
										 itemWithFrame:itemFrame
										 data:[itemDatas safeDictionaryAtIndex:w] 
										 showTitle:NO
										 loadImageNext:YES];
		//item.backgroundColor = [Utils colorFromHex:0xFF0000];
		UIImageView* frameimg = [Utils imageViewWithImageName:@"main-image-frame.png"];
		[Utils view:frameimg setX:-11 setY:-9];
		[item addSubview:frameimg];
		item.actionTarget = self;
		item.onTapItem_cb = @selector(onSelectItem:);
		
		[itemViews addObject:item];
		
		[self.scrollView addSubview:item];
		////NSLog(@"added scroll view");
	}
	
	scrollView.contentSize = CGSizeMake((numItems) * (itemWidth+itemSpacing)  - itemSpacing, 260);
	scrollView.contentOffset = CGPointMake(((int)(numItems/2)) * (itemWidth+itemSpacing),0 );
	
	pageControl.numberOfPages = numItems;
	[self scrollViewDidScroll:scrollView];
	
}

- (void)removeAllItems
{
	numItems = 0;
	int numItemViews = [itemViews count];
	
	for (int i = 0; i < numItemViews; i++) 
	{
		HorizontalSlideViewItem* itemView = [itemViews objectAtIndex:i];
		[itemView removeFromSuperview];
	}
	
	[itemViews release];
	itemViews = [[NSMutableArray alloc] initWithCapacity:10];
	
}

- (void) onSelectItem:(SafeDictionary*)itemData
{
	//NSLog(@"did select item %@", actionTarget);
	[actionTarget performSelector:onSelectItem_cb 
							withObject:itemData];
}

- (void)scrollViewWillBeginDecelerating:(UIScrollView *)scrollView
{
	////NSLog(@"Scroll view now decelerating!");
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
	if(!decelerate)
	{
		//NSLog(@"Scroll view did end drag && is NOT decelerating!");
	}
}


- (void)scrollViewDidScroll:(UIScrollView *)sender 
{

	/*
    // We don't want a "feedback loop" between the UIPageControl and the scroll delegate in
    // which a scroll event generated from the user hitting the page control triggers updates from
    // the delegate method. We use a boolean to disable the delegate logic when the page control is used.
    if (pageControlUsed) 
	{
        // do nothing - the scroll was initiated from the page control, not the user dragging
        return;
    }
	*/
	
    // Switch the indicator when more than 50% of the previous/next page is visible
	////NSLog(@"Scrolled content offset  %f ", scrollView.contentOffset.x);
	////NSLog(@"Page Width: %f", scrollView.frame.size.width);
	
	CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
	
	pageControl.currentPage = page;
	
	if(page >= 0 && page < [itemViews count] )
	{
		HorizontalSlideViewItem* itemView = [itemViews objectAtIndex:page];
		[self setDisplayTitle:itemView.itemTitle];
	}

	
	
	{
		if(page - 1 < 0 || (page + 1) >= [itemViews count] )
		{
			return;
		}
		
		HorizontalSlideViewItem* centerItem = [itemViews objectAtIndex:page];
		[centerItem loadImage];
		
		if(page > 0)
		{
			HorizontalSlideViewItem* leftItem = [itemViews objectAtIndex:page - 1];
			[leftItem loadImage];
		}
		
		if(page < numItems - 1)
		{
			HorizontalSlideViewItem* rightItem = [itemViews objectAtIndex:page + 1];
			[rightItem loadImage];
		}
		
	}
	
	
	
	
	////NSLog(@"Scrolled to page %i ", page);
	/*
	if(pageControl.currentPage != page)
	{
		pageControl.currentPage = page;
		[self pageDidChange:page];
	}
	
	*/
    // load the visible page and the page on either side of it (to avoid flashes when the user starts scrolling)
	/*
	[self loadScrollViewWithItem:page];
	[self loadScrollViewWithItem:page - 1];
    [self loadScrollViewWithItem:page + 1];  
	[self removeDistantViewsFromViewAtIndex:page];
	 */
	
    // A possible optimization would be to unload the views+controllers which are no longer visible
}
- (void) setDisplayTitle:(NSString*)displayTitleText
{
	displayTitle.text = displayTitleText;
}
/*
- (void)loadScrollViewWithItem:(int)index 
{
    if (index < 0) return;
    if (index >= numItems) return;
	
    // replace the placeholder if necessary
	
    NSDictionary* itemData = [itemDatas objectAtIndex:index];
	
	UIView* itemView;
    // add the controller's view to the scroll view
    if (nil == itemView.superview) 
	{
        CGRect frame = scrollView.frame;
        frame.origin.x = frame.size.width * index + spaceBetweenPages;
        frame.origin.y = 0;
        itemView.frame = frame;
        [scrollView addSubview:itemView];
    }
}
*/
- (void) removeDistantViewsFromViewAtIndex:(int)index
{
	/*
	for(int i = 0; i < numItems; i++)
	{
		if(abs(index - i) > 1)
		{
			[self unloadScrollViewWithItem:i];
		}
	}
	*/
}


- (void) unloadScrollViewWithItem:(int)index 
{
	if (index < 0) return;
    if (index >= numItems) return;
	/*
	UIViewController* controller = [viewControllers objectAtIndex:page];
	
	[controller viewDidDisappear:NO];
	*/
	
}

- (void) buildMenu
{
	
}

-(void)dealloc
{
	[itemViews release];
	[super dealloc];
}
@end
