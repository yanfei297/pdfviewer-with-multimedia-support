//
//  UserProfileData.m
//  Qwiket
//
//  Created by steve on 8/3/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "UserProfileData.h"


@implementation UserProfileData
@synthesize user,birthdate,email,last_activity,password,gender,about_desc,about_movies,about_music,about_magazines,about_books,about_games,about_websites,your_websites,relationship_status,location,latitude,longitude;
- (NSString*) description
{
	return [NSString stringWithFormat:@"{User:%@, Birthday:%@, Gender:%@, About_desc:%@, About_movies:%@, About_music:%@, About_magazines:%@, About_books:%@, About_games:%@, About_websites:%@, YourWebsites:%@, Location:%@, Relationship_status:%@, last_activity:%@}",user,birthdate,gender,about_desc,about_movies,about_music,about_magazines,about_books,about_games,about_websites,your_websites,location,relationship_status,last_activity];
}
			
- (id) initWithUser:(NSString*)user1
		   birthday:(NSString*)birthdate1
		   password:(NSString*)password1
			  email:(NSString*)email1
			 gender:(NSString*)gender1
		 about_desc:(NSString*)about_desc1
	   about_movies:(NSString*)about_movies1
		about_music:(NSString*)about_music1
	about_magazines:(NSString*)about_magazines1
		about_books:(NSString*)about_books1
		about_games:(NSString*)about_games1
	 about_websites:(NSString*)about_websites1
	   yourWebsites:(NSString*)your_websites1
		   location:(NSString*)location1
relationship_status:(NSString*)relationship_status1
{
	//////////NSLog(@"creating UserProfileDate Structure with memebers:: USER: %@, BIRTHDAY: %@, password: %@,email:%@,gender:%@,about_desc:%@,about_movies:%@,about_music:%@,about_magazines:%@,about_books:%@,about_games:%@,about_websites:%@,yourWebsites:%@,location:%@,relationship_status:%@",user1, birthdate1, password1, email1,gender1,about_desc1,about_movies1,about_music1,about_magazines1,about_books1,about_games1,about_websites1, your_websites1,location1,relationship_status1);
	
	self.user = user1;
	self.birthdate = birthdate1;
	self.gender = gender1;
	self.email = email1;
	self.password = password1;
	self.about_desc = about_desc1;
	self.about_movies = about_movies1;
	self.about_music = about_music1;
	self.about_magazines = about_magazines1;
	self.about_books = about_books1;
	self.about_games = about_games1;
	self.about_websites =about_websites1;
	self.your_websites =your_websites1;
	self.location = location1;
	self.relationship_status = relationship_status1;
	return self;
}

- (void) dealloc 
{
	
	////////NSLog(@"release %@",user);
	[user release];
	////////NSLog(@"release %@",birthdate);
	[birthdate release];
	////////NSLog(@"release %@",gender);
	[gender release];
	////////NSLog(@"release %@",about_desc);
	[about_desc release];
	////////NSLog(@"release %@",about_movies);
	[about_movies release];
	////////NSLog(@"release %@",about_music);
	[about_music release];
	////////NSLog(@"release %@",about_magazines);
	[about_magazines release];
	////////NSLog(@"release %@", about_books);
	[about_books release];
	////////NSLog(@"release %@",about_games);
	[about_games release];
	////////NSLog(@"release %@",about_websites);
	[about_websites release];
	////////NSLog(@"release %@",your_websites);
	[your_websites release];
	////////NSLog(@"release %@", location);
	[location release];
	////////NSLog(@"release %@", relationship_status);
	[relationship_status release];
	////////NSLog(@"release %@",last_activity);
	[last_activity release];
	[longitude release];
	[latitude release];
	
	[super dealloc];
}
@end
