//
//  SafeDictionary.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/11/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <Foundation/Foundation.h>

#import "SafeArray.h"
@class SafeArray;

@interface SafeDictionary : NSObject 
{
	NSMutableDictionary* mutableDictionary;
}
//UINavigationController
//::Public
@property(readonly) NSMutableDictionary* mutableDictionary;

+ (SafeDictionary*) safeDictionaryWithDictionary:(NSDictionary*)aDictionary;

- (id) initWithDictionary:(NSDictionary*)aDictionary;

- (BOOL) isValid;

- (NSMutableDictionary*) mutableDictionary;
- (NSUInteger)count;

- (NSString*) stringForKey:(NSString*)aKey; // nil strings are converted to empty strings like: @""
- (BOOL) stringIsDefinedForKey:(NSString*)aKey; // returns false when string at index is nil

- (SafeArray*) safeArrayForKey:(NSString*)aKey;
- (SafeDictionary*) safeDictionaryForKey:(NSString*)aKey;

- (void) setObject:(id)anObject forKey:(id)aKey; // if object is nil, simply does nothing
- (NSArray*) allKeys;


@end
