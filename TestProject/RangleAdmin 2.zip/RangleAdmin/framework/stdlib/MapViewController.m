//
//  MapViewController.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/18/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "MapViewController.h"
//#import "JSON.h"
#define kTreemoLatitude 47.6062095
#define kTreemoLongitude -122.3320708
//MKReverseGeoCoder
@implementation MapViewController


- (id) init
{
	if(self = [super init])
	{
		finishedLoading = NO;
	}
	return self;
}

 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
		
	

    }
    return self;
}


/*Load
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

-(void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	#ifdef FLURRYAPI_H
		[FlurryAPI logEvent:@"page view"];
	#endif
}
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	
	
	if(!localInformation && !notLocal)
	{
		[LocalInformation getLatLonWithDelegate:self];
		 
		// loadCoordsWithTarget:self 
						//   onLoadCoordsSuccess:@selector(onLoadCoordsWithLat:lon:) 
					//	   onLoadCoordsFailure:@selector(onLoadCoordsFailure:)];
		
		 [LocalInformation getCityNameWithDelegate:self];
		 
							//   onLoadCitySuccess:@selector(onLoadCity:) 
							//   onLoadCityFailure:@selector(onLoadCityFailure:)];
	}
	
	mapView = [[[MKMapView alloc] initWithFrame:self.view.bounds] autorelease];
	mapView.showsUserLocation = YES;
	mapView.delegate = self;
	
/*
	CLLocationCoordinate2D coords;
	coords.latitude = kTreemoLatitude;
	coords.longitude = kTreemoLongitude;
	BasicMapAnnotation* basicAnotation = [[BasicMapAnnotation alloc] initWithCoordinate:coords 
																				  title:@"Treemo Labs" 
																			   subtitle:@"Treemo Labs HQ"];
	[mapView addAnnotation:basicAnotation];
	*/
	
	[self.view addSubview:mapView];
}


- (void)localInformationGotCityName:(NSString*)city andReference:(LocalInformation*)localInformation
{
	//////NSLog(@"got city %@", city);
	finishedLoading = YES;
	cityName = [city copy];
	
}
- (void) localInformationCityRequestFailed:(NSString*)message
{
	//////NSLog(@"Could not update coords %@", message);
	if(message == nil)
	{
		errorMessage = [[UIAlertView alloc] initWithTitle:@"Failed to retrieve city name."
												  message:@"This may be caused by a lack of network connectivity."
												 delegate:self 
										cancelButtonTitle:@"Cancel"
										otherButtonTitles:@"Retry",nil];
	}
	else {
		errorMessage = [[UIAlertView alloc] initWithTitle:@"Failed to retrieve city name."
												  message:message
												 delegate:self 
										cancelButtonTitle:@"Cancel"
										otherButtonTitles:@"Retry",nil];
	}
	[errorMessage show];
		
}

-(void) alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	switch(buttonIndex)
	{
		case 0:
			[errorMessage release];
			errorMessage = nil;
			break;
		case 1:
			[errorMessage release];
			errorMessage = nil;
			if(self)[self viewDidLoad];
	}
}

- (void) mapViewDidFinishLoadingMap:(MKMapView*) mapView
{
	//////NSLog(@"Loading did finish");
}

- (void)mapView:(MKMapView *)mapView regionDidChangeAnimated:(BOOL)animated
{
	//////NSLog(@"Region Did Change");
}

- (void) localInformationGotLatitude:(NSNumber*)lat longitude:(NSNumber*)lon
{
	
	float latitude = [lat floatValue];
	float longitude = [lon floatValue];
	[self centerMapOnLat:latitude lon:longitude];

	 //////NSLog(@"Got Coords");
	
}

- (void) centerMapOnLat:(float)lat lon:(float)lon
{
	MKCoordinateRegion region;
	MKCoordinateSpan span;
	span.latitudeDelta=0.1;
	span.longitudeDelta=0.1;
	
	CLLocationCoordinate2D location = mapView.userLocation.coordinate;
	location.latitude=lat;
	location.longitude=lon;
	region.span=span;
	region.center=location;
	
	[mapView setRegion:region animated:TRUE];
	[mapView regionThatFits:region];
}

- (void) localInformationCoordsRequestFailed:(NSString*)message
{
	//////NSLog(@"Could not get local coords %@", message);
	if(message == nil)
	{
		errorMessage = [[UIAlertView alloc] initWithTitle:@"Failed to retrieve user coordinates."
											  message:@"This may be caused by a lack of network connectivity."
											 delegate:self 
									cancelButtonTitle:@"Cancel"
									otherButtonTitles:@"Retry",nil];
	}
	else {
		errorMessage = [[UIAlertView alloc] initWithTitle:@"Failed to retrieve user coordinates."
												  message:message
												 delegate:self 
										cancelButtonTitle:@"Cancel"
										otherButtonTitles:@"Retry",nil];
	}

	[errorMessage show];
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	//[localInformation start];
	if(!finishedLoading)
	{
		[self viewDidLoad];
	}
}

- (void) viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
	//[localInformation stop];
}
//MKUserLocation

- (MKAnnotationView *) mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>) annotation
{
	if ([annotation isKindOfClass:[MKUserLocation class]]) return nil;
	
	MKPinAnnotationView *annView= [[MKPinAnnotationView alloc] initWithAnnotation:annotation 
																  reuseIdentifier:@"defaultAnnotation"];
	annView.animatesDrop = YES;
	annView.canShowCallout = YES;
	
	if(!hideDetailsButton)
	{
		annView.rightCalloutAccessoryView = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	}
	
	return annView;
}
 
- (void) mapView:(MKMapView *)mapView annotationView:(MKAnnotationView*) view 
					   calloutAccessoryControlTapped:(UIControl*) control
{
	[self onTapCallout:view.annotation];
}


- (void) onTapCallout:(id<MKAnnotation>)annotation //Override this method
{
	
} 


/*

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation 
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

*/

- (void)didReceiveMemoryWarning 
{
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];	
	// Release any cached data, images, etc that aren't in use.
		//////NSLog(@"MapViewController did recieve memeory warning.");
}

- (void)viewDidUnload 
{
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}


- (void)dealloc 
{
	mapView.delegate = nil;
	[super dealloc];
	
}

- (void)mapViewDidFailLoadingMap:(MKMapView *)mapView withError:(NSError *)error
{
	if(!errorMessage)
	{
		errorMessage = [[UIAlertView alloc] initWithTitle:@"Failed to load map."
											  message:[error localizedDescription]
											 delegate:self 
									cancelButtonTitle:@"Cancel"
									otherButtonTitles:@"Retry",nil];
		//[errorMessage show];
	}
}



@end
 

