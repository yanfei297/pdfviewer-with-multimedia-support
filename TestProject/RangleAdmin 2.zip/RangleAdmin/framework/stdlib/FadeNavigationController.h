//
//  FadeNavigationController.h
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 2/10/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface FadeNavigationController : UINavigationController 
{
	UIView* blackOverlay;
	UIViewController* nextViewController;
	UIViewController* popToViewController;
	BOOL fading;
}

//::Public
- (void) pushViewController:(UIViewController *)viewController fade:(BOOL)fade;
- (void) popViewControllerFade:(BOOL)animated;

- (void) pushViewController:(UIViewController *)viewController fade:(BOOL)fade 
		popToViewController:(UIViewController*)controllerToPopToOrNil;
 
//::Private 
- (void)fadeInPush;
- (void) fadeInPop;

@end
