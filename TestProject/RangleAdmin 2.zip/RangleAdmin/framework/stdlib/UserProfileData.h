//
//  UserProfileData.h
//  Qwiket
//
//  Created by steve on 8/3/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UserProfileData : NSObject {
	NSString* user;
	NSString* birthdate;
	NSString* password;
	NSString* email;
	NSString* gender;
	NSString* about_desc;
	NSString* about_movies;
	NSString* about_music;
	NSString* about_magazines;
	NSString* about_books;
	NSString* about_games;
	NSString* about_websites;
	NSString* your_websites;
	NSString* last_activity;
	NSString* location;
	NSString* relationship_status;
	NSString* longitude;
	NSString* latitude;
}

//::: PUBLIC
- (id) initWithUser:(NSString*)user
		   birthday:(NSString*)birthdate	
		   password:(NSString*)password
			  email:(NSString*)email
			 gender:(NSString*)gender
		 about_desc:(NSString*)about_desc
	   about_movies:(NSString*)about_movies
		about_music:(NSString*)about_music
	about_magazines:(NSString*)about_magazines
		about_books:(NSString*)about_books
		about_games:(NSString*)about_games
	 about_websites:(NSString*)about_websites
	   yourWebsites:(NSString*)your_websites
		   location:(NSString*)location
relationship_status:(NSString*)relationship_status;

@property(copy) NSString* last_activity;
@property(copy) NSString* user;
@property(copy) NSString* birthdate;
@property(copy) NSString* email;
@property(copy) NSString* password;
@property(copy) NSString* gender;
@property(copy) NSString* about_desc;
@property(copy) NSString* about_movies;
@property(copy) NSString* about_music;
@property(copy) NSString* about_magazines;
@property(copy) NSString* about_books;
@property(copy) NSString* about_games;
@property(copy) NSString* about_websites;
@property(copy) NSString* your_websites;
@property(copy) NSString* location;
@property(copy) NSString* relationship_status;
@property(copy) NSString* longitude;
@property(copy) NSString* latitude;

@end
