//
//  CustomNavTool.m
//  AssociatedContent
//
//  Created by andrew on 5/5/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//


#import "CustomNavTool.h"
#import "Utils.h"

#import </usr/include/objc/objc-class.h>
#define APS_kSCNavigationBarBackgroundImageTag 6183746
//#define APS_kSCNavigationBarTintColor [UIColor colorWithRed:0.0 green:0.0 blue:0.00 alpha:1.0]

UIColor *APS_kSCNavigationBarTintColor;

@implementation UINavigationBar (APSBackgroundImage)


- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index
{
    [self scInsertSubview:view atIndex:index];
	
    UIView *backgroundImageView = [self viewWithTag:APS_kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

- (void)scSendSubviewToBack:(UIView *)view
{
    [self scSendSubviewToBack:view];
	
    UIView *backgroundImageView = [self viewWithTag:APS_kSCNavigationBarBackgroundImageTag];
    if (backgroundImageView != nil)
    {
        [self scSendSubviewToBack:backgroundImageView];
    }
}

@end

@implementation CustomNavTool

+ (void)initialize
{
	[Utils swizzleSelector:@selector(insertSubview:atIndex:)
				   ofClass:[UINavigationBar class]
			  withSelector:@selector(scInsertSubview:atIndex:)];
    [Utils swizzleSelector:@selector(sendSubviewToBack:)
				   ofClass:[UINavigationBar class]
			  withSelector:@selector(scSendSubviewToBack:)];
}
+(UIColor *)setNavBarColor:(int)color
{
	APS_kSCNavigationBarTintColor=[Utils colorFromHex:color];
	return APS_kSCNavigationBarTintColor;
}

+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				 withHeaderImageNamed:(NSString*)imageName
{
    UINavigationBar *navBar = [navigationController navigationBar];
    [navBar setTintColor:APS_kSCNavigationBarTintColor];
	
    UIImageView *imageView = (UIImageView *)[navBar viewWithTag:APS_kSCNavigationBarBackgroundImageTag];
    if (imageView == nil)
    {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:imageName]];
        [imageView setTag:APS_kSCNavigationBarBackgroundImageTag];
        [navBar insertSubview:imageView atIndex:0];
        [imageView release];
    }
}

+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				 withHeaderImageView:(UIImageView*)navImageView
{
    UINavigationBar *navBar = [navigationController navigationBar];
    [navBar setTintColor:APS_kSCNavigationBarTintColor];
	
    UIImageView *imageView = (UIImageView *)[navBar viewWithTag:APS_kSCNavigationBarBackgroundImageTag];
    if (imageView == nil)
    {
        imageView = navImageView;
        [imageView setTag:APS_kSCNavigationBarBackgroundImageTag];
        [navBar insertSubview:imageView atIndex:0];
        [imageView release];
    }
}


- (void)dealloc {
    [super dealloc];
}


@end
