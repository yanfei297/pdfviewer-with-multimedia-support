//
//  NetworkReachability.h
//  Andrew_CBSNews
//
//  Created by steve on 8/31/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <sys/socket.h>
#import <netinet/in.h>
#import <netinet6/in6.h>
#import <arpa/inet.h>
#import <ifaddrs.h>
#import <SystemConfiguration/SystemConfiguration.h>
#import <CoreFoundation/CoreFoundation.h>
#import <netdb.h>

typedef enum {
	NETREAC_NotReachable = 0,
	NETREAC_ReachableViaWiFi = 1,
	NETREAC_ReachableViaWWAN = 2
} NetworkStatus;

@interface NetworkReachability : NSObject {

}
+ (NetworkStatus) reachabilityForLocalWiFi;
+ (NetworkStatus) reachabilityForNetwork;
+ (NetworkStatus) reachability; //this will give you the enum for status bit-wise OR'd together.
+ (SCNetworkReachabilityRef) reachabilityWithAddress: (const struct sockaddr_in*) hostAddress;
@end
