//
//  UserGeoData.m
//  Qwiket
//
//  Created by Bryce Buchanan on 10/14/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "UserGeoData.h"


@implementation UserGeoData
@synthesize userName, latitude, longitude, geoDistance;

- (NSString*) description
{
	return [NSString stringWithFormat:@"UserGeoData: { \n		username:%@\n		latitude:%f\n		longitude:%f\n		geoDistance:%f\n}",userName,latitude,longitude, geoDistance];				
}
- (id) initWith:(NSString*)aUserName
 aLatitude:(NSString*)aLatitude
aLongitude:(NSString*)aLongitude 
aGeoDistance:(NSString*)aGeoDistance
{
	if(self = [super init])
	{
		userName = [aUserName copy];
		latitude = [aLatitude floatValue];
		longitude = [aLongitude floatValue];
		geoDistance = [aGeoDistance floatValue];
	}
	return self;
}


@end
