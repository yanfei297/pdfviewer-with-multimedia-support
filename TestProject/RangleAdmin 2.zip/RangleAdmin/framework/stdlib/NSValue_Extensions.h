//
//  NSValue_Extensions.h
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 3/6/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSValue (NSValue_Extensions)


+ (NSValue *)valueWithCGPoint:(CGPoint)inPoint;
- (CGPoint)CGPointValue;

+ (NSValue *)valueWithCGSize:(CGSize)inSize;
- (CGSize)CGSizeValue;

+ (NSValue *)valueWithCGRect:(CGRect)inRect;
- (CGRect)CGRectValue;


@end
