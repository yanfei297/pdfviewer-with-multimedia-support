//
//  PhysicalCutout.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 11/12/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface PhysicalCutout : NSObject 
{
	UIView* view;
	
	float ax;
	float ay;
	
	float vx;
	float vy;
	
	float horizontalMuK;
	float verticalMuK;
	
	float springX;
	float springY;
	
	float horizontalSpringK;	
	float verticalSpringK;
}


//::Public
- (id)initWithView:(UIView*)view;

- (void) update;
- (void) updateWithExternalForceX:(float)externalForceX externalForceY:(float)externalForceY;
-(void)attachHorizontalSpringWithConstant:(float)k x:(float)x;
-(void) attachVerticalSpringWithConstant:(float)k y:(float)y;

@property (assign) float x;
@property (assign) float y;

@property (assign) float ax;
@property (assign) float ay;

@property (assign) float vx;
@property (assign) float vy;

@property (assign) float horizontalMuK;
@property (assign) float verticalMuK;
@property (readonly) UIView* view;


//::Private

@end
