//
//  PhysicalView.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/17/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "PhysicalView.h"

#import <math.h>

#define kSensitivity 0.1

@implementation PhysicalView

@synthesize behavePhysically;
//WebScriptObject
- (id)initWithFrame:(CGRect)frame 
{
    if (self = [super initWithFrame:frame]) 
	{
		physicalCutouts = [[NSMutableArray alloc] initWithCapacity:0];
		
		self.backgroundColor = [UIColor clearColor];
			
		
		[[UIAccelerometer sharedAccelerometer] setDelegate:self];
		[[UIAccelerometer sharedAccelerometer]	setUpdateInterval:0.05];
		
		
		[NSTimer scheduledTimerWithTimeInterval: 0.02f 
										 target: self 
									   selector: @selector(onEnterFrame) 
									   userInfo: nil 
										repeats: YES];
    }
    return self;
}

- (void) addPhysicalCutout:(PhysicalCutout*)pc
{
	[self addSubview:pc.view];
	[physicalCutouts addObject:pc];
}

- (void)accelerometer:(UIAccelerometer*)accelerometer didAccelerate:(UIAcceleration*)acceleration
{
	double ax = acceleration.x;
	double ay = acceleration.y;
	Fx = ax*5;
	Fy = ay*5;
}

- (void)onEnterFrame
{
	//////////NSLog(@"Updating with force %f", Fx);
	
	if(behavePhysically)
	{
		for(int i = 0; i < [physicalCutouts count]; i++)
		{
			PhysicalCutout* pc = [physicalCutouts objectAtIndex:i]; 
			[pc updateWithExternalForceX:Fx externalForceY:Fy];
		}
	}
}



- (void)dealloc 
{
	[physicalCutouts release];
    [super dealloc];
}


@end
