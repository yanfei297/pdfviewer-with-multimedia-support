//
//  LoadingView.h
//  MichaelJackson
//
//  Create by Andrew Paul Simmons on 7/9/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
#import "fontnames.h"

@interface LoadingView : UIView 
{
	
	UIView* background;
	UILabel* loadingText;
	
}


@property(assign) NSString* text;

- (void) startAnimating;
- (void) stopAnimating;
- (BOOL) isAnimating;
@end
