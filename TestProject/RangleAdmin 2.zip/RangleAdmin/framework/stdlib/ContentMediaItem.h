//
//  MediaItem.h
//  EyeReport
//
//  Create by Andrew Paul Simmons Simmons on 10/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ContentMediaItem : NSObject 
{
	NSString* contentID;
	NSString* title;
	NSString* description;
	NSString* username;
	NSString* numComments;
	NSString* tags;
	NSString* date;
	NSString* contentPage;
	NSString* thumbnail;
	NSString* image;
	NSString* original;
	NSString* mp4;
	NSString* collectionName;
	CGSize imageSize;
	CGSize originalImageSize;
	NSNumber* index;
	NSDictionary* propertyTags;
	
	NSString *fileSize;
	NSString *contentDuration;
}

@property(copy) NSDictionary* propertyTags;
@property(copy) NSString* contentID;
@property(copy) NSString* title;
@property(copy, getter=_description, setter=_setDescription:) NSString* description;
@property(copy) NSString* username;
@property(copy) NSString* numComments;
@property(copy) NSString* tags;
@property(copy) NSString* date;
@property(copy) NSString* contentPage;
@property(copy) NSString* thumbnail;
@property(copy) NSString* image;
@property(copy) NSString* original;
@property(copy) NSString* mp4;
@property(copy) NSString* collectionName;
@property(copy) NSNumber* index;

@property(assign) CGSize imageSize;
@property (assign) CGSize originalImageSize;


@property (copy) NSString *fileSize;
@property (copy) NSString *contentDuration;

@end
