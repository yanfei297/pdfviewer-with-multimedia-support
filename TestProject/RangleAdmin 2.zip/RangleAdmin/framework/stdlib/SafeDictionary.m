
#import "SafeDictionary.h"


@implementation SafeDictionary

- (id) initWithDictionary:(NSDictionary*)aDictionary
{
	if(self = [super init])
	{
		if([aDictionary isKindOfClass:[NSDictionary class]])
		{

			mutableDictionary = [[NSMutableDictionary dictionaryWithDictionary:aDictionary] retain];
		}
		else 
		{
			////NSLog(@"Could not set internal dictionary as %@ is not of type Dictionary", aDictionary);
		}
	}
	return self;
}


+ (SafeDictionary*) safeDictionaryWithDictionary:(NSDictionary*)aDictionary
{
	return [[[SafeDictionary alloc] initWithDictionary:aDictionary] autorelease];
}

- (NSMutableDictionary*) mutableDictionary
{
	return mutableDictionary;
}

- (BOOL) isValid
{
	return !!mutableDictionary;
}


- (NSString*) stringForKey:(NSString*)aKey // nil strings are converted to empty strings like: @""
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::stringForKey: Warning: internal dictionary is nil");
		return @"";
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return @"";
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: nil value found for key %@", aKey);
		return @"";
	}
	
	else if(!([value_obj isKindOfClass:[NSString class]] || [value_obj isKindOfClass:[NSNumber class]] ) )
	{
		////NSLog(@"SafeDictionary::stringForKey Warning: non-string value found for key %@", aKey);
		return @"";
	}
	
	return [value_obj description]; // take desciption just incase it's a numer
	
}

- (BOOL) stringIsDefinedForKey:(NSString*)aKey // returns false when string at index is nil
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey: Warning: internal dictionary is nil");
		return NO;
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey Warning: nonString key used to access object with method stringIsDefinedForKey for internal dictionary %@",  mutableDictionary);
		return NO;
	}
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(![value_obj isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::stringIsDefinedForKey Warning: non-string value found for key %@", aKey);
		return NO;
	}
	
	
	return (value_obj != nil);
	
}

- (SafeArray*) safeArrayForKey:(NSString*)aKey
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::safeArrayForKey: Warning: internal dictionary is nil");
		return nil;
	}
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::safeArrayForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return nil;
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SafeDictionary::safeArrayForKey Warning nil value found for key %@", aKey);
		return nil;
	}
	else if(!([value_obj isKindOfClass:[NSArray class]] || [value_obj isKindOfClass:[SafeArray class]] ))
	{
		////NSLog(@"SafeDictionary::safeArrayForKey Warning non-array value found for key %@", aKey);
		return nil;
	}
	if([value_obj isKindOfClass:[SafeArray class]])
	{
		return (SafeArray*)value_obj;
	}
	else
	{
		return [[[SafeArray alloc] initWithArray:value_obj] autorelease];
	}
}

- (SafeDictionary*) safeDictionaryForKey:(NSString*)aKey
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::safeDictionaryForKey: Warning: internal dictionary is nil");
		return nil;
	}	
	// key must be a string
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::safeDictionaryForKey Warning: nonString key used to access object from dictionary %@", mutableDictionary);
		return nil;
	}
	
	id value_obj = [mutableDictionary objectForKey:aKey];
	if(value_obj == nil)
	{
		////NSLog(@"SafeDictionary::safeDictionaryForKey Warning nil value found for key %@", aKey);
		return nil;
	}
	else if(!([value_obj isKindOfClass:[NSDictionary class]] || [value_obj isKindOfClass:[SafeDictionary class]] ))
	{
		////NSLog(@"SafeDictionary::safeDictionaryForKey Warning non-dictionary value found for key %@", aKey);
		return nil;
	}
	if([value_obj isKindOfClass:[SafeDictionary class]])
	{
		return (SafeDictionary*)value_obj;
	}
	else
	{
		return [[[SafeDictionary alloc] initWithDictionary:value_obj] autorelease];
	}
}

- (void) setObject:(id)anObject forKey:(NSString*)aKey // if object is nil, simply does nothing
{
	
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning: internal dictionary is nil");
		return;
	}
	
	if(![aKey isKindOfClass:[NSString class]])
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning: ignored attempt to use nonString key to set object %@", anObject);
		return;
	}
	
	if(anObject == nil)
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning ignored attempt to set nil object for key %@", aKey);
		return;
	}
	
	if(![mutableDictionary isKindOfClass:[NSDictionary class]])
	{
		////NSLog(@"SafeDictionary::setObject:forKey: Warning attempted to set object on non-dictionary!");
		return;
	}
	
	[mutableDictionary setObject:anObject forKey:aKey];

}
- (NSArray*) allKeys
{
	if(!mutableDictionary)
	{
		////NSLog(@"SafeDictionary::allKeys: Warning: internal dictionary is nil");
		return nil;
	}	
	
	if(![mutableDictionary isKindOfClass:[NSDictionary class]])
	{
		////NSLog(@"SafeDictionary::allKeys Warning non-dictionary value found for internal dictionary!");
		return nil;
	}
	return [mutableDictionary allKeys];
}

- (NSUInteger)count
{
	return [mutableDictionary count];
}


- (NSString*)description
{
	return [NSString stringWithFormat:@"<SafeDictionary> mutableDictionary contents: %@", [mutableDictionary description]];
}

- (void)dealloc 
{
	[mutableDictionary release];
    [super dealloc];
}



@end
