//
//  RatingStars.h
//  Qwiket
//
//  Created by steve on 9/9/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"


@interface RatingStars : UIView {
	UIImageView* background;
	UIImageView* foreground;
	UIImageView* stars;
	CGFloat rating;
	BOOL selectable; 
}

- (id) initWithRating:(CGFloat)_rating;
- (void) setRatingWithPixelPosition:(NSInteger)pixelPosition;
- (void) setRating:(CGFloat)_rating;
@property(assign) CGFloat rating;
@end
