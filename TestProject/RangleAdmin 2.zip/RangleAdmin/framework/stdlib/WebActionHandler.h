//
//  WebActionHandler.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/17/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "constants.h"
#import "RestoreableViewController.h"
#import "Utils.h"
#define WebAction void   // a method invoked by a webview



@interface WebActionHandler : RestoreableViewController <UIWebViewDelegate> 
{
	NSURL* lastExteranalURL;
	BOOL supressLaunchExternal;
	UIAlertView* exitAndLaunchSafari_av;
	UIAlertView* loadFailure_av;
	BOOL supressNonConnectionFailureErrorAlerts;
	//BOOL loadErrorDisplayed;
}

//::Public


//::Protected 
@property(readonly) NSURL* lastExteranalURL;
- (void) retryLoadAfterFailure;

// Invoked: when host is not (about:blank or linkdomain)  
// return YES to launch in safari 
- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString;

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType;

//::Private

@end
