//
//  APSPictureShowImageData.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/13/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "APSPictureShowImageData.h"


@implementation APSPictureShowImageData

@synthesize title, caption, byline, url;


- (NSString*) description
{
	return [NSString stringWithFormat:@"title:%@, caption:%@, byline:%@, url:%@", title, caption, byline, url];
}

- (void)dealloc
{
	[title release];
	[caption release];
	[byline release];
	[url release];
	
	[super dealloc];
}
@end
