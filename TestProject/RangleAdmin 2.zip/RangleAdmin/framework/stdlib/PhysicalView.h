//
//  PhysicalView.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/17/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import <QuartzCore/QuartzCore.h>
#import "AccelerometerSimulation.h"
#import "PhysicalCutout.h"

@interface PhysicalView : UIView  <UIAccelerometerDelegate> 
{
	
	NSMutableArray* physicalCutouts;
	
	BOOL behavePhysically;
	
	float oldAccelerationX;
	float oldAccelerationY;
	float Fx;
	float Fy;
	
	float alpha;
	float omega;
	float theta;
}


//::Public
@property(assign) BOOL behavePhysically;


//::Private
- (void) addPhysicalCutout:(PhysicalCutout*)pc;
@end
