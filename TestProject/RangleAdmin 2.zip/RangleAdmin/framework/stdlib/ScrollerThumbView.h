//
//  ScrollerThumbView.h
//  eMagazine
//
//  Created by SMB on 21/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol ScrollerThumbViewDelegate

-(void)thumbViewDidReceiveTapAt:(int)page;

@end


@interface ScrollerThumbView : UIView<UIScrollViewDelegate> {
	UIScrollView *scrollView;
	id<ScrollerThumbViewDelegate> delegate;
	NSMutableArray *thumbURLs;
}
@property (nonatomic, retain) id<ScrollerThumbViewDelegate> delegate;
- (id)initWithFrame:(CGRect)frame;
- (int)getNumOfThumbs;
- (NSString*)getResourcePath;
- (void)drawThumbs;
-(void)didTapOnThumb:(UIButton*)but;
@end
