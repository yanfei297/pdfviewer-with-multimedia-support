//
//  ListCell.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/8/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "ListCell.h"
#import "fontnames.h"

@implementation ListCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier 
{
    if( self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]  ) 
	{
		int imageWidth = 75;
		int imageHeight = 56;
		int textPadding = 20;
		
		//Text
		titleText_lb = [[[UILabel alloc] initWithFrame:CGRectMake(imageWidth + textPadding, 7, 200, 50)] autorelease];
		titleText_lb.numberOfLines = 0;
		titleText_lb.font = [UIFont fontWithName:FONTNAME_helvetica size:15];
		titleText_lb.backgroundColor = [UIColor clearColor];
		titleText_lb.textColor = [Utils colorFromHex:0x233F65];
		[self addSubview:titleText_lb];
		
		//Thumbnail
		CGRect imageHolderFrame = CGRectMake(7, 5, imageWidth, imageHeight);
		CGRect imageFrame = CGRectMake(0, 0, imageWidth, imageHeight);
		webImage = [[[APSWebImageView alloc] initWithFrame:imageFrame] autorelease];
		webImageHolder = [[[UIView alloc] initWithFrame:imageHolderFrame] autorelease];
		[webImageHolder addSubview:webImage];
		webImage.backgroundColor = [UIColor clearColor];
		webImageHolder.backgroundColor = [Utils colorFromImageName:@"cbsnewsThumbnailLogo.png"];
		[self addSubview:[Utils imageViewWithImageName:@"separatorLineLight.png"]];
		[self addSubview:webImageHolder];
		self.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		self.selectionStyle = UITableViewCellSelectionStyleNone;
		
		
    }
    return self;
}


+ (NSString*) cellType
{
	return @"ListCell";
}


- (void)layoutSubviews
{
	[super layoutSubviews];
	self.backgroundColor = [UIColor whiteColor];
	
}


+ (int) cellHeight
{
	return  (56 + 2 * 5);
}


- (void) setTitleText:(NSString*)value
{
	titleText_lb.text = value;
}


- (NSString*) titleText
{	
	return titleText_lb.text;
}


- (void) setThumbnailURL:(NSString*)url
{
	//NSLog(@"Thumbnail Set");
	[webImage loadAndCacheImageWithStringURL:url];
}


- (NSString*) thumbnailURL
{
	return thumbnailURL;
}


- (void) setDictionary:(SafeDictionary*)safeDict
{
	dictionary = [safeDict retain];
	self.titleText = [safeDict stringForKey:@"title"];
	self.thumbnailURL = [safeDict stringForKey:@"thumbnail"];

}


- (NSDictionary*) dictionary
{
	return dictionary;
}


-(void)cellDidAppear
{
	//NSLog(@"Cell with text \"%@\" did appear!", self.titleText);
}

-(void)cellDidDissappear
{
	//NSLog(@"Cell with text \"%@\" did disappear!", self.titleText);
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
	if(selected)
	{
		self.backgroundColor = [UIColor lightGrayColor];
		titleText_lb.textColor = [UIColor whiteColor];
	}
	else
	{
		self.backgroundColor = [UIColor whiteColor];
		titleText_lb.textColor = [Utils colorFromHex:0x233F65];
	}
	
}


- (void)setHighlighted:(BOOL)highlighted animated:(BOOL)animated
{
	[super setHighlighted:highlighted animated:animated];
	
	if(highlighted)
	{
		self.backgroundColor = [UIColor lightGrayColor];
		titleText_lb.textColor = [UIColor whiteColor];
	}
	else 
	{
		self.backgroundColor = [UIColor whiteColor];
		titleText_lb.textColor = [Utils colorFromHex:0x233F65];
	}
	
}


- (void)dealloc 
{
	[dictionary release];
    [super dealloc];
}


@end
