//
//  TextOnlyListItem.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/7/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TreemoTableCellProtocol.h"

@interface TextOnlyListCellDark : UITableViewCell <TreemoTableCellProtocol>
{

	UILabel* titleText_lb;
	NSDictionary* dictionary;

}

//::Public 


- (void)setDictionary:(NSDictionary*)dict;
- (NSDictionary*)dictionary;

- (void)cellDidAppear;
- (void)cellDidDissappear;

+ (NSString*) cellType;
+ (int) cellHeight;


@property(assign) NSString* titleText;


@end
