//
//  ColoredTableViewCell.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/26/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ColoredTableViewCell : UITableViewCell 
{
	UIColor* retainedBackgroundColor;

}

@property(retain) UIColor* retainedBackgroundColor;

@end
