//
//  WebActionDelegate.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/18/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Utils.h"
#import "constants.h"

#define WebAction void

@interface WebActionDelegate : NSObject  <UIWebViewDelegate> 
{
	NSURL* lastExteranalURL;
	BOOL supressLaunchExternal;
	UIAlertView* exitAndLaunchSafari_av;
	UIAlertView* loadFailure_av;
	BOOL supressNonConnectionFailureErrorAlerts;
	id delegate;
}


//::Public
//when initialized with a delegate object,the WebActionDelegate will "forward"
// some webview events to the "aDelegate" object.
// (Note: If a new method needs to be forwarded just add it in.)
- (id)initWithDelegate:(id)aDelegate;

+(NSString*) webActionReplacementHREFWithWebActionName:(NSString*)webActionName 
										  withLinkText:(NSString*)linkText
											 withParam:(NSString*)paramOne;

+ (NSString*) webActionReplacementHREFWithWebActionName:(NSString*)webActionName 
										   withLinkText:(NSString*)linkText
											  withParam:(NSString*)paramOne 
											  withParam:(NSString*)paramTwo;										  


//::Protected 
@property(readonly) NSURL* lastExteranalURL;
- (void) retryLoadAfterFailure;

// Invoked: when host is not (about:blank or linkdomain)  
// return YES to launch in safari 
- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString;

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType;


//::Private
+ (NSString*) webActionWithName:(NSString*)webActionName withParam:(NSString*)paramOne;

+ (NSString*) webActionWithName:(NSString*)webActionName 
					  withParam:(NSString*)paramOne 
					  withParam:(NSString*)paramTwo;

- (void) clearDelegate;

@end
