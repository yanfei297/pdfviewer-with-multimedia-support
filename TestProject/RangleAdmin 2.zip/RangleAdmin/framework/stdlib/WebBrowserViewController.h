//
//  WebBrowserViewController.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/16/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RestoreableViewController.h"
#import "FadeNavigationController.h"

@interface WebBrowserViewController : RestoreableViewController <UIWebViewDelegate>
{
	IBOutlet UIWebView* myWebView;
	
	IBOutlet UIToolbar* toolBar;
	IBOutlet UIBarButtonItem* back;
	IBOutlet UIBarButtonItem* forward;
	IBOutlet UIBarButtonItem* hide;
	IBOutlet UIBarButtonItem* home;
	IBOutlet UIBarButtonItem* refresh;
	
	UIAlertView* noInternetAlert;
	
	IBOutlet UIActivityIndicatorView* connectingAnimation_ai;
	NSString* startLocation;
	BOOL loadPaused;
	BOOL viewClosed;
	UIBarButtonItem* camera_btn;

	id actionTarget;
	SEL onSelectReport;
	
	UINavigationController* myNavigationController;
}

//::Public
@property(copy) NSString* startLocation;
@property(assign) id actionTarget;
@property(assign) SEL onSelectReport;
@property(assign) UINavigationController* myNavigationController;

//::Private
- (id)doInit;
- (void) loadURLString:(NSString*)urlString;
- (IBAction) onBack:(id)sender;
- (IBAction) onForward:(id)sender;
- (IBAction) onHide:(id)sender;
- (IBAction) onReport:(id)sender;
- (IBAction) onRefresh:(id)sender;
- (IBAction) onHome:(id)sender;

@end
