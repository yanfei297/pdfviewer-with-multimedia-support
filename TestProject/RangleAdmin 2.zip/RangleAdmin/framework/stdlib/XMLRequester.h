//
//  XMLRequester.h
//  SwamiParthSarathi
//
//  Created by Sayan on 30/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Requester.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

@interface XMLRequester : Requester

//- (ASIHTTPRequest *)getASIHttpRequsetForFaceBookLoginWithDidFinishSelector:(SEL) action;
//- (ASIHTTPRequest *)getASIHttpRequsetForChallengeFriendWithDidFinishSelector:(SEL) action;

- (ASIHTTPRequest *)getASIHttpRequestWithDidFinishSelector:(SEL) action;
- (ASIFormDataRequest *)getASIFormDataRequestWithPostBody:(NSDictionary *)postdata DidFinishSelector:(SEL) action;
@end
