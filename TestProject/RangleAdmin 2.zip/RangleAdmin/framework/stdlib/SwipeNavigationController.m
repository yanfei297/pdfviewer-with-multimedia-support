    //
//  SwipeNavigationController.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/9/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "SwipeNavigationController.h"

@interface SwipeNavigationController (PrivateMethods)

- (void)loadScrollViewWithPage:(int)page;
- (void)scrollViewDidScroll:(UIScrollView *)sender;

@end

//static NSUInteger numPages = 7;

@implementation SwipeNavigationController

@synthesize viewControllers, pageControl, scrollView;

- (id)initWithViewControllers:(NSArray *)someViewControllers 
{	
	////NSLog(@"Swipe Navigation Controller Initialized With %@", someViewControllers);
	if(self = [super init])
	{
		[self setSwipeViewControllers:someViewControllers];
	}
	return self;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	//[controllers release];
	numPages = [self.viewControllers count];
	// a page is the width of the scroll view
	scrollView = [[[UIScrollView alloc] initWithFrame:CGRectMake(-spaceBetweenPages, 0 + uiTopOffset, 320 + 2*spaceBetweenPages, self.view.bounds.size.height)] autorelease];
	scrollView.pagingEnabled = YES;
	scrollView.contentSize = CGSizeMake(scrollView.frame.size.width * numPages, scrollView.frame.size.height);
	scrollView.showsHorizontalScrollIndicator = NO;
	scrollView.showsVerticalScrollIndicator = NO;
	scrollView.scrollsToTop = NO;
	scrollView.delegate = self;
	[self.view addSubview:scrollView];
	pageControl = [[[UIPageControl alloc] initWithFrame:CGRectMake(0,0 + uiTopOffset,320,50)] autorelease];
	pageControl.numberOfPages = numPages;
	pageControl.currentPage = 0;
	[self.view addSubview:pageControl];
	
	// pages are created on demand
	// load the visible page
	// load the page on either side to avoid flashes when the user starts scrolling
	[self loadScrollViewWithPage:0];
	[self loadScrollViewWithPage:1];
}

- (void) setSwipeViewControllers:(NSArray*)someViewControllers
{
	spaceBetweenPages = 14;
	self.viewControllers = [someViewControllers retain];
	numPages = [someViewControllers count];
}

- (void)loadScrollViewWithPage:(int)page 
{
    if (page < 0) return;
    if (page >= numPages) return;
	
    // replace the placeholder if necessary
	
    UIViewController* controller = [viewControllers objectAtIndex:page];
	
	/*
    if ((NSNull *)controller == [NSNull null]) {
        controller = [[MyViewController alloc] initWithPageNumber:page];
        [viewControllers replaceObjectAtIndex:page withObject:controller];
        [controller release];
    }
	*/
	
    // add the controller's view to the scroll view
    if (nil == controller.view.superview) 
	{
        CGRect frame = scrollView.frame;
        frame.origin.x = frame.size.width * page + spaceBetweenPages;
        frame.origin.y = 0;
        controller.view.frame = frame;
		//[Utils view:controller.view setX:00];
        [scrollView addSubview:controller.view];
		
    }
	[controller viewDidAppear:NO];
}


- (void) unloadScrollViewWithPage:(int)page 
{
	if (page < 0) return;
    if (page >= numPages) return;
	
	UIViewController* controller = [viewControllers objectAtIndex:page];
	/*
	if (controller.view.superview) 
	{
		[controller.view removeFromSuperview];
		[controller viewDidDisappear:NO];
	}
	 */
	[controller viewDidDisappear:NO];
	
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    // We don't want a "feedback loop" between the UIPageControl and the scroll delegate in
    // which a scroll event generated from the user hitting the page control triggers updates from
    // the delegate method. We use a boolean to disable the delegate logic when the page control is used.
    if (pageControlUsed) {
        // do nothing - the scroll was initiated from the page control, not the user dragging
        return;
    }
	
    // Switch the indicator when more than 50% of the previous/next page is visible
    CGFloat pageWidth = scrollView.frame.size.width;
    int page = floor((scrollView.contentOffset.x - pageWidth / 2) / pageWidth) + 1;
	if(pageControl.currentPage != page)
	{
		pageControl.currentPage = page;
		[self pageDidChange:page];
	}
	
	
    // load the visible page and the page on either side of it (to avoid flashes when the user starts scrolling)
    [self loadScrollViewWithPage:page];
	[self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page + 1];  
	[self removeDistantViewsFromViewAtIndex:page];
	
    // A possible optimization would be to unload the views+controllers which are no longer visible
}

- (void) removeDistantViewsFromViewAtIndex:(int)index
{
	for(int i = 0; i < numPages; i++)
	{
		if(abs(index - i) > 1)
		{
			[self unloadScrollViewWithPage:i];
			

		}
	}
}



// At the begin of scroll dragging, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    pageControlUsed = NO;
}

// At the end of scroll animation, reset the boolean used when scrolls originate from the UIPageControl
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    pageControlUsed = NO;
}

- (void) navigateToNextPage
{
	pageControl.currentPage++;
	[self changePage:self];
}

- (void) navigateToPreviousPage
{
	pageControl.currentPage--;
	[self changePage:self];
}

- (IBAction)changePage:(id)sender {
	
    int page = pageControl.currentPage;
	[self pageDidChange:page];
    // load the visible page and the page on either side of it (to avoid flashes when the user starts scrolling)
    [self loadScrollViewWithPage:page];
	[self loadScrollViewWithPage:page - 1];
    [self loadScrollViewWithPage:page + 1];
	[self removeDistantViewsFromViewAtIndex:page];
    
	// update the scroll view to the appropriate page
    CGRect frame = scrollView.frame;
    frame.origin.x = frame.size.width * page;
    frame.origin.y = 0;
    [scrollView scrollRectToVisible:frame animated:YES];
    
	// Set the boolean used when scrolls originate from the UIPageControl. See scrollViewDidScroll: above.
    pageControlUsed = YES;
}

-(void)pageDidChange:(int)newPageNumber
{
	
}

/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/





// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
	////NSLog(@"Should Autorotate To Interface Orientation");
    return NO;// (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void)viewWillAppear:(BOOL)animated 
{
	[super viewWillAppear:animated];
	/*
	[[UIDevice currentDevice] beginGeneratingDeviceOrientationNotifications];
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(receivedRotate:) 
												 name:UIDeviceOrientationDidChangeNotification object:nil];
	 */
}


float degreesToRadian(float degrees)
{
	return degrees * 3.14159265f/180.0f;
}

// How to do a real orientation change!!!
- (void) receivedRotate: (NSNotification *) notification 
{
	[Utils recordToAnimate];
	UIDeviceOrientation interfaceOrientation = [[UIDevice currentDevice] orientation];
	self.view.center = CGPointMake(160.0f,240.0f);
	if(interfaceOrientation == UIDeviceOrientationPortrait) 
	{
		self.view.transform = CGAffineTransformMakeRotation(degreesToRadian(0));
		self.view.bounds = CGRectMake(0, 0, 320, 480);
	}
	else if(interfaceOrientation == UIDeviceOrientationPortraitUpsideDown)
	{
		self.view.transform = CGAffineTransformMakeRotation(degreesToRadian(180));
		self.view.bounds = CGRectMake(0, 0, 320, 480);
	}
	else if(interfaceOrientation == UIDeviceOrientationLandscapeLeft) 
	{
		self.view.transform = CGAffineTransformMakeRotation(degreesToRadian(90));
		self.view.bounds = CGRectMake(0, 0, 480, 320);
	}
	else if(interfaceOrientation == UIDeviceOrientationLandscapeRight) 
	{
		self.view.transform = CGAffineTransformMakeRotation(degreesToRadian(-90));
		self.view.bounds = CGRectMake(0, 0, 480, 320);
	}
	[UIApplication sharedApplication].statusBarOrientation = interfaceOrientation;
	[Utils animate];
}


- (void)didReceiveMemoryWarning {
    // Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
    
    // Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}


- (void)dealloc {
    [super dealloc];
}


@end
