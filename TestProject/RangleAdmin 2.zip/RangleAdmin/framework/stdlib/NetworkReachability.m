//
//  NetworkReachability.m
//  Andrew_CBSNews
//
//  Created by steve on 8/31/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "NetworkReachability.h"


@implementation NetworkReachability

+ (NetworkStatus) reachabilityForLocalWiFi;
{
	////////NSLog(@"in check for local wifi.");
	struct sockaddr_in localWifiAddress;
	bzero(&localWifiAddress, sizeof(localWifiAddress));
	localWifiAddress.sin_len = sizeof(localWifiAddress);
	localWifiAddress.sin_family = AF_INET;
	// IN_LINKLOCALNETNUM is defined in <netinet/in.h> as 169.254.0.0
	localWifiAddress.sin_addr.s_addr = htonl(IN_LINKLOCALNETNUM);
	SCNetworkReachabilityFlags flags;
	SCNetworkReachabilityRef reachabilityRef = [self reachabilityWithAddress: &localWifiAddress];
	if(SCNetworkReachabilityGetFlags(reachabilityRef, &flags))
	{
		if((flags & kSCNetworkReachabilityFlagsReachable) && (flags & kSCNetworkReachabilityFlagsIsDirect))
		{
			return NETREAC_ReachableViaWiFi;
		}
	}
	////////NSLog(@"Wifi not reachable!");
	return NETREAC_NotReachable;
	
}

+ (NetworkStatus) reachabilityForNetwork
{
	////////NSLog(@"in check for network connectivity.");
	struct sockaddr_in zeroAddress;
	bzero(&zeroAddress, sizeof(zeroAddress));
	zeroAddress.sin_len = sizeof(zeroAddress);
	zeroAddress.sin_family = AF_INET;
	SCNetworkReachabilityFlags flags;
	SCNetworkReachabilityRef reachabilityRef = [self reachabilityWithAddress: &zeroAddress];
	if(SCNetworkReachabilityGetFlags(reachabilityRef, &flags))
	{
		if((flags & kSCNetworkReachabilityFlagsIsWWAN) == kSCNetworkReachabilityFlagsIsWWAN)
		{
			return NETREAC_ReachableViaWWAN;
		}
	}
	return NETREAC_NotReachable;
}

+ (SCNetworkReachabilityRef) reachabilityWithAddress: (const struct sockaddr_in*) hostAddress
{
	////////NSLog(@"atempting to get SCNetworkReachabilityRef");
	return SCNetworkReachabilityCreateWithAddress(kCFAllocatorDefault, (const struct sockaddr*)hostAddress);
}

//returns status of avaliable networks
+ (NetworkStatus) reachability
{
	////////NSLog(@"atempting ot run reacability:");
	return [self reachabilityForLocalWiFi] | [self reachabilityForNetwork];
}

@end
