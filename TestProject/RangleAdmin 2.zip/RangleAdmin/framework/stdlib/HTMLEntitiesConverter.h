//
//  HTMLEntitiesConverter.h
//  LimeLife
//
//  Create by Andrew Paul Simmons on 12/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>



@interface HTMLEntitiesConverter : NSObject 
{
	NSMutableString* resultString;
}

@property (nonatomic, retain) NSMutableString* resultString;
- (NSString*)convertEntiesInString:(NSString*)s;

@end
