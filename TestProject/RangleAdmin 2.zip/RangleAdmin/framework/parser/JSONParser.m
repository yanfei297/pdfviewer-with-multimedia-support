//
//  JSONParser.m
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import "JSONParser.h"
#import "SBJSON.h"


@implementation JSONParser

@synthesize recievedData;

-(id)initWithTarget:(id)sender{

	target = sender;
    hasAction = NO;
	recievedData = [NSMutableData new];
	if ([target isKindOfClass:[UIViewController class]] || [target isKindOfClass:[UIView class]]) {
		loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		loadingView.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.3];
		spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		[loadingView addSubview:spinner];
		spinner.center = CGPointMake(160, 240);
		if([target isKindOfClass:[UIViewController class]]){
			UIViewController *tempView = (UIViewController *)target;
			[tempView.view addSubview:loadingView];
		}
		else {
			UIView *tempView = (UIView *)target;
			[tempView addSubview:loadingView];
		}

	}
	return [self autorelease];
}

- (id)initWithTarget:(id)sender action:(SEL)action{
    target = sender;
    action_ = action;
    hasAction = YES;
	recievedData = [NSMutableData new];
	if ([target isKindOfClass:[UIViewController class]] || [target isKindOfClass:[UIView class]]) {
		loadingView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)];
		loadingView.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.3];
		spinner = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
		[loadingView addSubview:spinner];
		spinner.center = CGPointMake(160, 240);
		if([target isKindOfClass:[UIViewController class]]){
			UIViewController *tempView = (UIViewController *)target;
			[tempView.view addSubview:loadingView];
		}
		else {
			UIView *tempView = (UIView *)target;
			[tempView addSubview:loadingView];
		}
        
	}
	return [self autorelease];
}

/*- (void)stringWithUrl:(NSURL *)url {
	NSURLRequest *urlRequest = [NSURLRequest requestWithURL:url
												cachePolicy:NSURLRequestReturnCacheDataElseLoad
											timeoutInterval:30];
	// Fetch the JSON response
	NSData *urlData;
	NSURLResponse *response;
	NSError *error;
	
	// Make synchronous request
	urlData = [NSURLConnection sendSynchronousRequest:urlRequest
									returningResponse:&response
												error:&error];
	
	// Construct a String around the Data from the response
	return [[NSString alloc] initWithData:urlData encoding:NSUTF8StringEncoding];
}*/


- (void) parseJSON:(NSString *)jsonString {
	SBJSON *jsonParser = [SBJSON new];
	//NSString *jsonString = [self stringWithUrl:url];
	
	// Parse the JSON into an Object
	NSDictionary *feed = (NSDictionary *)[jsonParser objectWithString:jsonString error:NULL];
    if (hasAction) {
        [target performSelector:action_ withObject:feed];
    }
    else{
        [target performSelector:@selector(getJSONDictionary:) withObject:feed];
    }
	[jsonParser release];
}

+ (NSDictionary *) parseJSONFromJSONString:(NSString *)jsonString{
    SBJSON *jsonParser = [[SBJSON new] autorelease];

	// Parse the JSON into an Object
	return (NSDictionary *)[jsonParser objectWithString:jsonString error:NULL];
}

- (void ) downloadJSONFromURL:(NSString *)urlString{
	//id response = [self objectWithUrl:[NSURL URLWithString:urlString]];
	//@"http://fluorescent-monkey.com/app.php?action=getfaq"
	//NSDictionary *feed = (NSDictionary *)response;
	//NSLog(@"Feed : %@",feed);
	//return feed;
	if (loadingView) {
		[spinner startAnimating];
		UILabel *lab = [[UILabel alloc] initWithFrame:CGRectMake(35, 260, 250, 50)];
		lab.text = @"Page is Loading....Please Wait.";
		lab.textColor = [UIColor whiteColor];
		lab.font = [UIFont boldSystemFontOfSize:14];
		lab.textAlignment = UITextAlignmentCenter;
		lab.baselineAdjustment = UIBaselineAdjustmentAlignCenters;
		lab.backgroundColor = [UIColor clearColor];
		[loadingView addSubview:lab];
		[lab release];
	}
	
	NSLog(@"URL : %@",urlString);
	NSURLRequest *urlRequest = [NSURLRequest requestWithURL:[NSURL URLWithString:urlString]
												cachePolicy:NSURLRequestReturnCacheDataElseLoad
											timeoutInterval:30];

	// Fetch the JSON response Using A Asyncronus Connection

	[NSURLConnection connectionWithRequest:urlRequest delegate:self];
}

#pragma mark -
#pragma mark NSURLConnectionDelegate

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response{

	NSLog(@"HERE RESPONSE: %d",[(NSHTTPURLResponse*) response statusCode]);
	NSLog(@"response: %@",[response description]);
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{

	[recievedData appendData:data];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection{

	NSString *jsonString = [[[NSString alloc] initWithData:recievedData encoding:NSUTF8StringEncoding] autorelease];
    [self performSelector:@selector(parseJSON:) withObject:jsonString];
	if (loadingView) {
		[spinner stopAnimating];
		[loadingView removeFromSuperview];
	}
}

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{

	NSLog(@"ERROR: %@",[error description]);
	NSString *errorString = [error localizedDescription];
	NSDictionary *dict = [NSDictionary dictionaryWithObject:errorString forKey:@"error"];
	[target performSelector:@selector(getJSONDictionary:) withObject:dict];
	if (loadingView) {
		[spinner stopAnimating];
		[loadingView removeFromSuperview];
	}
}

-(void)dealloc{

	[recievedData release], recievedData = nil;
	[loadingView release], loadingView = nil;
	[super dealloc];
}

@end
