//
//  JSONParser.h
//  JSONParseTest
//
//  Created by Sayan Chatterjee on 18/03/11.
//  Copyright 2011 ObjectSol. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface JSONParser : NSObject {

	id target;
    SEL action_;
    BOOL hasAction;
	NSMutableData *recievedData;
	UIActivityIndicatorView *spinner;
	UIView *loadingView;
}

@property (nonatomic,retain) NSMutableData *recievedData;

-(id)initWithTarget:(id)sender;
- (id)initWithTarget:(id)sender action:(SEL)action;
//- (NSString *)stringWithUrl:(NSURL *)url ;
- (void) parseJSON:(NSString *)jsonString ;
+ (NSDictionary *) parseJSONFromJSONString:(NSString *)jsonString;
- (void ) downloadJSONFromURL:(NSString *)urlString;

@end
