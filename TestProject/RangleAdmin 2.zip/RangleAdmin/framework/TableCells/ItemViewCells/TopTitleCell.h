//
//  TopTitleCell.h
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/1/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"

@interface TopTitleCell : UITableViewCell 
{
	UILabel* title_lb;
	
	float height;
}

- (float) height;

@end
