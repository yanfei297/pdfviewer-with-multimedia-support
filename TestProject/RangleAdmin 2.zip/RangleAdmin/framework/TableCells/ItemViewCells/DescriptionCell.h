//
//  DescriptionCell.h
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/7/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Utils.h"

@interface DescriptionCell : UITableViewCell 
{
	UILabel* title_lb;
	UILabel* desc_lb;
	
	float height;

}


- (id) initWithTitle:(NSString*)title description:(NSString*)desc;


@end
