//
//  DescriptionCell.m
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/7/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "DescriptionCell.h"

#define kDescriptionCellIdentifier @"descriptionCell"

#define kTitleDescSpace 10
#define kBottomOffset 10
#define kTopOffset 10
@implementation DescriptionCell



- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier 
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) 
	{
        // Initialization code
    }	
    return self;
}


- (id) initWithTitle:(NSString*)title description:(NSString*)desc
{
	if(self = [self initWithFrame:CGRectZero reuseIdentifier:kDescriptionCellIdentifier])
	{
		title_lb = [[UILabel alloc] initWithFrame: CGRectMake(15, kTopOffset, 290, 0)];
		title_lb.font =  [UIFont boldSystemFontOfSize:14];
		title_lb.textColor = [UIColor grayColor];
		title_lb.backgroundColor = [UIColor clearColor];
		title_lb.numberOfLines = 0; //no maximum number of lines
		[Utils setLabel:title_lb withText:title maxHeight:INT_MAX];
		[self.contentView addSubview:title_lb];
		float descY = title_lb.frame.origin.y + title_lb.frame.size.height + kTitleDescSpace;
		desc_lb = [[UILabel alloc] initWithFrame:CGRectMake(15,descY , 290, 0)];
		desc_lb.font = [UIFont systemFontOfSize:12];
		desc_lb.textColor = [UIColor grayColor];
		desc_lb.backgroundColor = [UIColor clearColor];
		desc_lb.numberOfLines = 0; //no maximum number of lines
		[Utils setLabel:desc_lb withText:desc maxHeight:INT_MAX];
		
		height = title_lb.frame.origin.y +
					title_lb.frame.size.height + 
					kTitleDescSpace +
					desc_lb.frame.size.height +
					kBottomOffset;
		
		
		[self.contentView addSubview:desc_lb];
		self.backgroundColor = [UIColor groupTableViewBackgroundColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	
	return self;
}


- (float) height
{
	return height;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews 
{
    [super layoutSubviews];
	self.backgroundColor = [UIColor groupTableViewBackgroundColor];
}


- (void)dealloc {
    [super dealloc];
}


@end
