//
//  TopTitleCell.m
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/1/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "TopTitleCell.h"


#define kTopTitleCellIdentifier @"topTableCell"
#define kTopOffset 10
#define kBottomOffset 10

@implementation TopTitleCell

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier 
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) 
	{
        // Initialization code
    }
    return self;
}

- (id) initWithTitle:(NSString*)title
{
	if(self = [self initWithFrame:CGRectZero reuseIdentifier:kTopTitleCellIdentifier])
	{
		title_lb = [[UILabel alloc] initWithFrame:CGRectMake(15, kTopOffset, 290, 0)];
		title_lb.font =  [UIFont boldSystemFontOfSize:15];
		title_lb.textColor = [UIColor grayColor];
		title_lb.backgroundColor = [UIColor clearColor];
		title_lb.numberOfLines = 0; //no maximum number of lines
		[Utils setLabel:title_lb withText:title maxHeight:80];
		[self.contentView addSubview:title_lb];
		self.backgroundColor = [UIColor groupTableViewBackgroundColor];
		height = title_lb.frame.origin.y + title_lb.frame.size.height + kBottomOffset;
		self.selectionStyle = UITableViewCellSelectionStyleNone;
	}
	
	return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];
 
    // Configure the view for the selected state
}

- (void)layoutSubviews 
{
    [super layoutSubviews];
	self.backgroundColor = [UIColor blackColor];
}

- (NSString*) reuseIdentifier
{
	return kTopTitleCellIdentifier;
}

- (float) height
{
	return height;
}

- (void)dealloc 
{
    [super dealloc];
}


@end
