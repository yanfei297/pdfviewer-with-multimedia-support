//
//  ThumbnailCell.m
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/8/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "ThumbnailCell.h"

@implementation ThumbnailCell

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
        // Initialization code
    }
    return self;
}

- (id) initWithFullImageSize:(CGSize)size thumbnail:(UIImage*)thumbnail
{	
	//if (self = [super initWithFrame:CGRectZero reuseIdentifier:@"thumbnailCell"]) 
    if (self = [super initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"thumbnailCell"]) {
 	
		imageSize = size;
		thumbnail_iv = [[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 320)] autorelease];
		[self addSubview:thumbnail_iv];
		
		thumbnail_iv.image = thumbnail;
		
		// this calculation was pulled from other code and could be tightened up a bit.
		CGRect f = CGRectZero;
		f.size = imageSize;
		if(imageSize.width >= 320.0f)
		{
			float scale = 320.0f/imageSize.width;
			f.size.width = 320.0f;
			f.size.height = imageSize.height*scale;
		}
		else
		{
			f.origin.x = (320.0f - imageSize.width)/2;
		}

		
		if(f.size.height < 320)
		{
			f.size.width = f.size.height;
			f.origin.x = (320.0f - f.size.width)/2;
		}
		else
		{
			f.size.height = f.size.width; // thumb is always a square!
		}
		
		thumbnail_iv.frame = f;
		height = f.size.height;
		
		self.backgroundColor = [UIColor blackColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
	return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {

    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)layoutSubviews 
{
    [super layoutSubviews];
	self.backgroundColor = [UIColor blackColor];
}

- (float)height
{
	return height;
}

- (void)dealloc {
    [super dealloc];
}


@end
