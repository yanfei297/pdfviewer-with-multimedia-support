//
//  ImageTableCell.h
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/2/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "APSWebImageView.h"

@interface ImageTableCell : UITableViewCell 
{

	float height;
	/*
	UIImageView* thumbnail_iv;
	APSWebImageView* image_wiv;
	*/
	//CGSize imageSize;
}

//::Public
- (float) height;
- (id) initWithWebImageView:(APSWebImageView*)webImageView;
+ (NSString*) reuseIdentifier;
//- (void) unload;

//::Private

@end
