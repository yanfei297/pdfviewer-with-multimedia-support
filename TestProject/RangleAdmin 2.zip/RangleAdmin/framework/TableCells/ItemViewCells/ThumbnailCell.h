//
//  ThumbnailCell.h
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/8/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ThumbnailCell : UITableViewCell 
{
	UIImageView* thumbnail_iv;
	float height;
	CGSize imageSize;
}

- (id) initWithFullImageSize:(CGSize)size thumbnail:(UIImage*)thumbnail;
- (float) height;

@end
