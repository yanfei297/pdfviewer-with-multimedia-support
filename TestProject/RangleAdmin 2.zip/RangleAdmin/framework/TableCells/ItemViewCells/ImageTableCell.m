//
//  ImageTableCell.m
//  SeelebrityNative
//
//  Create by Andrew Paul Simmons on 12/2/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "ImageTableCell.h"

#define kReuseIdentifier @"imageTableCell"

@implementation ImageTableCell


- (NSString*) reuseIdentifier
{
	return kReuseIdentifier;
}

- (id) initWithWebImageView:(APSWebImageView*)webImageView
{
	
	if (self = [super initWithFrame:CGRectZero reuseIdentifier:kReuseIdentifier]) 
	{
		[self addSubview:webImageView];
		height = webImageView.frame.size.height;
		self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
	return self;
}

/*
- (id) initWithImageSize:(CGSize)size imageURLString:(NSString*)imageURL
{
	
	if (self = [super initWithFrame:CGRectZero reuseIdentifier:kReuseIdentifier]) 
	{
		imageSize = size;
		image_wiv = [[[APSWebImageView alloc] initWithFrame:CGRectMake(0, 0, 320, 320)] autorelease];
		[image_wiv loadImageWithStringURL:imageURL];
		
		[self addSubview:image_wiv];
		
		CGRect f = image_wiv.frame;
		
		f.size = imageSize;
		f.origin.x = 0;
		if(imageSize.width >= 320.0f)
		{
			float scale = 320.0f/imageSize.width;
			f.size.width = 320.0f;
			f.size.height = imageSize.height*scale;
		}
		else
		{
			f.origin.x = (320.0f - imageSize.width)/2;
		}
		height = f.size.height;
		image_wiv.frame = f;

		self.backgroundColor = [UIColor blackColor];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
	return self;
}
*/


- (void)layoutSubviews 
{
    [super layoutSubviews];
	self.backgroundColor = [UIColor blackColor];
}

- (float)height
{
	return height;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated 
{
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}


- (void)dealloc 
{
	
    [super dealloc];
}


@end
