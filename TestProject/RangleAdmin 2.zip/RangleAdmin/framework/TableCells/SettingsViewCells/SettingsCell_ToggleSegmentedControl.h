//
//  SettingsCell_ToggleSegmentedControl.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingsCell.h"

@interface SettingsCell_ToggleSegmentedControl : SettingsCell 
{
	UISegmentedControl* propertyToggleSegmentedControl;
	
}

/* remember to add segments in table view controller
 
 [cell.propertyToggleSegmentedControl insertSegmentWithTitle:@"Male" atIndex:0 animated:NO];
 [cell.propertyToggleSegmentedControl insertSegmentWithTitle:@"Female" atIndex:1 animated:NO];
 
*/

@property (retain, readonly) UISegmentedControl* propertyToggleSegmentedControl;

@end
