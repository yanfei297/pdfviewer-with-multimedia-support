//
//  SettingsCell_Switch.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "SettingsCell_Switch.h"


@interface SettingsCell_Switch ()

@property (retain) CustomSwitch *propertySwitch;

@end


@implementation SettingsCell_Switch

@synthesize propertySwitch;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) {
		
		CGRect frame = CGRectMake(CGRectGetMaxX(self.contentView.bounds) - 100.0, 7.0, 160.0, 32.0);
		UISwitch *stateSwitch = [[CustomSwitch alloc] initWithFrame:frame];
		stateSwitch.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		
		[stateSwitch addTarget:self action:@selector(stateSwitchFlipped:forEvent:) forControlEvents:UIControlEventValueChanged];
		
		self.propertySwitch = stateSwitch;
		
		[self.contentView addSubview:stateSwitch];
		[stateSwitch release];
		
		[self setNeedsLayout];
    }
	
    return self;
}

- (void)stateSwitchFlipped:(id)sender forEvent:(UIEvent *)event
{
	////////NSLog(@"State SwitchFlipped triggered.");
	[actionTarget performSelector:onChange];
}

- (void)dealloc
{
	self.propertySwitch = nil;
	
    [super dealloc];
}

@end