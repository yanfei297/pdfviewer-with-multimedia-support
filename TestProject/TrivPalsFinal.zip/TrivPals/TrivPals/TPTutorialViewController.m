//
//  TPTutorialViewController.m
//  TrivPals
//
//  Created by Sayan on 17/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPTutorialViewController.h"

@interface TPTutorialViewController ()

@end

@implementation TPTutorialViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    UIImageView *logo = [[UIImageView alloc] initWithFrame:CGRectMake(0, 12, 157, 31)];
    logo.image = [UIImage imageNamed:@"headerlogo.png"];
    UIBarButtonItem *logoItem = [[[UIBarButtonItem alloc] initWithCustomView:logo] autorelease];
    [logo release];
    self.navigationItem.leftBarButtonItem = logoItem;
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Home" style:UIBarButtonItemStyleDone target:self action:@selector(goHome)] autorelease];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) goHome{
    [self.navigationController popViewControllerAnimated:YES];
}

@end
