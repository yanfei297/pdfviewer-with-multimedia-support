//
//  TPFinalResultViewController.h
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPAppManager.h"

@interface TPFinalResultViewController : UIViewController<TPAppManagerDelegate,UINavigationControllerDelegate>{
    
    IBOutlet UITableView *_scoreTable;
    NSArray *turnsDetails;
    NSMutableArray *scores;
    //NSString *game_id;
}

@property (nonatomic,retain) UITableView *scoreTable;
@property (nonatomic,retain) NSArray *turnsDetails;
@property (nonatomic,retain,readwrite) NSMutableArray *scores;

- (id) initWithTurnDetails:(NSArray *)turns;
- (IBAction)nextAction:(id)sender;
- (IBAction)resign :(id)sender;

@end
