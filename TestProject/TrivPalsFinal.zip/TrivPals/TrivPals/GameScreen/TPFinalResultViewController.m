//
//  TPFinalResultViewController.m
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPFinalResultViewController.h"
#import "TPUtlis.h"
#import "TPGlobal.h"
#import "TPResultCell.h"
#import "TPQuestionScreenViewController.h"
#import "TPViewController.h"
#import "TPResultViewController.h"
#import "TPRoundResultViewController.h"
#import "TPGameLogic.h"
//#import "TPAppManager.h"

@interface TPFinalResultViewController ()

@end

@implementation TPFinalResultViewController

@synthesize scoreTable = _scoreTable;
@synthesize turnsDetails;
@synthesize scores;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (id) initWithTurnDetails:(NSArray *)turns{
    if ((self = [super init])) {
        self.turnsDetails = turns;
        NSLog(@"Turns : %@",turnsDetails);
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    self.title = @"Scorecard";
    
    //image
    [(UIImageView *)[self.view viewWithTag:10] setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[turnsDetails objectAtIndex:0] objectForKey:@"avater"]]]]];
    [TPUtlis getRoundedCornerFroView:[self.view viewWithTag:10] withCornerRadius:5.0];
     
    [(UIImageView *)[self.view viewWithTag:11] setImage:[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[turnsDetails objectAtIndex:1] objectForKey:@"avater"]]]]];
    [TPUtlis getRoundedCornerFroView:[self.view viewWithTag:11] withCornerRadius:5.0];
    
    NSString *str = @"";
    //clock image
    if ([[[turnsDetails objectAtIndex:1] objectForKey:@"turn"] isEqualToString:@"player"]) {
        ((UIImageView *)[self.view viewWithTag:12]).image = [UIImage imageNamed:@"clock_left.png"];
        str = [[[[turnsDetails objectAtIndex:0] objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0];
    }
    if ([[[turnsDetails objectAtIndex:1] objectForKey:@"turn"] isEqualToString:@"opponent"]) {
        ((UIImageView *)[self.view viewWithTag:12]).image = [UIImage imageNamed:@"clock_right.png"];
        str = [[[[turnsDetails objectAtIndex:1] objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0];
    }
    
    //name
    ((UILabel *)[self.view viewWithTag:22]).text = [[[[[turnsDetails objectAtIndex:0] objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0] uppercaseString];
    ((UILabel *)[self.view viewWithTag:22]).font = [UIFont fontWithName:@"AppleCasual" size:18.0];
    
    ((UILabel *)[self.view viewWithTag:23]).text = [((NSString *)[[[[turnsDetails objectAtIndex:1] objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0])uppercaseString];
    self.scoreTable.backgroundColor = [UIColor clearColor];  
    ((UILabel *)[self.view viewWithTag:23]).font = [UIFont fontWithName:@"AppleCasual" size:18.0];
    //turns text 
    ((UILabel *)[self.view viewWithTag:24]).text = [NSString stringWithFormat:@"IT'S %@'S TURN!",[str uppercaseString]];
    if ([[TPAppManager defaultManager].turn isEqualToString:@"yours"]) {
        ((UILabel *)[self.view viewWithTag:24]).text = [NSString stringWithFormat:@"IT'S YOUR TURN!"];
    }
    
    //final result screen bottom text
    str = [[turnsDetails objectAtIndex:0] objectForKey:@"winner"];
    if (str.length > 0) {
        NSArray *strArr = [str componentsSeparatedByString:@" "];
        
        NSString *newStr = [NSString stringWithFormat:@"%@ WINS!",[strArr objectAtIndex:0]];
        
        if ([[[strArr objectAtIndex:0] uppercaseString] isEqualToString:@"YOU"]) {
            newStr = [NSString stringWithFormat:@"%@ WIN!",[strArr objectAtIndex:0]];
        }
        
        ((UILabel *)[self.view viewWithTag:24]).text = [NSString stringWithFormat:@"%@",[newStr uppercaseString]];
    }
    
    
    //final result screen bottom text and clcok image
    str = [[turnsDetails objectAtIndex:0] objectForKey:@"who_win"];
    if (str.length > 0) {
        if ([str isEqualToString:@"player"]) {
            //player wins
            ((UIImageView *)[self.view viewWithTag:12]).image = [UIImage imageNamed:@"clock_left.png"];
        }
        else if ([str isEqualToString:@"opponent"]){
            //opponene wins
            ((UIImageView *)[self.view viewWithTag:12]).image = [UIImage imageNamed:@"clock_right.png"];
        }
        else{
            //tied
            ((UIImageView *)[self.view viewWithTag:12]).image = [UIImage imageNamed:@"clock_left.png"];
             ((UILabel *)[self.view viewWithTag:24]).text = [NSString stringWithFormat:@"%@",[@"YOU TIED!" uppercaseString]];
        }
    }
    
    self.scoreTable.backgroundColor = [UIColor clearColor];  
    ((UILabel *)[self.view viewWithTag:24]).font = [UIFont fontWithName:@"AppleCasual" size:18.0];
        
    if ([[TPAppManager defaultManager].turn isEqualToString:@"yours"]) {
        [((UIButton *)[self.view viewWithTag:31]) setTitle:@"PLAY!" forState:UIControlStateNormal];
        [((UIButton *)[self.view viewWithTag:31]).titleLabel setFont:[UIFont fontWithName:@"AppleCasual" size:32.0]];
    }
    else  {
        [((UIButton *)[self.view viewWithTag:31]) setTitle:@"DONE!" forState:UIControlStateNormal];
        [((UIButton *)[self.view viewWithTag:31]).titleLabel setFont:[UIFont fontWithName:@"AppleCasual" size:32.0]];
    }
    
    [((UIButton *)[self.view viewWithTag:32]).titleLabel setFont:[UIFont fontWithName:@"AppleCasual" size:32.0]];
    
    //play music
    str = [[turnsDetails objectAtIndex:0] objectForKey:@"winner_profile_id"];
    if (str.length > 0) {
        if ([[TPAppManager defaultManager].facebookId isEqualToString:str]) {
            [[TPGameLogic sharedLogic] playMusicFileForType:YOU_WIN];
        }
        else {
            [[TPGameLogic sharedLogic] playMusicFileForType:YOU_LOSE];
        }
    }
    
    //self.scoreTable.backgroundColor = [UIColor redColor];
    if ([TPAppManager defaultManager].isGameOver) {
        [TPAppManager defaultManager].isGameOver = NO;
        ((UIButton *)[self.view viewWithTag:30]).hidden = YES;
        ((UIButton *)[self.view viewWithTag:31]).hidden = YES;
        ((UIButton *)[self.view viewWithTag:32]).hidden = NO;
    }
    NSMutableArray *arr = [NSMutableArray new];
    self.scores = arr;
    [arr release];
    [self makeFinalDisplayString];
    //self.navigationController.delegate = self;
    self.navigationItem.hidesBackButton = YES;
    
    self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStylePlain target:self action:@selector(goBack)] autorelease];
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.scoreTable reloadData];
    self.title = @"Scorecard";
}

- (void) viewDidDisappear:(BOOL)animated{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    self.title = @"Back";
    [super viewDidDisappear:animated];
}

- (void)viewDidUnload
{
    self.scoreTable = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - ClassMethods

- (void) goBack{
    if ([TPAppManager defaultManager].isChallenged) {
       // [self.navigationController popToRootViewControllerAnimated:YES];
        [TPAppManager defaultManager].isChallenged = NO;
    }
    //else {
        //[self.navigationController popViewControllerAnimated:YES];
        [[TPAppManager defaultManager] userDidLoginFaceBook];
        [TPAppManager defaultManager].delegate = self;
    //}
}

- (BOOL) checkForFinished:(int)index{
    NSString *key = [NSString stringWithFormat:@"%d",index];
    NSDictionary *player = [[turnsDetails objectAtIndex:0] objectForKey:key];
    NSDictionary *opponent = [[turnsDetails objectAtIndex:1] objectForKey:key];
    BOOL isMsg = ![player objectForKey:@"msg"] && ![opponent objectForKey:@"msg"];
    BOOL isScore = (((NSString *)[player objectForKey:@"score"]).length > 0) && (((NSString *)[opponent objectForKey:@"score"]).length > 0);
    if (isMsg && isScore) {
        return YES;
    }
    return NO;
}

- (void) makeFinalDisplayString{
    int playerScore = 0;
    int opponentScore = 0;
    for (int i = 1; i < 4; i ++) {
        NSString *playerMsg = @"";
        NSString *opponentMsg = @"";
        NSString *key = [NSString stringWithFormat:@"%d",i];
        NSDictionary *player = [[turnsDetails objectAtIndex:0] objectForKey:key];
        NSDictionary *opponent = [[turnsDetails objectAtIndex:1] objectForKey:key];
        //stat for player
        if (((NSString *)[player objectForKey:@"msg"]).length > 0) {
            playerMsg = [player objectForKey:@"msg"];
        }
        else if(((NSString *)[player objectForKey:@"score"]).length > 0){
            playerMsg = [player objectForKey:@"score"];
            playerScore += [[player objectForKey:@"score"] intValue];
        }
        else {
            playerMsg = @"-";
        }
        //stat for opponent
        if (((NSString *)[opponent objectForKey:@"msg"]).length > 0) {
            opponentMsg = [opponent objectForKey:@"msg"];
        }
        else if(((NSString *)[opponent objectForKey:@"score"]).length > 0){
            opponentMsg = [opponent objectForKey:@"score"];
            opponentScore += [[opponent objectForKey:@"score"] intValue];
        }
        else {
            opponentMsg = @"-";
        }
        NSString *round = [player objectForKey:@"round_name"];
       // NSString *string = [NSString stringWithFormat:@"%@\t\t%@\t\t%@",msg1,round,msg2];
        NSArray *textArr = [NSArray arrayWithObjects:playerMsg,round,opponentMsg, nil];
        [self.scores addObject:textArr];
    }
    [self.scores addObject:[NSArray arrayWithObjects:[NSString stringWithFormat:@"%d",playerScore],@"TOTAL",[NSString stringWithFormat:@"%d",opponentScore], nil]];
     //[NSString stringWithFormat:@"%@\t\t%@\t\t%@",[NSString stringWithFormat:@"%d",score1],@"TOTAL",[NSString stringWithFormat:@"%d",score2]]];
    ((UILabel *)[self.view viewWithTag:20]).text = [NSString stringWithFormat:@"%d",playerScore];
    ((UILabel *)[self.view viewWithTag:21]).text = [NSString stringWithFormat:@"%d",opponentScore];
    //NSLog(@"SCORE : %@",scores);
}

- (IBAction)resign :(id)sender{
    //NSLog(@"TURN DETAILS : %@",self.turnsDetails);
    [[TPAppManager defaultManager] userWillResignGame:[[[self.turnsDetails objectAtIndex:0]objectForKey:@"1"]objectForKey:@"challenge_id"]];
    [TPAppManager defaultManager].delegate = self;
}

- (IBAction)nextAction:(id)sender {
    if (((UIButton *)sender).tag == 32) {
        [[TPAppManager defaultManager] userDidChallengeFriend:[self.turnsDetails objectAtIndex:0]];
        [TPAppManager defaultManager].delegate = self;
    }
    else {
        if ([[TPAppManager defaultManager].turn isEqualToString:@"yours"]) {
            [self getQuestion];
        }
        else{
            //[self.navigationController popToRootViewControllerAnimated:YES];
            [TPAppManager defaultManager].delegate = self;
            [[TPAppManager defaultManager] userDidLoginFaceBook];
            [[TPGameLogic sharedLogic] playMusicFileForType:OPTION_PRESS];
        }

    }
       
}

- (void) getQuestion{
    [[TPAppManager defaultManager]getQuestionsForTrivia];
    [TPAppManager defaultManager].delegate = self;
}

#pragma mark - UINavigationControllerDelegate

//- (void)navigationController:(UINavigationController *)navigationController didShowViewController:(UIViewController *)viewController animated:(BOOL)animate{
//    if ([viewController isKindOfClass:[TPFacebookFriendPageViewController class]]) {
//        [self.navigationController popToRootViewControllerAnimated:YES];
//    }
//}

#pragma mark - TPAppManagerDelegate

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

- (void) didGetQuestions:(NSDictionary *)questions{
    TPQuestionScreenViewController *questionScreen =[[[TPQuestionScreenViewController alloc]initWithNibName:@"TPQuestionScreenViewController" bundle:nil] autorelease];
    [self.navigationController pushViewController:questionScreen animated:YES];
}

- (void) didEndRound:(NSDictionary *)endRoundDetails{
    NSLog(@"ROUND DETAILS : %@",endRoundDetails);
    TPResultViewController *result = [[[TPResultViewController alloc] initWithNibName:@"TPResultViewController" bundle:nil andRoundDetails:endRoundDetails doneRequired:NO] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

- (void) didGetAnsware:(NSDictionary *)answare{
    TPRoundResultViewController *result = [[[TPRoundResultViewController alloc] initWithNibName:@"TPRoundResultViewController" bundle:nil andRoundDetails:answare doneRequired:NO] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

- (void) userDidLoginSuccessfullyWithDetils:(NSDictionary *)loginDetails{
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) didSuccesfullyChallenge:(NSDictionary *)challengeDetails{
    [TPAppManager defaultManager].isChallenged = YES;
    [TPAppManager defaultManager].activeGameId = [challengeDetails objectForKey:@"game_id"];
    [[TPAppManager defaultManager] getTurnDetails:challengeDetails];
    [TPAppManager defaultManager].delegate = self;
}

- (void) didGetTurnDetails:(NSArray *)turns{
    TPFinalResultViewController *result = [[[TPFinalResultViewController alloc] initWithTurnDetails:turns] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

- (void) userDidResignGame{
    [[TPAppManager defaultManager] userDidLoginFaceBook];
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    //NSLog(@"SCORE COUNT : %@",[scores count]);
    return [scores count];
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    static NSString *nilCellIdentifier = @"nil";
    TPResultCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
//	NSString *title = @"";
//    NSString *msg = @"";
//    NSString *time = @"";
//    NSString *image = @"";
    
	if (cell == nil) {
		cell = [[[TPResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryNone;
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
	}
    else{
        cell = [[[TPResultCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryNone;
		cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    if (indexPath.row < 3) {
        if ([self checkForFinished:(indexPath.row + 1)]) {
            cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
            cell.selectionStyle = UITableViewCellSelectionStyleBlue;
        }
    }
    else {
        UIImageView *grad = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"totalstrip.png"]];
        grad.frame = CGRectMake(0, 0, 280, 42);
       // grad.backgroundColor = [UIColor redColor];
        [cell.contentView addSubview:grad];
        [grad release];
        cell.accessoryType = UITableViewCellAccessoryNone;
    }
    //cell.textLabel.text = [scores objectAtIndex:indexPath.row];
    cell.player.text = [[scores objectAtIndex:indexPath.row] objectAtIndex:0];
    cell.round.text = [[scores objectAtIndex:indexPath.row] objectAtIndex:1];
    cell.opponent.text = [[scores objectAtIndex:indexPath.row] objectAtIndex:2];
    
    
    
    return cell;
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (cell) {
        if (cell.accessoryType == UITableViewCellAccessoryDisclosureIndicator ) {
            NSLog(@"Can Navigate");
            NSString *key = [NSString stringWithFormat:@"%d",(indexPath.row + 1)];
            NSString *gameId = [[[self.turnsDetails objectAtIndex:0] objectForKey:key] objectForKey:@"game_id"];
            //[[TPAppManager defaultManager] getScoreDetails:gameId];
            [[TPAppManager defaultManager] userWillGetAnswareForGame:gameId];
            [TPAppManager defaultManager].delegate = self;
        }
    }
}

#pragma mark - Memory

- (void) dealloc{
    [TPAppManager defaultManager].delegate = nil;
     [_scoreTable release];
    self.turnsDetails = nil;
    self.scores = nil;
    [super dealloc];
}

@end
