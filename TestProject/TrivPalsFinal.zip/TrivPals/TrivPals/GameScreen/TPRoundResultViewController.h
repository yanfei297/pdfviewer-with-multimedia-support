//
//  TPRoundResultViewController.h
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPAppManager.h"

@interface TPRoundResultViewController : UIViewController<TPAppManagerDelegate>{
    IBOutlet UIPickerView *picker;
    NSDictionary *questionDetails;
    BOOL doneRequired;
    BOOL pickerBackgroundNotHidden;
}

@property (nonatomic,retain) IBOutlet UIPickerView *picker;
@property (nonatomic,retain) NSDictionary *questionDetails;
- (IBAction)doneAction:(UIButton *)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details doneRequired:(BOOL)done;
@end
