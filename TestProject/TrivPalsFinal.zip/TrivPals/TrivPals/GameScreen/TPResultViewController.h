//
//  TPResultViewController.h
//  TrivPals
//
//  Created by Sayan on 30/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPAppManager.h"

@interface TPResultViewController : UIViewController<TPAppManagerDelegate>{
    NSDictionary *roundDetails;
    BOOL doneRequired;
}

@property (retain, nonatomic) IBOutlet UIScrollView *scroller;
@property (retain,nonatomic) NSDictionary *roundDetails;

- (IBAction)doneAction:(UIButton *)sender;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details;
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details doneRequired:(BOOL)done;
@end
