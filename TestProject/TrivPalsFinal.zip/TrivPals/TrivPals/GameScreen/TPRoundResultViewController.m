//
//  TPRoundResultViewController.m
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPRoundResultViewController.h"
#import "TPPickerRowView.h"
#import "TPUtlis.h"
#import "TPFinalResultViewController.h"
#import "TPGlobal.h"
#import "TPGameLogic.h"

@interface TPRoundResultViewController ()

@end

@implementation TPRoundResultViewController

@synthesize picker;
@synthesize questionDetails;


- (IBAction)doneAction:(UIButton *)sender{
    if (!doneRequired) {
        [self.navigationController popViewControllerAnimated:YES ];
    }
    else {
        NSMutableDictionary *scoreDict = [[NSMutableDictionary new] autorelease];
        [scoreDict setValue:[questionDetails objectForKey:@"challenge_id"] forKey:@"challenge_id"];
        [scoreDict setValue:[questionDetails objectForKey:@"frd_trivpal_id"] forKey:@"frd_trivpal_id"];
        [scoreDict setValue:[questionDetails objectForKey:@"game_id"] forKey:@"game_id"];
        [scoreDict setValue:@"pals" forKey:@"mode"];
        [[TPAppManager defaultManager] getTurnDetails:scoreDict];
        [TPAppManager defaultManager].delegate = self;
        [[TPGameLogic sharedLogic]playMusicFileForType:OPTION_PRESS];
    }
    
     
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details doneRequired:(BOOL)done
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.questionDetails = details;
        doneRequired = done;
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    if (!doneRequired) {
//        [self.view viewWithTag:100].hidden = YES;
//        ((UIButton *)[self.view viewWithTag:100]).enabled = NO;
        self.navigationItem.rightBarButtonItem = [[[UIBarButtonItem alloc] initWithTitle:@"Back" style:UIBarButtonItemStyleDone target:self action:@selector(doneAction:)] autorelease];
    }
//    else {
//        self.navigationItem.hidesBackButton = YES;
//    }
    self.navigationItem.hidesBackButton = YES;
   
    ((UIImageView *)[self.view viewWithTag:10]).image= [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[questionDetails objectForKey:@"player"] objectForKey:@"avater"]]]];
    //((UIImageView *)[self.view viewWithTag:10]).frame = CGRectMake(20, 10, 50, 100);
    [TPUtlis getRoundedCornerFroView:((UIImageView *)[self.view viewWithTag:10]) withCornerRadius:5.0];
    
    ((UIImageView *)[self.view viewWithTag:11]).image= [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[questionDetails objectForKey:@"opponent"] objectForKey:@"avater"]]]];
    //((UIImageView *)[self.view viewWithTag:11]).frame = CGRectMake(250, 10, 50, 100);
    [TPUtlis getRoundedCornerFroView:((UIImageView *)[self.view viewWithTag:11]) withCornerRadius:5.0];
        
    ((UILabel *)[self.view viewWithTag:20]).text = [[((NSString *)[[questionDetails objectForKey:@"player"] objectForKey:@"name"]) componentsSeparatedByString:@" "]objectAtIndex:0];
    ((UILabel *)[self.view viewWithTag:20]).textColor = [UIColor whiteColor];
    ((UILabel *)[self.view viewWithTag:20]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:20]).text = [((UILabel *)[self.view viewWithTag:20]).text uppercaseString];
    
    ((UILabel *)[self.view viewWithTag:21]).text = [[((NSString *)[[questionDetails objectForKey:@"opponent"] objectForKey:@"name"]) componentsSeparatedByString:@" "]objectAtIndex:0];
    ((UILabel *)[self.view viewWithTag:21]).textColor = [UIColor whiteColor];
    ((UILabel *)[self.view viewWithTag:21]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:21]).text = [((UILabel *)[self.view viewWithTag:21]).text uppercaseString];
    
    //((UILabel *)[self.view viewWithTag:22]).text = [[questionDetails objectForKey:@"player"] objectForKey:@"score"];
    
    //((UILabel *)[self.view viewWithTag:23]).text = [[questionDetails objectForKey:@"opponent"] objectForKey:@"score"] ;
    ((UILabel *)[self.view viewWithTag:50]).font = [UIFont fontWithName:MYRIAD_PRO size:12.0];
    ((UILabel *)[self.view viewWithTag:50]).minimumFontSize = 8.0;
    ((UILabel *)[self.view viewWithTag:50]).adjustsFontSizeToFitWidth = YES;
    ((UILabel *)[self.view viewWithTag:50]).text = [[[questionDetails objectForKey:@"answer"] objectAtIndex:0]objectForKey:@"question"];
    
    ((UILabel *)[self.view viewWithTag:51]).font = [UIFont fontWithName:MYRIAD_PRO size:12.0];
    ((UILabel *)[self.view viewWithTag:51]).minimumFontSize = 8.0;
    ((UILabel *)[self.view viewWithTag:51]).adjustsFontSizeToFitWidth = YES;
    ((UILabel *)[self.view viewWithTag:51]).text = [[[questionDetails objectForKey:@"answer"] objectAtIndex:0]objectForKey:@"option"];
    
    pickerBackgroundNotHidden = YES;
    
    self.title = [[questionDetails objectForKey:@"player"] objectForKey:@"round_name"];
}

- (void)viewDidUnload
{
    [picker release];
    picker = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Memory

- (void) dealloc{
    //[TPAppManager defaultManager].delegate = nil;
    [picker release];
    self.questionDetails = nil;
    [super dealloc];
}

#pragma mark - TPAppManagerDelegate

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
    
}

- (void) didGetTurnDetails:(NSArray *)turns{
    [TPAppManager defaultManager].isChallenged = YES;
    TPFinalResultViewController *result = [[[TPFinalResultViewController alloc] initWithTurnDetails:turns] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}


#pragma mark - UIPickerViewDelegate 

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view{
    
    if (pickerBackgroundNotHidden)
    {
        pickerBackgroundNotHidden = NO;
        //1st component
        [(UIView*)[[pickerView subviews] objectAtIndex:0] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:1] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:2] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:3] setHidden:YES];
        //[(UIView*)[[pickerView subviews] objectAtIndex:4] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:5] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:6] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:7] setHidden:YES];
        [(UIView*)[[pickerView subviews] objectAtIndex:8] setHidden:YES];
       
       // NSLog(@"COUNT : %d",[[pickerView subviews] count]);
    }
    
    TPPickerRowView *rowView = nil;
    if ([[questionDetails objectForKey:@"answer"] count] > 0) {
        NSMutableDictionary *deatils = [NSMutableDictionary dictionaryWithDictionary:[[questionDetails objectForKey:@"answer"]  objectAtIndex:row]];
        [deatils setValue:[NSString stringWithFormat:/*@"Question*/@" %d",(row + 1)] forKey:@"question"];
        rowView.userInteractionEnabled = NO;
        rowView = [[[TPPickerRowView alloc] initWithFrame:CGRectMake(2, 0, 300, 40) andRowDetails:deatils] autorelease];
    }
    
    
    return rowView;
}


- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component{
       
    ((UILabel *)[self.view viewWithTag:50]).text = [[[questionDetails objectForKey:@"answer"] objectAtIndex:row]objectForKey:@"question"];
    
    ((UILabel *)[self.view viewWithTag:51]).text = [[[questionDetails objectForKey:@"answer"] objectAtIndex:row]objectForKey:@"option"];
}

#pragma mark - UIPickerViewDataSource

// returns the number of 'columns' to display.
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView{
    return 1;
}

// returns the # of rows in each component..
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component{
    return [[questionDetails objectForKey:@"answer"] count];
}


@end
