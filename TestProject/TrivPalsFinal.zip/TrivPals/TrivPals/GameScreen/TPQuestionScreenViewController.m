//
//  TPQuestionScreenViewController.m
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPQuestionScreenViewController.h"
#import "TPGameLogic.h"
#import "TPQuestionView.h"
#import "TPGlobal.h"
#import "TPUtlis.h"
#import "TPResultViewController.h"
#import "TPRoundResultViewController.h"
//#import "TPAppManager.h"

@interface TPQuestionScreenViewController ()

@end

@implementation TPQuestionScreenViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    fiftyActivated = NO;
    self.navigationController.navigationBarHidden = YES;
    self.navigationItem.hidesBackButton = YES;
    ((UILabel *)[self.view viewWithTag:100]).text = [TPGameLogic sharedLogic].roundName;
    ((UILabel *)[self.view viewWithTag:100]).font = [UIFont fontWithName:@"AppleCasual" size:20.0];
    
    ((UILabel *)[self.view viewWithTag:101]).text = @"0";
        
    ((UILabel *)[self.view viewWithTag:102]).text = @"0 pts";
    ((UILabel *)[self.view viewWithTag:102]).font = [UIFont fontWithName:@"AppleCasual" size:24.0];
    ((UILabel *)[self.view viewWithTag:99]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:103]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:104]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:105]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:106]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    ((UILabel *)[self.view viewWithTag:107]).font = [UIFont fontWithName:@"AppleCasual" size:16.0];
    [self setQuestionUI];
    //[self performSelector:@selector(addGameOverScreen) withObject:nil afterDelay:120.0];
    [[TPGameLogic sharedLogic] incrementTime];
    
    //self.navigationItem.rightBarButtonItem =[[[UIBarButtonItem alloc] initWithTitle:@"Pause" style:UIBarButtonItemStyleDone target:self action:@selector(pauseGame)] autorelease];// [TPUtlis buttonWithFrame:CGRectZero label:@"Pause" actionTarget:self onTap:@selector(pauseGame)];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateTimer:) name:updateTimer object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(addGameOverScreen) name:gameOver object:nil];
}

- (void) viewWillDisappear:(BOOL)animated{
    self.navigationController.navigationBarHidden = NO;
    [super viewWillDisappear:animated];
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - ActionsForPauseScreen

- (void) roundOver{
    //[TPGameLogic sharedLogic].score = 0;
    //[self.navigationController popToRootViewControllerAnimated:YES];
    //[[TPGameLogic sharedLogic] JSONFromDictionary];
    [[TPAppManager defaultManager] userDiEndRound:[[TPGameLogic sharedLogic] JSONFromDictionary]];
    [TPAppManager defaultManager].delegate = self;
    //[[TPGameLogic sharedLogic] endGame];
    
}

- (void) goToMainMenu{
    if ([TPGameLogic sharedLogic].isSlowTime || [TPGameLogic sharedLogic].isFifty) {
        [[[[UIAlertView alloc] initWithTitle:@"Sorry!" message:@"You Can Not Navigate While Life Line Activated" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
        return;
    }
    [self.navigationController popToRootViewControllerAnimated:YES];
    [[TPGameLogic sharedLogic] endGame];
    //[TPGameLogic sharedLogic].score = 0;
}

- (void) endThisRound{
    //[TPGameLogic sharedLogic].score = 0;
    
    [[TPGameLogic sharedLogic] endGame];
    //[self.navigationController popToRootViewControllerAnimated:YES];
}

- (void) resign{
    //[TPGameLogic sharedLogic].score = 0;
    [[TPGameLogic sharedLogic] endGame];
}

#pragma mark - ClassMethods

- (void) enableQuestionUI{
    ((UILabel *)[self.view viewWithTag:104]).textColor = [UIColor blackColor];
    ((UILabel *)[self.view viewWithTag:105]).textColor = [UIColor blackColor];
    ((UILabel *)[self.view viewWithTag:106]).textColor = [UIColor blackColor];
    ((UILabel *)[self.view viewWithTag:107]).textColor = [UIColor blackColor];
    
    ((UILabel *)[self.view viewWithTag:104]).backgroundColor = [UIColor whiteColor];
    ((UILabel *)[self.view viewWithTag:105]).backgroundColor = [UIColor whiteColor];
    ((UILabel *)[self.view viewWithTag:106]).backgroundColor = [UIColor whiteColor];
    ((UILabel *)[self.view viewWithTag:107]).backgroundColor = [UIColor whiteColor];
    
    ((UILabel *)[self.view viewWithTag:104]).hidden = NO;
    ((UILabel *)[self.view viewWithTag:105]).hidden = NO;
    ((UILabel *)[self.view viewWithTag:106]).hidden = NO;
    ((UILabel *)[self.view viewWithTag:107]).hidden = NO;
    
    ((UIButton *)[self.view viewWithTag:501]).hidden = NO;
    ((UIButton *)[self.view viewWithTag:502]).hidden = NO;
    ((UIButton *)[self.view viewWithTag:503]).hidden = NO;
    ((UIButton *)[self.view viewWithTag:504]).hidden = NO;
}

- (void) addGameOverScreen{
    TPQuestionView *question = [[TPQuestionView alloc] initWithFrame:self.view.frame andTarget:self isPause:NO] ;
    [self.view addSubview:question];
    [question release];
}

- (void) updateTimer:(NSNotification *)sender{
    UIImageView *clock = (UIImageView *)[self.view viewWithTag:10];
    clock.transform = CGAffineTransformIdentity;
    clock.transform = CGAffineTransformMakeRotation([((NSString *)[sender object]) intValue] * 6 *  (M_PI / 180));
    int secs = [((NSString *)[sender object]) intValue];
    NSString *str = [NSString stringWithFormat:@"%d:",(secs / 60)] ;//],(secs % 60)];
    if ((secs % 60) < 10) {
        str = [str stringByAppendingFormat:@"0%d",(secs % 60)];
    }
    else {
        str = [str stringByAppendingFormat:@"%d",(secs % 60)];
    }
    ((UILabel *)[self.view viewWithTag:101]).text = str;//((NSString *)[sender object]);
    ((UILabel *)[self.view viewWithTag:101]).textColor = [UIColor redColor];
    ((UILabel *)[self.view viewWithTag:101]).font = [UIFont fontWithName:@"AppleCasual" size:20.0];
    if ([TPGameLogic sharedLogic].timePassed >= 120) {
        //[self addGameOverScreen];
    }
}

- (void) setQuestionUI{
    [self enableQuestionUI];
    
    NSArray *question =  [[TPGameLogic sharedLogic] setQuestions];
    if (question) {
        ((UILabel *)[self.view viewWithTag:99]).text = [question objectAtIndex:5];
        ((UILabel *)[self.view viewWithTag:103]).text = [question objectAtIndex:0];
        
        ((UILabel *)[self.view viewWithTag:104]).text = [NSString stringWithFormat:@"%@",[question objectAtIndex:1]];
        
        ((UILabel *)[self.view viewWithTag:105]).text =  [NSString stringWithFormat:@"%@",[question objectAtIndex:2]];
        
        ((UILabel *)[self.view viewWithTag:106]).text =  [NSString stringWithFormat:@"%@",[question objectAtIndex:3]];
        
        ((UILabel *)[self.view viewWithTag:107]).text =  [NSString stringWithFormat:@"%@",[question objectAtIndex:4]];
    }
    else {
        [[[[UIAlertView alloc] initWithTitle:@"Round End" message:@"No More Questions In This Round" delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
    }
}

- (void) isCorrect:(int)tag{
    fiftyActivated = NO;
    [TPGameLogic sharedLogic].isFifty = NO;
    if ([[TPGameLogic sharedLogic] checkCorrectAnsware:(tag % 500)]) {
        //[[TPGameLogic sharedLogic] checkCorrectAnsware:(tag % 500)];
        //[TPGameLogic sharedLogic].questionAnswared += 1;
        if (![TPGameLogic sharedLogic].isOnFire) {
            if ([TPGameLogic sharedLogic].onFireCount < 5) {
                [TPGameLogic sharedLogic].onFireCount += 1;
            }
            else{
                [TPGameLogic sharedLogic].isOnFire = YES;
                [TPGameLogic sharedLogic].totalOnFire += 1;
                [TPGameLogic sharedLogic].onFireCount = 0;
            }
        }
       
        if ([TPGameLogic sharedLogic].isOnFire) {
            [TPGameLogic sharedLogic].score += 15;
            [[TPGameLogic sharedLogic] createQuestionSetWithScore:15];
        }
        else {
            [TPGameLogic sharedLogic].score += 10;
            [[TPGameLogic sharedLogic] createQuestionSetWithScore:10];
        }
        [[TPGameLogic sharedLogic] playMusicFileForType:CORRECT_OPTION];
        switch (tag) {
            case 501:
                ((UILabel *)[self.view viewWithTag:104]).backgroundColor = [UIColor yellowColor];
                break;
            case 502:
                ((UILabel *)[self.view viewWithTag:105]).backgroundColor = [UIColor yellowColor];
                break;
            case 503:
                ((UILabel *)[self.view viewWithTag:106]).backgroundColor = [UIColor yellowColor];
                break;
            case 504:
                ((UILabel *)[self.view viewWithTag:107]).backgroundColor = [UIColor yellowColor];
                break;
            default:
                break;
        }
    }
    else {
        [TPGameLogic sharedLogic].onFireCount = 0;
        [TPGameLogic sharedLogic].isOnFire = NO;
        [[TPGameLogic sharedLogic]playMusicFileForType:WRONG_OPTION];
        switch (tag) {
            case 501:
                ((UILabel *)[self.view viewWithTag:104]).backgroundColor = [UIColor redColor];
                break;
            case 502:
                ((UILabel *)[self.view viewWithTag:105]).backgroundColor = [UIColor redColor];
                break;
            case 503:
                ((UILabel *)[self.view viewWithTag:106]).backgroundColor = [UIColor redColor];
                break;
            case 504:
                ((UILabel *)[self.view viewWithTag:107]).backgroundColor = [UIColor redColor];
                break;
            default:
                break;
        }
    }
    ((UILabel *)[self.view viewWithTag:(103 +  [[TPGameLogic sharedLogic] getCorrectAnswareIndex])]).textColor = [UIColor greenColor];
       ;
    ((UILabel *)[self.view viewWithTag:102]).text = [NSString stringWithFormat:@"%d pts",[TPGameLogic sharedLogic].score];
    ((UILabel *)[self.view viewWithTag:102]).font = [UIFont fontWithName:@"AppleCasual" size:24.0];
    
    [TPGameLogic sharedLogic].totalquestion += 1;
    [self performSelector:@selector(setQuestionUI) withObject:nil afterDelay:0.5];
}

- (void) animateAnsware{
    
}

- (IBAction)optionA:(UIButton *)sender {
    [[TPGameLogic sharedLogic]playMusicFileForType:OPTION_PRESS];
    [self isCorrect:sender.tag];
}

- (IBAction)optionB:(UIButton *)sender {
    [[TPGameLogic sharedLogic]playMusicFileForType:OPTION_PRESS];
    [self isCorrect:sender.tag];
}

- (IBAction)optionC:(UIButton *)sender {
    [[TPGameLogic sharedLogic]playMusicFileForType:OPTION_PRESS];
    [self isCorrect:sender.tag];
}

- (IBAction)optionD:(UIButton *)sender {
    [[TPGameLogic sharedLogic]playMusicFileForType:OPTION_PRESS];
    [self isCorrect:sender.tag];
}

- (IBAction)passQuestion:(UIButton *)sender {
    [[TPGameLogic sharedLogic]playMusicFileForType:PASS_PRESS];
    //[[TPGameLogic sharedLogic] checkCorrectAnsware:0];
    [TPGameLogic sharedLogic].isOnFire = NO;
    [TPGameLogic sharedLogic].status = [NSString stringWithFormat:@"%@",PASS];;
    [[TPGameLogic sharedLogic] createQuestionSetWithScore:0];
    [TPGameLogic sharedLogic].totalquestion += 1;
    [TPGameLogic sharedLogic].questionPassed += 1;
    //[TPGameLogic sharedLogic].t
    [self setQuestionUI];
    fiftyActivated = NO;
    [TPGameLogic sharedLogic].isFifty = NO;
}

- (IBAction)slowTime:(UIButton *)sender {
    sender.enabled = NO;
    [[TPGameLogic sharedLogic]playMusicFileForType:SLOW_PRESS];
    [TPGameLogic sharedLogic].isSlowTime = YES;
    [[TPGameLogic sharedLogic].lifeline setValue:@"1" forKey:LIFELINE_SLOW_TIME];
    //[NSObject cancelPreviousPerformRequestsWithTarget:self];
    //[self performSelector:@selector(addGameOverScreen) withObject:nil afterDelay:[[TPGameLogic sharedLogic] recalculateTime]];
}

- (IBAction)fiftyfifty:(UIButton *)sender {
    sender.enabled = NO;
    [[TPGameLogic sharedLogic]playMusicFileForType:FIFTY_PRESS];
    [[TPGameLogic sharedLogic].lifeline setValue:@"1" forKey:LIFELINE_FIFTY_FIFTY];
    [TPGameLogic sharedLogic].isFifty = YES;
    NSArray *wrongAns = [[TPGameLogic sharedLogic] getTwoWrongAnsware];
    int tag1 = [[wrongAns objectAtIndex:0] intValue];
    int tag2 = [[wrongAns objectAtIndex:1] intValue];
    ((UILabel *)[self.view viewWithTag:(tag1 + 103)]).hidden = YES;
    ((UILabel *)[self.view viewWithTag:(tag2 + 103)]).hidden = YES;
    ((UIButton *)[self.view viewWithTag:(tag1 + 500)]).hidden = YES;
    ((UIButton *)[self.view viewWithTag:(tag2 + 500)]).hidden = YES;
    
}

- (IBAction)pauseGame{
    TPQuestionView *question = [[TPQuestionView alloc] initWithFrame:self.view.frame andTarget:self isPause:YES];
    [self.view addSubview:question];
    [question release];
    [NSObject cancelPreviousPerformRequestsWithTarget:[TPGameLogic sharedLogic]];
    [[TPGameLogic sharedLogic] JSONFromDictionary];
    self.navigationItem.rightBarButtonItem.enabled = NO;
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag = 501) {
        [self roundOver];
    }
}

#pragma mark - TPAppManagerDelegate

- (void) didEndRound:(NSDictionary *)endRoundDetails{
    //TPResultViewController *result = [[[TPResultViewController alloc] initWithNibName:@"TPResultViewController" bundle:nil andRoundDetails:endRoundDetails] autorelease];
    //NSLog(@"ROUND DETAILS : %@",endRoundDetails);
    [[TPGameLogic sharedLogic] endGame];
    TPRoundResultViewController *result = [[[TPRoundResultViewController alloc] initWithNibName:@"TPRoundResultViewController" bundle:nil andRoundDetails:endRoundDetails doneRequired:YES] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

#pragma mark - Memory

- (void) dealloc{
    [TPAppManager defaultManager].delegate = nil;
    [super dealloc];
}

@end
