//
//  TPQuestionScreenViewController.h
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPAppManager.h"

@interface TPQuestionScreenViewController : UIViewController<TPAppManagerDelegate>{
    BOOL fiftyActivated;

}
- (IBAction)optionA:(UIButton *)sender;
- (IBAction)optionB:(UIButton *)sender;
- (IBAction)optionC:(UIButton *)sender;
- (IBAction)optionD:(UIButton *)sender;

- (IBAction)passQuestion:(UIButton *)sender;
- (IBAction)slowTime:(UIButton *)sender;
- (IBAction)fiftyfifty:(UIButton *)sender;

@end
