//
//  TPResultViewController.m
//  TrivPals
//
//  Created by Sayan on 30/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPResultViewController.h"
#import "TPResultView.h"
#import "TPGlobal.h"
#import "TPUtlis.h"
#import "TPFinalResultViewController.h"

@interface TPResultViewController ()

@end

@implementation TPResultViewController
@synthesize scroller;
@synthesize roundDetails;

- (IBAction)doneAction:(UIButton *)sender {
    
    NSMutableDictionary *scoreDict = [[NSMutableDictionary new] autorelease];
    [scoreDict setValue:[roundDetails objectForKey:@"challenge_id"] forKey:@"challenge_id"];
    [scoreDict setValue:[roundDetails objectForKey:@"frd_trivpal_id"] forKey:@"frd_trivpal_id"];
    [scoreDict setValue:[roundDetails objectForKey:@"game_id"] forKey:@"game_id"];
    [scoreDict setValue:@"pals" forKey:@"mode"];
    [[TPAppManager defaultManager] getTurnDetails:scoreDict];
    [TPAppManager defaultManager].delegate = self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        self.roundDetails = details;
        doneRequired = YES;
        //NSLog(@"Details : %@",details);
    }
    return self;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil andRoundDetails:(NSDictionary *)details doneRequired:(BOOL)done{
    self = [self initWithNibName:nibNameOrNil bundle:nibBundleOrNil andRoundDetails:details];
    doneRequired = done;
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //se
    
    ((UIImageView *)[self.view viewWithTag:101]).image= [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[roundDetails objectForKey:@"player"] objectForKey:@"avater"]]]];
    [TPUtlis getRoundedCornerFroView:((UIImageView *)[self.view viewWithTag:101]) withCornerRadius:5.0];
    
    ((UIImageView *)[self.view viewWithTag:102]).image= [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[roundDetails objectForKey:@"opponent"] objectForKey:@"avater"]]]];
    [TPUtlis getRoundedCornerFroView:((UIImageView *)[self.view viewWithTag:102]) withCornerRadius:5.0];
    
    ((UILabel *)[self.view viewWithTag:21]).text = [[roundDetails objectForKey:@"player"] objectForKey:@"score"];
    ((UILabel *)[self.view viewWithTag:23]).text = [[((NSString *)[[roundDetails objectForKey:@"player"] objectForKey:@"name"]) componentsSeparatedByString:@" "]objectAtIndex:0];
    NSString *score = @"N/A";
    if ([[roundDetails objectForKey:@"opponent"] objectForKey:@"score"]) {
        score = [[roundDetails objectForKey:@"opponent"] objectForKey:@"score"];
    }
     ((UILabel *)[self.view viewWithTag:22]).text = score;
     ((UILabel *)[self.view viewWithTag:24]).text = [[((NSString *)[[roundDetails objectForKey:@"opponent"] objectForKey:@"name"]) componentsSeparatedByString:@" "]objectAtIndex:0];
    
    [self.scroller addSubview:[[[TPResultView alloc] initWithFrame:CGRectMake(0, 0, WIDTH, HEIGHT) andResultDetails:[roundDetails objectForKey:@"player"]]autorelease]];
    
    [self.scroller addSubview:[[[TPResultView alloc] initWithFrame:CGRectMake(0 + WIDTH, 0, WIDTH, HEIGHT) andResultDetails:[roundDetails objectForKey:@"opponent"]]autorelease]];
    if (!doneRequired) {
        [self.view viewWithTag:100].hidden = YES;
        ((UIButton *)[self.view viewWithTag:100]).enabled = NO;
    }
    else {
        self.navigationItem.hidesBackButton = YES;
    }
}

- (void)viewDidUnload
{
    [self setScroller:nil];
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - TPAppManagerDelegate

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];

}

- (void) didGetTurnDetails:(NSArray *)turns{
    [TPAppManager defaultManager].isChallenged = YES;
    TPFinalResultViewController *result = [[[TPFinalResultViewController alloc] initWithTurnDetails:turns] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

//- (void) userDidLoginSuccessfullyWithDetils:(NSDictionary *)loginDetails{
//    [[NSNotificationCenter defaultCenter] postNotificationName:homePagerefresh object:nil];
//    [self.navigationController popToRootViewControllerAnimated:YES];
//}

#pragma mark - Memory

- (void) dealloc{
    [TPAppManager defaultManager].delegate = nil;
     [scroller release];
    self.roundDetails = nil;
    
    [super dealloc];
}

@end
