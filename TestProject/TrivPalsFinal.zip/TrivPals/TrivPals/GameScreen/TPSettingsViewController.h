//
//  TPSettingsViewController.h
//  TrivPals
//
//  Created by Sayan on 17/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPSettingsViewController : UIViewController

@end
