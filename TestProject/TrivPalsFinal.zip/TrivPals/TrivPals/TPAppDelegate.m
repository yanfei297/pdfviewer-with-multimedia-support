//
//  TPAppDelegate.m
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPAppDelegate.h"
#import "TPGlobal.h"
#import "TPViewController.h"
#import "TPAppManager.h"
#import "TPGameLogic.h"

@implementation TPAppDelegate

@synthesize window = _window;
@synthesize navigationController = _navigationController;
@synthesize viewController = _viewController;

- (void)dealloc
{
    [_window release];
    [_viewController release];
    [super dealloc];
}

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    self.window = [[[UIWindow alloc] initWithFrame:[[UIScreen mainScreen] bounds]] autorelease];
    // Override point for customization after application launch.
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        self.viewController = [[[TPViewController alloc] initWithNibName:@"TPViewController_iPhone" bundle:nil] autorelease];
    } else {
        self.viewController = [[[TPViewController alloc] initWithNibName:@"TPViewController_iPad" bundle:nil] autorelease];
    }
    UINavigationController *navigation = [[UINavigationController alloc] initWithRootViewController:self.viewController];
    self.navigationController = navigation;
    [navigation release];
    
    //self.window.rootViewController = self.navigationController;
    //[self.window makeKeyAndVisible];
    [self setupFaceBookLogin];
    [[TPGameLogic sharedLogic] loadMusicBackground];
    // Let the device know we want to receive push notifications
	[[UIApplication sharedApplication] registerForRemoteNotificationTypes:
     (UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application
{
    // Sent when the application is about/Users/sayan/Desktop/Myprojetcs/TrivPals/TrivPals/Manager/TPAppManager.m to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
    [[TPAppManager defaultManager] storeTPDetails];
}

- (void)applicationDidEnterBackground:(UIApplication *)application
{
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later. 
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
    [[TPAppManager defaultManager] storeTPDetails];
}

- (void)applicationWillEnterForeground:(UIApplication *)application
{
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
    [[TPAppManager defaultManager] loadTPDeatils];
}

- (void)applicationDidBecomeActive:(UIApplication *)application
{
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
    [[[TPAppManager defaultManager] facebook] extendAccessTokenIfNeeded];
    [[TPAppManager defaultManager] loadTPDeatils];
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    [[TPAppManager defaultManager] storeTPDetails];
}

- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return [[TPAppManager defaultManager].facebook handleOpenURL:url];
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [[TPAppManager defaultManager].facebook handleOpenURL:url];
}

#pragma mark - APNS

-(void) application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken{
    NSLog(@"Device Token : %@", deviceToken);
    NSString *curentDeviceToken = [[[[[deviceToken description] 
                                stringByTrimmingCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@""]] 
                               stringByReplacingOccurrencesOfString:@" " withString:@""] stringByReplacingOccurrencesOfString:@"<" withString:@""] stringByReplacingOccurrencesOfString:@">" withString:@""];
    NSLog(@"Device Token : %@",curentDeviceToken);
    NSLog(@"Remote type : %d", [[UIApplication sharedApplication] enabledRemoteNotificationTypes]);
    [TPAppManager defaultManager].deviceToken = curentDeviceToken;
}

-(void) application:(UIApplication *)application didFailToRegisterForRemoteNotificationsWithError:(NSError *)error{
    NSLog(@"Error in registration : %@", error);
    [TPAppManager defaultManager].deviceToken = @"";
    
//this fix for running in simulator
    if ([[[UIDevice currentDevice]model] isEqualToString:@"iPhone Simulator"]) {
        [TPAppManager defaultManager].deviceToken = @"a9fab5c951ba3e1e486d19cc011f7be365607ecc9228480893fc80c41ddd4fd0";
    }
}

-(void) application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo{
    NSLog(@"Received Notification");
    NSLog(@"remote notification: %@",[userInfo description]);
    application.applicationIconBadgeNumber++;
}

#pragma mark - Methods

- (void) setupFaceBookLogin{
    // Initialize Facebook
    TPAppManager *manager = [TPAppManager defaultManager];
    manager.facebook = [[[Facebook alloc] initWithAppId:fbAppId andDelegate:self.viewController] autorelease];
        // Check and retrieve authorization information
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"] && [defaults objectForKey:@"FBExpirationDateKey"]) {
        manager.facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        manager.facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
    }
    
    // Initialize API data (for views, etc.)
    //apiData = [[DataSet alloc] init];
    
    // Initialize user permissions
    //self.userPermissions = [[NSMutableDictionary alloc] initWithCapacity:1];
    
    // Override point for customization after application launch.
    // Add the navigation controller's view to the window and display.
    self.window.rootViewController = self.navigationController;
    [self.window makeKeyAndVisible];
    
    // Check App ID:
    // This is really a warning for the developer, this should not
    // happen in a completed app
    if (!fbAppId) {
        UIAlertView *alertView = [[UIAlertView alloc]
                                  initWithTitle:@"Setup Error"
                                  message:@"Missing app ID. You cannot run the app until you provide this in the code."
                                  delegate:self
                                  cancelButtonTitle:@"OK"
                                  otherButtonTitles:nil,
                                  nil];
        [alertView show];
        [alertView release];
    } else {
        // Now check that the URL scheme fb[app_id]://authorize is in the .plist and can
        // be opened, doing a simple check without local app id factored in here
        NSString *url = [NSString stringWithFormat:@"fb%@://authorize",fbAppId];
        BOOL bSchemeInPlist = NO; // find out if the sceme is in the plist file.
        NSArray* aBundleURLTypes = [[NSBundle mainBundle] objectForInfoDictionaryKey:@"CFBundleURLTypes"];
        if ([aBundleURLTypes isKindOfClass:[NSArray class]] &&
            ([aBundleURLTypes count] > 0)) {
            NSDictionary* aBundleURLTypes0 = [aBundleURLTypes objectAtIndex:0];
            if ([aBundleURLTypes0 isKindOfClass:[NSDictionary class]]) {
                NSArray* aBundleURLSchemes = [aBundleURLTypes0 objectForKey:@"CFBundleURLSchemes"];
                if ([aBundleURLSchemes isKindOfClass:[NSArray class]] &&
                    ([aBundleURLSchemes count] > 0)) {
                    NSString *scheme = [aBundleURLSchemes objectAtIndex:0];
                    if ([scheme isKindOfClass:[NSString class]] &&
                        [url hasPrefix:scheme]) {
                        bSchemeInPlist = YES;
                    }
                }
            }
        }
        // Check if the authorization callback will work
        NSLog(@"URL : %@",url);
        BOOL bCanOpenUrl = [[UIApplication sharedApplication] canOpenURL:[NSURL URLWithString: url]];
        if (!bSchemeInPlist || !bCanOpenUrl) {
            UIAlertView *alertView = [[UIAlertView alloc]
                                      initWithTitle:@"Setup Error"
                                      message:@"Invalid or missing URL scheme. You cannot run the app until you set up a valid URL scheme in your .plist."
                                      delegate:self
                                      cancelButtonTitle:@"OK"
                                      otherButtonTitles:nil,
                                      nil];
            [alertView show];
            [alertView release];
        }
    }
    

}

@end
