//
//  TPGameLogic.h
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <AudioToolbox/AudioToolbox.h>

#define RIGHT @"right"
#define WRONG @"wrong"
#define PASS @"pass"

#define LIFELINE_FIFTY_FIFTY @"fifty_fifty"
#define LIFELINE_SLOW_TIME @"slow_time"

//Sound Files
#define MUSIC_FILE_FIFTY @"50_50_sound.mp3"
#define MUSIC_FILE_CORRECT @"Correct_Answer.mp3"
#define MUSIC_FILE_WRONG @"wrong.mp3"
#define MUSIC_FILE_PASS @"Pass_Option.mp3"
#define MUSIC_FILE_OPTION_PRESS @"Press_Large_Buttons.mp3"//@"10_Blast.mp3"
#define MUSIC_FILE_SLOW_PRESS @"Freeze_Time_Option.mp3"
#define MUSIC_FILE_SLOW_END @"Freeze_Time_Ends.mp3"
#define MUSIC_FILE_TIME_UP @"Time_Up_Sound.mp3"

#define MUSIC_WARNING @"warning.wav"
#define MUSIC_WIN @"youwin.mp3"
#define MUSIC_LOSE @"youlose.mp3"

typedef enum music_for_app {
    CORRECT_OPTION = 0,
    WRONG_OPTION = 1,
    OPTION_PRESS = 2,
    PASS_PRESS = 3,
    SLOW_PRESS = 4,
    FIFTY_PRESS = 5,
    SLOW_END = 6,
    TIME_UP = 7,
    WARNING = 8,
    YOU_WIN = 9,
    YOU_LOSE
} MUSIC_FILE;


@interface TPGameLogic : NSObject{
    BOOL isOnFire;
    int onFireCount;
    int totalquestion;
    int questionAnswared;
    int questionPassed;
    int totalOnFire;
    int score;
    int timePassed;
    BOOL isSlowTime;
    BOOL isFifty;
    int slowTimeCount;
    
    NSMutableDictionary *questionSet;
    NSMutableDictionary *roundStat;
    NSMutableDictionary *lifeline;
    NSString *activeQuestionId;
    NSString *activeAnswareID;
    NSString *status;
    NSString *roundName;
    
    MUSIC_FILE musicChoosen;;
}

@property (nonatomic,assign) BOOL isOnFire;
@property (nonatomic,assign) int onFireCount;
@property (nonatomic,assign) int totalquestion;
@property (nonatomic,assign) int questionAnswared;
@property (nonatomic,assign) int questionPassed;
@property (nonatomic,assign) int totalOnFire;
@property (nonatomic,assign) int score;
@property (nonatomic,assign) int timePassed;
@property (nonatomic,assign) BOOL isSlowTime;
@property (nonatomic,assign) BOOL isFifty;
@property (nonatomic,assign) int slowTimeCount;

@property (nonatomic,retain) NSMutableDictionary *questionSet;
@property (nonatomic,retain) NSMutableDictionary *roundStat;
@property (nonatomic,retain) NSMutableDictionary *lifeline;
@property (nonatomic,retain) NSString *activeQuestionId;
@property (nonatomic,retain) NSString *activeAnswareID;
@property (nonatomic,retain) NSString *status;
@property (nonatomic,retain) NSString *roundName;

+ (TPGameLogic *) sharedLogic;
- (void) loadMusicBackground;
- (void) playMusicFileForType:(MUSIC_FILE)musicType;
- (NSArray *) setQuestions;
- (BOOL) checkCorrectAnsware:(int)index;
- (int) getCorrectAnswareIndex;
- (NSArray *) getTwoWrongAnsware;
- (float) calculateTime;
- (float) recalculateTime;
- (void) incrementTime;
- (void) resumeGame;
- (void) endGame;
- (void) createQuestionSetWithScore:(int)points;
- (NSString *) timeToString;
- (NSString *) intToString:(int)i;
- (void) createRoundStat;
- (NSString *) JSONFromDictionary;
@end
