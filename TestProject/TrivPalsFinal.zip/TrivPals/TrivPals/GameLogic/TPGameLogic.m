//
//  TPGameLogic.m
//  TrivPals
//
//  Created by Sayan on 22/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPGameLogic.h"
#import "TPAppManager.h"
#import "TPGlobal.h"
#import "TPAppManager.h"
#import "JSON.h"
#import "ShortSoundHandler.h"
#import "SimpleAudioEngine.h"

#define TOTAL_TIME 120.0

@interface TPGameLogic (Private)

- (void) initializeSharedInstance;

@end

@implementation TPGameLogic (Private)

- (void) initializeSharedInstance{
    totalquestion = 0;
    questionPassed = 0;
    questionAnswared = 0;
    onFireCount = 0;
    totalOnFire = 0;
    score = 0;
    isOnFire = NO;
    isSlowTime = NO;
    isFifty = NO;
    slowTimeCount = 0;
    
    NSMutableDictionary *dict = [NSMutableDictionary new];
    self.questionSet = dict;
    [dict release];
    dict = [NSMutableDictionary new];
    self.lifeline = dict;
    [dict release];
    dict = [NSMutableDictionary new];
    self.roundStat = dict;
    [dict release];
    [lifeline setValue:@"0" forKey:LIFELINE_FIFTY_FIFTY];
    [lifeline setValue:@"0" forKey:LIFELINE_SLOW_TIME];
    self.activeQuestionId = @"";
    self.activeAnswareID = @"";
    self.roundName = @"";
     
    
}

@end

@implementation TPGameLogic

@synthesize isOnFire;
@synthesize onFireCount;
@synthesize totalquestion;
@synthesize questionAnswared;
@synthesize questionPassed;
@synthesize totalOnFire;
@synthesize score;
@synthesize timePassed;
@synthesize isSlowTime;
@synthesize isFifty;
@synthesize slowTimeCount;

@synthesize questionSet;
@synthesize roundStat;
@synthesize lifeline;
@synthesize activeQuestionId;
@synthesize activeAnswareID;
@synthesize status;
@synthesize roundName;

static TPGameLogic *_sharedInstnace;

+ (TPGameLogic *) sharedLogic{
    if (!_sharedInstnace) {
        _sharedInstnace = [[self alloc] init];
        [_sharedInstnace initializeSharedInstance];
    }
    
    return _sharedInstnace;
}

#pragma mark - MUSIC FILES

- (void) loadMusicBackground{
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_FIFTY];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_CORRECT];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_WRONG];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_PASS];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_OPTION_PRESS];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_SLOW_PRESS];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_SLOW_END];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_FILE_TIME_UP];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_WARNING];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_WIN];
    [[SimpleAudioEngine sharedEngine] preloadBackgroundMusic:MUSIC_LOSE];
}

- (void) playMusicFileForType:(MUSIC_FILE)musicType{
    if ([TPAppManager defaultManager ].soundEnabled) {
        [[SimpleAudioEngine sharedEngine] playEffect:[self getMusicURLForMusicType:musicType]];
    }
    
}

- (NSString *) getMusicURLForMusicType:(MUSIC_FILE)music{
    NSString *musicFile = @"";
    switch (music) {
        case CORRECT_OPTION :
            musicFile = MUSIC_FILE_CORRECT;
            break;
        case WRONG_OPTION:
            musicFile = MUSIC_FILE_WRONG;
            break;
        case OPTION_PRESS:
            musicFile = MUSIC_FILE_OPTION_PRESS;
            break;
        case PASS_PRESS:
            musicFile = MUSIC_FILE_PASS;
            break;
        case SLOW_PRESS:
            musicFile = MUSIC_FILE_SLOW_PRESS;
            break;
        case FIFTY_PRESS:
            musicFile = MUSIC_FILE_FIFTY;
            break;
        case SLOW_END:
            musicFile = MUSIC_FILE_SLOW_END;
            break;
        case TIME_UP:
            musicFile = MUSIC_FILE_TIME_UP;
        break;
        case WARNING:
            musicFile = MUSIC_WARNING;
            break;    
        case YOU_WIN:
            musicFile = MUSIC_WIN;
            break;
        case YOU_LOSE:
            musicFile = MUSIC_LOSE;
            break;
        default:
            musicFile = @"";
            break;
    }
    return musicFile;
    //return [[[NSBundle mainBundle]resourcePath]stringByAppendingPathComponent:musicFile];
}

#pragma mark - QuestionUI

- (NSArray *) setQuestions{
    NSString *key = [NSString stringWithFormat:@"%d",totalquestion];
    NSDictionary *questionDict = [[TPAppManager defaultManager].questions objectForKey:key];
    NSLog(@"Answare : %@",[[questionDict objectForKey:@"answare"] objectForKey:@"name"]);
    if ([questionDict count] > 0) {
        NSString *question = [[questionDict objectForKey:@"question"] objectForKey:@"name"];
        self.activeQuestionId = [[questionDict objectForKey:@"question"] objectForKey:@"id"];
        NSString *option1 = [[[questionDict objectForKey:@"options"] objectForKey:@"1"] objectForKey:@"name"];
        NSString *option2 = [[[questionDict objectForKey:@"options"] objectForKey:@"2"] objectForKey:@"name"];
        NSString *option3 = [[[questionDict objectForKey:@"options"] objectForKey:@"3"] objectForKey:@"name"];
        NSString *option4 = [[[questionDict objectForKey:@"options"] objectForKey:@"4"] objectForKey:@"name"];
        NSString *questionMarkings = [NSString stringWithFormat:@"Question %@",key];
        return [NSArray arrayWithObjects:question,option1,option2,option3,option4, questionMarkings, nil];

    }
    return nil;
}

- (BOOL) isQuestionValid:(NSDictionary *)questionDict{
    if ([questionDict count] > 0 ){
        
    }
    return NO;
}

#pragma mark - GameLogic

- (BOOL) checkCorrectAnsware:(int)index{
    NSString *key = [NSString stringWithFormat:@"%d",totalquestion];
    NSDictionary *questionDict = [[TPAppManager defaultManager].questions objectForKey:key];
    if ([questionDict count] > 0) {
        int correctID = [[[questionDict objectForKey:@"answare"] objectForKey:@"id"] intValue];
        int userAnswareID = [[[[questionDict objectForKey:@"options"] objectForKey:[NSString stringWithFormat:@"%d",index]]objectForKey:@"id"] intValue];
        self.activeAnswareID = [NSString stringWithFormat:@"%d",userAnswareID];
        if (correctID == userAnswareID) {
            self.status = [NSString stringWithFormat:@"%@",RIGHT];
            if (!isFifty) {
                self.questionAnswared += 1;
            }
            return YES;
        }
        self.status = [NSString stringWithFormat:@"%@",WRONG];
        [self createQuestionSetWithScore:0];
        return NO;
    }
    self.status = [NSString stringWithFormat:@"%@",WRONG];
    return NO;
}

- (int) getCorrectAnswareIndex{
    NSString *key = [NSString stringWithFormat:@"%d",totalquestion];
    NSDictionary *questionDict = [[TPAppManager defaultManager].questions objectForKey:key];
    //NSLog(@"Question : %@",questionDict);
    if ([questionDict count] > 0) {
        int correctID = [[[questionDict objectForKey:@"answare"] objectForKey:@"id"] intValue];
        for (int i = 1; i <= 4; i++) {
            int answareID = [[[[questionDict objectForKey:@"options"] objectForKey:[NSString stringWithFormat:@"%d",i]]objectForKey:@"id"] intValue];
            if (answareID == correctID) {
                return i;
            }
            //else {
             //   return 0;
            //}
        }
    }
    return 0;
}

- (NSArray *) getTwoWrongAnsware{
    //integer in the range x to y
    //int randomNumber = (arc4random() % y) + x;
    int randomNo = (arc4random() % 4) + 1;
    NSMutableArray *wrongAns = [NSMutableArray new];
    while ([wrongAns count] < 2) {
        if (![self checkCorrectAnsware:randomNo]) {
            if ([wrongAns count] > 0) {
                if (randomNo != [[wrongAns objectAtIndex:0] intValue]) {
                    [wrongAns addObject:[NSString stringWithFormat:@"%d",randomNo]];
                }
            }
            else {
                [wrongAns addObject:[NSString stringWithFormat:@"%d",randomNo]];
            }
        }
       randomNo = (arc4random() % 4) + 1;
    }
    return [wrongAns autorelease];
}

- (float) calculateTime{
    NSLog(@"TIME : %d", (120 - timePassed));
    return (120.0 - timePassed);
}

- (float) recalculateTime{
    NSLog(@"RETIME :%@", 20 + [self calculateTime]);
    return (20 + [self calculateTime]);
}

- (void) incrementTime{
    if (timePassed >= TOTAL_TIME) {
        [self playMusicFileForType:TIME_UP];
        [[NSNotificationCenter defaultCenter] postNotificationName:gameOver object:nil];
        return;
    }
    if (isSlowTime) {
        [self performSelector:@selector(incrementTime) withObject:nil afterDelay:4.0];
        if (slowTimeCount > 4) {
            isSlowTime = NO;
            [self playMusicFileForType:SLOW_END];
        }
         slowTimeCount++;        
    }
    else {
        [self performSelector:@selector(incrementTime) withObject:nil afterDelay:1.0];
    }
    if (timePassed == (TOTAL_TIME - 15)) {
        [self playMusicFileForType:WARNING];
    }
    timePassed++;
    [[NSNotificationCenter defaultCenter] postNotificationName:updateTimer object:[NSString stringWithFormat:@"%d",timePassed]];
}

- (void) pauseGame{
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
}

- (void) resumeGame{
    [self incrementTime];
}

- (void) endGame{
    timePassed = 0;
    isSlowTime = NO;
    isOnFire = NO;
    onFireCount = 0;
    totalquestion = 0;
    questionAnswared = 0;
    questionPassed = 0;
    totalOnFire = 0;
    score = 0;
    timePassed = 0;
    slowTimeCount = 0;
    
    [questionSet removeAllObjects];
    [roundStat removeAllObjects];
    [lifeline setValue:@"0" forKey:LIFELINE_FIFTY_FIFTY];
    [lifeline setValue:@"0" forKey:LIFELINE_SLOW_TIME];
     
    self.activeQuestionId = @"0";
    self.activeAnswareID = @"0";
    self.status = @"N/A";
}

#pragma mark - JsonHelper

- (void) createQuestionSetWithScore:(int)points {
    NSMutableDictionary *question = [NSMutableDictionary new];
    [question setValue:activeQuestionId forKey:@"q_id"];
    [question setValue:activeAnswareID forKey:@"ans_id"];
    [question setValue:status forKey:@"status"];
    [question setValue:[NSString stringWithFormat:@"%d",points] forKey:@"score"];
    [questionSet setValue:question forKey:[NSString stringWithFormat:@"%d",totalquestion]];
    //NSLog(@"Question %@",question);
    [question release];
    self.activeAnswareID = @"0";
    //self.activeQuestionId = @"0";
    self.status = @"N/A";
}

- (NSString *) timeToString{
    int timeRemaining = (TOTAL_TIME - timePassed);
    int min = timeRemaining / 60;
    int sec = timeRemaining % 60;
    NSString *string = [NSString stringWithFormat:@"%d",sec];
    if (min != 0) {
        string = [NSString stringWithFormat:@"%d:%d",min,sec];
    }
    return string;
}

- (NSString *) intToString:(int)i{
    return [NSString stringWithFormat:@"%d",i];
}

- (NSString *)boolToString:(BOOL)flag{
    if(flag) return @"YES";
    return @"NO";
}

- (void) createRoundStat{
    NSMutableDictionary *dict = [NSMutableDictionary new];
    if (totalquestion == 0) {
        questionPassed = 1;
    }
    [dict setValue:[self intToString:score] forKey:@"score"];
    [dict setValue:[self intToString:totalquestion] forKey:@"totalQuestion"];
    [dict setValue:[self intToString:questionAnswared] forKey:@"answaredCorrect"];
    [dict setValue:[self intToString:questionPassed] forKey:@"passed"];
    [dict setValue:[self intToString:(totalquestion -(questionPassed + questionAnswared))] forKey:@"answredWrong"];
    [dict setValue:[self intToString:totalOnFire] forKey:@"onFireCount"];
    [dict setValue:[self intToString:isOnFire] forKey:@"onFire"];
    self.roundStat = dict;
    [dict release];
}

- (NSString *) JSONFromDictionary{
    [self createRoundStat];
    NSMutableDictionary *jsonDict = [[NSMutableDictionary new] autorelease];
    [jsonDict setValue:questionSet forKey:@"question"];
    [jsonDict setValue:roundStat forKey:@"stat"];
    [jsonDict setValue:lifeline forKey:@"life"];
    [jsonDict setValue:[TPAppManager defaultManager].trivpalID forKey:@"trivpalid"];
    [jsonDict setValue:[TPAppManager defaultManager].activeGameId forKey:@"gameid"];
    [jsonDict setValue:[TPAppManager defaultManager].activeChallengeID forKey:@"challengeid"];
    [jsonDict setValue:[self timeToString] forKey:@"timeleft"];
    [jsonDict setValue:activeQuestionId forKey:@"activequestionid"];
    //SBJSON *json = [[[SBJSON alloc] init] autorelease];
    //NSLog(@"JSON DICT : %@",jsonDict);
    //NSLog(@"JSON : %@",[jsonDict JSONRepresentation]);
    //[[TPAppManager defaultManager] userDiResumeGame:[jsonDict JSONRepresentation]];
    return [jsonDict JSONRepresentation];
}

@end
