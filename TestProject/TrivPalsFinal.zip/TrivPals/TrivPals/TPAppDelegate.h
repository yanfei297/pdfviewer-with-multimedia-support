//
//  TPAppDelegate.h
//  TrivPals
//Team.76${PRODUCT_NAME:rfc1034identifier}
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TPViewController;

@interface TPAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TPViewController *viewController;

@property (nonatomic,retain) UINavigationController *navigationController;

- (void) setupFaceBookLogin;

@end
