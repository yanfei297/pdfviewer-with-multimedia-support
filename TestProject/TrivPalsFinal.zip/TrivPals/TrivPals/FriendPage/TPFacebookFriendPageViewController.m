//
//  TPFacebookFriendPageViewController.m
//  TrivPals
//
//  Created by Sayan on 19/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPFacebookFriendPageViewController.h"
#import "TPGlobal.h"
#import "TPUtlis.h"
#import "AsyncImageView.h"
#import "MessageBox.h"
#import "TPFinalResultViewController.h"

@interface TPFacebookFriendPageViewController ()
- (void) createIndexedArrayForKey:(NSString *)key;
@end

@implementation TPFacebookFriendPageViewController
@synthesize friendtable;
@synthesize dictionary;

static NSString *image = @"http://192.168.2.209/trivpal/admin/images/hackbook.png";

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];

    // Uncomment the following line to preserve selection between presentations.
    // self.clearsSelectionOnViewWillAppear = NO;
 
    // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
    // self.navigationItem.rightBarButtonItem = self.editButtonItem;
//    NSMutableArray *arr = [NSMutableArray arrayWithArray:[[TPAppManager defaultManager].friends objectForKey:inTrivPal]];
//    [arr sortUsingDescriptors:[NSArray arrayWithObject:[[[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES] autorelease]]];
//    friendArray = [arr retain];
    
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadFriends:) name:frindPageRefresh object:nil];
    
    indexArr = [[NSArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z", nil] retain];
    [self createIndexedArrayForKey:inTrivPal];
    self.friendtable.backgroundColor = [UIColor clearColor];
    self.navigationItem.hidesBackButton = YES;
    
    UIBarButtonItem *back = [[[UIBarButtonItem alloc] initWithTitle:@"Done"
                                                                style:UIBarButtonItemStyleDone
                                                               target:self    
                                                               action:@selector(backToViewController)] autorelease];
    self.navigationItem.rightBarButtonItem = back;
    
}
/*
- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([TPAppManager defaultManager].isChallenged) {
//        [self.navigationController popViewControllerAnimated:NO];
        [TPAppManager defaultManager].isChallenged = NO;
    }
}
 */

- (void) backToViewController{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)viewDidUnload
{
    [self setFriendtable:nil];
    [freindType release];
    freindType = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    // e.g. self.myOutlet = nil;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

- (void) createIndexedArrayForKey:(NSString *)key{
    //NSLog(@"INDEX ARR : %@",indexArr);
    NSMutableArray *index = [NSMutableArray arrayWithObjects:@"A",@"B",@"C",@"D",@"E",@"F",@"G",@"H",@"I",@"J",@"K",@"L",@"M",@"N",@"O",@"P",@"Q",@"R",@"S",@"T",@"U",@"V",@"W",@"X",@"Y",@"Z", nil] ;
    NSMutableArray *arr = [NSMutableArray arrayWithArray:[[TPAppManager defaultManager].friends objectForKey:key]];
    [arr sortUsingDescriptors:[NSArray arrayWithObject:[[[NSSortDescriptor alloc] initWithKey:@"name" ascending:YES] autorelease]]];
    NSMutableDictionary *indexedDict = [NSMutableDictionary new];
    for (int i = 0; i < [index count]; i++)
    {
        NSMutableArray *section = [NSMutableArray new];
        for (NSDictionary *user in arr){
            NSString *c = [[user objectForKey:@"name"] substringToIndex:1];
            if ([c isEqualToString:[index objectAtIndex:i]]) {
                [section addObject:user];
            }
        }
       //if ([section count] > 0) {
            [indexedDict setObject:section forKey:[index objectAtIndex:i]];
        [section release];
//        }
//        else {
//            NSMutableArray *index = [NSMutableArray arrayWithArray:indexArr];
//            [index removeObjectAtIndex:i];
//            RELEASE_SAFELY(indexArr);
//            indexArr = [(NSArray *)index retain];
//        }
        
    }
    
    
    RELEASE_SAFELY(friendDict);
    friendDict = [[NSDictionary dictionaryWithDictionary:indexedDict] retain];
        
    NSEnumerator *enumartor = [friendDict keyEnumerator];
    //NSMutableArray *index = [NSMutableArray arrayWithArray:indexArr];
    for (key in enumartor) {
        if ([[friendDict objectForKey:key] count] < 1) {
            [indexedDict removeObjectForKey:key];
            [index removeObject:key];
        }
    }
    
    RELEASE_SAFELY(friendDict);
    friendDict = [((NSDictionary *)indexedDict) retain];
    [indexedDict release];
    RELEASE_SAFELY(indexArr);
    indexArr = [((NSArray *)index) retain];
}

#pragma mark - SendInvitiation

- (void) startGame{
    //[[TPAppManager defaultManager] getTurnDetails:<#(NSDictionary *)#>]
}

- (void) challengeAPlayer{//:(NSIndexPath *)indexpath{
    //NSString *key = [indexArr objectAtIndex:indexpath.section];
    //NSDictionary *dict = [[friendDict objectForKey:key] objectAtIndex:indexpath.row];
    //NSLog(@"DETAILS : %@",dict);
    NSLog(@"Challenge ; %@",dictionary);
    [[TPAppManager defaultManager] userDidChallengeFriend:self.dictionary];
    [TPAppManager defaultManager].delegate = self;
}

- (void) sendInvitationToAPlayer{//:(NSIndexPath *)indexpath{
    //NSString *key = [indexArr objectAtIndex:indexpath.section];
    //NSDictionary *dict = [[friendDict objectForKey:key] objectAtIndex:indexpath.row];
    //NSLog(@"DETAILS : %@",dictionary);
    NSString *freindName = [[[dictionary objectForKey:@"name"] componentsSeparatedByString:@" "] objectAtIndex:0];
    
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    NSArray* actionLinks = [NSArray arrayWithObjects:[NSDictionary dictionaryWithObjectsAndKeys:
                                                     @"Get Started",@"name",@"http://www.trivpals.com/",@"link", nil], nil];
    NSString *actionLinksStr = [jsonWriter stringWithObject:actionLinks];
    //The "to" parameter targets the post to a friend
    NSString *name = [NSString stringWithFormat:@"%@! Think you're smarter than me? Prove it with TrivPals!",freindName];
                      
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   [self.dictionary objectForKey:@"id"], @"to",
                                   name, @"name",
                                   @"", @"caption",
                                   @"TrivPals is the latest iPhone game that allows you to play trivia with your pals – anywhere, anytime.", @"description",
                                   @"http://www.trivpals.com/", @"link",
                                   image, @"picture",
                                    actionLinksStr, @"actions",
                                    nil];
    
   // [Friend first name]! Think you're smarter than me? Prove it with TrivPals, an iPhone game that lets you play trivia with your pals!
    
    //Please link it to: http://www.trivpals.com/
    [[[TPAppManager defaultManager] facebook] dialog:@"feed"
                      andParams:params
                    andDelegate:self];
    //[TPAppManager defaultManager].delegate = self;
     
}

#pragma mark - FBDialogDelegate

/**
 * Called when a UIServer Dialog successfully return. Using this callback
 * instead of dialogDidComplete: to properly handle successful shares/sends
 * that return ID data back.
 */
- (void)dialogCompleteWithUrl:(NSURL *)url {
    if (![url query]) {
        NSLog(@"User canceled dialog or there was an error");
        return;
    }
    MessageBox *message = [[[MessageBox alloc] initWithSuperview:self.view hasNavigationBar:YES] autorelease];
    [message showMessage:@"Invitation Sent Successfull."];
}

- (void)dialogDidNotComplete:(FBDialog *)dialog {
    NSLog(@"Dialog dismissed.");
}

- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error {
    NSLog(@"Error message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    //[self showMessage:@"Oops, something went haywire."];
    MessageBox *message = [[[MessageBox alloc] initWithSuperview:self.view hasNavigationBar:YES] autorelease];
    [message showMessage:@"There Was An Error To Sent Invitation."];
    
}



#pragma mark - NotificationCallbacks
/*
- (void) reloadFriends:(NSNotification *)sender{
    UISegmentedControl *segment = (UISegmentedControl *)[self.view viewWithTag:101];
    NSString *key = inTrivPal;
    if ([segment selectedSegmentIndex] == 1) {
        key = notInTrivpal;
    }
    [self createIndexedArrayForKey:key];
    [self.friendtable reloadData];
}
 */

#pragma mark - TPAppManagerDelegate

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

- (void) didSuccesfullyChallenge:(NSDictionary *)challengeDetails{
//    MessageBox *message = [[[MessageBox alloc] initWithSuperview:self.view hasNavigationBar:YES] autorelease];
//    [message showMessage:[challengeDetails objectForKey:@"msg"]];
//    [TPAppManager defaultManager].userDidChallenge = YES;
//    self.navigationItem.backBarButtonItem.enabled = NO;
    //NSLog(@"CHALENGE DETAILS : %@ ",challengeDetails);
    [TPAppManager defaultManager].isChallenged = YES;
    [TPAppManager defaultManager].activeGameId = [challengeDetails objectForKey:@"game_id"];
    [[TPAppManager defaultManager] getTurnDetails:challengeDetails];
    [TPAppManager defaultManager].delegate = self;
}

- (void) didGetTurnDetails:(NSArray *)turns{
    TPFinalResultViewController *result = [[[TPFinalResultViewController alloc] initWithTurnDetails:turns] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}


#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        if (alertView.tag == 1001) {
            [self challengeAPlayer];
        }
        if (alertView.tag == 1002) {
            [self performSelector:@selector(sendInvitationToAPlayer) withObject:nil afterDelay:0.3 ];
        }
    }
}

#pragma mark - UIActionSheetDelegate

// Called when a button is clicked. The view will be automatically dismissed after this call returns
- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 1) {
        if (actionSheet.tag == 1001) {
            [self challengeAPlayer];
        }
        if (actionSheet.tag == 1002) {
            [self sendInvitationToAPlayer];
        }
    }
    
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{

    // Return the number of sections.
    return [indexArr count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    return [[friendDict objectForKey:[indexArr objectAtIndex:section]]count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"cell";
    static NSString *nilCellIdentifier = @"nil";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
	}
    else{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }

    //cell.textLabel.text = [[friendArray objectAtIndex:indexPath.row] objectForKey:@"name"];
    
    UILabel *lab = [TPUtlis labelWithFrame:CGRectMake(70, 15, 200, 30) text:[[[friendDict objectForKey:[indexArr objectAtIndex:indexPath.section]]objectAtIndex:indexPath.row] objectForKey:@"name"]textColor:[UIColor blackColor] fontName:@"Helvetica" fontSize:20.0];
    lab.minimumFontSize = 10.0;
    [cell.contentView addSubview:lab];
    
    AsyncImageView *imageView = [[[AsyncImageView alloc]init] autorelease];
    [imageView loadImageFromURL:[NSURL URLWithString:[[[friendDict objectForKey:[indexArr objectAtIndex:indexPath.section]]objectAtIndex:indexPath.row] objectForKey:@"avater"]]];
    imageView.frame = CGRectMake(5, 5, 50, 50);
    [TPUtlis getRoundedCornerFroView:imageView withCornerRadius:5.0f];
    [cell.contentView addSubview:imageView];
    //cell.imageView.image = [UIImage imageNamed:@""] ;
    //[UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[[friendArray objectAtIndex:indexPath.row] objectForKey:@"avater"]]]];
    
    // Configure the cell...
    
    return cell;
}

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView{
    return indexArr;
}

- (NSInteger)tableView:(UITableView *)tableView sectionForSectionIndexTitle:(NSString *)title atIndex:(NSInteger)index{
    return index;
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section{
    return [indexArr objectAtIndex:section];
}

/*
// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    return YES;
}
*/

/*
// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }   
    else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}
*/

/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath
{
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    UISegmentedControl *segment = (UISegmentedControl *)[self.view viewWithTag:101];
    NSString *title = @"";
    NSString *msg = @"";
    NSString *buttonTitle = @"";
    int tag = 0;
    NSString *key = [indexArr objectAtIndex:indexPath.section];
    self.dictionary = [[friendDict objectForKey:key] objectAtIndex:indexPath.row];
    if (segment.selectedSegmentIndex == 0) {
        //[self challengeAPlayer:indexPath];
        tag = 1001;
        title = @"Create Game?";
        msg = [NSString stringWithFormat:@"Would you like to start a TrivPals game with %@",[self.dictionary objectForKey:@"name"]];
        //msg = [NSString stringWithFormat:@"Are You Sure To Challenge %@ To Play Trivia",[self.dictionary objectForKey:@"name"]];
        buttonTitle = @"Challenge";
    }
    else {
        //[self sendInvitationToAPlayer:indexPath];
        tag = 1002;
        title = @"Invite Freind?";
        msg = [NSString stringWithFormat:@"Would you like to invite %@ to play TrivPals.",[self.dictionary objectForKey:@"name"]];
        //msg = [NSString stringWithFormat:@"Are You Sure To Invite %@ To Play Trivia",[self.dictionary objectForKey:@"name"]];
        buttonTitle = @"Invite";
    }
//    UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:title delegate:self cancelButtonTitle:nil destructiveButtonTitle:@"Cancel" otherButtonTitles:buttonTitle, nil];
//    sheet.tag = tag;
//    [sheet showInView:self.view];
//    [sheet release];
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:msg delegate:self cancelButtonTitle:@"No thanks" otherButtonTitles:@"Yes!", nil];
    alert.tag = tag;
    [alert show];
    [alert release];
}

- (IBAction)friendTypeChanged:(id)sender {
    if (friendDict) {
        RELEASE_SAFELY(friendDict);
    }
    NSString *key = inTrivPal;
    if ([(UISegmentedControl *)sender selectedSegmentIndex] == 1) {
        key = notInTrivpal;
    }
    [self createIndexedArrayForKey:key];
    [friendtable reloadData];
}

- (void) dealloc{
    [TPAppManager defaultManager].delegate = nil;
    [friendtable release];
    [freindType release];
    RELEASE_SAFELY(friendDict);
    RELEASE_SAFELY(indexArr);
    self.dictionary = nil;
    
    [super dealloc];
}

@end
