//
//  TPFacebookFriendPageViewController.h
//  TrivPals
//
//  Created by Sayan on 19/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TPAppManager.h"
#import "FBConnect.h"

@interface TPFacebookFriendPageViewController : UIViewController<UITableViewDataSource,UITableViewDelegate,TPAppManagerDelegate,FBDialogDelegate,UIActionSheetDelegate>{
    
    IBOutlet UISegmentedControl *freindType;
    NSDictionary *friendDict;
    NSDictionary *dictionary;
    NSArray *indexArr;
}
@property (retain, nonatomic) IBOutlet UITableView *friendtable;
@property (nonatomic,retain) NSDictionary *dictionary;
- (IBAction)friendTypeChanged:(id)sender;
//- (void) cerateIndexedArrayForKey:(NSString *)key;
@end
