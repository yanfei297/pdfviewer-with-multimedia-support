//
//  TPViewController.h
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "FBConnect.h"
#import "TPAppManager.h"
#import "UINavigationBar+CustomImage.h"

@class TPHomeScreen;
//@class TPSettingsView;

@interface TPViewController : UIViewController<FBSessionDelegate,FBRequestDelegate,TPAppManagerDelegate>{
    NSArray *permissions;
    TPHomeScreen *homeScreen;
    //TPSettingsView *settingsScreen;
    IBOutlet UILabel *nameLabel;
    IBOutlet UIImageView *profilePhotoImageView;
    NSDictionary *turn;
}

@property (nonatomic,retain) NSArray *permissions;
@property (nonatomic,retain) TPHomeScreen *homeScreen;
//@property (nonatomic,retain) TPSettingsView *settingsScreen;
@property (nonatomic,retain) NSDictionary *turn;
- (void) pushFreindPage;
- (void) categoriesPlayersTurn;
- (void)login;
- (void)logout;
- (void) setUIHidden:(BOOL)hidden;
@end
