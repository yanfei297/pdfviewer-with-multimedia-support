//
//  TPViewController.m
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPViewController.h"
#import "TPHomeScreen.h"
#import "TPUtlis.h"
#import "TPGlobal.h"
#import "TPFinalResultViewController.h"
#import "TPFacebookFriendPageViewController.h"
#import "TPSettingsView.h"
#import "TPTutorialView.h"
#import "TPSettingsViewController.h"
#import "TPTutorialViewController.h"

@interface TPViewController (private)
- (void)showLoggedIn;
- (void)showLoggedOut;
- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt;
- (void)apiFQLIMe;
- (void)apiGraphUserPermissions;
@end

@implementation TPViewController

@synthesize permissions;
@synthesize homeScreen;
//@synthesize settingsScreen;
@synthesize turn;

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
    // Initialize permissions
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(reloadHome:) name:homePagerefresh object:nil];
    NSArray *permissionsArr = [[NSArray alloc] initWithObjects:@"offline_access",@"publish_stream", nil];
    NSDictionary *dict = [NSDictionary new];
    self.turn = dict;
    [dict release];
    [self setPermissions:permissionsArr];
    [permissionsArr release];
    //NSLog(@"PERMISSION : %@",permissions);
    [TPUtlis getRoundedCornerFroView:profilePhotoImageView withCornerRadius:5.0f];
    
    UIBarButtonItem *logoItem = [[[UIBarButtonItem alloc] initWithCustomView:[TPUtlis buttonWithNormalImageNamed:@"headerlogo.png" pressedImageName:@"headerlogo.png" actionTarget:self selector:@selector(closeSettings) x:0 y:12]] autorelease];
    self.navigationItem.leftBarButtonItem = logoItem;
    
    if ([[NSUserDefaults standardUserDefaults] objectForKey:@"FBAccessTokenKey"] ) {
        [self apiFQLIMe];
        [[TPAppManager defaultManager] startLoading];
    }
    else{
        [self showLoggedOut];
        //[self setUpLoginButton];
    }
}

- (void) viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    if ([TPAppManager defaultManager].userDidChallenge) {
        [TPAppManager defaultManager].userDidChallenge = NO;
    }
    [self.homeScreen reloadData];
    [UIApplication sharedApplication].applicationIconBadgeNumber = [[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] count];
}

- (void)viewDidUnload
{
    [nameLabel release];
    nameLabel = nil;
    [profilePhotoImageView release];
    profilePhotoImageView = nil;
    [super viewDidUnload];
    // Release any retained subviews of the main view.
    
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Methods

- (void) pushFreindPage{
    TPFacebookFriendPageViewController *frndPage = [[[TPFacebookFriendPageViewController alloc] initWithNibName:@"TPFacebookFriendPageViewController" bundle:nil] autorelease];
    [self.navigationController pushViewController:frndPage animated:YES ];
}

- (void) categoriesPlayersTurn{
    NSArray *playerArr = [[TPAppManager defaultManager].friends objectForKey:inTrivPal];
    NSLog(@"INTRIVPAL : %@",playerArr);
}

- (void) setUIHidden:(BOOL)hidden{
    [homeScreen setHidden:hidden];
    //((UIImageView *)[self.view viewWithTag:151]).hidden = hidden;
    if (hidden) {
        nameLabel.text = @"";
        [profilePhotoImageView setImage:nil];
        ((UIImageView *)[self.view viewWithTag:151]).image = nil;
    }
    else {
        ((UIImageView *)[self.view viewWithTag:11]).hidden = YES;
    }
    
    
}

- (void) setUpLoginButton{
    UIButton *loginButton = [TPUtlis buttonWithNormalImageNamed:@"fb_inactive.png" pressedImageName:@"fb_active.png" actionTarget:self selector:@selector(login) x:45 y:180];
    //[UIButton buttonWithType:UIButtonTypeCustom] ;
    //CGFloat xLoginButtonOffset = self.view.center.x - (318/2);
    //CGFloat yLoginButtonOffset = self.view.bounds.size.height - (58 + 13 + 44);
    //loginButton.frame = CGRectMake(xLoginButtonOffset,yLoginButtonOffset,318,58);
    //[loginButton addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    //[loginButton setImage:[UIImage imageNamed:@"FBConnect.bundle/images/LoginWithFacebookNormal@2x.png"] forState:UIControlStateNormal];
    //[loginButton setImage:[UIImage imageNamed:@"FBConnect.bundle/images/LoginWithFacebookPressed@2x.png"] forState:UIControlStateHighlighted];
    //[loginButton sizeToFit];
    [loginButton setTag:101];
    [self.view addSubview:loginButton];
    
    ((UIImageView *)[self.view viewWithTag:11]).hidden = NO;
}

- (void) setUpLogoutButton{
//    UIBarButtonItem *logout = [[[UIBarButtonItem alloc] initWithTitle:@"Settings"
//                                      style:UIBarButtonItemStyleDone
//                                     target:self    
//                                     action:@selector(openSettings)] autorelease];
//    logout.tag = 102;
    //self.navigationItem.rightBarButtonItem = logout;
    
    //UIImageView *logo = [[UIImageView alloc] initWithFrame:CGRectMake(0, 12, 157, 31)];
    //logo.image = [UIImage imageNamed:@"headerlogo.png"];
    
//    UIBarButtonItem *logoItem = [[[UIBarButtonItem alloc] initWithCustomView:[TPUtlis buttonWithNormalImageNamed:@"headerlogo.png" pressedImageName:@"headerlogo.png" actionTarget:self selector:@selector(closeSettings) x:0 y:12]] autorelease];
//    self.navigationItem.leftBarButtonItem = logoItem;
    
    UIView *barButonView = [[UIView alloc] initWithFrame:CGRectMake(0, 10, 60, 25)];
    barButonView.backgroundColor = [UIColor clearColor];
    [barButonView addSubview:[TPUtlis buttonWithNormalImageNamed:@"settings.png" pressedImageName:@"settings.png" actionTarget:self selector:@selector(openSettings) x:1 y:1]];
    [barButonView addSubview:[TPUtlis buttonWithNormalImageNamed:@"help.png" pressedImageName:@"help.png" actionTarget:self selector:@selector(openTutorial) x:30 y:1]];
    //UIBarButtonItem *barButto =[[UIBarButtonItem alloc] in]
    UIBarButtonItem *items = [[[UIBarButtonItem alloc] initWithCustomView:barButonView] autorelease];
    [barButonView release];
    self.navigationItem.rightBarButtonItem = items;
    
}

/**
 * Show the authorization dialog.
 */
- (void)login {
    //NSLog(@"PERMISSION : %@",self.permissions);
    ((UIImageView *)[self.view viewWithTag:11]).hidden = YES;
    if (![[[TPAppManager defaultManager] facebook] isSessionValid]) {
        [[[TPAppManager defaultManager] facebook] authorize:permissions];
    } else {
        [[TPAppManager defaultManager] startLoading];
        [TPAppManager defaultManager].delegate = self;
        [self apiFQLIMe];
        [[self.view viewWithTag:101] removeFromSuperview];
    }
}

/**
 * Invalidate the access token and clear the cookie.
 */
- (void)logout {
    
    [[[TPAppManager defaultManager] facebook] logout];
    [self showLoggedOut];
}

- (void) openTutorial{
    
    if ([TPUtlis isViewWithTag:6001 beingDispalyedOnSuperView:self.view]) {
        [self.view bringSubviewToFront:[self.view viewWithTag:6001]];
        return;
    }
    else{
        TPTutorialView *tutorial = [[TPTutorialView alloc] initWithFrame:self.view.frame andTarget:self];
        tutorial.tag = 6001;
        [self.view addSubview:tutorial];
        [tutorial release];
    }
    //[[[[UIAlertView alloc] initWithTitle:@"TEST!" message:@"Here Will Be An Tutorial" delegate:nil cancelButtonTitle:@"Ok" otherButtonTitles:nil] autorelease] show];
     
//    TPTutorialViewController *tutorial = [[[TPTutorialViewController alloc] initWithNibName:@"TPTutorialViewController" bundle:nil] autorelease];
//    
//    [self.navigationController pushViewController:tutorial animated:YES];
}

- (void) openSettings{
    
    if ([TPUtlis isViewWithTag:5001 beingDispalyedOnSuperView:self.view]) {
        [self.view bringSubviewToFront:[self.view viewWithTag:5001]];
        return;
    }
    else {
        NSMutableDictionary *deatils = [NSMutableDictionary new];
        [deatils setValue:nameLabel.text forKey:@"name"];
        [deatils setValue:UIImagePNGRepresentation(profilePhotoImageView.image) forKey:@"avater"];
        TPSettingsView *settings = [[TPSettingsView alloc] initWithFrame:self.view.frame userDetails: deatils andTarget:self];
        settings.tag = 5001;
        [self.view addSubview:settings];
        [deatils release];
        [settings release];
    }
     
//    TPSettingsViewController *settings = [[[TPSettingsViewController alloc] initWithNibName:@"TPSettingsViewController" bundle:nil] autorelease];
//    
//    [self.navigationController pushViewController:settings animated:YES];
    
}

- (void) closeSettings{
    if ([TPUtlis isViewWithTag:5001 beingDispalyedOnSuperView:self.view]) {
        [[self.view viewWithTag:5001] removeFromSuperview];
    }
    if ([TPUtlis isViewWithTag:6001 beingDispalyedOnSuperView:self.view]) {
        [[self.view viewWithTag:6001] removeFromSuperview];
    }
}

#pragma mark - NotificationCallbacks

- (void) reloadHome:(NSNotification *)sender{
    [self.homeScreen reloadData];
}

#pragma mark - TPAppManagerDelegate

- (void) userDidLoginSuccessfullyWithDetils:(NSDictionary *)loginDetails{
    //NSLog(@"Details : %@",loginDetails);
    nameLabel.text = [NSString stringWithFormat:@"Hello! %@",[loginDetails objectForKey:@"user"]];
    nameLabel.text = [nameLabel.text uppercaseString];
    nameLabel.font = [UIFont fontWithName:@"AppleCasual" size:20.0];
    nameLabel.textColor = [UIColor whiteColor];
    profilePhotoImageView.image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[loginDetails objectForKey:@"user_avater"]]]];    
    ((UIImageView *)[self.view viewWithTag:151]).image = [UIImage imageNamed:@"orangebar.png"];
    [TPAppManager defaultManager].trivpalID = [loginDetails objectForKey:@"trivpal_id"];
    [self showLoggedIn];
}

- (void) didGetTurnDetails:(NSArray *)turns{
    TPFinalResultViewController *result = [[[TPFinalResultViewController alloc] initWithTurnDetails:turns] autorelease];
    [self.navigationController pushViewController:result animated:YES];
}

- (void) userDidResignGame{
    [[TPAppManager defaultManager] userDidLoginFaceBook];
    [TPAppManager defaultManager].delegate = self;
}

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error!" message:[[errorDetails objectForKey:@"response"] objectForKey:@"error"]delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil];
    alert.tag = 501;
    [alert show];
    [alert release];
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (alertView.tag == 501) {
        [self showLoggedOut];
    }
}

#pragma mark - FBSessionDelegate Methods
/**
 * Called when the user has logged in successfully.
 */
- (void)fbDidLogin {
    //[[self.view viewWithTag:101] removeFromSuperview];
    [self storeAuthData:[[[TPAppManager defaultManager] facebook] accessToken] expiresAt:[[[TPAppManager defaultManager] facebook] expirationDate]];
    [self login];
    //[pendingApiCallsController userDidGrantPermission];
}

-(void)fbDidExtendToken:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSLog(@"token extended");
    [self storeAuthData:accessToken expiresAt:expiresAt];
}

/**
 * Called when the user canceled the authorization dialog.
 */
-(void)fbDidNotLogin:(BOOL)cancelled {
    //[pendingApiCallsController userDidNotGrantPermission];
    ((UIImageView *)[self.view viewWithTag:11]).hidden = NO;
}

/**
 * Called when the request logout has succeeded.
 */
- (void)fbDidLogout {
   // pendingApiCallsController = nil;
    
    // Remove saved authorization information if it exists and it is
    // ok to clear it (logout, session invalid, app unauthorized)
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults removeObjectForKey:@"FBAccessTokenKey"];
    [defaults removeObjectForKey:@"FBExpirationDateKey"];
    [defaults synchronize];
    [[TPAppManager defaultManager] removeFacebookId];
   // [self showLoggedOut];
}

/**
 * Called when the session has expired.
 */
- (void)fbSessionInvalidated {
    UIAlertView *alertView = [[UIAlertView alloc]
                              initWithTitle:@"Auth Exception"
                              message:@"Your session has expired."
                              delegate:nil
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
    [alertView show];
    [alertView release];
    [self fbDidLogout];
}

#pragma mark - FBRequestDelegate Methods
/**
 * Called when the Facebook API request has returned a response. This callback
 * gives you access to the raw response. It's called before
 * (void)request:(FBRequest *)request didLoad:(id)result,
 * which is passed the parsed response object.
 */
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response {
    NSLog(@"received response");
}

/**
 * Called when a request returns and its response has been parsed into
 * an object. The resulting object may be a dictionary, an array, a string,
 * or a number, depending on the format of the API response. If you need access
 * to the raw response, use:
 *
 * (void)request:(FBRequest *)request
 *      didReceiveResponse:(NSURLResponse *)response
 */
- (void)request:(FBRequest *)request didLoad:(id)result {
    //NSLog(@"RESULT : %@",result);
    if ([result isKindOfClass:[NSArray class]]) {
        if ([result count] > 0) {
            result = [result objectAtIndex:0];
        }
        
    }
    if ([result objectForKey:@"uid"]) {
        [TPAppManager defaultManager].facebookId = [result objectForKey:@"uid"];
        if([[result objectForKey:@"uid"] isKindOfClass:[NSDecimalNumber class]]){
            [TPAppManager defaultManager].facebookId = [[result objectForKey:@"uid"] stringValue];
        }
        [[TPAppManager defaultManager] storeFaceBookId];
        [[TPAppManager defaultManager] userDidLoginFaceBook];
        [TPAppManager defaultManager].delegate = self;
        [TPAppManager defaultManager].isLoogedIn = YES;
    }
    if ([result objectForKey:@"data"]) {
        [[TPAppManager defaultManager] setUserPermissions:[[result objectForKey:@"data"] objectAtIndex:0]];
    }
    /*
    // This callback can be a result of getting the user's basic
    // information or getting the user's permissions.
    if ([result objectForKey:@"name"]) {
        // If basic information callback, set the UI objects to
        // display this.
        nameLabel.text = [NSString stringWithFormat:@"Hello! %@",[result objectForKey:@"name"]];
        // Get the profile image
        UIImage *image = [UIImage imageWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:[result objectForKey:@"pic"]]]];
        
        // Resize, crop the image to make sure it is square and renders
        // well on Retina display
        float ratio;
        float delta;
        float px = 100; // Double the pixels of the UIImageView (to render on Retina)
        CGPoint offset;
        CGSize size = image.size;
        if (size.width > size.height) {
            ratio = px / size.width;
            delta = (ratio*size.width - ratio*size.height);
            offset = CGPointMake(delta/2, 0);
        } else {
            ratio = px / size.height;
            delta = (ratio*size.height - ratio*size.width);
            offset = CGPointMake(0, delta/2);
        }
        CGRect clipRect = CGRectMake(-offset.x, -offset.y,
                                     (ratio * size.width) + delta,
                                     (ratio * size.height) + delta);
        UIGraphicsBeginImageContext(CGSizeMake(px, px));
        UIRectClip(clipRect);
        [image drawInRect:clipRect];
        UIImage *imgThumb =   UIGraphicsGetImageFromCurrentImageContext();
        [imgThumb retain];
        
        [profilePhotoImageView setImage:imgThumb];
        [self apiGraphUserPermissions];
    } else {
        // Processing permissions information
        
        [[TPAppManager defaultManager] setUserPermissions:[[result objectForKey:@"data"] objectAtIndex:0]];
    }
     */
}

/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error {
    NSLog(@"Err message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    NSLog(@"Err code: %d", [error code]);
}

#pragma mark - Memory

- (void)dealloc {
    [nameLabel release];
    [profilePhotoImageView release];
    [TPAppManager defaultManager].delegate = nil;
    self.permissions = nil;
    self.homeScreen = nil;
    //self.settingsScreen = nil;
    self.turn = nil;
    [super dealloc];
}

@end

@implementation TPViewController(private)

#pragma - Private Helper Methods

/**
 * Show the logged in menu
 */

- (void)showLoggedIn {
    [self setUpLogoutButton];
    if (self.homeScreen) {
        [homeScreen reloadData];
        [self setUIHidden:NO];
    }
    else{
        TPHomeScreen *home = [[TPHomeScreen alloc] initWithFrame:CGRectMake(10, 15, 300, 401) andTarget:self] ;
        home.autoresizesSubviews = YES;
        home.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        //home.backgroundColor = [UIColor redColor];
        [self.view addSubview:home];
        self.homeScreen = home;
        [home release];
    }
    [self.homeScreen doneLoadingTableViewData];
    [UIApplication sharedApplication].applicationIconBadgeNumber = [[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] count];
}

/**
 * Show the logged in menu
 */

- (void)showLoggedOut {
    
    //[[self navigationController] popToRootViewControllerAnimated:YES];
    self.navigationItem.rightBarButtonItem = nil;
    [TPAppManager defaultManager].isLoogedIn = NO;
    [[TPAppManager defaultManager] resetTPAppManager];
    [self setUpLoginButton];
    [self closeSettings];
    [self setUIHidden:YES];
    [[TPAppManager defaultManager].facebook logout];
    [UIApplication sharedApplication].applicationIconBadgeNumber = 0;
}

- (void)storeAuthData:(NSString *)accessToken expiresAt:(NSDate *)expiresAt {
    NSLog(@"ACCESS TOKEN ; %@",accessToken);
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}

#pragma mark - Facebook API Calls
/**
 * Make a Graph API Call to get information about the current logged in user.
 */
- (void)apiFQLIMe {
    // Using the "pic" picture since this currently has a maximum width of 100 pixels
    // and since the minimum profile picture size is 180 pixels wide we should be able
    // to get a 100 pixel wide version of the profile picture
    NSMutableDictionary *params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"SELECT uid FROM user WHERE uid=me()", @"query",
                                   nil];
    [[[TPAppManager defaultManager] facebook] requestWithMethodName:@"fql.query"
                                     andParams:params
                                 andHttpMethod:@"POST"
                                   andDelegate:self];
}

- (void)apiGraphUserPermissions {
    
    [[[TPAppManager defaultManager] facebook] requestWithGraphPath:@"me/permissions" andDelegate:self];
}


@end
