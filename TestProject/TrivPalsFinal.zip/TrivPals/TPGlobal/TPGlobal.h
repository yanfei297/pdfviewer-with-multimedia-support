//
//  TPGlobal.h
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma mark Colors
#define SKYBLUE [UIColor colorWithRed:70.0/255.0 green:198.0/255.0 blue:248.0/255.0 alpha:1.0]
#define LIGHTGRAY [UIColor colorWithRed:240.0/255.0 green:240.0/255.0 blue:240.0/255.0 alpha:1.0]
#define DARKGREEN [UIColor colorWithRed:0.000 green:0.216 blue:0.212 alpha:1.000]
#define RGBCOLOR(r,g,b) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:1]
#define RGBACOLOR(r,g,b,a) [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
#define BACKGROUND_COLOR [UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]]

#pragma mark System Versioning Preprocessor Macros

#define DEVICE_ID ( [UIDevice currentDevice].uniqueIdentifier)

#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)

#pragma mark - Relese Pointer

#define RELEASE_SAFELY(__POINTER) { [__POINTER release]; __POINTER = nil; }

#pragma mark - NotificationNames

static NSString *frindPageRefresh = @"relodFreinds";
static NSString *homePagerefresh = @"reloadHome";
static NSString *updateTimer = @"updateTime";
static NSString *gameOver = @"gameOver";

#pragma mark - Appids and Secrets

static NSString *fbAppId = @"251364271613723";
static NSString *fbAppSecret = @"4fd992bdba190f383c96b4af2ebb25ad";
static NSString *twitterAppSecrt = @"";
static NSString *twitterAppId = @"";

static NSString *inTrivPal = @"trivpal";
static NSString *notInTrivpal = @"nottrivpal";

#pragma mark - Server URL 

static NSString *serverURL = @"http://23.23.219.27/trivpals/index.php?";

static NSString *developerUrl = @"http://192.168.2.209/trivpals/index.php?";
//@"http://174.136.1.35/dev/trivpals/index.php?";

#pragma mark - WebServiceActions

#define FBLOGIN(fbid,devicetoken) ([NSString stringWithFormat:@"action=fblogin&profile_id=%@&&device_id=%@&device_token=%@",fbid,DEVICE_ID,devicetoken])

#define CHALLENGE(utrivid,ftrivid) ([NSString stringWithFormat:@"action=throwchallenge&player_id=%@&opp_id=%@",utrivid,ftrivid])

#define INVITE(utrivid,ffbid) ([NSString stringWithFormat:@"action=invitefriend&trivpal_id=%@&profile_id=%@",utrivid,ffbid])

#define TURN(utrivid,ftrivid,chid,gamid,mode) ([NSString stringWithFormat:@"action=allturn&user_trivpal_id=%@&frd_trivpal_id=%@&challenge_id=%@&game_id=%@&turn=%@",utrivid,ftrivid,chid,gamid,mode])

#define QUESTION(gameid) ([NSString stringWithFormat:@"action=getquestion&game_id=%@",gameid])

#define DETAILS(gameid) ([NSString stringWithFormat:@"action=getdetails&game_id=%@",gameid])

#define ANSWAREDETAILS(gameid) ([NSString stringWithFormat:@"action=optiondetails&game_id=%@",gameid])

#define COMPLETEGAME() ([NSString stringWithFormat:@"action=completegame"])
//#define COMPLETEGAME(jsondata) ([NSString stringWithFormat:@"action=completegame&jsondata=%@",jsondata])

#define RESIGNGAME(utrivid,chid) ([NSString stringWithFormat:@"action=rejectchallenge&user_trivpal_id=%@&challenge_id=%@",utrivid,chid])

#define DELETEGAME(utrivid,chid) ([NSString stringWithFormat:@"action=deletegameover&user_trivpal_id=%@&challenge_id=%@",utrivid,chid])

#define ENABLEPUSH(utrivid,push) ([NSString stringWithFormat:@"action=pushsettings&user_trivpal_id=%@&push_enable=%@",utrivid,push])

//#define ENABLEPUSH (utrivid,push) ([NSString stringWithFormat:@"action=pushsettings&user_trivpal_id=%@&push_enable=%@",utrivid,push])

//

#pragma mark - Fonts

#define APPLE_CASUAL @"AppleCasual"
#define MYRIAD_PRO @"MyriadPro-Regular"


#pragma mark - Serialization Keys

static NSString *fbID = @"fb_id";

