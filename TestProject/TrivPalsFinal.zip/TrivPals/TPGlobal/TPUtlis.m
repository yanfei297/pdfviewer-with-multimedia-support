//
//  TPUtlis.m
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPUtlis.h"
#import "NSData+AES256.h"

@implementation TPUtlis

+ (NSString *)urlEncodeValue:(NSString *)str
{
	NSString *result = (NSString *) CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, 
                                                                            (CFStringRef)str, NULL, CFSTR("?=&+_."), kCFStringEncodingUTF8);
	return [result autorelease];
}

+ (NSString *) urlDecodeValue:(NSString *)str{
    NSString *result = [str stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    //(NSString *)CFURLCreateStringByReplacingPercentEscapesUsingEncoding(kCFAllocatorDefault, (CFStringRef)str, NULL,kCFStringEncodingUTF8);
    //result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    //NSLog(@"URL DECODE STRING : %@",result);
    return result;
}

+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment{
    NSString *result = [self urlDecodeValue:str];
    if (tretment) {
        result = [result stringByReplacingOccurrencesOfString:@"+" withString:@" "];
    }
    return result;
}

//returns Application document directory path
+ (NSString *) applicationDocumentsDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

//returns Application document directory path
+ (NSString *) applicationLibraryDirectory{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

//crate diretctory at path if created return sucess else false

+ (BOOL) createDirectoryAtPath:(NSString *)path withInterMediateDirectory:(BOOL)isIntermediateDirectory{
    //NSLog(@"NEW DIR PATH : %@",path);
    if ([self fileExistsAtPath:path]) {
        return YES;
    }
    return [[NSFileManager defaultManager] createDirectoryAtPath:path
                                     withIntermediateDirectories:isIntermediateDirectory
                                                      attributes:nil
                                                           error:NULL];
}
//returns temp directory path
+ (NSString *) tempFilePathForDir:(NSString *)dirName{
    //[NSTemporaryDirectory() stringByAppendingPathComponent:[[NSProcessInfo processInfo] globallyUniqueString]];
    return [NSTemporaryDirectory() stringByAppendingPathComponent:dirName];
}

+ (BOOL) fileExistsAtPath:(NSString *)path {
    BOOL directory;
    return [[NSFileManager defaultManager] fileExistsAtPath:path isDirectory:&directory];
}

//write file 

+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath {
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    //NSLog(@"PATH : %@",appendeFilePath);
    NSError *error = nil;
    if ([[self class] fileExistsAtPath:filePath ]) {
        if ([[self class] fileExistsAtPath:appendeFilePath]) {
            if ([[self class] deleteFileAtPath:appendeFilePath ]) {
                NSLog(@"File Deleted Successfully");
            }
            else{
                NSLog(@"File Not Deleted");
            }
            
        }
        return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:fileContent attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
    }
    [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:&error];
    return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:fileContent  attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
}

//encrypted write file with AES encryption

+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath isEncrypted:(BOOL)encrypted andAESKeys:(NSString *)keys{
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    //NSLog(@"PATH : %@",appendeFilePath);
    NSError *error = nil;
    if ([[self class] fileExistsAtPath:filePath ]) {
        if ([[self class] fileExistsAtPath:appendeFilePath]) {
            if ([[self class] deleteFileAtPath:appendeFilePath ]) {
                NSLog(@"File Deleted Successfully");
            }
            else{
                NSLog(@"File Not Deleted");
            }
            
        }
        return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:[fileContent AES256EncryptWithKey:keys] attributes:nil]; 
    }
    [[NSFileManager defaultManager] createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:&error];
    return [[NSFileManager defaultManager] createFileAtPath:appendeFilePath contents:[fileContent AES256EncryptWithKey:keys]  attributes:nil]; 
}

//read AES encrypted file

+ (NSData *) readAESEncryptedFileAtPAth:(NSString *)path andAESKey:(NSString *)key{
    if ([[self class] fileExistsAtPath:path]) {
        return [[[NSFileManager defaultManager] contentsAtPath:path] AES256DecryptWithKey:key];
    }
    return nil;
}

//delete file

+ (BOOL) deleteFileAtPath:(NSString *)filepath{
    NSError *err = nil;
    if ([[self class] fileExistsAtPath:filepath]) {
        [[NSFileManager defaultManager] removeItemAtPath:filepath error:&err];
    }
    else {
        return NO;
    }
    if (err) {
        return NO;
    }
    return YES;
}

//clear subviews

+ (void)clearSubviewsfromView:(UIView *)view{
    for(UIView *subview in [view subviews]){
        [subview removeFromSuperview];
    }
}

//getting a view if is it on the superview

+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview{
    for (UIView *view in [superview subviews]) {
        if (view.tag == tag) {
            return YES;
        }
    }
    return NO;
}

//rounded  croner view

+ (void) getRoundedCornerFroView:(UIView *)view withCornerRadius:(float)radius{
// create round corners
    [view.layer setCornerRadius:radius];
    [view.layer setMasksToBounds:YES];
}

+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName adnSize:(float)size{
    CGSize maximumSize = CGSizeMake(300, 1000);
    UIFont *selectedFont = [UIFont fontWithName:fontName size:size];
    CGSize stringSize = [str sizeWithFont:selectedFont 
                          constrainedToSize:maximumSize 
                              lineBreakMode:UILineBreakModeWordWrap];
    return stringSize.height;
}

@end

