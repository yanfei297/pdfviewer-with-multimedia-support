//
//  ShortSoundHandler.m
//  TrivPals
//
//  Created by Sayan on 16/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "ShortSoundHandler.h"

@implementation ShortSoundHandler

- (id) initWithPath: (NSString*) path
{
    [super init];
    //NSString *resourceDir = [[NSBundle mainBundle] resourcePath];
    //NSString *fullPath = [resourceDir stringByAppendingPathComponent:path];
    NSURL *url = [NSURL fileURLWithPath:path];
    
    OSStatus errcode = AudioServicesCreateSystemSoundID((CFURLRef) url, &handle);
    NSAssert1(errcode == 0, @"Failed to load sound: %@", path);
    return self;
}

- (void) dealloc
{
    AudioServicesDisposeSystemSoundID(handle);
    [super dealloc];
}

- (void) play
{
    AudioServicesPlaySystemSound(handle);
}


@end
