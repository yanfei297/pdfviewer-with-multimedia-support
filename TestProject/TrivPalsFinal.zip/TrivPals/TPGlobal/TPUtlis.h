//
//  TPUtlis.h
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Utils.h"

@interface TPUtlis : Utils

+ (NSString *)urlEncodeValue:(NSString *)str;
+ (NSString *) urlDecodeValue:(NSString *)str;
+ (NSString *) urlDecodeValue:(NSString *)str treatmentForPlus:(BOOL)tretment;
+ (NSString *) applicationDocumentsDirectory;
+ (NSString *) applicationLibraryDirectory;
+ (BOOL) createDirectoryAtPath:(NSString *)path withInterMediateDirectory:(BOOL)isIntermediateDirectory;
+ (NSString *) tempFilePathForDir:(NSString *)dirName;
+ (BOOL) fileExistsAtPath:(NSString *)path ;
+ (BOOL) deleteFileAtPath:(NSString *)filepath;
+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath ;
+ (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath isEncrypted:(BOOL)encrypted andAESKeys:(NSString *)keys;
+ (NSData *) readAESEncryptedFileAtPAth:(NSString *)path andAESKey:(NSString *)key;
+ (void)clearSubviewsfromView:(UIView *)view;
+ (BOOL) isViewWithTag:(int)tag beingDispalyedOnSuperView:(UIView *)superview;
+ (void) getRoundedCornerFroView:(UIView *)view withCornerRadius:(float)radius;
+ (float) getHeightForString:(NSString *)str forFontName:(NSString *)fontName adnSize:(float)size;
@end

