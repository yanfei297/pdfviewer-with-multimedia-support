//
//  SettingsCell_Switch.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SettingsCell.h"
#import "CustomSwitch.h"

@interface SettingsCell_Switch : SettingsCell 
{
	CustomSwitch* propertySwitch;
}

@property (retain, readonly) CustomSwitch *propertySwitch;

@end
