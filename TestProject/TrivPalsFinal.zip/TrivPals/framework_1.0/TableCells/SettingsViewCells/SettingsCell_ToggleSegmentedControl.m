//
//  SettingsCell_ToggleSegmentedControl.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/29/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "SettingsCell_ToggleSegmentedControl.h"


@interface SettingsCell_ToggleSegmentedControl ()

@property (retain) UISegmentedControl* propertyToggleSegmentedControl;

@end


@implementation SettingsCell_ToggleSegmentedControl

@synthesize propertyToggleSegmentedControl;

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier
{
    if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) 
	{
		CGRect frame = CGRectMake(CGRectGetMaxX(self.contentView.bounds) - 190.0, 7.0, 160.0, 32.0);
		UISegmentedControl* toggleSegmentedControl = [[UISegmentedControl alloc] initWithFrame:frame];
		toggleSegmentedControl.segmentedControlStyle = UISegmentedControlStyleBar;
		toggleSegmentedControl.autoresizingMask = UIViewAutoresizingFlexibleLeftMargin;
		self.propertyToggleSegmentedControl = toggleSegmentedControl;
		[self.contentView addSubview:toggleSegmentedControl];
		
		[toggleSegmentedControl addTarget:self 
								   action:@selector(onSelectSegment:forEvent:) 
						 forControlEvents:UIControlEventValueChanged];
		
		[toggleSegmentedControl release];
		[self setNeedsLayout];
    }
    return self;
}

- (void)onSelectSegment:(id)sender forEvent:(UIEvent *)event
{
	
	[actionTarget performSelector:onChange withObject:self];
}

- (NSString*) value
{
	return [NSString stringWithFormat:@"i", propertyToggleSegmentedControl.selectedSegmentIndex];
}
- (void)layoutSubviews 
{
    [super layoutSubviews];
	[self.contentView addSubview:self.propertyToggleSegmentedControl];	
}

@end
