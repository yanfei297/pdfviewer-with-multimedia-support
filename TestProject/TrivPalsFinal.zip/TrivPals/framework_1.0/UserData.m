//
//  UserData.m
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "UserData.h"


@implementation UserData
@synthesize userID,userName,displayName,realName;
@end
