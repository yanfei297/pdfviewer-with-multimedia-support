//
//  UserData.h
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UserData : NSObject 
{
	NSString *userID;
	NSString *userName;
	NSString *displayName;
	NSString *realName;
}
@property (copy) NSString *userID;
@property (copy) NSString *userName;
@property (copy) NSString *displayName;
@property (copy) NSString *realName;
@end
