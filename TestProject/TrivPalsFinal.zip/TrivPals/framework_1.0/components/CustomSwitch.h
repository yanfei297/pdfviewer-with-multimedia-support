//
//  CustomSwitch.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 7/6/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UISwitch (extended)
- (void) setAlternateColors:(BOOL) boolean;
@end

@interface _SwitchSlider : UIView
@end

@interface CustomSwitch : UISwitch
- (void) setLeftLabelText: (NSString *) labelText;
- (void) setRightLabelText: (NSString *) labelText;
@end
