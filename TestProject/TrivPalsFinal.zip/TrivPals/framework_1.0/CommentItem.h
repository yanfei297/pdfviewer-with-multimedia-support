//
//  CommentItem.h
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserData.h"

@interface CommentItem : NSObject
{
	int commentID;
	int contentID;
	NSString *commentDate;
	UserData *user;
	NSString *commentText;
}
@property (assign) int commentID;
@property (assign) int contentID;
@property (copy) NSString *commentDate;
@property (copy) UserData *user;
@property (copy) NSString *commentText;
@end
