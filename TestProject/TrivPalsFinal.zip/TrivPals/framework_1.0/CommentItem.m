//
//  CommentItem.m
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "CommentItem.h"


@implementation CommentItem
@synthesize commentID,contentID,commentDate,user,commentText;
-(id)init
{
	if(self = [super init])
	{
		user = [[UserData alloc] init];
	}
	return self;
}
@end
