//
//  DocumentLoader.h
//  EyeReport
//
//  Create by Andrew Paul Simmons on 9/30/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"

@interface DocumentLoader : NSObject 
{	
	NSMutableData* receivedData;
	
	id actionTarget;
	SEL onSuccess;
	SEL onFailure;
}

//:: Public

@property (assign) SEL onSuccess, onFailure;
@property (assign) id actionTarget;
+ (void) loadDocumentAtURL:(NSString*)url actionTarget:(id)target success:(SEL)success_cb failure:(SEL)failure_cb;
- (id) initWithURL:(NSString*)stringURL;

//:: Private

@end
