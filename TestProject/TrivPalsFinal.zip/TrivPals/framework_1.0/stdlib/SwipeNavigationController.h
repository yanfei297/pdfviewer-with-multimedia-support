//
//  SwipeNavigationController.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/9/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Utils.h"
@interface SwipeNavigationController : UIViewController <UIScrollViewDelegate>
{
	UIScrollView *scrollView;
	UIPageControl *pageControl;
    NSMutableArray *viewControllers;
	int numPages;
	BOOL pageControlUsed;
	float spaceBetweenPages;
	float uiTopOffset;
}

//::Public

- (id)initWithViewControllers:(NSArray *)someViewController;

@property (nonatomic, retain) IBOutlet UIScrollView *scrollView;
@property (nonatomic, retain) IBOutlet UIPageControl *pageControl;
@property (nonatomic, retain) NSMutableArray *viewControllers;

- (void) setSwipeViewControllers:(NSArray*)someViewControllers;


//::Private
- (void) navigateToPreviousPage;
- (void) navigateToNextPage;
-(void) pageDidChange:(int)newPageNumber; //override
- (void) removeDistantViewsFromViewAtIndex:(int)index;
- (IBAction) changePage:(id)sender;
@end
