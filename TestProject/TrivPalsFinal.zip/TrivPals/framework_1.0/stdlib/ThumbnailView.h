//
//  ThumbnailView.h
//  eMagazine
//
//  Created by SOHAMPAUL on 04/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface ThumbnailView : UIView {

}
- (id)initWithOrigin:(CGPoint)origin andImage:(UIImage*)img;
@end
