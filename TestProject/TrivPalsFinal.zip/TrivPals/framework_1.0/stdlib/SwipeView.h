//
//  SwipeView.h
//  Swipe_View
//
//  Created by Amrit on 04/03/09.
//  Copyright 2009 __GlobalLogic__. All rights reserved.
//

#import <UIKit/UIKit.h>


// Maccro Defination
#define kEdgePadding					160
#define kDefaultPadding					 0 

#define kDefaultNumLeftViewsToStore       2
#define kDefaultNumRightViewsToStore	  3

#define HORIZ_SWIPE_DRAG_MIN             10
#define VERT_SWIPE_DRAG_MAX               4
#define kDefaultScrollWidth		        320
#define kDefaultScrollHeight	        480


@class SwipeView;

// Data surce protocol
@protocol SwipeViewDataSource<NSObject>

@required
// After a view has been released from memory SwipeView will need to request the 
// view from the data source. 
- (UIView*) swipeView:(SwipeView*)swipeView viewForIndex:(int)index;
- (NSInteger)numberOfViewsInSwipView:(SwipeView*)swipeView;

@end

// SwipeView Delegate
@protocol SwipeViewDelegate <NSObject>
@optional
// if delegate is nil or if shouldSlideForwardToView:viewIndex: or shouldSlideBackwardToView:viewIndex: 
// are not implemented SwipeViewController should behave as if shouldSlideForwardToView:viewIndex: and 
// shouldSlideBackwardToView:viewIndex: were implemented so that they always returned YES. 
- (BOOL) shouldSlideForwardToView:(UIView*)view viewIndex:(int)viewIndex;
- (BOOL) shouldSlideBackwardToView:(UIView*)view viewIndex:(int)viewIndex;

// invoked immediately after currentView is updated to point to the new currently visible view.
- (void) didSlideForwardToView:(UIView*)view previousView:(UIView*)view; 
- (void) didSlideBackwardToView:(UIView*)view previousView:(UIView*)view; 

// When a view is about to be released willUnloadView is invoked.
// (Views are released when they are more than numRightViewsToStore or numLeftViewsToStore removed from currentView.
// Also, all views, except currentView, are released in response to low memory warnings.) 
- (void) willUnloadView:(UIView*)view;
@end

/******************************************************************************
 Class Name: SwipeView
 
 Inherits From: UIScrollView:UIView
 
 Description: The SwipeView Class is used to acheive the swipe gesture along the
 iPhone screen.This class is derived from the UIScrollView.The advantage of using 
 the UIScrollView class is that it provides us the functionality to swipe across 
 multiple pages both horizonatlly and vertically by default.To suite our purpose
 we have just used the horizontal scroll.
 ******************************************************************************/

@interface SwipeView : UIScrollView <UIScrollViewDelegate>
{
	UIView *currentView;
	
	// maintain the view Padding Deviation value
	NSUInteger	 viewPaddingValue;
	int currentPageIndex; // ivar to maintain currentPageIndex
	int numViews;		  // ivar to maintain total number of views
	float x_CordinateForPreviousView;
	CGPoint startTouchPosition; //ivar maintaining the stat touch pixel
	
	id <SwipeViewDelegate>   aDelegate;
	id <SwipeViewDataSource> dataSource;
	
	BOOL b_shouldSlideForward ;
	BOOL b_shouldSlideBackWard;
	//int previousPageIndex;
}

#pragma mark propertyDecalration
@property (readonly)			UIView *currentView;
@property (readonly)			int currentPageIndex;
@property (readonly)			int numViews;
@property (nonatomic,assign)	id <SwipeViewDelegate> aDelegate;
@property (nonatomic,assign)	id <SwipeViewDataSource> dataSource;

#pragma mark initialization methods
// initializes view and displays view firstView 
// viewPadding is space seen between views when the user is performing a horizontal swipe.
// [see diagram 1_LeftSwipe.png]
-(id) initWithFirstView:(UIView*)firstView viewPadding:(float)viewPadding;

// invokes initWithFirstView:viewPadding with padding of kDefaultPadding pixels
-(id) initWithFirstView:(UIView*)firstView;


#pragma mark add a view
// adds view after the rightmost view
-(void) addView:(UIView*)view;


#pragma mark remove a view
// removes view and performs the first possible of the following actions 
// 1) if view is currentView, SwipeView animates back one view after invoking shouldSlideBackwardToView:viewIndex: 
//		(if shouldSlideBackwardToView:viewIndex: returns NO, raises an exception)
// 2) if view is currentView and leftmost view, SwipeView animates forward after invoking shouldSlideForwardToView:vewIndex:
//		(if shouldSlideForwardToView:vewIndex: returns NO, raises an exception)
// 3) if numViews is 1, removeView does NOT remove the only view and instead raises an exception. 
- (void) removeView:(UIView*)view;
- (void) removeViewAtIndex:(int)index;


#pragma mark Slide actions
//slides forward one view  if shouldSlideForwardToView:vewIndex: returns YES
- (void) slideForwardAnimated:(BOOL)animated;
//slides backward one view  if shouldSlideBackwardToView:viewIndex:returns YES
- (void) slideBackwardAnimated:(BOOL)animated;

#pragma mark slide to view
// if view is to the left of currentView slides view in from the left (if shouldSlideBackwardToView:viewIndex:returns YES)
// if view is to the right of currentView slides view in from the right (shouldSlideForwardToView:vewIndex: returns YES)
// Views between currentView and view are not seen in the animation; however, the order of the views is unchanged.
- (void) slideToView:(UIView*)view;
@end
