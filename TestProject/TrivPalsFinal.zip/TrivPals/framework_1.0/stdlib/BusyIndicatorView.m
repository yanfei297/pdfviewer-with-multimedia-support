//
//  BusyIndicatorView.m
//  SwamiParthSarathi
//
//  Created by Sayan on 31/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "BusyIndicatorView.h"

@interface BusyIndicatorView (Private)

-(void) initializeSharedInstance;

@end

@implementation BusyIndicatorView (Private)

-(void) initializeSharedInstance{
    
}

@end

@implementation BusyIndicatorView

static BusyIndicatorView *_sharedInstance;

@synthesize loadingView = _loadingView;
//@synthesize spinner = _spinner;
@synthesize loadingText = _loadingText;

#pragma mark - Initialize

- (id)initWithFrame:(CGRect)frame andLoadingText:(NSString *)text
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.loadingText = text;
        UILabel  *lblLoadingView=[[UILabel alloc]initWithFrame:CGRectMake(50,25,135,37)];
        lblLoadingView.text=self.loadingText;
        lblLoadingView.font=[UIFont fontWithName:@"Verdana-Bold" size:17];
        lblLoadingView.textColor=[UIColor whiteColor];
        lblLoadingView.textAlignment=UITextAlignmentRight;
        lblLoadingView.backgroundColor=[UIColor clearColor];
        UIActivityIndicatorView *spinner = [[[UIActivityIndicatorView alloc] initWithFrame:CGRectMake(0,2,35,35)] autorelease];
        spinner.activityIndicatorViewStyle = UIActivityIndicatorViewStyleWhite;
        spinner.autoresizingMask = (UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin);
        spinner.backgroundColor=[UIColor clearColor];
        spinner.opaque=YES;
        [lblLoadingView addSubview:spinner];
        self.loadingView = lblLoadingView;
        [lblLoadingView release];
    }
    return self;
}

//convenient approach to initialize

+ (BusyIndicatorView *) defaultLoadingViewWithFrame:(CGRect)frame andText:(NSString *)loadingText{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] initWithFrame:frame andLoadingText:loadingText];
        [_sharedInstance initializeSharedInstance];
    }
    return _sharedInstance;
}

+ (BusyIndicatorView *) defaultLoadingViewWithText:(NSString *)loadingText{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] initWithFrame:CGRectZero andLoadingText:loadingText];
        [_sharedInstance initializeSharedInstance];
    }
    return _sharedInstance;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
    
}
*/

#pragma mark - Loading Text
- (void) setText:(NSString *)text{
    self.loadingText = text;
    self.loadingView.text = self.loadingText;
}
#pragma mark - Loading
-(void)startLoading
{
	UIAlertView *alert=[[UIAlertView alloc]initWithTitle:@"" message:@"" delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
//    NSLog(@"Loading Text : %@",self.loadingText);
//    NSLog(@"TEXT : %@",self.loadingView.text);
	[alert addSubview:self.loadingView];
	[(UIAlertView *)[self.loadingView superview] show];
	[[self.loadingView.subviews objectAtIndex:0] startAnimating];
	[alert release];	
	
}

-(void)stopLoading
{
	[[self.loadingView.subviews objectAtIndex:0] stopAnimating];
	[(UIAlertView *)[self.loadingView superview] dismissWithClickedButtonIndex:0 animated:YES];
}

- (BOOL) isAnimating{
    UIActivityIndicatorView *animator =[self.loadingView.subviews objectAtIndex:0];
    return [animator isAnimating];
}

- (void) networkIndicatorVisible:(BOOL)visible{
    [[UIApplication sharedApplication] setNetworkActivityIndicatorVisible:visible];
}

@end
