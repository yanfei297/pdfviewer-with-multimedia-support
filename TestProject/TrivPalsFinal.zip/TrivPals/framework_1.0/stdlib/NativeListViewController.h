//
//  NativeListViewController.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/6/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "CellDescription.h"
#import	"TreemoTableCellProtocol.h"
#import "ListCell.h"
#import "TextOnlyListCell.h"

#define TTCProtocol UITableViewCell<TreemoTableCellProtocol>

@interface NativeListViewController : UIViewController <UITableViewDelegate, UITableViewDataSource>
{
	UITableView* tableView;
	NSMutableArray* cellDescriptions;
}

//::Public


//::Protected

@property(nonatomic, retain) UITableView* tableView;

//- (void) setupContent; // recommended for classes extending NativeListViewController
//- (void) buildCellDescriptions; // recommended for classes extending NativeListViewController


//::Private

- (TTCProtocol*) treemoCellForType:(NSString*)type;
- (void) setupTableView;


@end
