//
//  untitled.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/19/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <MapKit/MapKit.h>
#import <MapKit/MKAnnotation.h>
#import <MapKit/MKAnnotationView.h>

@interface BasicMapAnnotation : NSObject <MKAnnotation>
{
	CLLocationCoordinate2D coordinate;
	NSString* title;
	NSString* subtitle;
}


//::Public
- (id) initWithCoordinate:(CLLocationCoordinate2D)coords title:(NSString*)title subtitle:(NSString*)subtitle; 

@property (nonatomic, readonly) CLLocationCoordinate2D coordinate;
- (NSString *) title;
- (NSString *) subtitle;

//::Private


@end
