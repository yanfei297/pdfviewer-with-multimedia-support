//
//  TraceImage.m
//  HarpersIsland
//
//  Create by Andrew Paul Simmons on 4/6/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "TraceImageView.h"

//UIImage
@implementation TraceImageView

static int numImages;

- (id) initWithImageNamed:(NSString*) imageName  memlog:(BOOL)memlog 
{
	if(!imageName)
	{
		////////NSLog(@"cannot create image with nil image name");
	}
	
	logAllocationsAndDeallocations = NO; //memlog;
	
	NSArray* fileName_ary = [imageName componentsSeparatedByString:@"."];
	NSString* filePath = [[NSBundle mainBundle] pathForResource:[fileName_ary objectAtIndex:0] 
														 ofType:[fileName_ary objectAtIndex:1]];  
	UIImage* image = [UIImage imageWithContentsOfFile:filePath];
	
	if(image.size.width < 1 && ![imageName isEqual:@"nil.png"])
	{
		////////NSLog(@"Image [%@] may not exist", imageName);
	}
	if(self = [super initWithImage:[UIImage imageWithContentsOfFile:filePath]])
	{
		myImageName = [imageName copy];
		if(logAllocationsAndDeallocations)
		{
            numImages++;
			NSLog(@"%i >>>>>>> Performing alloc of image %@", numImages, myImageName);
		}
		
	}
	return self;
}

- (void)dealloc 
{
	if(logAllocationsAndDeallocations)
	{
        numImages--;
		NSLog(@"%i <<<<<<< Performing dealloc of image %@", numImages, myImageName);
	}
	[myImageName release];
    [super dealloc];
}

@end
