//
//  FormViewController.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 8/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "FormViewController.h"


#define FIELD_SCROLL_OFFSET 190  // The number of pixels above the text field to scroll to


@implementation FormViewController

// Implement loadView if you want to create a view hierarchy programmatically
- (void)loadView 
{
	[super loadView];
	hitArea = [[[HitAreaView alloc] initWithFrame:CGRectMake(0, 0, 320, 480)] autorelease];
	hitArea.actionTarget = self;
	hitArea.onPress = @selector(onClickOut);
	
	//[self.view addSubview:hitArea];
	viewAsSrollView = (UIScrollView*)self.view;
	viewAsSrollView.scrollEnabled = YES;
	viewAsSrollView.alwaysBounceVertical = YES;
	//viewAsSrollView.indicatorStyle = UIScrollViewIndicatorStyleWhite;
	editContentFrameSize.width = 320;
	editContentFrameSize.height = 480;
	normalContentFrameSize.width = 320;
	normalContentFrameSize.height = 480;

	UIEdgeInsets edgeInsets;
	edgeInsets.top = 0;
	edgeInsets.bottom = 50;
	edgeInsets.left = 0;
	edgeInsets.right = 0;
	viewAsSrollView.contentInset = edgeInsets;
	[self.view insertSubview:hitArea atIndex:0];
}

- (void)viewDidLoad
{
	[super viewDidLoad];
	viewAsSrollView.contentSize = normalContentFrameSize;
}

@synthesize editContentFrameSize;
@synthesize normalContentFrameSize;

- (void) viewDidAppear:(BOOL)animated
{
	[super viewDidAppear:animated];
	[viewAsSrollView flashScrollIndicators];
	/* scroll so that a rect is visible 
	 CGRect frame;
	 frame.origin.x = 0;
	 frame.origin.y = 800;
	 frame.size.width = 320;
	 frame.size.height = 200;
	 
	 ////////NSLog(@"Doing animated scroll");
	 [viewAsSrollView scrollRectToVisible:description_tv.frame animated:YES];
	 */
	
	// scroll to a specific offset 
	/*
	 CGPoint offset;
	 offset.x = 0;
	 offset.y = description_lb.frame.origin.y - 5;
	 [viewAsSrollView setContentOffset:offset animated:YES];
	 */
	
}
- (void)dealloc {
	[super dealloc];
}

- (void) onClickOut // override this
{
	
	[self scrollToTop];
	////////NSLog(@"Clicked Out");
}

- (BOOL) textViewShouldBeginEditing:(UITextView*)text_tv
{
	
	if(suppressAutoOffsetAdjust)
	{
		return YES;
	}
	
	CGPoint offset;
	offset.x = 0;
	offset.y = text_tv.frame.origin.y + text_tv.frame.size.height  - FIELD_SCROLL_OFFSET;
	//////////NSLog(@"CurrentOffset = %d, NewOffset = %d", viewAsSrollView.contentOffset.y, offset.y);
	if(offset.y < 0) return YES;
	[viewAsSrollView setContentOffset:offset animated:YES];
	
	viewAsSrollView.contentSize = editContentFrameSize;
	////////NSLog(@"TextView textViewShouldBeginEditing");
	return YES;
}

- (void) viewWillAppear:(BOOL)animated
{
	[super viewWillAppear:animated];
	
	CGPoint offset;
	offset.x = 0;
	offset.y = 0;
	viewAsSrollView.contentSize = normalContentFrameSize;
	[viewAsSrollView setContentOffset:offset animated:NO];
	////////NSLog(@"View Scrolled to the top");
}

- (void)viewWillDisappear:(BOOL)animated
{
	[super viewWillDisappear:animated];
	CGPoint offset;
	offset.x = 0;
	offset.y = 0;
	viewAsSrollView.contentSize = normalContentFrameSize;
	[viewAsSrollView setContentOffset:offset animated:NO];
}

- (void) textViewDidBeginEditing:(UITextView*)text_tv
{
	////////NSLog(@"TextView textViewDidBeginEditing");
}

- (BOOL) textViewShouldEndEditing:(UITextView*)text_tv
{
	////////NSLog(@"TextView textViewShouldEndEditing");
	return YES;
}

- (void) textViewDidEndEditing:(UITextView*)text_tv
{
	////////NSLog(@"TextView textViewDidEndEditing");
}

- (void)textViewDidChange:(UITextView *)text_tv
{
	////////NSLog(@"TextView textViewDidChange");
}

- (BOOL) textFieldShouldBeginEditing:(UITextField*)text_txt
{
	
	if(suppressAutoOffsetAdjust)
	{
		return YES;
	}
	
	CGPoint offset;
	offset.x = 0;
	offset.y = text_txt.frame.origin.y + text_txt.frame.size.height - FIELD_SCROLL_OFFSET;
	if(offset.y < 0) return YES;
	//	////////NSLog(@"CurrentOffset = %f, NewOffset = %f", viewAsSrollView.contentOffset.y, offset.y);
	[viewAsSrollView setContentOffset:offset animated:YES];
	////////NSLog(@"Content INset updated");

	/*
	[viewAsSrollView scrollRectToVisible:text_txt.frame animated:YES];
	////////NSLog(@"TextField textFieldShouldBeginEditing");
	*/
	return YES;
}

- (void) textFieldDidBeginEditing:(UITextField*)text_txt
{
	viewAsSrollView.contentSize = editContentFrameSize;
	////////NSLog(@"TextField textFieldDidBeginEditing");
}

- (BOOL) textFieldShouldEndEditing:(UITextField*)text_txt
{
	////////NSLog(@"TextField textFieldShouldEndEditing");
	return YES;
}

- (void) textFieldDidEndEditing:(UITextField*)text_txt
{
	
}


- (void)textFieldDidChange:(UITextField *)text_txt
{
	////////NSLog(@"TextField textFieldDidChange");
}

- (BOOL)textFieldShouldReturn:(UITextField *)text_txt
{
	////////NSLog(@"TextField textFieldDidEndEditing Scrolling to top");
	if(suppressAutoOffsetAdjust)
	{
		return YES;
	}
	[self scrollToTop];
	[text_txt  resignFirstResponder];
	return YES;
}

- (void) scrollToTop
{

	CGPoint offset;
	offset.x = 0;
	offset.y = 0;
	//viewAsSrollView.contentSize = normalContentFrameSize;
	[viewAsSrollView setContentOffset:offset animated:YES];
}
@end
