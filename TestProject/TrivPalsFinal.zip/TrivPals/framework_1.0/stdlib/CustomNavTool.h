//
//  CustomNavTool.h
//  AssociatedContent
//
//  Created by andrew on 5/5/10.
//  Copyright 2010 Apple Inc. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface UINavigationBar (APSBackgroundImage)

- (void)scInsertSubview:(UIView *)view atIndex:(NSInteger)index;
- (void)scSendSubviewToBack:(UIView *)view;

@end

@interface CustomNavTool : NSObject 
{

}
+(UIColor *)setNavBarColor:(int)color;
+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				 withHeaderImageNamed:(NSString*)imageName;
+ (void)customizeNavigationController:(UINavigationController*)navigationController 
				  withHeaderImageView:(UIImageView*)navImageView;
@end
