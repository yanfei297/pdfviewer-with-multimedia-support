//
//  APIBinding.m
//  MyImagePicker
//
//  Create by Andrew Paul Simmons on 7/26/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "APIBinding.h"
#import "ApplicationAPIBinding.h"
#import "SafeDictionary.h"
#define PROPERTY_TAG_TOKEN @"__prop__"
#define DECIMAL_POINT_TOKEN @"__dp__"
/*
 Array
 (
    [method] => treemo.auth.getTokenFromCredentials
    [password] => test
    [username] => foouser
 )
 */


#define BITLY_VER @"2.0.1"
#define BITLY_USRNAME @"treemo" 
#define BITLY_KEY @"R_b0ffca95f36cfaaf7ae5eea1049f8ee8"

@implementation APIBinding




static NSString* auth_token;


+ (Requester*) bitlyShortenURLRequest:(NSString*)longURL
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_action = @"shorten";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:longURL forKey:@"longUrl"]; 
	[vars setObject:BITLY_KEY forKey:@"apiKey"];
	[vars setObject:BITLY_USRNAME forKey:@"login"];
	[vars setObject:BITLY_VER forKey:@"version"];
	
	SEL rh = @selector(bitlyResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeGetRequestWithURL:@"http://api.bit.ly"
								forAction:api_action 
								paramters:vars
						  responseHandler:rh 
						   failureHandler:fh
								   target:target
							   success_cb:success
							   failure_cb:failure
									extra:nil];
}
//::Public
/*
+ (void)trustedGetToken:(NSString*)username
{
	NSString* api_method = @"treemo.auth.trustedGetToken";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	[vars setObject:username forKey:@"username"];
	[self makeRequest:api_method paramters:vars delegate:self requestMethod:nil];
}
*/
+ (void) SetGenericPushToken:(NSString*)deviceToken
				actionTarget:(id)target
				  success_cb:(SEL)success
				  failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.registerDevice";
	//auth_token = [Utils preferenceWithKey:@"authToken"];
	//if(auth_token == nil) 
	//{
	//////NSLog(@"Error cannot login! auth_token is nil!!");
	////	return;
	//}
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	
	[vars setObject:deviceToken forKey:@"push_token"];
	//[vars setObject:auth_token forKey:@"auth_token"];
	//NSString* tmp1 = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"];
	//NSString* tmp2 = [[UIDevice currentDevice] uniqueIdentifier];
	//NSString* tmp3 = deviceToken;
	////NSLog(@"App_id: %@",[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"]);
	[vars setObject:[[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleIdentifier"]  forKey:@"application_id"];
	[vars setObject:[[UIDevice currentDevice] uniqueIdentifier] forKey:@"device_id"];
	//[vars setObject:API_KEY forKey:@"api_key"]; 
	
	SEL rh = @selector(onPushTokenSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:target success_cb:success failure_cb:failure];
	
}

+ (void) SetPushToken:(void*)deviceToken
		 actionTarget:(id)target
		   success_cb:(SEL)success
		   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.setPushToken";
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nil!!");
		return;
	}
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	
	[vars setObject:deviceToken forKey:@"push_token"];
	[vars setObject:auth_token forKey:@"auth_token"];
	
	SEL rh = @selector(onPushTokenSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:target success_cb:success failure_cb:failure];
	
}

+ (void) changeEmailPreference:(BOOL)isOn
{
	NSString* api_method = @"treemo.users.setPreferences";
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nil!!");
		return;
	}
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:auth_token forKey:@"auth_token"];
	[vars setObject:[NSString stringWithFormat:@"notificationTimePreference::%@::::notificationMethodPreference::email::::uploadToGroupsEmailPreference::everyone",(isOn?@"immediate":@"never")]
			 forKey:@"preferences"];
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:@selector(doNothing)
	   failureHandler:@selector(doNothing)
			   target:nil 
		   success_cb:@selector(doNothing) 
		   failure_cb:@selector(doNothing)];
		
}
+(void) doNothing{}

+ (void) onPushTokenSuccess:(APIResponseHandler*)apirh
{	
	////NSLog(@"Push_token recieved by server: %@!",apirh.response);
}

+ (void)setAuthToken:(NSString*)authToken

{
	auth_token = authToken;
}


+ (NSString*) authLoginFromAuthTokenRequest:(NSString*)url //relativeURL
{
	NSString* api_method = @"treemo.auth.loginFromAuthToken";
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nil!!");
		return nil;
	}
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	[vars setObject:api_method forKey:@"method"];
	[vars setObject:API_KEY forKey:@"api_key"]; // changed APIBinding to self
	[vars setObject:url forKey:@"tossto"];
	[vars setObject:auth_token forKey:@"auth_token"];
	NSString* api_sig = [self generateSignature:vars];
	[vars setObject:api_sig forKey:@"api_sig"];

	NSString* methodWithVars_url = [[API_URL stringByAppendingString:@"?"] 
											  stringByAppendingString:[Requester urlEncodeVars:vars]];
	
	////////NSLog(@"Method URL: %@", methodWithVars_url);
	//[vars release];
	return methodWithVars_url;
}
+ (void) logAppAction:(NSString*)application_action
	  applicationName:(NSString*)application_name
   applicationVersion:(NSString*)application_version
			 username:(NSString*)username
			installID:(NSString*)install_id
		   linkDomain:(NSString*)link_domain
{
	NSString* api_method = @"treemo.log.appAction";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:8];
	
	[vars setObject:application_action forKey:@"application_action"];
	[vars setObject:application_name forKey:@"application_name"];
	
	[vars setObject:application_version forKey:@"application_version"];
	[vars setObject:username forKey:@"username"];
	[vars setObject:install_id forKey:@"install_id"];
	[vars setObject:link_domain forKey:@"link_domain"];

	SEL rh = @selector(onLogAppActionSuccess:);
	SEL fh = @selector(onLogAppActionFailure:withRequester:);
	
	[self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:nil success_cb:nil failure_cb:nil];
}

+ (void) onLogAppActionSuccess:(APIResponseHandler*)apirh
{
	//////////NSLog(@"Action Logged Successfully %@", apirh.response );
}

+ (void) onLogAppActionFailure:(APIResponseHandler*) apirh withRequester:(Requester*)r
{
	////////NSLog(@"Action Logged Failure %@", apirh.response );
}

+ (void) passwordUpdate:(NSString*)password
			oldPassword:(NSString*)oldPassword
		   actionTarget:(id)target
			  onSuccess:(SEL)onSuccess
			  onFailure:(SEL)onFailure
{
	NSString* api_method = @"treemo.users.changePassword";
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nil!!");
		return;
	}
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:auth_token forKey:@"auth_token"];
	[vars setObject:oldPassword forKey:@"old_password"];
	[vars setObject:password forKey:@"password"];
	
	SEL rh = @selector(onPasswordUpdateSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars 
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:onSuccess 
		   failure_cb:onFailure];
	
	
}

+ (void) onPasswordUpdateSuccess:(APIResponseHandler*) apirh
{
	////////NSLog(@"Got response: %@",apirh.response);
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/user"])
	{

		[apirh.target performSelector:apirh.success withObject:nil];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
	
	
}
+ (void) authGetTokenFromUsername:(NSString*)username 
					  andPassword:(NSString*)password
				   responseTarget:(id)target
					   success_cb:(SEL)success
					   failure_cb:(SEL)failure

{
	////////NSLog(@"Getting auth token");
	NSString* api_method = @"treemo.auth.getTokenFromCredentials";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
 
	[vars setObject:username forKey:@"username"];
	[vars setObject:password forKey:@"password"];
	[vars setObject:@"true" forKey:@"returnAuth"];
	
	SEL rh = @selector(onAuthGetTokenResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars 
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
}

+ (void) onAuthGetTokenResponse:(APIResponseHandler*)apirh
{
	////////NSLog(@"\n\n\nGot authtoken response %@\n\n\n", apirh.response );

	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/response/auth/user/username"])
	{
		NSString* username = [xml firstValueWithPath:@"/response/auth/user/username"];
		[self parseAndHandleAuthenticationXML:xml];
		[apirh.target performSelector:apirh.success withObject:username];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}



// should return requester
+ (Requester*) exploreGetMostRecentWithPageSize:(int)page_size
										   type:(NSString*)contentTypeOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.explore.getMostRecent";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	if(contentTypeOrNil)
	{
		[vars setObject:contentTypeOrNil forKey:@"type"];
	}
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
	SEL rh = @selector(onTagsGetListContentForTag:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];
}

+ (Requester*) exploreGetMostViewedWithPageSize:(int)page_size
										   type:(NSString*)contentTypeOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.explore.getMostViewed";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	if(contentTypeOrNil)
	{
		[vars setObject:contentTypeOrNil forKey:@"type"];
	}
    
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
    [vars setObject:[NSString stringWithString:@"thisweek"] forKey:@"timeframe"];
    
	SEL rh = @selector(onTagsGetListContentForTag:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];
}

+ (Requester*) exploreGetMostCommentedWithPageSize:(int)page_size
										   type:(NSString*)contentTypeOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.explore.getMostCommented";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	if(contentTypeOrNil)
	{
		[vars setObject:contentTypeOrNil forKey:@"type"];
	}
    
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
    [vars setObject:[NSString stringWithString:@"thisweek"] forKey:@"timeframe"];

	SEL rh = @selector(onTagsGetListContentForTag:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];
}


/*
 
 treemo.channel.getList
 username 
 page_number
 page_size
*/

+ (Requester*) channelGetListContentForUsername:(NSString*)username
									  authToken:(NSString*)authTokenOrNil
									   pageSize:(int)page_size
									contentType:(NSString *)contentType
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	return [self channelGetListContentForUsername:username
										authToken:authTokenOrNil
										 pageSize:page_size
									   pageNumber:1
									  contentType:contentType
								   responseTarget:target
									   success_cb:success
									   failure_cb:failure];
}

+ (Requester*) channelGetListContentForUsername:(NSString*)username
									  authToken:(NSString*)authTokenOrNil
									   pageSize:(int)page_size
									 pageNumber:(int)page_number
									contentType:(NSString *)contentType
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.channel.getList";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	////////NSLog(@"Loading channel %@ ", username);
	
	[vars setObject:username forKey:@"username"];
	if(authTokenOrNil)[vars setObject:authTokenOrNil forKey:@"auth_token"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_number] forKey:@"page_number"];
	[vars setObject:contentType  forKey:@"type"];
	
	SEL rh = @selector(onTagsGetListContentForTag:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	//////////NSLog(@"loading channel");
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure extra:username];	
}

#pragma mark  CONTENT INFO 
+(Requester *)channelGetContentInfoForContentID:(NSString *)contentID
									  authToken:(NSString*)authTokenOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.channel.getInfo";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	////////NSLog(@"Loading channel %@ ", username);
	
	[vars setObject:contentID forKey:@"content_id"];
	if(authTokenOrNil)[vars setObject:authTokenOrNil forKey:@"auth_token"];
	
	//Place new methods here for parsing the response
	SEL rh = @selector(onContentInfoReceived:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	//////////NSLog(@"loading channel");
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure extra:contentID];
}

+ (void) onContentInfoReceived:(APIResponseHandler*)apirh
{
	////////NSLog(apirh.response);
	NSLog(@"Respons: %@", apirh.response);
	NSString* tag = (NSString*)apirh.extra;
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	/*// for testing
	 [xml release];
	 [apirh.target performSelector:apirh.failure withObject:@"PhonyTag" withObject:@"Some error"];
	 return;
	 */
	//////////NSLog(@"Response %@", apirh.response);
	xmlNodeSetPtr nodeset;
	if(xml == nil)
	{
		////////NSLog(@"Could not create XML Document!");
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:tag withObject:error_msg];
	}
	else if( (nodeset = [xml nodeSetWithPath:@"/content"]) && nodeset->nodeNr > 0)
	{
		////////NSLog(@"Number of pages %@", [xml firstValueWithPath:@"/channel/@total_pages"]);
		
			ContentMediaItem* mediaItem = [[[ContentMediaItem alloc] init] autorelease];
			
			mediaItem.contentID = [xml firstValueWithPath:@"//content/id"];
			//////////NSLog(@"Item id: %@", mediaItem.contentID);
			mediaItem.title = [xml firstValueWithPath:@"//content/title"];
			mediaItem.description = [xml firstValueWithPath:@"//content/description"];
			
			
			if(mediaItem.description)
			{
				mediaItem.description = [Utils string:[xml firstValueWithPath:@"//content/description"]  
									 replaceSubstring:@"<br />" 
										   withString:@"\n"
									 adjacentAsSingle:YES];
				
				
			}
			
			mediaItem.numComments = [xml firstValueWithPath:@"//content/comments"];
			mediaItem.username = [xml firstValueWithPath:@"//content/owner/username"];
			//mediaItem.thumbnail = [xml firstValueWithPath:@"urls/url[@sizecode='sm']/@address" fromNode:n];
            if([Utils isPad]) {
                mediaItem.thumbnail = [xml firstValueWithPath:@"//content/urls/url[@sizecode='vl']/@address"];
            } else {
                mediaItem.thumbnail = [xml firstValueWithPath:@"//content/urls/url[@sizecode='vs']/@address"];
            }
			mediaItem.image = [xml firstValueWithPath:@"//content/urls/url[@sizecode='dd']/@address"];
			mediaItem.original = [xml firstValueWithPath:@"//content/urls/url[@sizecode='or']/@address"];
			mediaItem.mp4 = [xml firstValueWithPath:@"//content/urls/url[@sizecode='mp4']/@address"];
			
			//For Getting Original file size and Duration
			mediaItem.fileSize=[xml firstValueWithPath:@"//content/urls/url[@sizecode='or']/@filesize"];
			mediaItem.contentDuration=[xml firstValueWithPath:@"//content/urls/url[@sizecode='or']/@duration"];
			
			
			NSString* imageWidth_str = [xml firstValueWithPath:@"//content/urls/url[@sizecode='dd']/@width" ];
			NSString* imageHeight_str = [xml firstValueWithPath:@"//content/urls/url[@sizecode='dd']/@height"];
			int imageWidth_int = [imageWidth_str integerValue];
			int imageHeight_int = [imageHeight_str integerValue];
			CGSize imageSize = CGSizeMake((float)imageWidth_int, (float)imageHeight_int);
			mediaItem.imageSize = imageSize;
			
			NSString* original_imageWidth_str = [xml firstValueWithPath:@"//content/urls/url[@sizecode='or']/@width" ];
			NSString* original_imageHeight_str = [xml firstValueWithPath:@"//content/urls/url[@sizecode='or']/@height" ];
			int original_imageWidth_int = [original_imageWidth_str integerValue];
			int original_imageHeight_int = [original_imageHeight_str integerValue];
			CGSize original_imageSize = CGSizeMake((float)original_imageWidth_int, (float)original_imageHeight_int);
			mediaItem.originalImageSize = original_imageSize;
			
			
			mediaItem.date = [xml firstValueWithPath:@"//content/dates/@posted"];
			//////////NSLog(@"MediaItemDate %@", mediaItem.date);
			
			//printf("Item %d title: %s\n", i, [mediaItem.username cString]);
		
		
		[apirh.target performSelector:apirh.success withObject:tag withObject:mediaItem];
	}
	
	else
	{
		[apirh.target performSelector:apirh.failure withObject:tag withObject:nil];
	}
	
	[xml release];
}


#pragma mark  COMMENT  LIST 
+ (Requester*) commentGetListForContent:(NSString*)contentID
							  authToken:(NSString*)authTokenOrNil
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
{
    return [self commentGetListForContent:contentID
                                authToken:authTokenOrNil
                             markAsViewed:NO
                                 pageSize:page_size
                               pageNumber:page_size
                           responseTarget:target
                               success_cb:success
                               failure_cb:failure];
}

+ (Requester*) commentGetListForContent:(NSString*)contentID
							  authToken:(NSString*)authTokenOrNil
                           markAsViewed:(BOOL)mark
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.comment.getList";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	////////NSLog(@"Loading channel %@ ", username);
	
	if(authTokenOrNil)
		[vars setObject:authTokenOrNil forKey:@"auth_token"];
	[vars setObject:contentID  forKey:@"content_id"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_number] forKey:@"page_number"];
    if(mark) {
        [vars setObject:@"true" forKey:@"mark_as_viewed"];
    }
	
	SEL rh = @selector(onCommentsListRecieved:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	//////////NSLog(@"loading channel");
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure extra:contentID];	
}


+ (void) onCommentsListRecieved:(APIResponseHandler*)apirh
{
	////////NSLog(apirh.response);
	
	NSString* tag = (NSString*)apirh.extra;
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	NSLog(@"Response %@", apirh.response);
	xmlNodeSetPtr nodeset;
	if(xml == nil)
	{
		[apirh.target performSelector:apirh.failure withObject:tag withObject:nil];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:tag withObject:error_msg];
	}
	else if((nodeset = [xml nodeSetWithPath:@"/comment_list/comment"]) && nodeset->nodeNr > 0)
	{
		/*CommentsList *commentList=[[CommentsList alloc] init];
		commentList.totalItems=[[xml firstValueWithPath:@"/comment_list/@total_items"] intValue];
		commentList.totalPages=[[xml firstValueWithPath:@"/comment_list/@total_pages"] intValue];
		commentList.pageNumber=[[xml firstValueWithPath:@"/comment_list/@page_number"] intValue];
		commentList.pageSize=[[xml firstValueWithPath:@"/comment_list/@page_size"] intValue];
		
		for(int i = 0; i < nodeset->nodeNr; i++)
		{	
			xmlNodePtr n = nodeset->nodeTab[i];
			
			
			CommentItem* commentItem = [[[CommentItem alloc] init] autorelease];
			commentItem.contentID=[[xml valueWithPath:@"/comment_list/comment/comment_id" fromNode:n atIndex:i] intValue];
			commentItem.commentID=[[xml valueWithPath:@"/comment_list/comment/comment_id" fromNode:n atIndex:i] intValue];
			commentItem.commentDate=[xml valueWithPath:@"/comment_list/comment/date" fromNode:n atIndex:i];
			commentItem.user.realName=[xml valueWithPath:@"/comment_list/comment/commenter/real_name" fromNode:n atIndex:i];
			commentItem.user.displayName=[xml valueWithPath:@"/comment_list/comment/commenter/display_name" fromNode:n atIndex:i];
			commentItem.user.userName=[xml valueWithPath:@"/comment_list/comment/commenter/username" fromNode:n atIndex:i];
			commentItem.commentText=[xml valueWithPath:@"/comment_list/comment/comment_body" fromNode:n atIndex:i];
			[commentList addObject:commentItem];
		}
		[apirh.target performSelector:apirh.success withObject:tag withObject:commentList];
		*/
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:tag withObject:nil];
	}
	
	[xml release];
}

#pragma mark USER PROFILE
+ (Requester*) userProfileLoadForUser:(NSString*)userName
							authToken:(NSString*)authTokenOrNil
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.getProfile";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	////////NSLog(@"Loading channel %@ ", username);
	
	if(authTokenOrNil)
			[vars setObject:authTokenOrNil forKey:@"auth_token"];
	[vars setObject:userName  forKey:@"username"];
	[vars setObject:@"json" forKey:@"format"];
	
	
	SEL rh = @selector(onUserProfileRecieved:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	//////////NSLog(@"loading channel");
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure extra:userName];	
}


+ (void) onUserProfileRecieved:(APIResponseHandler*)apirh
{
	NSLog(@"Image create respones %@", apirh.response);
	NSDictionary* dict = [apirh.response JSONValue];
	NSLog(@"Converted json string to NSDictionary %@", dict);
	NSNumber *code=[dict objectForKey:@"code"];
	if([[NSString stringWithFormat:@"%d",[code intValue]] isEqualToString:@"401"])
	{
		NSString *strDomain=[dict objectForKey:@"error"];
		NSError *error=[[NSError alloc] initWithDomain:strDomain code:[code intValue] userInfo:nil];
		[apirh.target performSelector:apirh.failure withObject:error];
		[error release];
	}
	else 
	{
		if(dict)
		{
			
			SafeDictionary* safeDict = [SafeDictionary safeDictionaryWithDictionary:dict];
			
			//assume success 
			
			[apirh.target performSelector:apirh.success withObject:safeDict];
		}
		else 
		{
			NSString *searchForWarning = @"Warning";
			NSRange rangeWarning = [apirh.response rangeOfString : searchForWarning];
			
			NSString *searchForError = @"error";
			NSRange rangeError = [apirh.response rangeOfString : searchForError];
			
			NSString *searchBracket=@"<";
			NSRange rangeBarcket = [apirh.response rangeOfString : searchBracket];
			if (rangeWarning.location != NSNotFound || rangeError.location != NSNotFound || rangeBarcket.location != NSNotFound)
			{
				NSLog(@"I found something.");
				[apirh.target performSelector:apirh.failure withObject:nil];
			}
			
		}
		
	}
	
}


#pragma mark COMMENT ADD 
+ (Requester*) addNewCommentForContent:(NSString*)contentID
							 authToken:(NSString*)authTokenOrNil
							   comment:(NSString *)comment 
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.comment.add";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	////////NSLog(@"Loading channel %@ ", username);
	
	if(authTokenOrNil)
		[vars setObject:authTokenOrNil forKey:@"auth_token"];
	[vars setObject:contentID  forKey:@"content_id"];
	[vars setObject:comment forKey:@"comment"];
	
	
	
	SEL rh = @selector(onCommentAddedSuccessfully:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	//////////NSLog(@"loading channel");
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure extra:nil];	
}


+(void)onCommentAddedSuccessfully:(APIResponseHandler*)apirh
{
	////////NSLog(apirh.response);
	
	/*
	 <comment>
	 <comment_id>8</comment_id>
	 <content_id>38</content_id>
	 <date />
	 <commenter>
	 <username>sumitprasad</username>
	 <display_name />
	 <real_name />
	 </commenter>
	 <comment_body><![CDATA[jhdfhdhdg udgudgu]]></comment_body>
	 </comment>
	 
	 */
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	NSLog(@"Response %@", apirh.response);
	xmlNodeSetPtr nodeset;
	if(xml == nil)
	{
		[apirh.target performSelector:apirh.failure  withObject:nil];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure  withObject:error_msg];
	}
	else if((nodeset = [xml nodeSetWithPath:@"/comment/comment_id"]) && nodeset->nodeNr > 0)
	{
		/*CommentItem* commentItem = [[[CommentItem alloc] init] autorelease];
		commentItem.commentID=[[xml firstValueWithPath:@"/comment/comment_id"] intValue] ;
		commentItem.contentID=[[xml firstValueWithPath:@"/comment/content_id"] intValue];
		commentItem.commentDate=[xml firstValueWithPath:@"/comment/date"] ;
		commentItem.commentText=[xml firstValueWithPath:@"/comment/comment_body"];
		commentItem.user.userName=[xml firstValueWithPath:@"/comment/commenter/username"] ;
		commentItem.user.displayName=[xml firstValueWithPath:@"/comment/commenter/display_name"] ;
		commentItem.user.realName=[xml firstValueWithPath:@"/comment/commenter/real_name"] ;
		[apirh.target performSelector:apirh.success  withObject:commentItem];*/
	}
	[xml release];
}	
/*
 treemo.tags.getListContent
 1. api_key (Required) 
 2. api_sig (Required) 
 3. auth_token (Required) 
 4. tag (Required) the tag to search on 
 5. page_number (optional) The integer page number 
 6. page_size (optional) The integer size of the page. Defaults to 20. Acceptable Range 1-100.
*/
+ (Requester*) tagsGetListContentForTag:(NSString*)tag
							   pageSize:(int)page_size
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
{
	return [self tagsGetListContentForTag:tag
								 pageSize:page_size
							   pageNumber:1
						   responseTarget:target
							   success_cb:success
							   failure_cb:failure];
}
+ (Requester*) x:(NSString*)tag
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
{

	NSString* api_method = @"treemo.tags.getListContent";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	//////////NSLog(@"Loading tag %@ ", tag);
	[vars setObject:tag forKey:@"tag"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_size] forKey:@"page_size"];
	[vars setObject:[NSString stringWithFormat:@"%i", page_number] forKey:@"page_number"];
	
	SEL rh = @selector(onTagsGetListContentForTag:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:target success_cb:success failure_cb:failure extra:tag];
}


+ (void) onTagsGetListContentForTag:(APIResponseHandler*)apirh
{
	////////NSLog(apirh.response);
	NSLog(@"Respons: %@", apirh.response);
	NSString* tag = (NSString*)apirh.extra;
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	/*// for testing
	 [xml release];
	 [apirh.target performSelector:apirh.failure withObject:@"PhonyTag" withObject:@"Some error"];
	 return;
	 */
	//////////NSLog(@"Response %@", apirh.response);
	xmlNodeSetPtr nodeset;
	if(xml == nil)
	{
		////////NSLog(@"Could not create XML Document!");
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:tag withObject:error_msg];
	}
	else if( (nodeset = [xml nodeSetWithPath:@"/channel/content"]) && nodeset->nodeNr > 0)
	{
		////////NSLog(@"Number of pages %@", [xml firstValueWithPath:@"/channel/@total_pages"]);
		
		ContentList* contentItems = [[[ContentList alloc] init] autorelease];
		contentItems.totalNumberOfPages = [[xml firstValueWithPath:@"/channel/@total_pages"] intValue];
		contentItems.totalNumberOfItems = [[xml firstValueWithPath:@"/channel/@total_items"] intValue];
		contentItems.pageSize = [[xml firstValueWithPath:@"/channel/@page_size"] intValue];
		contentItems.pageNumber = [[xml firstValueWithPath:@"/channel/@page_number"] intValue];
	
		
		for(int i = 0; i < nodeset->nodeNr; i++)
		{	
			ContentMediaItem* mediaItem = [[[ContentMediaItem alloc] init] autorelease];
			xmlNodePtr n = nodeset->nodeTab[i];
			
			
			xmlNodeSetPtr tagNodes = [xml nodeSetWithPath:@"tags/tag" fromNode:n];
			NSMutableString* tags = [[[NSMutableString alloc] initWithCapacity:0] autorelease];
			NSMutableDictionary* propertyTags = [[[NSMutableDictionary alloc] initWithCapacity:0] autorelease];
			if(tagNodes && tagNodes->nodeNr > 0)
			{
				for(int j = 0; j < tagNodes->nodeNr; j++)
				{
					NSString* tag = [xml valueWithPath:@"tags/tag/@raw" fromNode:n atIndex:j];
					if([Utils string:tag containsSubstring:PROPERTY_TAG_TOKEN])
					{
						NSArray* tag_prsary = [Utils splitString:tag onString:PROPERTY_TAG_TOKEN];
						NSString* propertyName = [tag_prsary objectAtIndex:0];
						NSString* propertyValue = [tag_prsary objectAtIndex:1];
						if([Utils string:propertyValue containsSubstring:DECIMAL_POINT_TOKEN])
						{
							propertyValue = [Utils string:propertyValue replaceSubstring:DECIMAL_POINT_TOKEN withString:@"."];
						}
						
						[propertyTags setObject:propertyValue forKey:propertyName];
					}
					else
					{
						if([tags length] < 1)
						{
							[tags appendString:tag];
						}
						else
						{
							[tags appendFormat:@",%@", tag];
						}
					}
					//////////NSLog(@"Tag: %@", [xml valueWithPath:@"tags/tag/@raw" fromNode:n atIndex:j]);
				}
			}
			
			if([tags length] < 1) tags = nil;
			if([propertyTags count] < 1) propertyTags = nil;
			
			mediaItem.propertyTags = propertyTags;
			////////NSLog(@"Property Tags: %@", propertyTags);
			mediaItem.tags = tags;
			
			mediaItem.contentID = [xml firstValueWithPath:@"id" fromNode:n];
			//////////NSLog(@"Item id: %@", mediaItem.contentID);
			mediaItem.title = [xml firstValueWithPath:@"title" fromNode:n];
			mediaItem.description = [xml firstValueWithPath:@"description" fromNode:n];
			
			
			if(mediaItem.description)
			{
				mediaItem.description = [Utils string:[xml firstValueWithPath:@"description" fromNode:n]  
								 replaceSubstring:@"<br />" 
									   withString:@"\n"
								   adjacentAsSingle:YES];
				
			
			}
		
			mediaItem.numComments = [xml firstValueWithPath:@"comments" fromNode:n];
			mediaItem.username = [xml firstValueWithPath:@"owner/username" fromNode:n];
			//mediaItem.thumbnail = [xml firstValueWithPath:@"urls/url[@sizecode='sm']/@address" fromNode:n];
            if([Utils isPad]) {
                mediaItem.thumbnail = [xml firstValueWithPath:@"urls/url[@sizecode='vl']/@address" fromNode:n];
            } else {
                mediaItem.thumbnail = [xml firstValueWithPath:@"urls/url[@sizecode='vs']/@address" fromNode:n];
            }
			mediaItem.image = [xml firstValueWithPath:@"urls/url[@sizecode='dd']/@address" fromNode:n];
			mediaItem.original = [xml firstValueWithPath:@"urls/url[@sizecode='or']/@address" fromNode:n];
			mediaItem.mp4 = [xml firstValueWithPath:@"urls/url[@sizecode='mp4']/@address" fromNode:n];
			
			//For Getting Original file size and Duration
			mediaItem.fileSize=[xml firstValueWithPath:@"urls/url[@sizecode='or']/@filesize" fromNode:n];
			mediaItem.contentDuration=[xml firstValueWithPath:@"urls/url[@sizecode='or']/@duration" fromNode:n];
			
			
			NSString* imageWidth_str = [xml firstValueWithPath:@"urls/url[@sizecode='dd']/@width" fromNode:n];
			NSString* imageHeight_str = [xml firstValueWithPath:@"urls/url[@sizecode='dd']/@height" fromNode:n];
			int imageWidth_int = [imageWidth_str integerValue];
			int imageHeight_int = [imageHeight_str integerValue];
			CGSize imageSize = CGSizeMake((float)imageWidth_int, (float)imageHeight_int);
			mediaItem.imageSize = imageSize;
			
			NSString* original_imageWidth_str = [xml firstValueWithPath:@"urls/url[@sizecode='or']/@width" fromNode:n];
			NSString* original_imageHeight_str = [xml firstValueWithPath:@"urls/url[@sizecode='or']/@height" fromNode:n];
			int original_imageWidth_int = [original_imageWidth_str integerValue];
			int original_imageHeight_int = [original_imageHeight_str integerValue];
			CGSize original_imageSize = CGSizeMake((float)original_imageWidth_int, (float)original_imageHeight_int);
			mediaItem.originalImageSize = original_imageSize;
			
			
			mediaItem.date = [xml firstValueWithPath:@"dates/@posted" fromNode:n];
			//////////NSLog(@"MediaItemDate %@", mediaItem.date);
			[contentItems addObject:mediaItem];
			//printf("Item %d title: %s\n", i, [mediaItem.username cString]);
		}
		
		[apirh.target performSelector:apirh.success withObject:tag withObject:contentItems];
	}
	else if( [[xml firstValueWithPath:@"/channel/@total_items"] intValue]==0)
	{
		[apirh.target performSelector:apirh.success withObject:tag withObject:nil];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:tag withObject:nil];
	}
	
	[xml release];
}

+ (void) onTagsGetListContentForTagConnectionFailure:(APIResponseHandler*)apirh
{
	//[apirh.target performSelector:apirh.failure withObject:[apirh.error localizedDescription]];
	////////NSLog(@"onChannelAddConnectionError - %@ %@", [apirh.error localizedDescription],[[apirh.error userInfo] objectForKey:NSErrorFailingURLStringKey]);
}


+ (void) usersRegisterWithUserProfileData:(UserProfileData*)userProfileData
					responseTarget:(id)target
						success_cb:(SEL)success
						failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.register";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	[vars setObject:userProfileData.user forKey:@"username"];
	[vars setObject:userProfileData.password forKey:@"password"];
	[vars setObject:userProfileData.email forKey:@"email"];
	[vars setObject:@"true" forKey:@"returnAuth"];
	////////NSLog(@"About to submit userprofiledata to server: %@",userProfileData.description);
	if(userProfileData.about_movies!= nil)
	{
		////////NSLog(@"adding about movies to API call");
		[vars setObject:userProfileData.about_movies forKey:@"about_movies"];
	}
	if(userProfileData.relationship_status != nil)
	{
		////////NSLog(@"adding relationship status to API call.");
		[vars setObject:userProfileData.relationship_status forKey:@"relationship_status"];
	}
	if(userProfileData.about_desc != nil)
	{
		////////NSLog(@"adding about_desc to API call.");
		[vars setObject:userProfileData.about_desc forKey:@"about_desc"];
	}
	if(userProfileData.birthdate != nil)
	{
		////////NSLog(@"adding birthdate to API call.");
		[vars setObject:userProfileData.birthdate forKey:@"birthdate"];
	}
	if(userProfileData.your_websites != nil)
	{
		////////NSLog(@"adding your_websites to API call");
		[vars setObject:userProfileData.your_websites forKey:@"yourwebsite"];
	}
	if(userProfileData.gender != nil)
	{ 
		////////NSLog(@"adding gender to API call");
		[vars setObject:userProfileData.gender forKey:@"gender"];
	}
	if(userProfileData.about_websites  != nil)
	{
		////////NSLog(@"adding about_websites to API Call");
		[vars setObject:userProfileData.about_websites forKey:@"about_websites"];
	}
	SEL rh = @selector(onUserRegisterResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars 
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success
		   failure_cb:failure];
}



+ (void) reportAbuseWithDescription:(NSString*)description
					responseHandler:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.reportIssue";
	if(auth_token == nil) 
	{
		if(!(auth_token = [Utils preferenceWithKey:@"authToken"]))
		{
			////////NSLog(@"ERROR!!! auth_token and uploadEmail are both undefined");
			return;
		}
	}	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	[vars setObject:auth_token forKey:@"auth_token"];
	[vars setObject:description forKey:@"description"];
	
	SEL rh = @selector(onAbuseReported:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method
			paramters:vars
	  responseHandler:rh
	   failureHandler:fh 
			   target:target
		   success_cb:success
		   failure_cb:failure];
}

+ (void) onAbuseReported:(APIResponseHandler*)apirh
{
	////////NSLog(@"onAbuseReported response: %@",apirh.response);
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/response"])
	{
		//NSString* username = [xml firstValueWithPath:@"/response"];
		[apirh.target performSelector:apirh.success withObject:self];
		
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
	
	
}

+ (void) retrieveLostUserInfo:(NSString*)email
			   responseTarget:(id)target
				   success_cb:(SEL)success
				   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.forgotPassword";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	[vars setObject:email forKey:@"username"];
	
	SEL rh = @selector(onRetrivalSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	   [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];
}


+ (void) onRetrivalSuccess:(APIResponseHandler*)apirh
{
	////////NSLog(@"Got register response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/user/username"])
	{
		NSString* username = [xml firstValueWithPath:@"/user/username"];
		
		
		[apirh.target performSelector:apirh.success withObject:username];
		
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}

+ (void) usersRegisterWithUsername:(NSString*)username 
						  password:(NSString*)password
							 email:(NSString*)email
					responseTarget:(id)target
						success_cb:(SEL)success
						failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.register";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	

	[vars setObject:username forKey:@"username"];
	[vars setObject:password forKey:@"password"];
	[vars setObject:email forKey:@"email"];
	[vars setObject:@"true" forKey:@"returnAuth"];
	[vars setObject:[[UIDevice currentDevice] uniqueIdentifier] forKey:@"device_id"];
	
	SEL rh = @selector(onUserRegisterResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:target success_cb:success failure_cb:failure];
}


+ (void) onUserRegisterResponse:(APIResponseHandler*)apirh
{
	/*
	 <response>
		<cookie_auth>
			<auth_token>930d3abb1f306108292aee65cc2c0289</auth_token>
			<cookie_path>/</cookie_path>
			<cookie_domain>cbs.josh.dw2.treemo.com</cookie_domain>
		</cookie_auth>
		<auth>
			<token>61f726d8bd25f80979447fdc93f31d86</token>
			<user>
				<username>asfsadfsdaf</username>
				<display_name />
				<real_name />
			</user>
		</auth>
	 </response>
	 */
	////////NSLog(@"Got register response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/response/auth/user/username"])
	{
		NSString* username = [xml firstValueWithPath:@"/response/auth/user/username"];
		////////NSLog(@"Registered User: %@", username);
		[self parseAndHandleAuthenticationXML:xml];
		[apirh.target performSelector:apirh.success withObject:username];
		#ifdef FLURRYAPI_H
			[FlurryAPI logEvent:@"USER REGSITERED"];
		#endif
	

	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
		#ifdef FLURRYAPI_H
			[FlurryAPI logEvent:[NSString stringWithFormat:@"USER REGSITERED FAILED: %@",error_msg]];
		#endif
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}

+ (void) parseAndHandleAuthenticationXML:(WebXML*)xml
{
	NSString* username = [xml firstValueWithPath:@"/response/auth/user/username"];
	if(username == nil)NSLog(@"/response/auth/user/username is nil");
	
	NSString* apiAuthToken = [xml firstValueWithPath:@"/response/auth/token"];
	if(apiAuthToken == nil)NSLog(@"/response/auth/token is nil");
	
	NSString* cookieName = [xml firstValueWithPath:@"/response/cookie_auth/cookie_name"];
	if(cookieName == nil) NSLog(@"/response/cookie_auth/cookie_name is nil");
	
	NSString* cookieAuthToken = [xml firstValueWithPath:@"/response/cookie_auth/auth_token"];
	if(cookieAuthToken == nil) NSLog(@"/response/cookie_auth/auth_token is nil");
	
	auth_token = apiAuthToken;
	
	[self setAndStoreLoginForUser:username 
						authToken:apiAuthToken 
					  cookieToken:cookieAuthToken 
					   cookieName:cookieName];
}

+ (void) setAndStoreLoginForUser:(NSString*)username
					   authToken:(NSString*)authToken
					 cookieToken:(NSString*)cookieTokenOrNil
					  cookieName:(NSString*)cookieNameOrNil
{
	[Utils setPreference:@"username" withValue:username];
	[Utils setPreference:@"authToken" withValue:authToken];
	
	if(cookieTokenOrNil)
	{
		[Utils setPreference:@"cookieToken" withValue:cookieTokenOrNil];
		[Utils setPreference:@"cookieName" withValue:cookieNameOrNil];
		[Utils setCookieAtDomain:LINK_DOMAIN name:cookieNameOrNil value:cookieTokenOrNil];
	}
}

+ (void) onConnectionFailure:(APIResponseHandler*)apirh withRequester:(Requester*)r
{
	////////NSLog(@"onConnectionFailure called.");
	[apirh.target performSelector:apirh.failure 
					   withObject:[Utils  nameStringFromString:[apirh.error localizedDescription]]
					   withObject:r
	 ];
	
	////////NSLog(@"onConnectionError - %@ %@", [apirh.error localizedDescription],[[apirh.error userInfo] objectForKey:NSErrorFailingURLStringKey]);
	//[apirh.target performSelector:apirh.failure withObject:[apirh.error localizedDescription]];
}

+ (void) userEditProfileWithUserProfileData: (UserProfileData*) upd
							   actionTarget:(id)target
								 success_cb:(SEL)success
								 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.editProfile";
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:12];
	if(auth_token == nil)
	{
		if(!(auth_token = [Utils preferenceWithKey:@"authToken"]))
		{
			////////NSLog(@"ERROR!!! auth_token is undefined %@ not invoked",api_method);
			return;
		}
	}
	[vars setObject:auth_token forKey:@"auth_token"];
	if(upd.birthdate != nil)           [vars setObject:upd.birthdate forKey:@"birthdate"];
	if(upd.gender != nil)              [vars setObject:upd.gender forKey:@"gender"];
	if(upd.about_desc != nil)          [vars setObject:upd.about_desc forKey:@"about_desc"];
	if(upd.about_movies != nil)        [vars setObject:upd.about_movies forKey:@"about_movies"];
	if(upd.about_music != nil)		   [vars setObject:upd.about_music forKey:@"about_music"];
	if(upd.about_magazines != nil)     [vars setObject:upd.about_magazines forKey:@"about_magazines"];
	if(upd.about_books != nil)         [vars setObject:upd.about_books forKey:@"about_books"];
	if(upd.about_games != nil)         [vars setObject:upd.about_games forKey:@"about_games"];
	if(upd.about_websites != nil)      [vars setObject:upd.about_websites forKey:@"about_websites"];
	if(upd.your_websites != nil)       [vars setObject:upd.your_websites forKey:@"yourwebsite"];
	if(upd.location != nil)            [vars setObject:upd.location forKey:@"location"];
	if(upd.relationship_status != nil) [vars setObject:upd.relationship_status forKey:@"relationship_status"];
	
	SEL rh = @selector(onGetProfileResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
}

+ (void) userEditProfileWithLocation:(NSString*)location 
						actionTarget:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
{
	
	NSString* api_method = @"treemo.users.editProfile";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:8];

	if(auth_token == nil) 
	{
		if(!(auth_token = [Utils preferenceWithKey:@"authToken"]))
		{
			////////NSLog(@"ERROR!!! auth_token is undefined %@ not invoked", api_method);
			return;
		}
	}
	
	[vars setObject:location forKey:@"location"];
	[vars setObject:auth_token forKey:@"auth_token"];
	
	SEL rh = @selector(onUserEditProfileSuccess:);
	SEL fh = @selector(onUserEditProfileFailure:withRequester:);
	
	[self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
			   target:nil success_cb:nil failure_cb:nil];	
	
}

+ (void) onUserEditProfileSuccess:(APIResponseHandler*)apirh
{
	////////NSLog(@"Profile details updated%@", apirh.response);
	[apirh.target performSelector:apirh.success];
	
}



+ (void) onUserEditProfileFailure:(APIResponseHandler*) apirh withRequester:(Requester*)requester
{
	[apirh.target performSelector:apirh.failure withObject:apirh.response];
	////////NSLog(@"Edit Profile Failure %@", apirh.response);
}


+ (void) getUserProfileWithUser:(NSString*)user
				   actionTarget:(id)target
					 success_cb:(SEL)success
					 failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.getProfile";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:user forKey:@"username"];
	SEL rh = @selector(onGetProfileResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
	
}

+ (void) setUserLocationWithLongitude:(NSString*)longitude
							 Latitude:(NSString*)latitude
						 actionTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.users.setLocation";
	NSString* auth_token;
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:0];
	if( auth_token =[Utils preferenceWithKey:@"authToken"])
	{
		[vars setObject:auth_token forKey:@"auth_token"];
	}
	else
	{
		return;
	}
	[vars setObject:latitude forKey:@"latitude"];
	[vars setObject:longitude forKey:@"longitude"];
	SEL rh = @selector(OnSetLocationSuccess:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
}

+ (void) OnSetLocationSuccess:(APIResponseHandler*)apirh
{
	////////NSLog(@"Got profile response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	if([xml elementExistsForPath:@"/user"])
	{
		if(apirh.target != nil && apirh.success != nil)
		{
			[apirh.target performSelector:apirh.success];
		}
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		if(apirh.target != nil && apirh.failure != nil)
		{
			[apirh.target performSelector:apirh.failure withObject:[xml firstValueWithPath:@"/error/message"]];
		}
	}
	else
	{
		if(apirh.target != nil && apirh.failure != nil)
		{
			[apirh.target performSelector:apirh.failure withObject:nil];
		}
	}
	[xml release];
	
}

+ (void) userReviewSubmission:(NSString*)reviewedUser
				   withRating:(NSString*)rating
				  andFeedback:(NSString*)feedback
		   andInteractionType:(NSInteger)interactionType
				 actionTarget:(id)target
				   success_cb:(SEL)success
				   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.review.add";
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nil!!");
		return;
	}
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:auth_token forKey:@"auth_token"];
	[vars setObject:reviewedUser forKey:@"item_id"];
	[vars setObject:rating forKey:@"rating"];
	[vars setObject:feedback forKey:@"feedback"];
	[vars setObject:(interactionType ?@"2":@"3") forKey:@"extra_int"];
	[vars setObject:@"user" forKey:@"item_type"];
	
	SEL rh = @selector(onSubmitReview:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
	
}

+ (void) getUserRating:(NSString*)username
		  actionTarget:(id)target
			success_cb:(SEL)success
			failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.review.getAverageRating";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:2];
	[vars setObject:@"user" forKey:@"item_type"];
	[vars setObject:username forKey:@"item_id"];
	
	SEL rh = @selector(onGetRating:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
	
}

+ (void) onGetRating:(APIResponseHandler*)apirh
{
	////////NSLog(@"Got profile response %@", apirh.response );
	////////NSLog(@"apirh response length: %i",[apirh.response length]);
	if([apirh.response length] == 175)
	{
	   //[apirh.target performSelector:apirh.failure];
		return;
	}
		
		
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	if([xml elementExistsForPath:@"/response"])
	{
		NSString* rating_str = [xml firstValueWithPath:@"/response/avgRating"];

		[apirh.target performSelector:apirh.success withObject:rating_str];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		[apirh.target performSelector:apirh.failure];
	}
	else
	{
		[apirh.target performSelector:apirh.failure];
	}
	[xml release];
}

+ (void) onSubmitReview:(APIResponseHandler*)apirh
{
	////////NSLog(@"Got profile response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	if([xml elementExistsForPath:@"/review"])
	{
		[apirh.target performSelector:apirh.success];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		[apirh.target performSelector:apirh.failure withObject:[xml firstValueWithPath:@"/error/message"]];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}



+ (void) onGetProfileResponse:(APIResponseHandler*)apirh
{
	////////NSLog(@"Got profile response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	////////NSLog(@"OUTPUT: %@",xml);
	if([xml elementExistsForPath:@"/profile"])
	{
		NSString* username = [xml firstValueWithPath:@"/profile/username"];
		NSString* birthdate = [xml firstValueWithPath:@"/profile/birthdate"];
		//////////NSLog(@"bithdate = %@",birthdate);
		NSString*   gender = [xml firstValueWithPath:@"/profile/gender"];
		NSString* about_desc = [xml firstValueWithPath:@"/profile/about_desc"];
		NSString* about_movies = [xml firstValueWithPath:@"/profile/about_movies"];
		NSString* about_music = [xml firstValueWithPath:@"/profile/about_music"];
		NSString* about_magazines = [xml firstValueWithPath:@"/profile/about_magazines"];
		NSString* about_books = [xml firstValueWithPath:@"/profile/about_books"];
		NSString* about_games = [xml firstValueWithPath:@"/profile/about_games"];
		NSString* about_websites  = [xml firstValueWithPath:@"/profile/about_websites"];
		NSString* yourWebsites = [xml firstValueWithPath:@"/profile/yourwebsite"];
		NSString* location = [xml firstValueWithPath:@"/profile/location"];
		NSString* relationship_status = [xml firstValueWithPath:@"/profile/relationship_status"];
		
		//////////NSLog(@"RELATIONSHIPSTATUS::::: %@",relationship_status);
		
		UserProfileData* userProfileDate = [[[UserProfileData alloc] initWithUser:username
																		 birthday:birthdate
																		 password:nil
																			email:nil
																		   gender:gender 
																	   about_desc:about_desc 
																	 about_movies:about_movies 
																	  about_music:about_music
																  about_magazines:about_magazines
																	  about_books:about_books
																	  about_games:about_games
																   about_websites:about_websites
																	 yourWebsites:yourWebsites
																		 location:location
															  relationship_status:relationship_status] autorelease];
		
		userProfileDate.last_activity = [[xml firstValueWithPath:@"/profile/relative_last_activity"] retain];
		////////NSLog(@"%@",userProfileDate.description);
		userProfileDate.longitude = [[xml firstValueWithPath:@"/profile/longitude"]retain];
		userProfileDate.latitude = [[xml firstValueWithPath:@"/profile/latitude"]retain];
		
		[apirh.target performSelector:apirh.success withObject:userProfileDate];
				
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
	
}

+ (Requester*) searchGeoWithMyLatitude:(NSString*)latitude
						  MyLongitude:(NSString*)longitude
						  contentTypeOrNil:(NSString*)contentType
							   radiusOrNil:(NSString*)radius
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.search.geo";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:0];
	[vars setObject:latitude forKey:@"latitude"];
	[vars setObject:longitude forKey:@"longitude"];
	if(contentType)[vars setObject:contentType forKey:@"query"];
	if(radius)[vars setObject:radius forKey:@"radius"];
	
	
	SEL rh = @selector(onGetGeoContent:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
	
}

+ (void) onGetGeoContent:(APIResponseHandler*)apirh
{
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	xmlNodeSetPtr nodeset;
	//////NSLog(@"XML For User Geo Cords: %@",apirh.response);

	if(xml == nil)
	{
		[apirh.target performSelector:apirh.failure withObject:@"Could not parse review list response."];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [[[xml firstValueWithPath:@"/error/@string"] copy] autorelease];
		// it is ok for the error_msg to be nil
		error_msg = [NSString stringWithFormat:@"Eventful %@", error_msg];
		[apirh.target performSelector:apirh.failure  withObject:error_msg];
	}
	else if( (nodeset = [xml nodeSetWithPath:@"/search_results/result"]) && nodeset->nodeNr > 0)
	{
		NSMutableArray* GeoCords = [[[NSMutableArray alloc] initWithCapacity:10] autorelease];
		for(int i = 0; i < nodeset->nodeNr;i++)
		{
			xmlNodePtr n = nodeset->nodeTab[i];
			UserGeoData* x = [[UserGeoData alloc] initWith:[xml firstValueWithPath:@"user/username" fromNode:n]
												 aLatitude:[xml firstValueWithPath:@"latitude" fromNode:n]
												aLongitude:[xml firstValueWithPath:@"longitude" fromNode:n]
											  aGeoDistance:[xml firstValueWithPath:@"geo_distance" fromNode:n]];
			[GeoCords addObject:x];
			
		}
		[apirh.target performSelector:apirh.success withObject:[GeoCords retain]];
	}
	else
	{
		[apirh.target performSelector:apirh.success withObject:nil];
	}
	[xml release];
	
	
}

+ (Requester*) channelAddMedia:(NSData*)mediaOrNil 
			   withTitle:(NSString*)titleOrNil
			 description:(NSString*)descriptionOrNil
					tags:(NSString*)tagsOrNil
			propertyTags:(NSMutableDictionary*)propertyTagsOrNil
				location:(NSString*)locationOrNil 
		  responseTarget:(id)target
			  success_cb:(SEL)success
			  failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.channel.add";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:3];
	
	if(auth_token == nil) 
	{
		if(!(auth_token = [Utils preferenceWithKey:@"authToken"]))
		{
			////////NSLog(@"ERROR!!! auth_token and uploadEmail are both undefined");
			return nil;
		}
	}
	
	NSString* tags = nil;
	if(tagsOrNil)
	{
		tags = tagsOrNil;
	}
	
	if(propertyTagsOrNil)
	{
		
		NSString* propertyTags_str = [self propertyTagStringFromDictionary:propertyTagsOrNil];
		
		////////NSLog(@"Property Tags %@", propertyTags_str);
		
		if(tags)
		{
			tags = [NSString stringWithFormat:@"%@,%@", tags, propertyTags_str];
		}
		else
		{
			tags = propertyTags_str;
		}
		 
	}
	
	
	if(tags)[vars setObject:tags forKey:@"tags"];

	 
	if(titleOrNil != nil)
	{
		[vars setObject:titleOrNil forKey:@"title"];
	}
	
	if(descriptionOrNil != nil)
	{
		[vars setObject:descriptionOrNil forKey:@"description"];
	}
	

	
	if(locationOrNil != nil)
	{
		[vars setObject:locationOrNil forKey:@"location"];
	}
	

	
	[vars setObject:auth_token forKey:@"auth_token"];

	[vars setObject:api_method forKey:@"method"];
	[vars setObject:API_KEY forKey:@"api_key"]; // changed APIBinding to self
	NSString* api_sig = [self generateSignature:vars];
	[vars setObject:api_sig forKey:@"api_sig"];
	
	SEL rh = @selector(onChannelAddResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	APIResponseHandler* responseHandler = [[APIResponseHandler alloc] 
										   initWithResponseHandler:rh 
										   failureHanlder:fh 
										   target:target
										   success_cb:success 
										   failure_cb:failure];
	
	Requester* r = [(Requester*)[Requester alloc] initWithURL:API_URL actionTarget:responseHandler];
	r.onFailure = @selector(onFailure:requester:);
	r.onResponse = @selector(onResponse:requester:);
	
	if(mediaOrNil)[r attachData:mediaOrNil withFieldName:@"media" andFileName:@"Photo.jpg"];
	[r submit:vars  requestMethod:@"POST"];

	return r;
}


+ (void) changeAvatar:(NSString*)contentID
	   responstTarget:(id)target
		   success_cb:(SEL)success
		   failure_cb:(SEL)failure
{
	
	////////NSLog(@"Called changeAvatar function.");
	NSString* api_method = @"treemo.users.changeAvatar";
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:12];
	if(auth_token == nil)
	{
		if(!(auth_token = [Utils preferenceWithKey:@"authToken"]))
		{
			////////NSLog(@"ERROR!!! auth_token is undefined %@ not invoked",api_method);
			return;
		}
	}
	[vars setObject:auth_token forKey:@"auth_token"];
	[vars setObject:contentID forKey:@"content_id"];
	
	SEL rh = @selector(onChangedAvatar:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	[self makeRequest:api_method 
			paramters:vars
	  responseHandler:rh 
	   failureHandler:fh 
			   target:target 
		   success_cb:success 
		   failure_cb:failure];
}

+ (void) onChangedAvatar:(APIResponseHandler*)apirh
{
	////////NSLog(@"Avatar change success.");
	////////NSLog(@"Got register response %@", apirh.response );
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if([xml elementExistsForPath:@"/content"])
	{
		//NSString* contentID = [xml firstValueWithPath:@"/content/id"];
		////////NSLog(@"ContentID: %@", contentID);
		
		//[apirh.target performSelector:apirh.success withObject:contentID];		
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
	
}

//::Private


+ (void) onChannelAddResponse:(APIResponseHandler*)apirh
{
	////////NSLog(@"ChannelAdd Responded: %@", apirh.response);
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	if(xml == nil)
	{
		////////NSLog(@"Could not create XML Document!");
	}
	//NSString* apiError_str = [[NSString alloc] initWithString:@"API ERROR"];
	//[apiError_str retain];
	if([xml elementExistsForPath:@"/content"])
	{
		NSString* contentID = [xml firstValueWithPath:@"/content/id"];
		[apirh.target performSelector:apirh.success withObject:contentID];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		//It is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}


+ (Requester*) channelDelete:(NSString*)contentID 
			  responseTarget:(id)target
				  success_cb:(SEL)success
				  failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.channel.delete";
	
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error cannot login! auth_token is nill!!");
		return nil;
	}
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:contentID forKey:@"content_id"];
	[vars setObject:auth_token forKey:@"auth_token"];
	
	SEL rh = @selector(onChannelDeleteResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];
}

+ (void) onChannelDeleteResponse:(APIResponseHandler*)apirh
{
	////////NSLog(@"ChannelDelete Responded: %@", apirh.response);
	
	 
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if(xml == nil)
	{
		////////NSLog(@"Could not create XML Document!");
	}
	//NSString* apiError_str = [[NSString alloc] initWithString:@"API ERROR"];
	//[apiError_str retain];
	if([xml elementExistsForPath:@"/response/status"])
	{
		[apirh.target performSelector:apirh.success];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}

+ (Requester*) deleteUserWithActionTarget:(id)target success_cb:(SEL)success failure_cb:(SEL)failure
{
	
	NSString* api_method = @"qwikets.profile.delete";
	
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error: cannot post scores! auth_token is nil!");
		return nil;
	}
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:auth_token forKey:@"auth_token"];
	
	SEL rh = @selector(deleteSuccessful:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];	
	
}
+(void) deleteSuccessful:(APIResponseHandler*)apirh
{
	
	////////NSLog(@"DELETE SUCCESSFUL!");
	
	[self setAndStoreLoginForUser:nil 
						authToken:nil 
					  cookieToken:nil 
					   cookieName:nil];
	[apirh.target performSelector:apirh.success];
}
////////////// Leaderboard


+ (Requester*) leaderboardRecordScore:(NSString*)score 
							   gameID:(NSString*)game_id
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure
{
	NSString* api_method = @"treemo.leaderboard.recordScore";
	
	auth_token = [Utils preferenceWithKey:@"authToken"];
	if(auth_token == nil) 
	{
		////////NSLog(@"Error: cannot post scores! auth_token is nil!");
		return nil;
	}
	
	NSMutableDictionary* vars = [NSMutableDictionary dictionaryWithCapacity:1];
	[vars setObject:score forKey:@"score"];
	[vars setObject:game_id forKey:@"game_id"];
	[vars setObject:auth_token forKey:@"auth_token"];
	
	SEL rh = @selector(onLeaderboardRecordScoreResponse:);
	SEL fh = @selector(onConnectionFailure:withRequester:);
	
	return [self makeRequest:api_method paramters:vars responseHandler:rh failureHandler:fh 
					  target:target success_cb:success failure_cb:failure];	
}

+ (void) onLeaderboardRecordScoreResponse:(APIResponseHandler*)apirh
{
	////////NSLog(@"ChannelDelete Responded: %@", apirh.response);
	WebXML* xml = [[WebXML alloc] initWithString:apirh.response];
	
	if(xml == nil)
	{
		////////NSLog(@"Could not create XML Document!");
	}
	//NSString* apiError_str = [[NSString alloc] initWithString:@"API ERROR"];
	//[apiError_str retain];
	if([xml elementExistsForPath:@"/score/game"])
	{
		[apirh.target performSelector:apirh.success];
	}
	else if([xml elementExistsForPath:@"/error"])
	{
		NSString* error_msg = [xml firstValueWithPath:@"/error/errorMessage"];
		// it is ok for the error_msg to be nil
		[apirh.target performSelector:apirh.failure withObject:error_msg];
	}
	else
	{
		[apirh.target performSelector:apirh.failure withObject:nil];
	}
	[xml release];
}


//////////////////////
+ (NSString*) propertyTagStringFromDictionary:(NSMutableDictionary*)dict
{
	NSMutableString* propertyTags_str = [[NSMutableString alloc] initWithCapacity:0];
	NSArray* propertyNames = [dict allKeys];
	
	int numProperties = [propertyNames count];

	for(int i = 0; i < numProperties; i++)
	{
		NSString* propertyName  = [propertyNames objectAtIndex:i];
		NSString* propertyValue = [dict objectForKey:propertyName];
		if([Utils string:propertyValue containsSubstring:@"."])
		{
			propertyValue = [Utils string:propertyValue replaceSubstring:@"." withString:DECIMAL_POINT_TOKEN];
		}
		
		[propertyTags_str appendFormat: (i ? @",%@%@%@" : @"%@%@%@"), propertyName, PROPERTY_TAG_TOKEN, propertyValue];
	}
	
	return propertyTags_str;
}

/* So far handled in xml parser 
// str is comma delimited tag string: key1_value1,key2_value2,...,keyn_valuen
+ (NSDictionary*) propertyTagDictionaryFromString:(NSString*)str
{

}
*/					   




NSString* md5( NSString *str )
{
	
	const char *cStr = [str UTF8String];
	unsigned char result[CC_MD5_DIGEST_LENGTH];
	CC_MD5( cStr, strlen(cStr), result );

	return [[NSString 
			 
			 stringWithFormat: @"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
			 
			 result[0], result[1],
			 
			 result[2], result[3],
			 
			 result[4], result[5],
			 
			 result[6], result[7],
			 
			 result[8], result[9],
			 
			 result[10], result[11],
			 
			 result[12], result[13],
			 
			 result[14], result[15]
			 
			 ] lowercaseString];
}


+ (NSString*)generateSignature:(NSMutableDictionary*)vars
{
	

	NSMutableArray* sigGenArray = [NSMutableArray arrayWithCapacity:3];
	[sigGenArray addObject:API_PASSWORD];
	
	NSEnumerator *enumerator = [vars keyEnumerator];
	NSString* key;
	while ((key = (NSString*)[enumerator nextObject])) 
	{
		[sigGenArray addObject:[key stringByAppendingString:[vars objectForKey:key]]];
	}
	
	NSMutableArray* sigGenArraySorted = (NSMutableArray*)[sigGenArray sortedArrayUsingSelector:@selector(compare:)];
	//////////NSLog(@"Pre md5: %@", sigGenArraySorted);
	NSString* signatureGenStr = [sigGenArraySorted componentsJoinedByString:@""];
	return md5(signatureGenStr);
}

+ (Requester*) makeRequest:(NSString*)api_method  
		   paramters:(NSMutableDictionary*)vars 
	 responseHandler:(SEL)rh 
	  failureHandler:(SEL)fh 
			  target:(id)target
		  success_cb:(SEL)success
		  failure_cb:(SEL)failure

{
	return [self makeRequest:(NSString*)api_method  
			paramters:(NSMutableDictionary*)vars 
	  responseHandler:(SEL)rh 
	   failureHandler:(SEL)fh 
			   target:(id)target
		   success_cb:(SEL)success
		   failure_cb:(SEL)failure
				extra:nil];
}


+ (Requester*) makeRequest:(NSString*)api_method  
				 paramters:(NSMutableDictionary*)vars 
		   responseHandler:(SEL)rh 
			failureHandler:(SEL)fh 
					target:(id)target
				success_cb:(SEL)success
				failure_cb:(SEL)failure
					 extra:extraOrNil
{
	
	[vars setObject:api_method forKey:@"method"];
	[vars setObject:API_KEY forKey:@"api_key"];
	NSString* api_sig = [self generateSignature:vars];
	[vars setObject:api_sig forKey:@"api_sig"];
	//////////NSLog(@"signature gen string: %@", api_sig);

	APIResponseHandler* responseHandler = [[[APIResponseHandler alloc] 
										   initWithResponseHandler:rh 
										   failureHanlder:fh 
											target:target
										   success_cb:success 
										   failure_cb:failure
											extra:extraOrNil] autorelease];
	
	// autorelease responseHandler
	////////NSLog(@"Making request with url: %@", API_URL);
	Requester* r = [[(Requester*)[Requester alloc] initWithURL:API_URL actionTarget:responseHandler] autorelease];
	r.onFailure = @selector(onFailure:requester:);  //request is to invoke onFailure on responseHandler
	r.onResponse = @selector(onResponse:requester:);  //request is to invoke onSuccess on responseHandler
	responseHandler.requester = r;
	[r submit:vars  requestMethod:@"POST"];

	return r;
	
}


+ (Requester*) makeGetRequestWithURL:(NSString*)url
						   forAction:(NSString*)action
						   paramters:(NSMutableDictionary*)vars 
					 responseHandler:(SEL)rh 
					  failureHandler:(SEL)fh 
							  target:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
							   extra:extraOrNil
{
	APIResponseHandler* responseHandler = [[[APIResponseHandler alloc] 
											initWithResponseHandler:rh 
											failureHanlder:fh 
											target:target
											success_cb:success 
											failure_cb:failure
											extra:extraOrNil] autorelease];
	
	NSString* actionURL = [url stringByAppendingFormat:@"/%@",action];
						 //  ?app_key=%@&id=%@,[vars objectForKey:@"app_id"],[vars objectForKey:@"id"]];
	
	
	// autorelease responseHandler
	////NSLog(@"URL created: %@",actionURL);
	Requester* r = [[(Requester*)[Requester alloc] initWithURL:actionURL actionTarget:responseHandler] autorelease];
	r.onFailure = @selector(onFailure:requester:);  //request is to invoke onFailure on responseHandler
	r.onResponse = @selector(onResponse:requester:);  //request is to invoke onSuccess on responseHandler
	[r submit:vars  requestMethod:@"GET"];
	////NSLog(@"URL created: %@/%@",r.requestURL,vars);
	return r;
}

@end


//::Private Class
@implementation APIResponseHandler




- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f
{
	return [self initWithResponseHandler:rh 
						  failureHanlder:fh 
								  target:t
							  success_cb:s 
							  failure_cb:f 
								   extra:nil];	
}

- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f extra:extraOrNil
{
	if(self = [super init])
	{	
		responseHandler = rh;
		failureHandler = fh;
		target = t;
		success = s;
		failure = f;
		extra = [extraOrNil retain];
		//////////NSLog(@"Response Handler Created");
	}
	return self;
}

@synthesize response;
@synthesize requester;
@synthesize error;
@synthesize target;
@synthesize success;
@synthesize failure;
@synthesize extra;

- (void) onResponse:(NSString*)apiResponse requester:(Requester*)requester
{
	//////////NSLog(@"API Responded: %@", apiResponse);
	response = apiResponse;
	[[response retain] autorelease];
	//[requester release];
	[ApplicationAPIBinding performSelector:responseHandler  withObject:self];
	//[requester release];
}

- (void) onFailure:(NSError*)connectionError requester:(Requester*)_requester
{
	error = connectionError;
	[error retain];
	//[requester release];
	[ApplicationAPIBinding performSelector:failureHandler withObject:self withObject:_requester];
	//[requester release];
}

- (void)dealloc 
{
	[response release];
	[error release];
	[extra release];
	[super dealloc];
}


@end

