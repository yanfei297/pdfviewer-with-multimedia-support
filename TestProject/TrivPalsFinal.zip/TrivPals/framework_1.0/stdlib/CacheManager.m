//
//  CBSNewsCache.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 12/10/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "CacheManager.h"
#import <CoreData/CoreData.h>  

#define EXPIRATION_DURATION_SECONDS 60*60*24*10 // 10 days //test time 10*60 

NSManagedObjectModel* managedObjectModel;
NSManagedObjectContext* managedObjectContext;    
NSPersistentStoreCoordinator* persistentStoreCoordinator;


@implementation CacheManager

+ (NSManagedObjectContext*) managedObjectContext 
{	
    if (managedObjectContext != nil) 
	{
        return managedObjectContext;
    }
	
    NSPersistentStoreCoordinator* coordinator = [self persistentStoreCoordinator];
	
    if (coordinator != nil) {
        managedObjectContext = [[NSManagedObjectContext alloc] init];
        [managedObjectContext setPersistentStoreCoordinator: coordinator];
    }
    return managedObjectContext;
}

 //Returns the managed object model for the application.
 //If the model doesn't already exist, it is created by merging all of the models found in the application bundle.
 
+ (NSManagedObjectModel *)managedObjectModel 
{
	
    if (managedObjectModel != nil) {
        return managedObjectModel;
    }
    managedObjectModel = [[NSManagedObjectModel mergedModelFromBundles:nil] retain];    
    return managedObjectModel;
}



 //Returns the persistent store coordinator for the application.
 //If the coordinator doesn't already exist, it is created and the application's store added to it.
 
+ (NSPersistentStoreCoordinator *)persistentStoreCoordinator 
{
	
    if (persistentStoreCoordinator != nil) {
        return persistentStoreCoordinator;
    }
	
    NSURL *storeUrl = [NSURL fileURLWithPath:[[self applicationCacheDirectory] stringByAppendingPathComponent:@"CoreData_2_0.sqlite"]];
	
	NSError *error;
    persistentStoreCoordinator = [[NSPersistentStoreCoordinator alloc] initWithManagedObjectModel: [self managedObjectModel]];
    if (![persistentStoreCoordinator addPersistentStoreWithType:NSSQLiteStoreType configuration:nil URL:storeUrl options:nil error:&error]) {
        // Handle error
		NSLog(@"There was an error creating the data store.");
    }    
	
    return persistentStoreCoordinator;
}

+ (NSString *)applicationCacheDirectory 
{	
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES);
    NSString *basePath = ([paths count] > 0) ? [paths objectAtIndex:0] : nil;
    return basePath;
}

+ (id) newManagedObjectForEntityName:(NSString*)name
{
	id newManagedObj = [NSEntityDescription insertNewObjectForEntityForName:name 
													 inManagedObjectContext:[CacheManager managedObjectContext]];
	[newManagedObj setCreationDate:[NSDate date]];
	
	
	return newManagedObj;
}

 //Performs the save action for the application, which is to send the save:
 //message to the application's managed object context.


+ (void)save
{
    NSError *error;
	//NSManagedObjectContext* magObj = ;
    if (![[self managedObjectContext] save:&error]) {
		// Handle error
		//NSLog(@"Unresolved error %@, %@", error, [error userInfo]);
		exit(-1);  // Fail
    }
}

+ (NSArray*) deleteOldEntitiesWith:(NSString*)entityName
{
	
	//info on predicates and dates
	//http://stackoverflow.com/questions/1965331/nspredicate-filtering-objects-by-day-of-nsdate-property
	
	{
		NSFetchRequest *request = [[NSFetchRequest alloc] init];
		NSEntityDescription *entity = [NSEntityDescription entityForName:entityName 
											  inManagedObjectContext:[CacheManager managedObjectContext]];
		[request setEntity:entity];
	
		double timeToRemainInCache = EXPIRATION_DURATION_SECONDS;
		NSDate* experationDate = [[NSDate date] addTimeInterval:-timeToRemainInCache];
	
		NSError* error=nil;
		NSMutableArray *mutableFetchResults = [[[CacheManager managedObjectContext] executeFetchRequest:request error:&error] mutableCopy];
		//NSLog(@"Found %i total %@ objects", [mutableFetchResults count], entityName);
	}
	
	//create fetch request for entity 
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:entityName 
											  inManagedObjectContext:[CacheManager managedObjectContext]];
	[request setEntity:entity];
	
	double timeToRemainInCache = 60; // seconds 
	NSDate* experationDate = [[NSDate date] addTimeInterval:-timeToRemainInCache];
	NSPredicate* p = [NSPredicate predicateWithFormat:@"(creationDate <= %@)", experationDate];
	[request setPredicate:p];
	
	NSError* error=nil;
	NSMutableArray *mutableFetchResults = [[[CacheManager managedObjectContext] executeFetchRequest:request error:&error] mutableCopy];
	
	//NSLog(@"Found %i old %@ objects: \n %@", [mutableFetchResults count], entityName, mutableFetchResults);
	
	int numResults = [mutableFetchResults count];
	for(int i = 0; i < numResults; i++)
	{
		NSManagedObject* anExpiredObject = [mutableFetchResults objectAtIndex:i];
		[[CacheManager managedObjectContext] deleteObject:anExpiredObject];
	}
	
	
	
	//- (void)deleteObject:(NSManagedObject *)object;
	if(error)
	{
		//NSLog(@"error: %@",[error localizedDescription] );
	}
	else 
	{
		[self save];
	}


}


+ (id) readEntityWithName:(NSString*)entityName withCacheID:(NSString*)cacheID 
{
	//create fetch request for entity 
	NSFetchRequest *request = [[NSFetchRequest alloc] init];
	NSEntityDescription *entity = [NSEntityDescription entityForName:entityName 
											  inManagedObjectContext:[CacheManager managedObjectContext]];
	[request setEntity:entity];
	
	NSPredicate* p = [NSPredicate predicateWithFormat:@"cacheID = %@", cacheID];
	[request setPredicate:p];
	
	NSError* error=nil;
	NSMutableArray *mutableFetchResults = [[[CacheManager managedObjectContext] executeFetchRequest:request error:&error] mutableCopy];
	
	if(error)
		NSLog(@"error: %@",[error localizedDescription] );
	int numResults = [mutableFetchResults count];
	////NSLog(@"Fetched %i cahced items (should not be more than one", numResults);
	
	if([mutableFetchResults count] > 0) 
	{
		return [mutableFetchResults objectAtIndex:0];
	}
	else
	{
		return nil;
	}
}


@end
