//
//  RegisterViewController.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/27/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "RegisterViewController.h"


@implementation RegisterViewController

@synthesize actionTarget, onRegister;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil 
{
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) 
	{
		[self doInit];
    }
    return self;
}

-(id) init
{
	if(self = [super init])
	{
		[self doInit];
	}
	return self;
}

- (void)doInit
{
	tableFrame = CGRectMake(0, 0, 320, 367);
	tableStyle = UITableViewStyleGrouped;
}

- (void) enableRegister
{
	registerbtn.enabled = YES;
}
- (void) disableRegister
{
	registerbtn.enabled = NO;
}
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/
//UITableViewCell
/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

- (void) viewDidAppear:(BOOL)animated
{
	
	//[TreemoAnalytics logScreenViewWithScreenName:@"Register"];
	
	[super viewDidAppear:animated];
	/*#ifdef FLURRYAPI_H
		[FlurryAPI logEvent:@"page view"];
	#endif*/
}
// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad 
{
    [super viewDidLoad];
	
	registerbtn = [[[UIBarButtonItem alloc] initWithTitle:@"Register" 
													style:UIBarButtonItemStyleBordered 
												   target:self
												   action:@selector(onPeformRegister)] autorelease];
	
	[self.navigationItem setRightBarButtonItem:registerbtn];
	
	myTableView = [[[UITableView alloc] initWithFrame:tableFrame style:tableStyle] autorelease];
	myTableView.delegate = self;
	myTableView.dataSource = self;
	
	cells = [[NSMutableDictionary alloc] initWithCapacity:0];
	
	[self createCells];
	[self.view addSubview:myTableView];
}

- (void)viewDidUnload 
{
	[cells release];
	cells = nil;
	myTableView = nil;
}

- (void) onPeformRegister
{
	
	NSString* username = ((SettingsCell_TextEntry*)[cells objectForKey:@"username"]).propertyText.text;
	NSString* password = ((SettingsCell_TextEntry*)[cells objectForKey:@"password"]).propertyText.text;
	NSString* email = ((SettingsCell_TextEntry*)[cells objectForKey:@"email"]).propertyText.text;
	////////NSLog(@"calling OnPerformRegister!");
	NSInvocation* inv = [Utils makeInv:onRegister target:actionTarget];
	[inv setArgument:&username atIndex:2];
	[inv setArgument:&password atIndex:3];
	[inv setArgument:&email atIndex:4];
	[inv retain];
	[inv retainArguments];
	[inv invoke];
	
}

- (void) createCells
{
	//Create Email Cell
	{
		NSString* cellIdentifier = @"email";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		cell.label.text = @"Email";
		cell.propertyText.keyboardType = UIKeyboardTypeEmailAddress;
		[cells setObject:cell forKey:cellIdentifier];
		////////NSLog(@"Created cell %@", [cells objectForKey:@"email"]);
		
	}
	
	// Create Password Cell
	{
		NSString* cellIdentifier = @"password";
		SettingsCell_TextEntry* cell;
		cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		cell.label.text = @"Password";
		cell.propertyText.secureTextEntry = YES;
		[cells setObject:cell forKey:cellIdentifier];
	}
	
	// Create Email Notification (Switch Cell)
	{
		NSString* cellIdentifier = @"emailNotifications";
		SettingsCell_Switch* cell;
		
		cell = [[[SettingsCell_Switch alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];	
		cell.label.text = @"Email Notifications";
		////////NSLog(@"Property Switch VALUE: %@",cell.propertySwitch);
		[cells setObject:cell forKey:cellIdentifier];				
	}
	
	// Create Age Cell (Disclosure Cell) 
	{
		NSString* cellIdentifier = @"age";
		SettingsCell* cell;
		cell = [[[SettingsCell alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		
		cell.label.text = @"Age";
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleGray;
		
		[cells setObject:cell forKey:cellIdentifier];					
	}
	
	// Create Gender/Age Cell (Segmented Control)
	{
		NSString* cellIdentifier = @"gender";
		SettingsCell_ToggleSegmentedControl* cell;

		cell = [[[SettingsCell_ToggleSegmentedControl alloc]  initWithFrame:CGRectZero 
																reuseIdentifier:cellIdentifier] autorelease];
		//Deselect Others When Segmented Control Clicked
		cell.actionTarget = self;
		cell.onChange = @selector(genderSelectorChanged:);
		
		
		cell.label.text = @"Gender";
		[cell.propertyToggleSegmentedControl insertSegmentWithTitle:@"Male" atIndex:0 animated:NO];
		[cell.propertyToggleSegmentedControl insertSegmentWithTitle:@"Female" atIndex:1 animated:NO];
		[cells setObject:cell forKey:cellIdentifier];				
	}
	
}

- (void)genderSelectorChanged:(UITableViewCell*)genderSelectorCell
{

	genderSelectorCell.selected = YES;
	ignoreNextKeyboardHideNotification = NO;
	ignoreNextKeyboardShowNotification = NO;
	selectedCellIsTextEntryCell = NO;
	
	[self deselectOthers:genderSelectorCell];
	keyboardDown = YES;
	////////NSLog(@"keyboard down set");
	
	
}

/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/


- (void) viewWillAppear:(BOOL)animated 
{
	
	[super viewWillAppear:animated];
	insetUpdateTimer = [[NSTimer scheduledTimerWithTimeInterval:0.2f 
									 target:self 
								   selector:@selector(updateInsets) 
								   userInfo:nil 
									repeats:YES] retain];
	////////NSLog(@"Timer set");
	NSNotificationCenter* center = [NSNotificationCenter defaultCenter];
	UIWindow *window = self.view.window;
	
	[center addObserver:self 
			   selector:@selector(keyboardWillShow:) 
				   name:UIKeyboardWillShowNotification 
				 object:window];
	
	[center addObserver:self 
			   selector:@selector(keyboardWillHide:) 
				   name:UIKeyboardWillHideNotification 
				 object:window];
}

- (void)onSelectDone
{
	[self onPeformRegister];
}

-(void)onSelectNext
{
	//UITableView
	NSIndexPath* indexPath = [myTableView indexPathForSelectedRow];
	indexPath = [Utils indexPathWithIndex:indexPath.section withIndex:indexPath.row + 1];
	[myTableView selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionMiddle];
}

- (void) viewWillDisappear:(BOOL)animated 
{
	[super viewWillDisappear:animated];
	
	[insetUpdateTimer invalidate];
	
	NSNotificationCenter* center = [NSNotificationCenter defaultCenter];
	UIWindow* window = self.view.window;
	
	[center removeObserver:self name: UIKeyboardWillShowNotification object:window]; 
	[center removeObserver:self name: UIKeyboardWillHideNotification object:window];
}

- (void)keyboardWillHide:(NSNotification *)note 
{
	keyboardIsVisible = NO;
	return;
	if(ignoreNextKeyboardHideNotification)
	{
		////////NSLog(@"Ignored Hide Notification");
		ignoreNextKeyboardHideNotification = NO;
		return;
	}
	else
	{
		////////NSLog(@"Refused to ignored hide notification");
	}
	[Utils recordToAnimate];
	
	UIEdgeInsets insets = myTableView.contentInset;
	insets.bottom = 0;
	myTableView.contentInset = insets;
	
	[Utils animate];
}
- (void)keyboardWillShow:(NSNotification *)note 
{
	
	keyboardIsVisible = YES;
	return;
	if(!keyboardDown)
	{
		if(ignoreNextKeyboardShowNotification)
		{
			////////NSLog(@"Ignored Show Notification");
			ignoreNextKeyboardShowNotification = NO;
			return;
		}
		else
		{
			////////NSLog(@"Refused to ignored show notification");
		}
	}
	[Utils recordToAnimate];
	CGRect bounds;
	[[note.userInfo valueForKey:UIKeyboardBoundsUserInfoKey] getValue:&bounds];
	UIEdgeInsets insets = myTableView.contentInset;
	insets.bottom = bounds.size.height - 30;
	myTableView.contentInset = insets;
	[Utils animate];
}

- (void)updateInsets
{
		UIEdgeInsets insets = myTableView.contentInset;
	//////////NSLog(@"Keyboard Visible %i, bottomInset %f",keyboardIsVisible ,insets.bottom);
	

	if(keyboardIsVisible && (insets.bottom == 0) )
	{
		////////NSLog(@"Keyboard visible");
		[Utils recordToAnimate];
		CGRect bounds;
	
		insets.bottom = bounds.size.height + 200;
		myTableView.contentInset = insets;
		myTableView.scrollIndicatorInsets = insets; 
		[Utils animate];
	}
	else if(!keyboardIsVisible && (insets.bottom != 0))
	{
		////////NSLog(@"Keyboard hidden");
		[Utils recordToAnimate];
		
		UIEdgeInsets insets = myTableView.contentInset;
		insets.bottom = 0;
		myTableView.contentInset = insets;
		myTableView.scrollIndicatorInsets = insets;
		[Utils animate];		
	}
}

#pragma mark Table view methods

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView 
{
	// section 0 (required) section 1 (optional) 
    return 2;
}


// Customize the number of rows in the table view.
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
    if(section == 0)
	{
		return 2;
	}
	else if(section == 1)
	{
		return 3;
	}
	else
	{
		return 0;
	}
}



// Customize the appearance of table view cells.
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{    
	//int index = indexPath.section;
	//UITextField
	
	if(indexPath.section == 0) //required
	{
		if(indexPath.row == 0) 
		{
			////////NSLog(@"Returning cell %@",[cells objectForKey:@"email"]);
			return [cells objectForKey:@"email"];
		}
		else if(indexPath.row == 1) return [cells objectForKey:@"password"];
		else return  [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:@"test"] autorelease];
	}
	else if(indexPath.section == 1)
	{
		if(indexPath.row == 0) 	return [cells objectForKey:@"emailNotifications"];
		else if(indexPath.row == 1) return [cells objectForKey:@"age"];
		else if(indexPath.row == 2) return [cells objectForKey:@"gender"];
	}

	

	//This case will never be reached unless extending class has added elements
	return nil;  //Subclass must provide a cell for this row 
}

- (void)textViewDidBeginEditing:(UITextView *)textView
{
	//UIScrollView
	////////NSLog(@"text edit begins view scrolling to top"); 
}
/*
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
	
	scrollView.contentOffset = CGPointMake(0,0);
	////////NSLog(@"Scroll view scrolling to top %d",scrollView.contentOffset.y);

}
 */
- (NSIndexPath *)tableView:(UITableView *)tableView willSelectRowAtIndexPath:(NSIndexPath *)indexPath
{

	if(selectedCellIsTextEntryCell)
	{
		ignoreNextKeyboardHideNotification = YES;
		ignoreNextKeyboardShowNotification = YES;
	}
	return indexPath;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{


	UITableViewCell* cell = [tableView cellForRowAtIndexPath:indexPath];
	selectedCellIsTextEntryCell = [cell isKindOfClass:[SettingsCell_TextEntry class]];
	////////NSLog(@"selected text entry view with y: %f", cell.frame.origin.y);
	if(selectedCellIsTextEntryCell)
	{
		CGPoint contentOffset;
		contentOffset.x = 0;
		contentOffset.y = cell.frame.origin.y - 60 ;
		[tableView setContentOffset:contentOffset animated:YES];
	}
	

}



- (void) deselectOthers:(UITableViewCell*)selectedCell
{
	
	NSArray* cellKeys = [cells allKeys];
	int numCells = [cellKeys count];
	
	for(int i = 0; i < numCells; i++)
	{
		NSString* key = (NSString*)[cellKeys objectAtIndex:i];
		UITableViewCell* cell = [cells objectForKey:key];
		if(cell == selectedCell) continue;
		
		//[myTableView deselectRowAtIndexPath:[myTableView indexPathForCell:cell] animated:NO];
		//[[UIApplica=ion sharedApplication]  resignFirstResponder];
		[cell setSelected:NO animated:NO];
	}
	[myTableView reloadData];
}
/*
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
	if(section == 0)
	{
		return @"Register";
	}
	else if(section == 1)
	{
		return @"(Optional)";
	}
	else
	{
		return @"";
	}

}
 */
- (void)didReceiveMemoryWarning 
{
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
		////////NSLog(@"RegisterViewController did recieve memeory warning.");
	// Release any cached data, images, etc that aren't in use.
}


- (void) reactivate
{
	
}

- (void)dealloc 
{
	[cells release];
    [super dealloc];
}


@end
