//
//  APIBinding.h
//  
//
//  Create by Andrew Paul Simmons on 7/26/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//



#import <CommonCrypto/CommonDigest.h>
#import "Requester.h"
#import "WebXML.h"
#import "UserGeoData.h"
#import "constants.h"
#import "lang.h"
#import "ContentMediaItem.h"
#import "HTMLEntitiesConverter.h"
//#import "CommentsList.h"
#import "ContentList.h"
//#import "CommentItem.h"
#import "UserProfileData.h"
@class ApplicationAPIBinding;
//Private Class APIResponseHandler
@interface APIResponseHandler : NSObject
{
	id target; // the calling object (of the api method)
	SEL success; // the callback method to invoke on the calling object
	SEL failure; // the API response handler method
	NSString* response; // api response
	NSError* error; // connection error
	SEL responseHandler; // the API method that will process the returned XML
	SEL failureHandler; // the API method that will process the connection error
	Requester* requester;
	id extra;
}

//::Public
- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f;
- (id)initWithResponseHandler:(SEL)rh failureHanlder:(SEL)fh target:(id)t success_cb:(SEL)s failure_cb:(SEL)f extra:extraOrNil;
+ (void) changeAvatar:(NSString*)contentID responstTarget:(id)target success_cb:(SEL)success failure_cb:(SEL)failure;
@property(assign, readonly) NSString* response;
@property(assign, readonly) NSError* error;
@property(assign, readonly) id target;
@property(assign, readonly) SEL success; 
@property(assign, readonly) SEL failure;
@property(retain, readonly) id extra;
@property(assign) Requester* requester;


//::Private
- (void) onResponse:(NSString*)apiResponse requester:(Requester*)requester; // treemo api http response
- (void) onFailure:(NSError*)connectionError requester:(Requester*)requester; // io error

@end
//end Private Class APIResponseHandler


@interface APIBinding : NSObject 
{

}

//::Public

//+ (void)trustedGetToken:(NSString*)username;

+ (void)setAuthToken:(NSString*)authToken;

+ (NSString*) propertyTagStringFromDictionary:(NSMutableDictionary*)dict;

+ (NSString*)authLoginFromAuthTokenRequest:(NSString*)url;

+ (void) reportAbuseWithDescription:(NSString*)description
					responseHandler:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure;

+ (Requester*) tagsGetListContentForTag:(NSString*)tag
						 pageSize:(int)page_size
				   responseTarget:(id)target
					   success_cb:(SEL)success
					   failure_cb:(SEL)failure;

+ (Requester*) tagsGetListContentForTag:(NSString*)tag
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure;




+ (Requester*) channelGetListContentForUsername:(NSString*)username
									  authToken:(NSString*)authTokenOrNil
									   pageSize:(int)page_size
									contentType:(NSString *)contentType
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;

+ (Requester*) channelGetListContentForUsername:(NSString*)username
									  authToken:(NSString*)authTokenOrNil
									   pageSize:(int)page_size
									 pageNumber:(int)page_number
									contentType:(NSString *)contentType
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;


+ (void) SetPushToken:(void*)deviceToken
		 actionTarget:(id)target
		   success_cb:(SEL)success
		   failure_cb:(SEL)failure;

+ (void) authGetTokenFromUsername:(NSString*)username 
					  andPassword:(NSString*)password
				   responseTarget:(id)target
					   success_cb:(SEL)success
					   failure_cb:(SEL)failure;

+ (void) logAppAction:(NSString*)application_action
	  applicationName:(NSString*)application_name
   applicationVersion:(NSString*)application_version
			 username:(NSString*)username
			installID:(NSString*)install_id
		   linkDomain:(NSString*)link_domain;


///only supports searching for users at this point.
+ (Requester*) searchGeoWithMyLatitude:(NSString*)latitude
						  MyLongitude:(NSString*)longitude
						  contentTypeOrNil:(NSString*)contentType
							   radiusOrNil:(NSString*)radius
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure;


+ (Requester*) getUsersReviews:(NSString*)userName
				viewMode:(NSString*)extra_int
			   item_type:(NSString*)item_type
			 page_number:(NSInteger)page_number
			   page_size:(NSInteger)page_size
			actionTarget:(id)target
			  success_cb:(SEL)success
			  failure_cb:(SEL)failure;

+ (void) getUserRating:(NSString*)username
		  actionTarget:(id)target
			success_cb:(SEL)success
			failure_cb:(SEL)failure;


//Allows to set the currently logged in user's location
//The callbacks aren't neccessary.
+ (void) setUserLocationWithLongitude:(NSString*)longitude
							 Latitude:(NSString*)latitude
						 actionTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure;

+ (void) retrieveLostUserInfo:(NSString*)email
			   responseTarget:(id)target
				   success_cb:(SEL)success
				   failure_cb:(SEL)failure;

+ (void) passwordUpdate:(NSString*)password
			oldPassword:(NSString*)oldPassword
		   actionTarget:(id)target
			  onSuccess:(SEL)onSuccess
			  onFailure:(SEL)onFailure;

+ (void) passwordUpdate:(NSString*)password
		   actionTarget:(id)target
			  onSuccess:(SEL)onSuccess
			  onFailure:(SEL)onFailure;

+ (void) usersRegisterWithUsername:(NSString*)username 
						  password:(NSString*)password
							 email:(NSString*)email
					responseTarget:(id)target
						success_cb:(SEL)success
						failure_cb:(SEL)failure;

+ (Requester*) exploreGetMostRecentWithPageSize:(int)page_size
										   type:(NSString*)contentTypeOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;

+ (Requester*) exploreGetMostViewedWithPageSize:(int)page_size
										   type:(NSString*)contentTypeOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;

+ (Requester*) exploreGetMostCommentedWithPageSize:(int)page_size
											  type:(NSString*)contentTypeOrNil
									responseTarget:(id)target
										success_cb:(SEL)success
										failure_cb:(SEL)failure;
+ (void) userEditProfileWithUserProfileData: (UserProfileData*) upd
							   actionTarget:(id)target
								 success_cb:(SEL)success
								 failure_cb:(SEL)failure;

+ (void) userEditProfileWithLocation:(NSString*)location 
						actionTarget:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure; 

//Get user's profile data by user name. No authentication needed.
+ (void) getUserProfileWithUser:(NSString*)user
				   actionTarget:(id)target
					 success_cb:(SEL)success
					 failure_cb:(SEL)failure;


//::Private
+ (void) parseAndHandleAuthenticationXML:(WebXML*)xml;

+ (void) setAndStoreLoginForUser:(NSString*)username
					   authToken:(NSString*)authToken
					 cookieToken:(NSString*)cookieToken
					  cookieName:(NSString*)cookieName;

+ (void) onConnectionFailure:(APIResponseHandler*)apirh;

+ (Requester*) channelAddMedia:(NSData*)mediaOrNil 
			   withTitle:(NSString*)titleOrNil
			 description:(NSString*)descriptionOrNil
					tags:(NSString*)tagsOrNil
			propertyTags:(NSDictionary*)propertyTagsOrNil
				location:(NSString*)locationOrNil 
		  responseTarget:(id)target
			  success_cb:(SEL)success
			  failure_cb:(SEL)failure;

+ (Requester*) channelDelete:(NSString*)contentID 
				responseTarget:(id)target
					success_cb:(SEL)success
					failure_cb:(SEL)failure;


+ (Requester*) leaderboardRecordScore:(NSString*)score 
							   gameID:(NSString*)game_id
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure;

+ (NSString*) generateSignature:(NSMutableDictionary*)vars;

+ (Requester*) makeRequest:(NSString*)api_method  
		   paramters:(NSMutableDictionary*)vars 
	 responseHandler:(SEL)rh 
	  failureHandler:(SEL)fh 
			  target:(id)target
		  success_cb:(SEL)success
		  failure_cb:(SEL)failure
			   extra:extraOrNil;

+ (Requester*) makeRequest:(NSString*)api_method 
				 paramters:(NSMutableDictionary*)vars
		   responseHandler:(SEL)rh // API Response Handler
			failureHandler:(SEL)fh // Connection Failure Handler
					target:(id)target // stored to be used by the responseHandler
				success_cb:(SEL)success //stored to be used by the the responseHandler
				failure_cb:(SEL)failure; //stored to be used by the the responseHandler

+ (Requester*) makeGetRequestWithURL:(NSString*)url
						   forAction:(NSString*)action
						   paramters:(NSMutableDictionary*)vars 
					 responseHandler:(SEL)rh 
					  failureHandler:(SEL)fh 
							  target:(id)target
						  success_cb:(SEL)success
						  failure_cb:(SEL)failure
							   extra:extraOrNil;


+ (void) usersRegisterWithUserProfileData:(UserProfileData*)userProfiledData
						   responseTarget:(id)target
							   success_cb:(SEL)success
							   failure_cb:(SEL)failure;

// create a useGet overload (if get is ever required)

+ (void) changeAvatar:(NSString*)contentID
	   responstTarget:(id)target
		   success_cb:(SEL)success
		   failure_cb:(SEL)failure;

#pragma mark Comment LIST 
+ (Requester*) commentGetListForContent:(NSString*)contentID
							  authToken:(NSString*)authTokenOrNil
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure;

+ (Requester*) commentGetListForContent:(NSString*)contentID
							  authToken:(NSString*)authTokenOrNil
                           markAsViewed:(BOOL)mark
							   pageSize:(int)page_size
							 pageNumber:(int)page_number
						 responseTarget:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure;
#pragma mark Comment ADD
+ (Requester*) addNewCommentForContent:(NSString*)contentID
							 authToken:(NSString*)authTokenOrNil
							   comment:(NSString *)comment 
						responseTarget:(id)target
							success_cb:(SEL)success
							failure_cb:(SEL)failure;

#pragma mark  COMMENT  LIST 
+ (Requester*) userProfileLoadForUser:(NSString*)userName
							authToken:(NSString*)authTokenOrNil
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure;

#pragma mark CONTENT INFO 
+(Requester *)channelGetContentInfoForContentID:(NSString *)contentID
									  authToken:(NSString*)authTokenOrNil
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;
@end








