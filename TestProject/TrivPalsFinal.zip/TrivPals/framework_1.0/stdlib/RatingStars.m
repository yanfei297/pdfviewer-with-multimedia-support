//
//  RatingStars.m
//  Qwiket
//
//  Created by steve on 9/9/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "RatingStars.h" 
#import <math.h>
#define STAR_BUTTON_WIDTH 170

@implementation RatingStars
@synthesize rating;

- (id) init
{
	if (self = [self initWithFrame:CGRectMake(0, 0, STAR_BUTTON_WIDTH, 23)])
	{
		background = [Utils imageViewWithImageName:@"common_ratingStars-off.png"];
		foreground = [Utils imageViewWithImageName:@"common_ratingStars.png"];
		stars = [Utils imageViewWithImageName:@"common_ratingStars-on.png"];
		[Utils view:background setX:10 setY:3];
		[Utils view:foreground setX:0 setY:0];
		[Utils view:stars setX:-STAR_BUTTON_WIDTH setY:3];
		self.clipsToBounds = YES;
		[self addSubview:background];
		[self addSubview:stars];
		[self addSubview:foreground];
		selectable = YES;
	}
	return self;
}

- (id) initWithRating:(CGFloat)_rating
{
	if( self = [self init])
	{
		selectable = NO;
		[self setRating:_rating];
	}
	return self;
}
- (id)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        // Initialization code
    }
    return self;
}


- (void)drawRect:(CGRect)rect {
    // Drawing code
}

//this if on a scale of 0 to 5 
- (void) setRating:(CGFloat)_rating
{
	if(_rating > 5.0)
	{
		rating = 5.0;
	}
	else if(_rating < 0.0)
	{
		rating = 0.0;
	}
	else
	{
		rating = _rating;
	}
	[Utils view:stars setX:((rating / 5.0 * ((CGFloat)STAR_BUTTON_WIDTH)) - ((CGFloat)STAR_BUTTON_WIDTH))];
}

//this is for having a pixel position
- (void) setRatingWithPixelPosition:(NSInteger)pixelPosition
{
	NSInteger pixel;
	if(pixelPosition > STAR_BUTTON_WIDTH)
	{
		pixel = STAR_BUTTON_WIDTH;
	}
	else if(pixelPosition < 0)
	{
		pixel = 0;
	}
	else
	{
		pixel = pixelPosition;
	}
	[Utils view:stars setX: (-STAR_BUTTON_WIDTH + pixel)] ;
}

- (void)dealloc {
    [super dealloc];
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event
{
	if(selectable)
	{
		//UITouch* touch = [touches anyObject];
		//CGPoint location = [touch locationInView:self];
		//[super touchesBegan:touches	withEvent:event];
		//self.selectedIndex = ((location.x > split_point)?1:0); 
		UITouch* touch = [touches anyObject];
		CGPoint location = [touch locationInView:self];
		[self setRatingWithPixelPosition:location.x];
	}
}
- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesMoved:touches withEvent:event];
	if(selectable)
	{
		UITouch* touch = [touches anyObject];
		CGPoint location = [touch locationInView:self];
		[self setRatingWithPixelPosition:location.x];
	}
}
- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesEnded:touches withEvent:event];
	if(selectable)
	{
		UITouch* touch = [touches anyObject];
		CGPoint location = [touch locationInView:self];
		CGFloat rating = location.x / STAR_BUTTON_WIDTH * 5;
		[self setRating:ceil(rating)];
	}
}
- (void)touchesCancelled:(NSSet *)touches withEvent:(UIEvent *)event
{
	[super touchesCancelled:touches withEvent:event];
	if(selectable)
	{
		UITouch* touch = [touches anyObject];
		CGPoint location = [touch locationInView:self];
		CGFloat rating = location.x / STAR_BUTTON_WIDTH * 5;
		[self setRating:ceil(rating)];
	}
}

@end
