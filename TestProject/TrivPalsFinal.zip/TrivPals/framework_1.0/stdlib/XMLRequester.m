//
//  XMLRequester.m
//  SwamiParthSarathi
//
//  Created by Sayan on 30/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "XMLRequester.h"
#import "NetworkReachability.h"


#define SOAP_HEADER @"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.clients.genmagazine.com\">\n<soapenv:Header/>"

//#define SOAP_HEADER @"<soapenv:Envelope xmlns:soapenv=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:ws=\"http://ws.clients.betterexp.com\">\n<soapenv:Header/>"

#define kTimeOutSeconds 120

@interface XMLRequester (Private) 
- (NSString *) createSOAPBodyForUserLogin:(NSDictionary *)params;
- (NSString *) createSOAPBodyForUserName:(NSDictionary *)params;
- (NSString *) createSOAPBodyForUserRegistration:(NSDictionary *)params;
- (NSString *) createSOAPBodyForCollectionItems:(NSDictionary *)params;
- (NSString *) createSOAPBodyForStoreItems:(NSDictionary *)params;
- (NSString *) encodeNodeValueForXMLRequest:(NSArray *)var;
- (void) createGenericRequest:(ASIHTTPRequest *)request;
@end

@implementation XMLRequester

-(id)initWithURL:(NSString*)url actionTarget:(id)target{
    if ((self = [super initWithURL:url actionTarget:target])) {
        //
    }
    return self;
}

#pragma mark - AIHTTPREQUEST

/*
- (ASIHTTPRequest *) getASIHttpRequsetForUserLogin:(NSDictionary *)params andAction:(NSString *)soapAction {
    NSString *postMsg = [NSString stringWithFormat:@"%@\n%@",SOAP_HEADER,[self createSOAPBodyForUserLogin:params]];
    NSLog(@"REQUEST : %@",postMsg);
    NSData *postData = [postMsg dataUsingEncoding:NSUTF8StringEncoding];
    
    
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request addRequestHeader:@"SOAPAction" value:soapAction];
    [request appendPostData:postData];
    [request setDelegate:actionTarget];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForUserLogin:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self getASIHttpRequsetForUserLogin:params andAction:soapAction];
    [request setDelegate:actionTarget];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForUserName:(NSDictionary *)params andAction:(NSString *)soapAction {
    NSString *postMsg = [NSString stringWithFormat:@"%@\n%@",SOAP_HEADER,[self createSOAPBodyForUserName:params]];
    //NSLog(@"REQUEST : %@",postMsg);
    NSData *postData = [postMsg dataUsingEncoding:NSUTF8StringEncoding];
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request addRequestHeader:@"SOAPAction" value:soapAction];    
    [request appendPostData:postData];
    [request setDelegate:actionTarget];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForUserName:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self getASIHttpRequsetForUserName:params andAction:soapAction];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForUserRegistration:(NSDictionary *)params andAction:(NSString *)soapAction {
    NSString *postMsg = [NSString stringWithFormat:@"%@\n%@",SOAP_HEADER,[self createSOAPBodyForUserRegistration:params]];
    //NSLog(@"REQUEST : %@",postMsg);
    NSData *postData = [postMsg dataUsingEncoding:NSUTF8StringEncoding];
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request addRequestHeader:@"SOAPAction" value:soapAction];
    [request appendPostData:postData];
    [request setDelegate:actionTarget];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForUserRegistration:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self getASIHttpRequsetForUserRegistration:params andAction:soapAction];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForCollectionPage:(NSDictionary *)params andAction:(NSString *)soapAction {
    NSString *postMsg = [NSString stringWithFormat:@"%@\n%@",SOAP_HEADER,[self createSOAPBodyForCollectionItems:params]];
    //NSLog(@"REQUEST : %@",postMsg);
    NSData *postData = [postMsg dataUsingEncoding:NSUTF8StringEncoding];
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request addRequestHeader:@"SOAPAction" value:soapAction];
    [request appendPostData:postData];
    [request setDelegate:actionTarget];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForCollectionPage:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self getASIHttpRequsetForCollectionPage:params andAction:soapAction];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForStorePage:(NSDictionary *)params andAction:(NSString *)soapAction {
    NSString *postMsg = [NSString stringWithFormat:@"%@\n%@",SOAP_HEADER,[self createSOAPBodyForStoreItems:params]];
    //NSLog(@"REQUEST : %@",postMsg);
    NSData *postData = [postMsg dataUsingEncoding:NSUTF8StringEncoding];
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request addRequestHeader:@"SOAPAction" value:soapAction];
    [request appendPostData:postData];
    [request setDelegate:actionTarget];
    return request;
}

- (ASIHTTPRequest *) getASIHttpRequsetForStorePage:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self getASIHttpRequsetForStorePage:params andAction:soapAction];
    [request setDidFinishSelector:action];
    [request setUserInfo:[params objectForKey:@"info"]];
    [request startAsynchronous];
    return request;
}
*/

- (ASIHTTPRequest *)getASIHttpRequestWithDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [ASIHTTPRequest requestWithURL:[NSURL URLWithString:requestURL]];
    //[self createGenericRequest:request];
    [request setRequestMethod:@"POST"];
    [request setDelegate:actionTarget];
    [request setTimeOutSeconds:1000];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}

- (ASIFormDataRequest *)getASIFormDataRequestWithPostBody:(id)postdata DidFinishSelector:(SEL) action{

    ASIFormDataRequest *request = [ASIFormDataRequest requestWithURL:[NSURL URLWithString:requestURL]];
    [request setDelegate:actionTarget];
    [request setTimeOutSeconds:1000];
    [request setPostValue:postdata forKey:@"jsondata"];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}


/*
- (ASIHTTPRequest *)getASIHttpRequsetForChallengeFriendWithDidFinishSelector:(SEL) action{
    ASIHTTPRequest *request = [self createGenericRequestWithURL:[NSURL URLWithString:requestURL]];
    [request setDelegate:actionTarget];
    [request setDidFinishSelector:action];
    [request startAsynchronous];
    return request;
}
 */

@end

@implementation XMLRequester (Private)

- (NSString *) createSOAPBodyForUserLogin:(NSDictionary *)params{
    NSString *requestBody = @"<soapenv:Body>"
    @"<ws:login>";//userLogin
    NSEnumerator *enumarator = [params keyEnumerator];
    NSString *key = nil;
    while (key = [enumarator nextObject]) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:key,[params objectForKey:key], nil]]];
    }
    requestBody = [requestBody stringByAppendingFormat:@"<ws:deviceID>%@</ws:deviceID>",[UIDevice currentDevice].uniqueIdentifier];
    requestBody = [requestBody stringByAppendingFormat:@"</ws:login>\n</soapenv:Body>\n</soapenv:Envelope>"];
    //NSLog(@"BODY : %@",requestBody);
    return requestBody;
}

- (NSString *) createSOAPBodyForUserName:(NSDictionary *)params{
    NSString *requestBody = @"<soapenv:Body>"
    @"<ws:validateUser>";
    NSEnumerator *enumarator = [params keyEnumerator];
    NSString *key = nil;
    while (key = [enumarator nextObject]) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:key,[params objectForKey:key], nil]]];
    }
    //requestBody = [requestBody stringByAppendingFormat:@"<ws:deviceID>%@</ws:deviceID>",[UIDevice currentDevice].uniqueIdentifier];
    requestBody = [requestBody stringByAppendingFormat:@"</ws:validateUser>\n</soapenv:Body>\n</soapenv:Envelope>"];
    //NSLog(@"BODY : %@",requestBody);
    return requestBody;
}

- (NSString *) createSOAPBodyForUserRegistration:(NSDictionary *)params{
    NSString *requestBody = @"<soapenv:Body>"
    @"<ws:registration>";
    /*NSString *key = nil;
    while (key = [enumarator nextObject]) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:key,[params objectForKey:key], nil]]];
    }
     */
    NSArray *values = [params objectForKey:@"values"];
    NSArray *keys = [params objectForKey:@"keys"];
    for (int i = 0; i < [values count]; i++) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:[keys objectAtIndex:i], [values objectAtIndex:i],nil]]];
    }
    requestBody = [requestBody stringByAppendingFormat:@"<ws:deviceID>%@</ws:deviceID>",[UIDevice currentDevice].uniqueIdentifier];
    requestBody = [requestBody stringByAppendingFormat:@"</ws:registration>\n</soapenv:Body>\n</soapenv:Envelope>"];
    //NSLog(@"BODY : %@",requestBody);
    return requestBody;
}

- (NSString *) createSOAPBodyForCollectionItems:(NSDictionary *)params{
    NSString *requestBody = @"<soapenv:Body>"
    @"<ws:collectionItems>";
    /*NSString *key = nil;
     while (key = [enumarator nextObject]) {
     requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:key,[params objectForKey:key], nil]]];
     }
     */
    NSArray *values = [params objectForKey:@"values"];
    NSArray *keys = [params objectForKey:@"keys"];
    for (int i = 0; i < [values count]; i++) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:[keys objectAtIndex:i], [values objectAtIndex:i],nil]]];
    }
    //requestBody = [requestBody stringByAppendingFormat:@"<ws:deviceID>%@</ws:deviceID>",[UIDevice currentDevice].uniqueIdentifier];
    requestBody = [requestBody stringByAppendingFormat:@"</ws:collectionItems>\n</soapenv:Body>\n</soapenv:Envelope>"];
    
    //NSLog(@"BODY : %@",requestBody);
    return requestBody;
}

- (NSString *) createSOAPBodyForStoreItems:(NSDictionary *)params{
    NSString *requestBody = @"<soapenv:Body>"
    @"<ws:storeItems>";
    /*NSString *key = nil;
     while (key = [enumarator nextObject]) {
     requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:key,[params objectForKey:key], nil]]];
     }
     */
    NSArray *values = [params objectForKey:@"values"];
    NSArray *keys = [params objectForKey:@"keys"];
    for (int i = 0; i < [values count]; i++) {
        requestBody = [requestBody stringByAppendingFormat:@"%@",[self encodeNodeValueForXMLRequest:[NSArray arrayWithObjects:[keys objectAtIndex:i], [values objectAtIndex:i],nil]]];
    }
    requestBody = [requestBody stringByAppendingFormat:@"</ws:storeItems>\n</soapenv:Body>\n</soapenv:Envelope>"];
    //requestBody = [requestBody stringByAppendingFormat:@"<ws:deviceID>%@</ws:deviceID>",[UIDevice currentDevice].uniqueIdentifier];
    //NSLog(@"BODY : %@",requestBody);
    return requestBody;
}

- (NSString *) encodeNodeValueForXMLRequest:(NSArray *)var{
    return [NSString stringWithFormat:@"<ws:%@>%@</ws:%@>",[var objectAtIndex:0],[var objectAtIndex:1],[var objectAtIndex:0]];
}

- (void) createGenericRequest:(ASIHTTPRequest *)request{
   
    [request setRequestMethod:@"POST"];
    [request setTimeOutSeconds:kTimeOutSeconds];
    [request addRequestHeader:@"Content-Type" value:@"text/xml"];
    //[request addRequestHeader:@"SOAPAction" value:soapAction];
	[request addRequestHeader:@"X-DEVICE-MODEL" value:[UIDevice currentDevice].model];
	[request addRequestHeader:@"X-DEVICE-UNIQ" value:[UIDevice currentDevice].uniqueIdentifier];
	[request addRequestHeader:@"X-DEVICE-SYSTEM-VERSION" value:[UIDevice currentDevice].systemVersion];
	[request addRequestHeader:@"X-DEVICE-NAME" value:[UIDevice currentDevice].name];
	[request addRequestHeader:@"X-DEVICE-SYSTEM-NAME" value:[UIDevice currentDevice].systemName];
	int networkType = [NetworkReachability reachability];
	if (networkType == 1) {
		[request addRequestHeader:@"X-DEVICE-NETWORK-TYPE" value:@"wifi"];
	} else if (networkType == 0) {
		[request addRequestHeader:@"X-DEVICE-NETWORK-TYPE" value:@"none"];
	} else {
		[request addRequestHeader:@"X-DEVICE-NETWORK-TYPE" value:@"cellular"];
	}
}


@end
