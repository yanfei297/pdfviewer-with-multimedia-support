//
//  MediaTableCell.m
//  MediaExplorer
//
//  Create by Andrew Paul Simmons on 8/23/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "MediaTableCell.h"
#define kLeftOffset 20
#define kTextOffset 75
@implementation MediaTableCell

- (id)initWithFrame:(CGRect)frame reuseIdentifier:(NSString *)reuseIdentifier 
{
	if (self = [super initWithFrame:frame reuseIdentifier:reuseIdentifier]) 
	{
		// Initialization code
		
		/*
		 init the url label. (you will see a difference in the font color and size here!
		 set the text alignment to align on the left
		 add the label to the subview
		 release the memory
		 */
		
	
		
        title_lb = [self newLabelWithPrimaryColor:[UIColor blackColor] 
									selectedColor:[UIColor blackColor] 
										 fontSize:15.0 
											 bold:NO];
		title_lb.frame = CGRectMake(kLeftOffset + kTextOffset, 8, 170, 60);
		title_lb.backgroundColor = [UIColor clearColor];
		title_lb.numberOfLines = 0; //no maximum number of lines
	
		[self.contentView addSubview:title_lb];
	
		/*
        authorLabel = [self newLabelWithPrimaryColor:[UIColor blackColor] 
									   selectedColor:[UIColor lightGrayColor] 
											fontSize:10.0 bold:NO];
		authorLabel.numberOfLines = 0; //no maximum number of lines
		[self.contentView addSubview:authorLabel];
		*/
		
        dateLabel = [self newLabelWithPrimaryColor:[UIColor blackColor] 
									 selectedColor:[UIColor blackColor] 
										  fontSize:12.0 bold:NO];
		dateLabel.numberOfLines = 0; //no maximum number of lines
		dateLabel.backgroundColor = [UIColor clearColor];
		[self.contentView addSubview:dateLabel];
		
		
		thumbnail_wiv = [[APSWebImageView alloc] initWithFrame:CGRectZero];
		
		self.accessoryType = UITableViewCellAccessoryNone;
		[self.contentView addSubview:thumbnail_wiv];
		self.selectionStyle = UITableViewCellSelectionStyleNone;
	
		//[title_lb release];
	}
	return self;
}

- (void) setTitle:(NSString*)newTitle
{
	if (title != newTitle) 
	{ 
		[title release]; 
		title = [newTitle copy];
		[Utils setLabel:title_lb withText:title maxHeight:45];
		//////////NSLog(@"Label Height %f", title_lb.frame.size.height);
		//title_lb.text = [Utils truncateAndAddEllipsisWithString:title maxLengthIncludingEllipsis:40];
		//////////NSLog(@"Created new title %@", newTitle);
	} 	
	
}

- (NSString*) title
{
	return title;
}


- (void) setAuthor:(NSString*)theAuthor
{
	if (author != theAuthor) 
	{ 
		[theAuthor release]; 
		theAuthor = [theAuthor copy]; 
		authorLabel.text = [@"by " stringByAppendingString:theAuthor];
	} 	
	
}

- (NSString *) author { return author; }

- (void) setDate:(NSString*)theDate
{
	if (date != theDate) 
	{ 
		[theDate release]; 
		theDate = [theDate copy]; 
		//////////NSLog(@"Setting date to %@", theDate);
		dateLabel.text = theDate;
	} 	
	
}

- (NSString *) date { return date; }


- (void) setImageURL:(NSString*)newImageURL
{
	
	if (imageURL != newImageURL) 
	{ 
		
		[imageURL release]; 
		imageURL = [newImageURL copy]; 
		[thumbnail_wiv loadAndCacheImageWithStringURL:newImageURL];
	} 	
}

//if(thumbnail_wiv.image) return;
//////////NSLog(@"Starting Download");
//thumbnail_img = [self newUIImageWithURL:newImageURL];
//////////NSLog(@"Creating ImageView");
//////////NSLog(@"Loading Cell %@", self.title );
//imageLoader_wv = [[UIWebView alloc] initWithFrame:CGRectMake(boundsX + 4, 4, 100, 100)];	


- (NSString*) imageURL
{
	return imageURL;
}

- (void)layoutSubviews {
	
    [super layoutSubviews];
	[self addSubview:[Utils imageViewWithImageName:@"ListItem.png" x:kLeftOffset y:0]];
	[self addSubview:thumbnail_wiv];
	[self addSubview:dateLabel];
	[self addSubview:title_lb];
	// getting the cell size
    CGRect contentRect = self.contentView.bounds;
	
	// In this example we will never be editing, but this illustrates the appropriate pattern
	// get the X pixel spot
	CGFloat boundsX = contentRect.origin.x;
	CGFloat width = contentRect.size.width;
	
	
	//authorLabel.frame = CGRectMake(boundsX + 114, 60, 170, 15);
	dateLabel.frame = CGRectMake(boundsX + kTextOffset + kLeftOffset, 50, 170, 15);
	
	thumbnail_wiv.frame = CGRectMake(boundsX + 8 + kLeftOffset, 7, 60, 60); 
	//detailDisclosure_btn.frame = CGRectMake(width - 35.0, 50.0, 25.0, 25.0);
	self.backgroundColor = [UIColor clearColor];
}


/*
-(UIImage*) newUIImageWithURL:(NSString*)urlString
{
	return [[UIImage alloc] initWithData:[NSData dataWithContentsOfURL:[NSURL URLWithString:urlString]]];
}
*/
 
- (UILabel *)newLabelWithPrimaryColor:(UIColor *)primaryColor 
						selectedColor:(UIColor *)selectedColor 
									
							 fontSize:(CGFloat)fontSize 
								 bold:(BOOL)bold
{
	/*
	 Create and configure a label.
	 */
	
	UIFont *font;
	
	if (bold) 
	{
		font = [UIFont fontWithName:@"TimesNewRomanPS-BoldMT" size:fontSize];
	}
	else 
	{
		font = [UIFont fontWithName:@"AppleGothic" size:fontSize];
	}
	
	/*
	 Views are drawn most efficiently when they are opaque and do not have a clear background, 
	 so set these defaults.  To show selection properly, however, the views need to be transparent 
	 (so that the selection color shows through).  This is handled in setSelected:animated:.
	 */
	UILabel *newLabel = [[UILabel alloc] initWithFrame:CGRectZero];
	newLabel.backgroundColor = [UIColor whiteColor];
	newLabel.opaque = YES;
	newLabel.textColor = primaryColor;
	newLabel.highlightedTextColor = selectedColor;
	newLabel.font = font;
	
	return newLabel;
}
		

- (UIButton*)newDetailDisclosureButton
{
	// create a UIButton (UIButtonTypeDetailDisclosure)
	UIButton* ddButton;
	ddButton = [UIButton buttonWithType:UIButtonTypeDetailDisclosure];
	ddButton.frame = CGRectMake(0.0, 0.0, 25.0, 25.0);
	[ddButton setTitle:@"Detail Disclosure" forState:UIControlStateNormal];
	ddButton.backgroundColor = [UIColor clearColor];
	//[ddButton addTarget:self action:@selector(action:) forControlEvents:UIControlEventTouchUpInside];
	return [ddButton retain]; // hence this is a 'new' method;
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated 
{
	if(selected)
	{
		//[thumbnail_wiv unload];
	}
	
	[super setSelected:selected animated:animated];
		//////////NSLog(@"Selected");
}

- (UIImage*) thumbnail
{
	return thumbnail_wiv.image;
}
- (void)dealloc 
{
	[thumbnail_wiv release];
	//[thumbnail_img release];
	[title_lb release];
	[title release];
	[imageURL release];
	
	[super dealloc];
}


@end
