//
//  StockCell.h
//  Andrew_CBSNews
//
//  Created by Bryce Buchanan on 3/2/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//
#import <UIKit/UIKit.h>
#import "APSWebImageView.h"
#import "TreemoTableCellProtocol.h"

@interface ListCellDark : UITableViewCell <TreemoTableCellProtocol>
{
	NSString* titleText;
	UILabel* titleText_lb;
	NSDictionary* dictionary;
	NSString* thumbnailURL;
	APSWebImageView* webImage;
	UIView* webImageHolder;
	
}

//::Public 

- (void)setDictionary:(NSDictionary*)dict;
- (NSDictionary*)dictionary;

- (void)cellDidAppear;
- (void)cellDidDissappear;

+ (NSString*) cellType;
+ (int) cellHeight;


//::Protected
@property(assign) NSString* titleText;
@property(assign) NSString* thumbnailURL;



@end
