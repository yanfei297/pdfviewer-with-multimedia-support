//
//  TreemoTableCellProtocol.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/29/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <UIKit/UIKit.h>


@protocol TreemoTableCellProtocol <NSObject>

@required 
+ (NSString*) cellType;
+ (NSString*) cellHeight;

- (void) setDictionary:(NSDictionary*)dict;
- (NSDictionary*) dictionary;


- (void) cellDidAppear;
- (void) cellDidDissappear;

//NSUserDefaults


// No Optional Parts //@optional

@end
