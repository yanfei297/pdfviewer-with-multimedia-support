//
//  TextOnlyListItem.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/7/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "TreemoTableCellProtocol.h"
#import "SafeDictionary.h"

@interface TextOnlyListCell : UITableViewCell <TreemoTableCellProtocol>
{

	UILabel* titleText_lb;
	SafeDictionary* dictionary;

}

//::Public 


- (void)setDictionary:(SafeDictionary*)dict;
- (SafeDictionary*)dictionary;

- (void)cellDidAppear;
- (void)cellDidDissappear;

+ (NSString*) cellType;
+ (int) cellHeight;


@property(assign) NSString* titleText;


@end
