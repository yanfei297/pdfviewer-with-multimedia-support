//
//  XMLRequester.h
//  SwamiParthSarathi
//
//  Created by Sayan on 30/01/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Requester.h"
#import "ASIHTTPRequest.h"
#import "ASIFormDataRequest.h"

@interface XMLRequester : Requester
/*
- (ASIHTTPRequest *) getASIHttpRequsetForUserLogin:(NSDictionary *)params andAction:(NSString *)soapAction;
- (ASIHTTPRequest *) getASIHttpRequsetForUserLogin:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action;
- (ASIHTTPRequest *) getASIHttpRequsetForUserName:(NSDictionary *)params andAction:(NSString *)soapAction;
- (ASIHTTPRequest *) getASIHttpRequsetForUserName:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action;
- (ASIHTTPRequest *) getASIHttpRequsetForUserRegistration:(NSDictionary *)params andAction:(NSString *)soapAction;
- (ASIHTTPRequest *) getASIHttpRequsetForUserRegistration:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action;
- (ASIHTTPRequest *) getASIHttpRequsetForCollectionPage:(NSDictionary *)params andAction:(NSString *)soapAction;
- (ASIHTTPRequest *) getASIHttpRequsetForCollectionPage:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action;
    - (ASIHTTPRequest *) getASIHttpRequsetForStorePage:(NSDictionary *)params andAction:(NSString *)soapAction;
    - (ASIHTTPRequest *) getASIHttpRequsetForStorePage:(NSDictionary *)params andAction:(NSString *)soapAction andDidFinishSelector:(SEL) action;
 */

//- (ASIHTTPRequest *)getASIHttpRequsetForFaceBookLoginWithDidFinishSelector:(SEL) action;
//- (ASIHTTPRequest *)getASIHttpRequsetForChallengeFriendWithDidFinishSelector:(SEL) action;

- (ASIHTTPRequest *)getASIHttpRequestWithDidFinishSelector:(SEL) action;
- (ASIFormDataRequest *)getASIFormDataRequestWithPostBody:(id)postdata DidFinishSelector:(SEL) action;
@end
