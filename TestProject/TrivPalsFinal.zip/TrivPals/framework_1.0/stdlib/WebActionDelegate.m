//
//  WebActionDelegate.m
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 2/18/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import "WebActionDelegate.h"


@implementation WebActionDelegate

@synthesize lastExteranalURL;

- (id)initWithDelegate:(id)aDelegate
{
	if(self = [super init])
	{
		delegate = aDelegate;
		
	}
	return self;
}



- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType
{
	if([delegate respondsToSelector:@selector(webView:shouldStartLoadWithRequest:navigationType:)])
	{
		return [delegate webView:webView shouldStartLoadWithRequest:request 
		   navigationType:navigationType];
	}
	
	NSString* url = [[request URL] absoluteString];
	////NSLog(@"Should webactiondelegate start load with url: %@", url);
	//return YES;
	NSString* requesthost = [[request URL] host];
	NSString* linkDomainHost = [[NSURL URLWithString:LINK_DOMAIN_URL_STRING] host];

	if(!supressLaunchExternal && !([requesthost isEqualToString:linkDomainHost] || [url isEqualToString:@"about:blank"])) 
	{	
		[lastExteranalURL release];
		lastExteranalURL = [[request URL] retain];
		BOOL launchInSafari = [self shouldLaunchExternalInSafari:url];
		if(launchInSafari)
		{
			return NO;
		}
		
	}
	
	NSArray* url_prsary = [url componentsSeparatedByString:@"__EXTERNAL_"];
	////////NSLog(@"Parse array: %@", url_prsary);
	if([url_prsary count] < 2) 
	{
		return YES;  	
	}
	else
	{
		NSArray* method_prsary = [[url_prsary objectAtIndex:1] componentsSeparatedByString:@"__PARAM__"];
		NSString* method_str = [method_prsary objectAtIndex:0];	
		//////NSLog(@"Trying to launch method %@", method_str);
		SEL method_sel = NSSelectorFromString(method_str);
		if([delegate respondsToSelector:method_sel])
		{
			int numParams = [method_prsary count] - 1;
			//////NSLog(@"Will respond to method: %@ using %i params", method_str, numParams);
			
			if(numParams == 0)
			{
				[self performSelector:method_sel];
			}
			else if(numParams > 0)
			{
				NSString* paramOne = [method_prsary objectAtIndex:1]; 
				paramOne = [paramOne stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
				
				if(numParams == 1)
				{
					[delegate performSelector:method_sel withObject:paramOne];
				}
				else if(numParams == 2)
				{
					
					NSString* paramTwo = [method_prsary objectAtIndex:2]; 
					paramTwo = [paramTwo stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
					////////NSLog(@"Performing method invokation with paramOne:%@  paramTwo:%@", paramOne, paramTwo);
					[delegate performSelector:method_sel withObject:paramOne withObject:paramTwo];
				}
			}
		}
		return NO;
	}
}

- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString
{
	if([delegate respondsToSelector:@selector(shouldLaunchExternalInSafari:)])
	{
		return [delegate shouldLaunchExternalInSafari:urlString];
	}
	
	exitAndLaunchSafari_av = [[UIAlertView alloc] initWithTitle:@"Exit and Launch Browser?"
														message:@"Do you wish to exit this application and launch your web browser?"
													   delegate:self
											  cancelButtonTitle:@"Cancel"
											  otherButtonTitles:@"Go", nil];
	
	
	[exitAndLaunchSafari_av show];
	
	return YES;
}


- (void) clearDelegate
{
	delegate = nil;
}

- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	int noInternetConnectionErrorCode = -0x3F1;
	
	if([error code] ==  noInternetConnectionErrorCode)
	{
		loadFailure_av = [[UIAlertView alloc] initWithTitle:@"No Internet connection."
													message:nil
												   delegate:self
										  cancelButtonTitle:@"Cancel"
										  otherButtonTitles:@"Reload", nil];
		[self retain];
		[loadFailure_av show];
	}
	
	else if(!supressNonConnectionFailureErrorAlerts)
	{
		
		// loadFailure_av = [[[UIAlertView alloc] initWithTitle:@"Load Error"
		// message:nil
		// delegate:self
		// cancelButtonTitle:@"Cancel"
		// otherButtonTitles:@"Reload", nil] autorelease];
		// [self retain];
		// [loadFailure_av show];
		 
		
		
	}
	////////NSLog(@"Failed Load with error %@", error);	
}

- (void) retryLoadAfterFailure
{
	//override this method
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	//[super alertView:alertView clickedButtonAtIndex:buttonIndex];
	if([alertView.title compare:@"Error Loading Page"] != 0)
	{
		if(alertView == exitAndLaunchSafari_av)
		{
			if(buttonIndex == 0) 
			{
				// cancel
			}
			else
			{
				[[UIApplication sharedApplication] openURL:lastExteranalURL];
				//goto upload page
			}
		}
		else if(alertView == loadFailure_av)
		{
			if(buttonIndex == 0) 
			{
				////////NSLog(@"NOT!!! reloading after failure");
				// cancel
			}
			else
			{
				////////NSLog(@"Reloading after failure");
				[self retryLoadAfterFailure];
				//goto upload page
			}
		}
	}
	[alertView release];
	[self release];
}

// Generic WebAction HyperText-Reference Creation Methods
+(NSString*) webActionReplacementHREFWithWebActionName:(NSString*)webActionName 
										  withLinkText:(NSString*)linkText
											 withParam:(NSString*)paramOne 	
{
	
	return [self webActionReplacementHREFWithWebActionName:webActionName
											  withLinkText:linkText
												 withParam:paramOne
												 withParam:nil];
}
+ (NSString*) webActionReplacementHREFWithWebActionName:(NSString*)webActionName 
										   withLinkText:(NSString*)linkText
											  withParam:(NSString*)paramOne 
											  withParam:(NSString*)paramTwo										  
{
	NSString* webAction = [self webActionWithName:webActionName withParam:paramOne withParam:paramTwo];
	return [NSString stringWithFormat:@"<a href=\"%@\">%@</a>", webAction, linkText];	
}

+ (NSString*) webActionWithName:(NSString*)webActionName withParam:(NSString*)paramOne 
{
	return [self webActionWithName:webActionName withParam:paramOne withParam:nil];	
}

+ (NSString*) webActionWithName:(NSString*)webActionName withParam:(NSString*)paramOne withParam:(NSString*)paramTwo
{
	
	NSString* webActionURLString = [NSString stringWithFormat:@"__EXTERNAL_%@", webActionName];
	if(paramOne)
	{
		webActionURLString = [NSString stringWithFormat:@"%@__PARAM__%@", webActionURLString, paramOne];
	}
	if(paramTwo)
	{
		webActionURLString = [NSString stringWithFormat:@"%@__PARAM__%@", webActionURLString, paramTwo];
	}
	
	return webActionURLString;
	
}
// end Generic WebAction HyperText-Reference Creation Methods



- (void) webViewDidFinishLoad:(UIWebView *)webView 
{
	if([delegate respondsToSelector:@selector(webViewDidFinishLoad:)])
	{
		[delegate webViewDidFinishLoad:webView];
	}
}


- (void)dealloc 
{
    [super dealloc];
}

@end
