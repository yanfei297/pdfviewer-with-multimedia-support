//
//  CellData.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 1/29/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <Foundation/Foundation.h>  
#import "SafeDictionary.h"

@interface CellDescription : NSObject 
{
	NSString* type; // class name of cell
	SafeDictionary* data; // all of the data required to build the cell 
	int height;
	NSString* contentID;
	NSString* contentType;
}

@property(readonly) NSString* type;
@property(readonly) SafeDictionary* data;
@property(readwrite) int height;
@property(readonly) NSString* contentID;
@property(readonly) NSString* contentType;

-(id)initWithType:(NSString*)cellType  
			 data:(SafeDictionary*)cellData 
		   height:(int) cellHeight
		contentID:(NSString*)cellContentID
	  contentType:(NSString*)cellContentType;

@end
