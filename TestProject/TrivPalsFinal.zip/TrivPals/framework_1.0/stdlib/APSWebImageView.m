//
//  APSWebImageView.m
//

#import "APSWebImageView.h"

// Normally you would use a DiskCache/RamCache object. 
// In order to distribute this class without dependencies 
// the queueing logic has been included in this class.
NSMutableDictionary* ramCache;
NSUserDefaults* diskCache;
NSMutableDictionary* diskCacheDatas;

// Normally you would use a DispatchQueue object. 
// In order to distribute this class without dependencies 
// the queueing logic has been included in this class.
NSMutableArray* loadRequestQueue;  
APSWebImageView* currentLoadingImageView;

#define DISK_CACHE_MAX_BYTES 5.0*1024*1024

#define LAST_ACCESSED @"last_accessed"
#define NUM_BYTES @"num_bytes"
#define URL_KEY @"url"
#define SAVED @"saved"

#define DISK_CACHE_DATAS @"diskCacheDatas"
#define FADE_SUSPEND_TIME_INTERVAL 0.1f

double fadeSuspendTime;

//UIImage
@implementation APSWebImageView

@synthesize actionTarget, onLoadSuccess, onLoadFailure;
@synthesize onLoadStart, onLoadProgress, onLoadFromWebSuccess;

@synthesize diskCacheOnly;

@synthesize bytesLoaded, bytesTotal, loaded, viewSize, suppressFadeInOnLoadFromWeb;

/*
- (id) initWithConstraintFrame:(CGRect)constraintFrame
{
	return [self initWithConstraintFrame:constraintFrame 
							   anchorTop:NO 
							  anchorLeft:NO];	
}
*/
/* USE APS Web Image Widget
- (id) initWithConstraintFrame:(CGRect)constraintFrame 
					 anchorTop:(BOOL)lockTop 
					anchorLeft:(BOOL)lockLeft
{
	if(self = [super initWithFrame:constraintFrame])
	{
		originalFrame = constraintFrame;
		anchorTop = lockTop;
		anchorLeft = lockLeft;
		
		//float widthConstraint = constraintFrame.size.width;
		//float heightConstraint = constraintFrame.size.height;
		self.backgroundColor = [UIColor clearColor];
		useConstraints = YES;
	}
 
	return self;
}
*/

+ (void)suspendFadeIn
{
	fadeSuspendTime = [[NSDate date] timeIntervalSince1970];
}


- (BOOL) imageIsDiskCachedForStringURL:(NSString*)aURL
{
	return [[diskCacheDatas allKeys] containsObject:aURL];
}

- (void) loadAndCacheImageWithStringURL:(NSString*)url  
{
	[self loadAndCacheImageWithStringURL:url loadNext:NO];
}


- (void) loadAndCacheImageWithStringURL:(NSString*)url  loadNext:(BOOL)loadNext
{	
	urlString = [url copy];
	////////NSLog(@"Loading url [%@] loaded url [%@]", url, urlOfLoadedImage);
	if ([url isEqualToString:urlOfLoadedImage])return;
	[urlOfLoadedImage release];
	
	if(!url)
	{
		[self unload];
		////////NSLog(@"@@@@@@@@@@@@@@ Warning: Could not load image because url is nil string");
		return;
	}
	[APSWebImageView registerToReceiveRelevantSystemNotifications];
	if(!ramCache)
	{
		ramCache = [[NSMutableDictionary dictionaryWithCapacity:8] retain];
	}
	
	if(!diskCache)
	{
		//UINavigationController
		diskCache = [[NSUserDefaults alloc] init];
		////////NSLog(@"Disk Cache Dictionary Representation %@", [[diskCache dictionaryRepresentation] allKeys]);
		NSDictionary* diskCacheDatasDictionary = [diskCache objectForKey:DISK_CACHE_DATAS];
		if(!diskCacheDatasDictionary)
		{
			[diskCache setObject:[NSDictionary dictionary] forKey:DISK_CACHE_DATAS];
			diskCacheDatasDictionary = [[diskCache arrayForKey:DISK_CACHE_DATAS] retain];
		}
		diskCacheDatas = [[NSMutableDictionary dictionaryWithDictionary:diskCacheDatasDictionary] retain];
	}
	useCache = YES;
	
	UIImage* cachedImage = [self cachedImageForURL:url];
	if(cachedImage)
	{
		////////NSLog(@"Image at [%@] still in cache.", url);
		urlOfLoadedImage = [url retain];
		
		[self unload];
		//BOOL fadeIn = ([[NSDate date] timeIntervalSince1970] - fadeSuspendTime > FADE_SUSPEND_TIME_INTERVAL);
		//if(fadeIn)self.alpha = 0;
		self.image = cachedImage;
		/*
		if(fadeIn)
		{
			[Utils recordToAnimate];
			self.alpha = 1.0;
			[Utils animate];
		}
		*/
		loaded = YES;
		
		if([actionTarget respondsToSelector:onLoadSuccess])
		{
			[actionTarget performSelector:onLoadSuccess];
		}
		
		[self didLoadImage];
	}
	else
	{
		[self loadImageWithStringURL:url  loadNext:loadNext];
	}
}
- (void)loadImageWithStringURL:(NSString*)url
{
	[self loadImageWithStringURL:url loadNext:NO];
}

- (void)loadImageWithStringURL:(NSString*)url loadNext:(BOOL)loadNext
{
	if(useConstraints) self.frame = originalFrame;
	
	if(!url)
	{
		[self unload];
		////////NSLog(@"@@@@@@@@@@@@@@ Warning: Could not load image because url is nil string.");
		return;
	}
	[self unload];
	urlString = [url copy];
	
	UIImage* cachedImage = [ramCache objectForKey:url];
	if(cachedImage)
	{
		//////////NSLog(@"Image at [%@] still in cache.", url);
		self.image = cachedImage;
		loaded = YES;
		//self.image.size.height;
		if([actionTarget respondsToSelector:onLoadSuccess])
		{
			[actionTarget performSelector:onLoadSuccess];
		}
		[self didLoadImage];
		
	}
	else
	{
		//////////NSLog(@"Image [%@] not in cache", url);
		[self enqueueLoadRequestWithPriority:loadNext];
	}
	//////////NSLog(@"HEIGHT OF CACHED IMAGE: %f",cachedImage.size.height);
}

- (UIImage*) ramCachedImageForURL:(NSString*)url
{	
	return [ramCache objectForKey:url];
}

- (void) setRamCachedImage:(UIImage*)img forURL:(NSString*)url
{
	if(!diskCacheOnly) 
	{
		[ramCache setObject:img forKey:url];
	}
}


- (UIImage*) diskCachedImageForURL:(NSString*)url
{
	NSData* imageData;
	
	if(imageData = [diskCache dataForKey:url])
	{
		return [[UIImage alloc] initWithData:imageData];
	}
	else 
	{
		return nil;
	}	
}

- (void) setDiskCachedImageData:(NSData*)img_data forURL:(NSString*)url
{
	
	if(!img_data || !url)
	{
		////NSLog(@"Warning could not disk cache image because image data or image url was nil");
	}
	NSNumber* imageBytes = [NSNumber numberWithInt:[img_data length]];
	NSNumber* timestamp = [NSNumber numberWithInt:[[NSDate date] timeIntervalSince1970]];
	
	NSMutableDictionary* data = 
		[NSMutableDictionary dictionaryWithObjects:[NSArray arrayWithObjects:timestamp,      imageBytes,  [NSNumber numberWithBool:0], nil]
										   forKeys:[NSArray arrayWithObjects:LAST_ACCESSED,  NUM_BYTES,   SAVED,                       nil]];
	
	[diskCacheDatas setObject:data forKey:urlString];
	[diskCache setObject:img_data forKey:urlString];
	
}


- (UIImage*) cachedImageForURL:(NSString*)url
{
	UIImage* cachedImage;
	if(cachedImage = [self ramCachedImageForURL:url]) 
	{
		////////NSLog(@"Image found in __RAM__ cache");
		NSMutableDictionary* data = [NSMutableDictionary dictionaryWithDictionary:[diskCacheDatas objectForKey:url]];
		if(data == nil)
		{
			//////NSLog(@"No disk cache record found for ram cached image!");
		}
		else 
		{
			[data setObject:[NSNumber numberWithInt:[[NSDate date] timeIntervalSince1970]]
					 forKey:LAST_ACCESSED];
			[diskCacheDatas setObject:data forKey:url];
		}

			
		return cachedImage; //image found in ram cache
	}
	else if(cachedImage = [self diskCachedImageForURL:url]) 
	{
		NSMutableDictionary* data = [NSMutableDictionary dictionaryWithDictionary:[diskCacheDatas objectForKey:url]];
		if(data == nil)
		{
			//////NSLog(@"No disk cache record found for disk cached image!");
		}
		else 
		{
			[data setObject:[NSNumber numberWithInt:[[NSDate date] timeIntervalSince1970]]
					 forKey:LAST_ACCESSED];
			[diskCacheDatas setObject:data forKey:url];
		}
		
		////////NSLog(@"Image found in __DISK__ cache");
		[self setRamCachedImage:cachedImage forURL:url];
		return cachedImage; //image found in disk cache
		
	}
	else 
	{
		return nil; // no cached image found
	}

}




- (void) cancel
{
	/*
	for(int i = 0; i < [loadRequestQueue count]; i++)
	{
		
		if( (!connection) && (self == [loadRequestQueue objectAtIndex:i]) )
		{
			////////NSLog(@"_______Warning: Object enqueue is being removed but not!");
		}
	}
	*/
	[ai stopAnimating];
	[loadRequestQueue removeObject:self];
	
	if(connection)
	{
		[connection cancel];
	
		[connection release];
		connection = nil;
		[receivedData release];
		receivedData = nil;	
		 
		if(!stopped)
		{
			currentLoadingImageView = nil;
			[urlString release];
			urlString = nil;
			[loadRequestQueue removeObject:self];
			[self loadNextRequest];
		}
	}
}

// used when the image is to be loaded later
- (void) stop
{
	[ai stopAnimating];
	currentLoadingImageView = nil;
	stopped = YES;
	[connection cancel];
	[connection release];
	connection = nil;
	[receivedData release];
	receivedData = nil;	
}

- (void) unload
{
	if (loaded) 
	{
		[self didUnloadImage];
	}
	urlOfLoadedImage = nil;
	loaded = NO;
	[self cancel];
	self.image = nil;
	
} 


- (void) enqueueLoadRequest
{
	[self enqueueLoadRequestWithPriority:NO];
}

- (void) enqueueLoadRequestWithPriority:(BOOL)loadSelfNext
{
	if(loadRequestQueue ==  nil)
	{
		loadRequestQueue = [NSMutableArray array];
		[loadRequestQueue retain];
	}
	
	if(loadSelfNext)
	{
		[loadRequestQueue insertObject:self atIndex:0];
	}
	else 
	{
		[loadRequestQueue addObject:self];
		
	}

	int numLoadRequestsEnqueued = [loadRequestQueue count];
	if(numLoadRequestsEnqueued == 1)
	{
		[self loadNextRequest];
	}
	enqueued = YES;
}

- (void) loadNextRequest
{
	
	if([loadRequestQueue count])
	{
		
		APSWebImageView* webImageView = [loadRequestQueue objectAtIndex:0];
		[webImageView startLoad];
	}
}


- (void) startLoad
{
	if(ai == nil)
	{
		ai = [Utils activityInidicatorCenteredInSize:self.frame.size white:NO];
		////////NSLog(@"Starting load using frame size (%f,%f)", self.frame.size.width, self.frame.size.height);

		// updates ai position;
		//CGSize myViewSize = viewSize;
		self.viewSize = viewSize;
	}
	[ai retain];
	//[self addSubview:ai];
	//[ai startAnimating];
	[ai hidesWhenStopped];
	
	//int progressBarHeght = 1;
	//float width = self.frame.size.width;
	//float height = self.frame.size.height;
	//progressBar = [[[UIView alloc] initWithFrame:CGRectMake(0, height - progressBarHeght -1, 0, progressBarHeght)] autorelease];
	//progressBar.backgroundColor = [Utils colorFromHex:0xa6c8eb];
	//[self addSubview:progressBar];			   
	
	if([actionTarget respondsToSelector:onLoadStart])
	{
		[actionTarget performSelector:onLoadStart];
	}
	
	//CGSize imageSize = self.frame.size;
	/*
	CGSize aiSize = ai.frame.size;
	ai.frame = CGRectMake( (imageSize.width - aiSize.width) / 2, (imageSize.height - aiSize.height) / 2, 
																	aiSize.width, aiSize.height);
	*/
	
	if(currentLoadingImageView != nil) 
	{
		/*
		@throw [NSException exceptionWithName:@"Sequential Image Load Error" 
									   reason:@"Sequential load started while other sequential load in progress." 
									 userInfo:@"Could not load image"];
		 */
	}
	currentLoadingImageView = self;
	stopped = NO;
	
	
	NSURLRequest* r = [[NSURLRequest alloc] initWithURL:[NSURL URLWithString:urlString]];

	receivedData  = [[NSMutableData alloc] initWithCapacity:100];
	connection = [[NSURLConnection alloc] initWithRequest:r delegate:self startImmediately:YES];
	[r release];
	

	
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
	//NSData
	if(!receivedData) return;
	
	[receivedData appendData:data];
	bytesLoaded = [receivedData length];
	
	
	//float percentComplete = ((float)bytesLoaded)/((float)bytesTotal);
	
	if([actionTarget respondsToSelector:onLoadProgress])
	{
		[actionTarget performSelector:onLoadProgress];
	}
		
	/*
	//////NSLog(@"percent complete %f", percentComplete);
	float width = self.frame.size.width;
	[Utils recordToAnimateWithDuration:1.5 ];
	[Utils view:progressBar setWidth:percentComplete*width];
	[Utils animate];
	 */
	

}

- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
	NSHTTPURLResponse* httpResponse = (NSHTTPURLResponse*)response;
	NSDictionary* headers = [httpResponse allHeaderFields];
	NSString* bytesTotalString = (NSString*)[headers objectForKey:@"Content-Length"];
	bytesTotal = [bytesTotalString intValue];
	////////NSLog(@"NSURL connection will load %@ bytes", bytesTotalString);
	
	
	//int bytesTotal = [bytesTotalString intValue];
	//////////NSLog(@"got bytesTotal %i", bytesTotal);
    [receivedData setLength:0];	
}

- (void)connection:(NSURLConnection *)c didFailWithError:(NSError *)error
{
	[ai stopAnimating];
	////////NSLog(@"Connection failed! Error - %@ %@", [error localizedDescription], [[error userInfo] objectForKey:NSErrorFailingURLStringKey]);
	if([actionTarget respondsToSelector:onLoadFailure])
	{
		[actionTarget performSelector:onLoadFailure];
	}
	[self loadDone];
}

-(void)connectionDidFinishLoading:(NSURLConnection *)c
{
	
	[ai stopAnimating];
	if(self.image)
	{
		////////NSLog(@"Loaded completed after another image had already loaded!!!");
		return;
	}
	
	UIImage* loadedImage = [[UIImage alloc] initWithData:receivedData];
	UIImage* reasonablizedImage = [self reasonablizeImageFromImage:loadedImage];
	if(loadedImage != reasonablizedImage)
	{
		[loadedImage release];
		loadedImage = [reasonablizedImage retain];
	}
	
	//Data done loading, but data is not image data.
	if(!loadedImage)
	{
		if([actionTarget respondsToSelector:onLoadFailure])
		{
			[actionTarget performSelector:onLoadFailure];
		}
		[self loadDone];
		return;
	}
	CGRect frameForImage = [self frameForImageSize:loadedImage.size];
	
		
	if(useConstraints) self.frame = frameForImage;
	
	/*@!! remove comment
	BOOL fadeIn = ([[NSDate date] timeIntervalSince1970] - fadeSuspendTime > FADE_SUSPEND_TIME_INTERVAL);
	if(!suppressFadeInOnLoadFromWeb && fadeIn)self.alpha = 0;
	
	*/
	self.image = loadedImage;
	/*@!! remove comment
	if(!suppressFadeInOnLoadFromWeb && fadeIn)
	{
		[Utils recordToAnimate];
		self.alpha = 1.0;
		[Utils animate];
	}
	*/
	
	urlOfLoadedImage = [urlString retain];
	[loadedImage release];
	//[progressBar removeFromSuperview];
	//progressBar = nil;
	
	if(useCache)
	{
		//UIImage
		////NSLog(@"Trying to disk cache image %@ reasonablized image @i", reasonablizedImage, UIImagePNGRepresentation(reasonablizedImage) == nil);
		[self setDiskCachedImageData: UIImagePNGRepresentation(reasonablizedImage) forURL:urlString];
		[self setRamCachedImage:reasonablizedImage forURL:urlString];
		
	}
	loaded = YES;
	if([actionTarget respondsToSelector:onLoadSuccess])
	{
		[actionTarget performSelector:onLoadSuccess];
	}
	if([actionTarget respondsToSelector:onLoadFromWebSuccess])
	{
		[actionTarget performSelector:onLoadFromWebSuccess];
	}
	[self didLoadImage];
	[self loadDone];
}

- (UIImage*) reasonablizeImageFromImage:(UIImage*)img
{


	//////NSLog(@"Reasonablize Image with actual size (%f,%f)", img.size.width, img.size.height);
	float imageWidth = img.size.width;
	float imageHeight = img.size.height;
	float maxWidth = 1024;
	float maxHeight = 1024;
	float scale;
	if(imageWidth > imageHeight)
	{
		scale = maxWidth / imageWidth; 
	}
	else
	{
		scale = maxWidth / imageHeight; 
	}  
	
	if(scale*imageWidth > maxWidth + 1)
	{
		scale = maxWidth/imageHeight;
	}
	else if(scale*imageHeight > maxHeight)
	{
		scale = maxHeight / imageHeight;
	}
	
	if(scale < 1.0f)
	{
		//////NSLog(@"Reducing image size by factor of %f", scale);
		CGSize reasonableSize = CGSizeMake(imageWidth*scale, imageHeight*scale);
		UIImage* theImage = [[UIImage imageWithData:UIImageJPEGRepresentation(img,1)] resizedImage:reasonableSize interpolationQuality:kCGInterpolationHigh];
		//////NSLog(@"Returning Image %@", theImage);
		return theImage;
	}
	else 
	{
		////NSLog(@"Returning original image");
		return img;
	}
	
	return img;
	
}
- (void) didLoadImage
{

	//NSLog(@">>>>>>> Performing alloc of web-image %@", urlString);
}

-(void) didUnloadImage
{
	if(!urlString) return; // no image loaded?
	//NSLog(@"<<<<<<< Performing dealloc of web-image %@", urlString);
}


- (CGRect) frameForImageSize:(CGSize)imageSize
{
	CGSize maxSize = self.frame.size;
	float scaleRatio;
	
	if(imageSize.width > imageSize.height)
	{
		scaleRatio = maxSize.width/imageSize.width;
		
		////////NSLog(@"scaleRatio:%f, maxWidth:%f, maxHeight:%f", scaleRatio, maxSize.width, imageSize.width);
	}
	else
	{
		scaleRatio = maxSize.width/imageSize.width;
	}
	
	// It is possible that one and only one side
	// still will not fit into the rectangle described by
	// maxHeight and maxWidth (because it may not be square)
	//Here we check for this side and rescale if needed
	if(imageSize.width*scaleRatio  > maxSize.width)
	{
		////////NSLog(@"!!!!! Rescaling Width");
		scaleRatio = maxSize.width/imageSize.width;
	}
	else if(imageSize.height*scaleRatio > maxSize.height)
	{
		////////NSLog(@"!!!!! Rescaling Height");
		scaleRatio = maxSize.height/imageSize.height;
	}
	
	float newWidth = imageSize.width * scaleRatio;
	float newHeight = imageSize.height * scaleRatio;
	////////NSLog(@"NewWidth:%f, NewHeight:%f", newWidth, newHeight);
	
	float newX; 
	float newY;
	newX = anchorLeft ? self.frame.origin.x : self.frame.origin.x + (maxSize.width - newWidth)/2;
	newY = anchorTop ? self.frame.origin.y : self.frame.origin.y + (maxSize.height - newHeight)/2;  
	
	return CGRectMake(newX, newY, newWidth, newHeight);
}

- (void) loadDone
{
	////NSLog(@"Load Done");
	[ai stopAnimating];
	currentLoadingImageView = nil;
	[connection release];
    connection = nil;
    [receivedData release];
	receivedData = nil;
	[loadRequestQueue removeObject:self];
	[self loadNextRequest];
}

+ (void) clearRamCache
{
	if(!ramCache) return;
	[ramCache release];
	ramCache = nil;
}

+ (void) registerToReceiveRelevantSystemNotifications
{
	static BOOL registerComplete = NO;	
	if(!registerComplete)
	{
		[self registerToReceiveLowMemoryWarnings];
		[self registerToReceiveApplicationTerminationNotification];
	}
	registerComplete = YES;
}

+ (void) registerToReceiveLowMemoryWarnings
{
	static BOOL registeredForMemoryWarning;
	if(registeredForMemoryWarning) return;
	[[NSNotificationCenter defaultCenter]  addObserver:self
											  selector:@selector(onReceiveLowMemoryWarning:)
												  name:UIApplicationDidReceiveMemoryWarningNotification object:nil];
	registeredForMemoryWarning = YES;
}

+ (void) registerToReceiveApplicationTerminationNotification
{
	UIApplication* app = [UIApplication sharedApplication];
	[[NSNotificationCenter defaultCenter] addObserver:self 
											 selector:@selector(applicationWillTerminate:) 
												 name:UIApplicationWillTerminateNotification 
											   object:app];
}

+ (void) onReceiveLowMemoryWarning:(NSNotification*)n
{
	[self clearRamCache];
}


+ (void) applicationWillTerminate:(NSNotification *)notification 
{
	//////NSLog(@"Application Starting Termination___________");
	
	
	NSArray* allCachedDataKeys = [diskCacheDatas allKeys];
	NSMutableArray* diskCacheDatasArray = [NSMutableArray arrayWithCapacity:0];
	int diskCacheDatas_length = [diskCacheDatas count];
	
	int bytestotal = 0;
	for(int i = 0; i < diskCacheDatas_length; i++)
	{
		NSString* url = [allCachedDataKeys objectAtIndex:i];
		NSDictionary* dict = [diskCacheDatas objectForKey:url];
		
		
		BOOL imageIsSaved = [(NSNumber*)[dict objectForKey:SAVED] boolValue];
		if(imageIsSaved) 
		{
			// do not remove saved objects
			
			// saved object do not get inserted into the array of objects
			// which is used to find objects to remvoe from diskCachDatas
			continue;
		}
		
		NSMutableDictionary* dictWithKey = [NSMutableDictionary dictionaryWithDictionary:dict];
		int numBytes = [(NSNumber*)[dict objectForKey:NUM_BYTES] intValue];
		bytestotal += numBytes;
		
		////////NSLog(@"Added %i bytes | New bytes total %i", numBytes, bytestotal);
		
		[dictWithKey setObject:url forKey:URL_KEY];
		[diskCacheDatasArray addObject:dictWithKey];
	}
	
	NSSortDescriptor* lruSorter = [[NSSortDescriptor alloc] initWithKey:LAST_ACCESSED ascending:NO];
	[diskCacheDatasArray sortUsingDescriptors:[NSArray arrayWithObject:lruSorter]];
	
	
	//////NSLog(@"Disk Cache Datas _Array_ Sorted?? %@", diskCacheDatasArray);
	
	
	for (int j = diskCacheDatas_length - 1; bytestotal > DISK_CACHE_MAX_BYTES && j >= 0; j--) 
	{
		NSDictionary* leastRecentlyAccessed_data = [diskCacheDatasArray lastObject];
		int imageBytes = [(NSNumber*)[leastRecentlyAccessed_data objectForKey:NUM_BYTES] intValue];
		NSString* urlKey = [leastRecentlyAccessed_data objectForKey:URL_KEY];
		[diskCacheDatas removeObjectForKey:urlKey];
		[diskCache removeObjectForKey:urlKey];
		
		bytestotal -= imageBytes;
		[diskCacheDatasArray removeLastObject];
		
		//////NSLog(@"Removing image with key %@", urlKey);
	}
	
	[diskCache setObject:diskCacheDatas forKey:DISK_CACHE_DATAS];
	[diskCache synchronize];
	
	
	
	//////NSLog(@"Application Completing Termination___________");
}


+ (void) saveCachedImageWithURL:(NSString*)imageURL
{
	NSDictionary* dict = [diskCacheDatas objectForKey:imageURL];
	if(dict == nil)
	{
		////NSLog(@"Warning: Attempting to save image with url %@ but no image object found!", imageURL);
	}
	[dict setValue:[NSNumber numberWithBool:1] forKey:SAVED];
}

+ (void) unsaveCachedImageWithURL:(NSString*)imageURL
{
	NSDictionary* dict = [diskCacheDatas objectForKey:imageURL];
	[dict setValue:[NSNumber numberWithBool:0] forKey:SAVED];
	
}


- (void)dealloc 
{
	if(enqueued)
	{
		[loadRequestQueue removeObject:self];
	}
	
	if(connection) //we are the active loading view
	{
		// start the next view loading
		[self loadNextRequest];
	}
	[self didUnloadImage];
	
	[urlString release];
	[connection release];
	[receivedData release];

	
	[super dealloc];
}

@end
