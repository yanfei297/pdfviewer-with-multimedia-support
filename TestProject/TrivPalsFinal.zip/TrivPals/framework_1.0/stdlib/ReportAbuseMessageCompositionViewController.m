//
//  ReportAbuseMessageCompositionViewController.m
//  Qwiket
//
//  Created by steve on 8/12/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "ReportAbuseMessageCompositionViewController.h"


@implementation ReportAbuseMessageCompositionViewController
@synthesize generatedSubject;


- (id) initWithSubject:(NSString*) subject
{
	////////NSLog(@"ReportAbuseMessageCompositionViewController initWithSubject reached.");
	if(self = [super init])
	{
		self.generatedSubject = subject;
	}
	return self;
}
/*
 // The designated initializer.  Override if you create the controller programmatically and want to perform customization that is not appropriate for viewDidLoad.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/

-(void) alertView:(UIAlertView*)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	//[super alertView:alertView clickedButtonAtIndex:buttonIndex];
	if([alertView.title compare:@"Error Loading Page"] != 0)
	{
	////////NSLog(@"alertview reached for message: %@",alertView.title);
	
	if( alertView.title == @"Message Sent" || alertView.title == @"Error")
	{
		////////NSLog(@"poping view controller.");
		[self dismissModalViewControllerAnimated:YES];
	}
	send.enabled = YES;
	[alertView release];
	alertView = nil;
	}
	return;
}

// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	cells = [[NSMutableDictionary alloc] initWithCapacity:0];
	[self createCells];
	body = [[[UITextView alloc] initWithFrame:CGRectMake(0, 0, 320, 135)]autorelease];
	body.font = [UIFont fontWithName:FONTNAME_helvetica size:15];
	if([Utils username] == nil)
	{
		UIAlertView* messageSent = [[UIAlertView alloc] initWithTitle: @"Error"
															  message: @"You must be logged in to send an abuse report." 
															 delegate:self
													cancelButtonTitle:nil 
													otherButtonTitles:@"OK",nil];
		
		messageSent.delegate = self;
		[messageSent show];
	}
	//body.placeholder = @"Optional Abuse Report Description";
	myTableView.tableFooterView = body;
	//UILabel* headerLabel = [[[UILabel alloc] initWithFrame:CGRectMake(0, 0, 320, 50)] autorelease];
	//[Utils view:myTableView setY:0];
	
	////headerLabel.text = @"                    Report Abuse";
	//headerLabel.textColor = [UIColor whiteColor];
	////headerLabel.backgroundColor = [UIColor clearColor];
	//myTableView.tableHeaderView = headerLabel;
	[self.view addSubview:myTableView];
	
}


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	////////NSLog(@"reporabusemessagecomposisitionviewcontroller did recieve memeory warning.");
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

- (void) viewDidAppear:(BOOL)animated	
{
	[super viewDidAppear:animated];	
	[((UITextView*)myTableView.tableFooterView) becomeFirstResponder];
	NSInteger length = ((UITextView*)myTableView.tableFooterView).text.length;
	((UITextView*)myTableView.tableFooterView).selectedRange = NSMakeRange(0,0);
}
- (void)dealloc {
    [super dealloc];
}

- (IBAction) onCancel:(id)sender
{
	////////NSLog(@"Cancel button tapped.");
	[loading stopAnimating];
	[requester cancel];
	[super dismissModalViewControllerAnimated:YES];
}
- (IBAction) onSendMessage:(id)sender
{
	send.enabled = NO;
	[loading startAnimating];
	[APIBinding reportAbuseWithDescription: [NSString stringWithFormat:@"%@ : %@", generatedSubject,body.text]
						   responseHandler:self
								success_cb:@selector(success:)
								failure_cb:@selector(failure:)];
}
- (void) createCells
{
	
		{
			NSString* cellIdentifier = @"subject";
			UITableViewCell* cell;
			cell = [[UITableViewCell alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier];
			UILabel* title = [Utils labelWithFrame:CGRectMake(5, 25, 70, 20)
									   text:@"Subject"
								  textColor:[UIColor blackColor]
								   fontName: nil 
								   fontSize:20
									   bold:YES];
			UILabel* subject = [Utils labelWithFrame:CGRectMake(85, 5, 230, 90) 
												text:nil 
										   textColor:[UIColor blueColor] 
											fontName:nil 
											fontSize:18
												bold:NO];
			cell.selectionStyle = UITableViewCellSelectionStyleNone;
			[Utils setLabel:subject withText:generatedSubject maxHeight:80];
			
			[cell.contentView addSubview:subject];
			[cell.contentView addSubview:title];
			[cells setObject:cell forKey:cellIdentifier];
			
			
			/*
			 cell.label.text = @"Subject";
			
			cell.editable = NO;
			//[Utils setLabel:cell.propertyText withText:generatedSubject maxHeight:90];
			cell.propertyText.text = generatedSubject;
			;
			////////NSLog(@"Created cell %@", [cells objectForKey:@"subject"]);
		*/
		}
		/*
		 {
		 NSString* cellIdentifier = @"Body";
		 SettingsCell_TextEntry* cell;
		 cell = [[[SettingsCell_TextEntry alloc] initWithFrame:CGRectZero reuseIdentifier:cellIdentifier] autorelease];
		 cell.label.text = @"Body";
		 cell.propertyText.keyboardType = UIKeyboardTypeDefault;
		 [cells setObject:cell forKey:cellIdentifier];
		 ////////NSLog(@"Created cell %@", [cells objectForKey:@"Body"]);
		 }
		 */
	
}


-(void) success:(id)sender
{
	[loading stopAnimating];
	UIAlertView* messageSent = [[UIAlertView alloc] initWithTitle: @"Message Sent"
														  message: @"Your report has been sent." 
														 delegate:self
												cancelButtonTitle:nil 
												otherButtonTitles:@"OK",nil];
	
	
	messageSent.delegate = self;
	[messageSent show];
	////////NSLog(@"onSend successful!");
}

-(void) failure:(NSString*)sender
{
	[loading stopAnimating];
	UIAlertView* messageSendFailed = [[UIAlertView alloc] initWithTitle: @"Message Send Failed"
																message: sender 
															   delegate:self
													  cancelButtonTitle:nil 
													  otherButtonTitles:@"OK",nil];
	
	messageSendFailed.delegate = self;
	[messageSendFailed show];
	////////NSLog(@"onSend failure :( .");
	
}


-(NSInteger)tableView:(UITableView*)tableView numberOfRowsInSection:(NSInteger)section
{
	return 1;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	
	if(indexPath.section == 0)
	{
		if(indexPath.row == 0) return [cells objectForKey:@"subject"];
	}
	return nil;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
	if(indexPath.section == 0)
	{
		return 90;
	}
}
@end
