//
//  UserGeoData.h
//  Qwiket
//
//  Created by Bryce Buchanan on 10/14/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UserGeoData : NSObject {
	float latitude;
	float longitude;
	NSString* userName;
	float geoDistance;
}

-(id) initWith:(NSString*)aUserName aLatitude:(NSString*)aLatitude aLongitude:(NSString*)aLongitude aGeoDistance:(NSString*)aGeoDistance;

@property(readonly) float latitude;
@property(readonly) float longitude;
@property(readonly) NSString* userName;
@property(readonly) float geoDistance;
@end
