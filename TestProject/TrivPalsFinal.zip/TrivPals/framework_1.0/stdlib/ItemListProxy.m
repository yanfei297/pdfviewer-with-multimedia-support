//
//  ItemListProxy.m
//  EyeReport
//
//  Create by Andrew Paul Simmons Simmons on 11/5/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "ItemListProxy.h"

#define DEFUALT_MAX_FEED_LENGTH 100

//:: static
NSMutableDictionary* itemListsCache;


@implementation ItemListProxy
@synthesize delegate;

- (id) init
{
	[super init];
	
	if(!itemListsCache)
	{
		itemListsCache = [[NSMutableDictionary dictionaryWithCapacity:8] retain]; 
	}
	
	return self;
}

- (void) requestItemListForTag:(NSString*)tag 
{
	[self requestItemListForTag:tag maxLength:DEFUALT_MAX_FEED_LENGTH];
}

- (void) requestItemListForTag:(NSString*)tag maxLength:(int)length
{
	
	if(loadInProgress)
	{
		[requester cancel];
	}
	loadInProgress = YES;
	
	NSArray* cachedItemsOrNil = [itemListsCache objectForKey:tag];
	if(cachedItemsOrNil)
	{
		[self onLoadItemsForTag:tag contentItems:cachedItemsOrNil];
	}
	else
	{
		requester = [APIBinding tagsGetListContentForTag:tag
											pageSize:length
									  responseTarget:self
										  success_cb:@selector(onLoadItemsForTag:contentItems:)
										  failure_cb:@selector(onLoadItemsFailureForTag:failureMessage:)];
	}
}

- (void) onLoadItemsForTag:(NSString*)tag contentItems:(NSArray*)contentItems
{
	loadInProgress = false;
	/*
	 if( ![tag isEqualToString:lastTagRequested] )
	 {
	 ////////NSLog(@"ERROR: Last tag requested %@ tag loaded %@", tag);
	 return;
	 }
	 */
	
	
	if(tag)[itemListsCache setObject:contentItems forKey:tag];
	[delegate didGetItemList:contentItems];
	
	//////////NSLog(@"Got %d ContentItems for tag %@", [contentItems count], tag);
}



- (void) onLoadItemsFailureForTag:(NSString*)tag failureMessage:(NSString*)failureMessage
{
	loadInProgress = false;
	NSArray* possiblePreviouslyLoadedItemList = [itemListsCache objectForKey:tag];
	if(possiblePreviouslyLoadedItemList)
	{
		[delegate didGetItemList:possiblePreviouslyLoadedItemList];
		////////NSLog(@"didGetItemList from previus load");
	}
	else
	{
		if([delegate respondsToSelector:@selector(cannotGetItemList:)])
		{
			[delegate cannotGetItemList:failureMessage];
			////////NSLog(@"invoked selector [cannotGetItemList:] on delegate [%@] ", delegate);
		}
		else
		{
			////////NSLog(@"delegate [%@] does not respond to selector [cannotGetItemList:]",delegate);
		}
	}
	
}




- (void) requestItemListForChannel:(NSString*)channel
{
	[self requestItemListForChannel:channel maxLength:100];
}

- (void) requestItemListForChannel:(NSString*)channel maxLength:(int)length
{
	if(loadInProgress)
	{
		[requester cancel];
	}
	
	loadInProgress = YES;

	NSArray* cachedItemsOrNil = [itemListsCache objectForKey:channel];
	
	if(cachedItemsOrNil)
	{
		[self onLoadItemsForChannel:channel contentItems:cachedItemsOrNil];
	}
	else
	{
		requester = [APIBinding channelGetListContentForUsername:channel
													   authToken:APP_USER_TOKEN
														pageSize:length
												  responseTarget:self
													  success_cb:@selector(onLoadItemsForChannel:contentItems:)
													  failure_cb:@selector(onLoadItemsFailureForChannel:failureMessage:)];
	}
}



- (void) onLoadItemsForChannel:(NSString*)channel contentItems:(NSArray*)contentItems
{
	loadInProgress = false;
	
	if(channel)[itemListsCache setObject:contentItems forKey:channel];
	[delegate didGetItemList:contentItems];
	
	//////////NSLog(@"Got %d ContentItems for tag %@", [contentItems count], tag);
}



- (void) onLoadItemsFailureForChannel:(NSString*)channel failureMessage:(NSString*)failureMessage
{
	loadInProgress = false;
	NSArray* possiblePreviouslyLoadedItemList = [itemListsCache objectForKey:channel];
	if(possiblePreviouslyLoadedItemList)
	{
		[delegate didGetItemList:possiblePreviouslyLoadedItemList];
	}
	else
	{
		if([delegate respondsToSelector:@selector(cannotGetItemList:)])
		{
			[delegate cannotGetItemList:failureMessage];
		}
	}
	////////NSLog(@"Could not load content items");
}








- (void) requestItemListForExploreFeed:(NSString*)exploreType
{
	if(loadInProgress)
	{
		[requester cancel];
	}
	
	loadInProgress = true;
	requester = [APIBinding exploreGetMostRecentWithPageSize:DEFUALT_MAX_FEED_LENGTH
									  responseTarget:self
										  success_cb:@selector(onLoadItemsForTag:contentItems:)
										  failure_cb:@selector(onLoadItemsFailureForTag:failureMessage:)];
}


	
	
@end
