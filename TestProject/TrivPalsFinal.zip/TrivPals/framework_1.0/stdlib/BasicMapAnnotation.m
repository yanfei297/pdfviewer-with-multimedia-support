//
//  untitled.m
//  Qwiket
//
//  Create by Andrew Paul Simmons on 6/19/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import "BasicMapAnnotation.h"

@implementation BasicMapAnnotation

@synthesize coordinate;

- (id) initWithCoordinate:(CLLocationCoordinate2D)coords title:(NSString*)_title subtitle:(NSString*)_subtitle
{
	if(self = [super init])
	{
		coordinate = coords;
		title = [_title copy];
		subtitle = [_subtitle copy];
	}
	return self;
}

- (NSString *)title
{
	return title;
}

- (NSString *)subtitle
{
	return subtitle;
}


- (void)dealloc 
{
	[title release];
	[subtitle release];
    [super dealloc];
}

@end
