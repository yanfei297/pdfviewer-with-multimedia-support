//
//  WebActionHandler.m
//  EyeReport
//
//  Create by Andrew Paul Simmons on 10/17/08.
//  Copyright 2008 Treemo Labs. All rights reserved.
//

#import "WebActionHandler.h"


@implementation WebActionHandler
@synthesize lastExteranalURL;
/*
 // Override initWithNibName:bundle: to load the view using a nib file then perform additional customization that is not appropriate for viewDidLoad.
 - (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
 if (self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil]) {
 // Custom initialization
 }
 return self;
 }
 */
//UIWebView
/*
 // Implement loadView to create a view hierarchy programmatically.
 - (void)loadView {
 }
 */

/*
 // Implement viewDidLoad to do additional setup after loading the view.
 - (void)viewDidLoad {
 [super viewDidLoad];
 }
 */
- (UIViewController*) restoreViewState
{
	[super restoreViewState];
	return self;
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request 
 navigationType:(UIWebViewNavigationType)navigationType
{
	
	NSString* url = [[request URL] absoluteString];
	////NSLog(@"Will start load %@ link domain is %@",url, LINK_DOMAIN );
	//////NSLog(@"Think about startin load %@", url);
	if(!supressLaunchExternal && !([LINK_DOMAIN isEqualToString:[[request URL] host]] || [url isEqualToString:@"about:blank"])) 
	{	
		[lastExteranalURL release];
		lastExteranalURL = [[request URL] retain];
		BOOL launchInSafari = [self shouldLaunchExternalInSafari:url];
		if(launchInSafari)
		{
			return NO;
		}
		
	}
	
	NSArray* url_prsary = [url componentsSeparatedByString:@"__EXTERNAL_"];
	//////NSLog(@"Parse array: %@", url_prsary);
	if([url_prsary count] < 2) 
	{
		
		return YES;
	}
	else
	{
		NSArray* method_prsary = [[url_prsary objectAtIndex:1] componentsSeparatedByString:@"__PARAM__"];
		NSString* method_str = [method_prsary objectAtIndex:0];	
		SEL method_sel = NSSelectorFromString(method_str);
		if([self respondsToSelector:method_sel])
		{
			int numParams = [method_prsary count] - 1;
			//////NSLog(@"Will respond to method: %@ using %i params", method_str, numParams);
			
			if(numParams == 0)
			{
				[self performSelector:method_sel];
			}
			else if(numParams > 0)
			{
				NSString* paramOne = [method_prsary objectAtIndex:1]; 
				paramOne = [paramOne stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
				
				if(numParams == 1)
				{
					[self performSelector:method_sel withObject:paramOne];
				}
				else if(numParams == 2)
				{
					
					NSString* paramTwo = [method_prsary objectAtIndex:2]; 
					paramTwo = [paramTwo stringByReplacingPercentEscapesUsingEncoding:NSASCIIStringEncoding];
					////////NSLog(@"Performing method invokation with paramOne:%@  paramTwo:%@", paramOne, paramTwo);
					[self performSelector:method_sel withObject:paramOne withObject:paramTwo];
				}
			}
		}
		return NO;
	}
}

- (BOOL) shouldLaunchExternalInSafari:(NSString*)urlString
{
	exitAndLaunchSafari_av = [[UIAlertView alloc] initWithTitle:@"Exit and Launch Browser?"
													 message:@"Do you wish to exit this application and launch your web browser?"
													delegate:self
										   cancelButtonTitle:@"Cancel"
										   otherButtonTitles:@"Go", nil];
	[self retain];
	[exitAndLaunchSafari_av show];
	
	return YES;
}



- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
	int noInternetConnectionErrorCode = -0x3F1;

		if([error code] ==  noInternetConnectionErrorCode)
		{
			loadFailure_av = [[UIAlertView alloc] initWithTitle:@"No Internet connection."
															 message:nil
															delegate:self
												   cancelButtonTitle:@"Cancel"
												   otherButtonTitles:@"Reload", nil];
			[self retain];
			[loadFailure_av show];
		}
		
		else if(!supressNonConnectionFailureErrorAlerts)
		{
		/*
		loadFailure_av = [[[UIAlertView alloc] initWithTitle:@"Load Error"
													 message:nil
													delegate:self
										   cancelButtonTitle:@"Cancel"
										   otherButtonTitles:@"Reload", nil] autorelease];
		[self retain];
		[loadFailure_av show];
		 */
		 
	
	}
	////////NSLog(@"Failed Load with error %@", error);	
}

- (void) retryLoadAfterFailure
{
	//override this method
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
	//[super alertView:alertView clickedButtonAtIndex:buttonIndex];
	if([alertView.title compare:@"Error Loading Page"] != 0)
	{
	if(alertView == exitAndLaunchSafari_av)
	{
		if(buttonIndex == 0) 
		{
			// cancel
		}
		else
		{
			[[UIApplication sharedApplication] openURL:lastExteranalURL];
			//goto upload page
		}
	}
	else if(alertView == loadFailure_av)
	{
		if(buttonIndex == 0) 
		{
			////////NSLog(@"NOT!!! reloading after failure");
			// cancel
		}
		else
		{
			////////NSLog(@"Reloading after failure");
			[self retryLoadAfterFailure];
			//goto upload page
		}
	}
		
	}
	[alertView release];
	[self release];
}


- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning]; // Releases the view if it doesn't have a superview
    // Release anything that's not essential, such as cached data
		////////NSLog(@"WebActionHandler did recieve memeory warning.");
}


- (void)dealloc {
    [super dealloc];
}


@end
