//
//  SafeArray.h
//  Andrew_CBSNews
//
//  Create by Andrew Paul Simmons on 3/11/10.
//  Copyright 2010 Treemo Labs All rights reserved.
//

#import <Foundation/Foundation.h>
#import "SafeDictionary.h"
@class SafeDictionary;

@interface SafeArray : NSObject 
{
	NSMutableArray* mutableArray;
	NSArray* _innerArray;
}

@property(readonly) NSMutableArray* mutableArray;

+ (SafeArray*) safeArrayWithArray:(NSArray*)anArray;

- (id)initWithArray:(NSArray*)anArray;
- (void)addObject:(id)anObject;


//  will not throw out of range exceptions & will not return nil but instead @""
- (NSString*)stringAtIndex:(NSUInteger)index;

// will not throw out of range exceptions 
- (SafeArray*)safeArrayAtIndex:(NSUInteger)index;

// will not throw out of range exceptions 
- (SafeDictionary*)safeDictionaryAtIndex:(NSUInteger)index;

// will not throw out of range exception
- (void) removeObjectAtIndex:(NSUInteger)index; 

- (NSUInteger)count;

@end
