//
//  Qwiket_APIBinding.h
//  Qwiket
//
//  Create by Andrew Paul Simmons on 7/27/09.
//  Copyright 2009 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "APIBinding.h"
#import "WebXML.h"
@interface ApplicationAPIBinding : APIBinding
{
	
}


//This is to add a level of abstraction from the APIBinding.
+ (Requester*) makeGetAppRequestWithURL:(NSString*)url
							  forAction:(NSString*)action
							  paramters:(NSMutableDictionary*)vars 
						responseHandler:(SEL)rh 
						 failureHandler:(SEL)fh 
								 target:(id)target
							 success_cb:(SEL)success
							 failure_cb:(SEL)failure
								  extra:extraOrNil;


+ (Requester*) bitlyShortenURLRequest:(NSString*)longURL
					   responseTarget:(id)target
						   success_cb:(SEL)success
						   failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadListForMultipleCategory:(NSString*)category
								   multipleVideo:(NSString*)video
									  pageNumber:(int)pageNumber
								  responseTarget:(id)target
									  success_cb:(SEL)success
									  failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadVideoListForCategory:(NSString*)category
								   pageNumber:(int)pageNumber
										 wifi:(BOOL)wifi
									  popular:(BOOL)popular
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadStoryForID:(NSString*)storyID
						  storyType:(NSString*)storyType
					 responseTarget:(id)target
						 success_cb:(SEL)success
						 failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadVideoDetailsForID:(NSString*)videoID
								 videoType:(NSString*)videoType
							responseTarget:(id)target
								success_cb:(SEL)success
								failure_cb:(SEL)failure;


+ (Requester*) getXMLAccuWeather_loadWeatherFromLat:(NSString*)latitude
											andLong:(NSString*)longitude
									 responseTarget:(id)target
										 success_cb:(SEL)success
										 failure_cb:(SEL)failure;

+ (Requester*) AccuWeather_loadCityNameFromZipcode:(NSString*)zipcode
									responseTarget:(id)target
										success_cb:(SEL)success
										failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadCombinedListForCategory:(NSString*)category
											wifi:(BOOL)wifi
								  responseTarget:(id)target
									  success_cb:(SEL)success
									  failure_cb:(SEL)failure;
+ (Requester*) Jiffy_loadCombinedListForCategory:(NSString*)category
											wifi:(BOOL)wifi
										 popular:(BOOL)popular
								  responseTarget:(id)target
									  success_cb:(SEL)success
									  failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadListForCategory:(NSString*)category
							  pageNumber:(int)pageNumber
						  responseTarget:(id)target
							  success_cb:(SEL)success
							  failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadVideoListForCategory:(NSString*)category
								   pageNumber:(int)pageNumber
										 wifi:(BOOL)wifi
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure;


+ (Requester*) Jiffy_loadTwitterListForSearch:(NSString*)search
							   responseTarget:(id)target
								   success_cb:(SEL)success
								   failure_cb:(SEL)failure;

+ (Requester*) Jiffy_loadTwitterListForCategory:(NSString*)category
								 responseTarget:(id)target
									 success_cb:(SEL)success
									 failure_cb:(SEL)failure;

+ (Requester*) getXMLForStockFeed:(NSString*)stockList
				   responseTarget:(id)target
					   success_cb:(SEL)success
					   failure_cb:(SEL)failure;


/// APIs for NewsLists:
+ (Requester*) getJSONforImageList:(NSString*)searchCriteria
						pageNumber:(NSString*)page
					responseTarget:(id)target
						success_cb:(SEL)success
						failure_cb:(SEL)failure;

@end
