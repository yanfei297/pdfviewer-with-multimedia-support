//
//  CommentsList.h
//  RealWeatherGirls
//
//  Created by Sumit Kr Prasad on 03/08/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CommentsList : NSObject 
{
	int totalItems;
	int totalPages;
	int pageSize;
	int pageNumber;
	
	NSMutableArray *comments;
	
}
@property (assign) int totalItems;
@property (assign) int totalPages;
@property (assign) int pageSize;
@property (assign) int pageNumber;

@property (readonly) NSMutableArray *comments;
- (id) objectAtIndex:(NSUInteger)index;
- (void) removeObjectAtIndext:(NSUInteger)index;
- (void)addObject:(NSObject*) anObject;
- (NSUInteger) count;
@end
