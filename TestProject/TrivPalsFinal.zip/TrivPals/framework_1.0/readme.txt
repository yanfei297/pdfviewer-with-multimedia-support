Required Framework :\
\
 1. AudioToolbox\
\
2. AVFoundation\
\
3. AddressBook\
\
4. CoreMedia\
\
5. CoreData (N/A)\
\
6. CoreGraphics (N/A)\
\
7. CoreLocation\
\
8. CFNetwork\
\
9. CoreAudio\
\
10. CoreTelephony\
\
11. Core Video\
\
12. Foundation (N/A)\
\
13. libsqlite3.0\
\
14. libxml2\
\
15.  libz\
\
16. MobileCoreServices\
\
17. MediaPlayer\
\
18. MapKit\
\
19. MessageUI\
\
20. OpenGLES\
\
21. OpenAL\
\
22. QuartzCore\
\
23. SystemConfiguration\
\
24. Security\
\
25. StoreKit\
\
26. UIKit (N/A)\
\
27. libcommonCrypto\
