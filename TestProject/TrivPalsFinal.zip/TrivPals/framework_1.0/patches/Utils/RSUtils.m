//
//  RSUtils.m
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 04/10/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import "RSUtils.h"


@implementation RSUtils
+(UIButton *)createRoundedButtonWithFrame:(CGRect)frame 
								    title:(NSString *)title
								   target:(id)target
								   action:(SEL)action
{
	UIButton *btn=[UIButton buttonWithType:UIButtonTypeRoundedRect];
	btn.frame=frame;
	[btn setTitle:title forState:UIControlStateNormal];
	[btn setHighlighted:NO];
	btn.showsTouchWhenHighlighted=NO;
	[btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
	return btn;
}

+(NSString *)podcastDir {
    NSArray  *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    path = [NSString stringWithFormat:@"%@/podcasts", path];
    
    [[NSFileManager defaultManager] createDirectoryAtPath:path
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    
    return path;
}

+(NSString*)finishedDownloadsFile {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    
    [[NSFileManager defaultManager] createDirectoryAtPath:path
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    
    path = [NSString stringWithFormat:@"%@/finished.dat",path];
    return path;
}

+(NSString*)failedDownloadsFile {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    
    [[NSFileManager defaultManager] createDirectoryAtPath:path
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    
    path = [NSString stringWithFormat:@"%@/failed.dat",path];
    return path;
}

+(NSString*)pausedDownloadsFile {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    
    [[NSFileManager defaultManager] createDirectoryAtPath:path
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    
    path = [NSString stringWithFormat:@"%@/paused.dat",path];
    return path;
}
    
+(NSString*)notificationsFile {
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSApplicationSupportDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    
    [[NSFileManager defaultManager] createDirectoryAtPath:path
                              withIntermediateDirectories:YES
                                               attributes:nil
                                                    error:NULL];
    
    path = [NSString stringWithFormat:@"%@/notifications.dat",path];
    return path;
}

/*+(NSString *)timeInMin:(NSString *)strTime
{
	int time=[strTime intValue];
	NSString *strCalculatedTime=@"";
	if(time<=0)
	{
		strCalculatedTime=@"0sec";
	}
	else 
	{
		if(time>=3600)
		{
			int hour=time/3600;
			time=time % 3600;
			if(hour>1)
			{
				strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dhrs", hour]];
			}
			else {
				strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dhr", hour]];
			}
			
			
		}
		if(time<3600 && time>=60)
		{
			int min=time/60;
			time=time%60;
			strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dmin",min]];
		}
		if(time<60 && time>0)
		{
			
			strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dsec",time]];
		}
	}
	return strCalculatedTime;
}*/

+(NSString *)timeInMin:(NSString *)strTime
{
	int time=[strTime intValue];
	NSString *strCalculatedTime=@"";
	if(time<=0)
	{
		strCalculatedTime=@"0sec";
	}
	else 
	{
		if(time<3600 && time>=60)
		{
			int min=time/60;
			strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dmin",min]];
		}
		else if(time<60 && time>0)
		{
			
			strCalculatedTime=[strCalculatedTime stringByAppendingString:[NSString stringWithFormat:@" %dsec",time]];
		}
	}
	return strCalculatedTime;
}

+(NSString *)timeInMinuteSecondFormat:(NSString *)strTime
{
	int time=[strTime intValue];;
	NSString *strCalculatedTime=@"";
	if(time<=0)
	{
		strCalculatedTime=@"00:00";
	}
	else 
	{
        //Get the minutes
        int minutes = time/60;
        int seconds = time - (minutes * 60);
        
        strCalculatedTime = [NSString stringWithFormat:@"%02i:%02i", minutes, seconds];
        /*
		if(time>=3600)
		{
			int hour=time/3600;
			time=time%3600;
			if(hour<10)
				strCalculatedTime=[strCalculatedTime stringByAppendingString:@"0"];
			strCalculatedTime=[strCalculatedTime stringByAppendingFormat:@"%d",hour];
			strCalculatedTime=[strCalculatedTime stringByAppendingString:@":"];
		}
		if(time<3600 && time>= 60)
		{
			int min=time/60;
			time=time%60;
			if(min<10)
				strCalculatedTime=[strCalculatedTime stringByAppendingString:@"0"];
			strCalculatedTime=[strCalculatedTime stringByAppendingFormat:@"%d",min];
			strCalculatedTime=[strCalculatedTime stringByAppendingString:@":"];
		}
		if(time<60 && time>0)
		{
			if(time<10)
				strCalculatedTime=[strCalculatedTime stringByAppendingString:@"0"];
			strCalculatedTime=[strCalculatedTime stringByAppendingFormat:@"%d",time];
		}
         */
	}
	
	return strCalculatedTime;
}
+(NSString *)fileSizeInMb:(NSString *)strSize
{
	float size=0;
	if([strSize floatValue]>0.0f)
	{
		size=[strSize floatValue];
		size=size/(1024.0f * 1024.0f);
	}
	NSString *strSizeinMb=[NSString stringWithFormat:@"%0.1fmb",size];
	return strSizeinMb;
}

+(UIColor *)addTracksCellBGColor {
    return [Utils colorFromHex:0xffffff];
}

+(UIImageView*)bottomAddTracksBar {
    static UIImageView *bar;
    
    if(!bar) {
        bar = [[Utils imageViewWithImageName:@"bottom-bar.png"] retain];
        bar.userInteractionEnabled = YES;
    }
    
    return bar;
}

+(UIImageView*)bottomBackToPlistBar {
    static UIImageView *bar;
    
    if(!bar) {
        bar = [[Utils imageViewWithImageName:@"bottom-bar.png"] retain];
        bar.userInteractionEnabled = YES;
    }
    
    return bar;
}

@end
