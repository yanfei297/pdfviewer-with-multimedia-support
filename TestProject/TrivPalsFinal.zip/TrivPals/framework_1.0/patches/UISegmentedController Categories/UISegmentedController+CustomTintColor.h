//
//  UISegmentedController+CustomTintColor.h
//  BigGameRegs
//
//  Created by Sayan on 18/02/11.
//  Copyright 2011 Sportsmanregs LLC. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface UISegmentedController_CustomTintColor : NSObject {

}

@end


@interface UISegmentedControl(CustomTintExtension)

-(void)setTag:(NSInteger)tag forSegmentAtIndex:(NSUInteger)segment;
-(void)setTintColor:(UIColor*)color forTag:(NSInteger)aTag;
-(void)setTextColor:(UIColor*)color forTag:(NSInteger)aTag;
-(void)setShadowColor:(UIColor*)color forTag:(NSInteger)aTag;
-(void)setFont:(UIFont *)textFont forTag:(NSInteger)aTag;

@end