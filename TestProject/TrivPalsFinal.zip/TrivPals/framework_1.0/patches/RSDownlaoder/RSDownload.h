//
//  RSDownload.h
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/5/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RSDownloadFailedNotification @"RSDownloadFailedNotification"
#define RSDownloadCompleteNotification @"RSDownloadCompleteNotification"
#define RSDownloadPausedNotification @"RSDownloadPausedNotification"
#define RSDownloadCancelledNotification @"RSDownloadCancelledNotification"
#define RSDownloadRestartNotification @"RSDownloadRestartNotification"
#define RSDownloadConnectionInterruptedNotifiaction @"RSDownloadConnectionInterruptedNotifiaction"
#define RSDownloadConnectionRestoredNotification @"RSDownloadConnectionRestoredNotification"
#define RSDownloadPodCastUpdatedNotification @"RSDownloadPodCastUpdatedNotification"
@class RSProgressBar;

@interface RSDownload : NSObject <NSCoding> {
    NSFileHandle *fileHandle;
    NSURLConnection *conn;
    
    //Properties
    //int size;
    //NSString *url;
    //NSString *saveDir;
    UIProgressView *progressBar;
    UILabel *progressValue;
    //NSString *filename;
    //NSString *title;
    //NSString *ID;
    //NSString *filepath;
    //int64_t startByte;
}

@property(nonatomic, readonly) int size;
@property(nonatomic, copy) NSString *url;
@property(nonatomic, copy) NSString *saveDir;
@property(nonatomic, retain) UIProgressView *progressBar;
@property(nonatomic, retain) UILabel *progressValue;
@property(nonatomic, copy) NSString *filename;
@property(nonatomic, copy) NSString *title;
@property(nonatomic, copy) NSString *ID;
@property(nonatomic, readonly, copy) NSString *filepath;
@property(nonatomic, readonly) int64_t bytesDownloaded;
@property(nonatomic, readwrite) BOOL played;
@property(nonatomic, copy) NSString *playDuration;

//Queue the download onto the download manager
-(void)enqueue;

//Cancel the download and delete any of its stored data
-(void)destroy;

//Pause the download, keeping any stored data
-(void)pause;

//Resume the download, putting it back on the download queue
-(void)resume;

//Restart the download from the beginning... this is done if a download has failed. If the download
//has not failed, the download is just queued like normal
-(void)restart;

//Download Item Desciption
-(NSString *)description;
//Grab a download from the manager by url or create it if not present.
//Please use this method instead of an init method
+(RSDownload*)downloadForID:(NSString*)_ID;

//Returns a list of all the downloads queued up to download
+(NSArray*)allQueuedDownloads;

/*
//Return Download Items Values
-(NSString *)title;

-(NSString *)saveDir;

-(NSString *)url;

-(NSString *)filename;

-(NSString *)ID;
 */

@end