//
//  RSDownloadedFilesPicker.m
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 07/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RSDownloadedFilesPicker.h"
#import "RSUtils.h"
#import "SafeDictionary.h"
NSMutableArray *downloadedFiles;
@implementation RSDownloadedFilesPicker
+(NSMutableArray *)downloadedFiles
{
	NSString *filedir = [NSString stringWithFormat:@"%@", [RSUtils podcastDir]];
    
    //Create a directory if it doesn't already exist
	downloadedFiles=[[NSMutableArray alloc] init];
    NSError *read_error;
    //BOOL writeSuccess = [receivedData writeToFile:filepath options:NSDataWritingAtomic error:&write_error];
    NSArray *arrDirectories=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:filedir error:&read_error];
	NSLog(@"files: %@",arrDirectories);
	for(int i=0;i<[arrDirectories count];i++)
	{
		NSString *directoryName=(NSString *)[arrDirectories objectAtIndex:i];
		NSMutableDictionary *audioFilesDir=[[NSMutableDictionary alloc] init];
		[audioFilesDir setObject:directoryName forKey:@"root"];
		NSString *directoryPath= [NSString stringWithFormat:@"%@/%@", [RSUtils podcastDir],directoryName];
		NSArray *arrFiles=[[NSFileManager defaultManager] contentsOfDirectoryAtPath:directoryPath error:&read_error];
		SafeArray *files=[[SafeArray alloc] initWithArray:arrFiles];
		[audioFilesDir setObject:files forKey:@"audioFiles"];
		SafeDictionary *dataDict=[[SafeDictionary alloc] initWithDictionary:audioFilesDir];
		[audioFilesDir release];
		[downloadedFiles addObject:dataDict];
		[files release];
		[dataDict release];
	}
	return downloadedFiles;
}
@end
