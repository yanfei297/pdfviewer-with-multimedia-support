//
//  RSDownloader.h
//  RickSteves_AudioEurope
//
//  Created by Paul Neiland on 10/5/10.
//  Copyright 2010 Treemo Labs. All rights reserved.
//

#import <Foundation/Foundation.h>

#define RSDMNetworkConnectionAvailableNotification @"RSDMNetworkConnectionAvailableNotification"

@class RSDownload;
@class RSDloadDirectoryData;
@interface RSDownloadManager : NSObject {
}

+(RSDownload *)itemCurrentlyDownloading;

+(NSArray*)allPausedDownloads;

+(NSArray*)allCompleteDownloads;

+(NSArray*)allQueuedDownloads;

+(NSArray *)allFailedDownloads;

+(void)restartDownload:(RSDownload*)dload;

+(NSArray *)allDownloadedDirectories;

+(RSDloadDirectoryData *)downloadsForDirectory:(NSString *)directoryName;

+(NSArray *)allDownloadingDirectory;

+(RSDloadDirectoryData *)downloadingForDirectory:(NSString *)directoryName;

+(NSArray *)allPausedDirectories;

+(RSDloadDirectoryData *)pausedForDirectory:(NSString *)directoryName;

+(RSDloadDirectoryData *)anyDownloadForDirectory:(NSString *)directory;

+(NSArray *)allFailedDirectories;

+(RSDloadDirectoryData *)failedForDirectory:(NSString *)directoryName;

+(void)pauseAllDownloads;

+(NSArray *)everyDownload;

//Use these methods if you make changes to RSDownload properties and want the changes saved to file
+(void)writeFinishedDownloads;
+(void)writePausedDownlaods;

+(void)downloadFailed:(RSDownload*)dload;

+(void)writeFailedDownlaods;

+(NSArray *)allDownloads;;
@end
