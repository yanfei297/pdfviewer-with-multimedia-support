//
//  RSDloadDirectoryData.m
//  RickSteves_AudioEurope
//
//  Created by Sumit Kr Prasad on 19/10/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "RSDloadDirectoryData.h"


@implementation RSDloadDirectoryData
@synthesize directory;
@synthesize tracks;

-(id)init
{
	self=[super init];
	if(self==nil)
	{
		return nil;
	}
	//tracks=[[[[NSMutableArray alloc] init] retain] autorelease];
	tracks=[[NSMutableArray alloc] init] ;
	return self;
}

/*-(void)dealloc
{
	NSLog(@"rsDloadDirectoryData dealloc called");
	directory = nil;
	[tracks release];
	tracks=nil;
	[super dealloc];
}*/
@end
