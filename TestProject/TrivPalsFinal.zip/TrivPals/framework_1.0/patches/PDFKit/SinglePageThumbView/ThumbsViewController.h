//
//  PDFReaderbottomToolbar.m
//  SMBPDFKit
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//


#import <UIKit/UIKit.h>

#import "ThumbsMainToolbar.h"
#import "ReaderThumbsView.h"

@class ThumbsViewController;
@class PDFDocument;

@protocol ThumbsViewControllerDelegate <NSObject>

@required // Delegate protocols

- (void)thumbsViewController:(ThumbsViewController *)viewController gotoPage:(NSInteger)page;

- (void)dismissThumbsViewController:(ThumbsViewController *)viewController;

@end

@interface ThumbsViewController : UIViewController <ThumbsMainToolbarDelegate, ReaderThumbsViewDelegate>
{
@private // Instance variables

	PDFDocument *document;

	ThumbsMainToolbar *mainToolbar;

	ReaderThumbsView *theThumbsView;

	NSMutableArray *bookmarked;

	BOOL updateBookmarked;

	CGPoint thumbsOffset;
	CGPoint markedOffset;

	BOOL showBookmarked;
}

@property (nonatomic, assign, readwrite) id <ThumbsViewControllerDelegate> delegate;

- (id)initWithPDFDocument:(PDFDocument *)object;

@end

#pragma mark -

//
//	ThumbsPageThumb class interface
//

@interface ThumbsPageThumb : ReaderThumbView
{
@private // Instance variables

	UIView *backView;

	UILabel *textLabel;

	UIImageView *bookMark;

	CGSize maximumSize;

	CGRect defaultRect;
}

- (CGSize)maximumContentSize;

- (void)showText:(NSString *)text;

- (void)showBookmark:(BOOL)show;

@end
