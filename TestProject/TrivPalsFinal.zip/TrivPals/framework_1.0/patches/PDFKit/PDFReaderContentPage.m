//
//  PDFReaderContentPage.m
//  TestPDF
//
//  Created by SMB on 10/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PDFReaderContentPage.h"
#import "PDFReaderContentTile.h"
#import "CGPDFDocument.h"
#import <MediaPlayer/MediaPlayer.h>
#import "PDFReaderConfig.h"
#import "SMBMediaPlayer.h"

@implementation PDFReaderContentPage
@synthesize delegate;

#pragma mark PDFReaderContentPage class methods

+ (Class)layerClass
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	return [PDFReaderContentTile class];
}

#pragma mark PDFReaderContentPage PDF link methods
//SMB: Changed from void to CGRect
- (CGRect)highlightPageLinks
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	CGRect rect = CGRectNull; //SMB: new added
	
	if (_links.count > 0) // Add highlight views over all links
	{
		
		for (PDFReaderDocumentLink *link in _links) // Enumerate the links array
		{
			rect = link.rect;
			[self parseLinksAndDrawContents:[self findLinkTarget:link.dictionary] withRect:link.rect];
			
		}
	}
	return rect;
}

- (PDFReaderDocumentLink *)linkFromAnnotation:(CGPDFDictionaryRef)annotationDictionary
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	PDFReaderDocumentLink *documentLink = nil; // Document link object
	
	CGPDFArrayRef annotationRectArray = NULL; // Annotation co-ordinates array
	
	if (CGPDFDictionaryGetArray(annotationDictionary, "Rect", &annotationRectArray))
	{
		CGPDFReal ll_x = 0.0f; CGPDFReal ll_y = 0.0f; // PDFRect lower-left X and Y
		CGPDFReal ur_x = 0.0f; CGPDFReal ur_y = 0.0f; // PDFRect upper-right X and Y
		
		CGPDFArrayGetNumber(annotationRectArray, 0, &ll_x); // Lower-left X co-ordinate
		CGPDFArrayGetNumber(annotationRectArray, 1, &ll_y); // Lower-left Y co-ordinate
		
		CGPDFArrayGetNumber(annotationRectArray, 2, &ur_x); // Upper-right X co-ordinate
		CGPDFArrayGetNumber(annotationRectArray, 3, &ur_y); // Upper-right Y co-ordinate
		
		if (ll_x > ur_x) { CGPDFReal t = ll_x; ll_x = ur_x; ur_x = t; } // Normalize Xs
		if (ll_y > ur_y) { CGPDFReal t = ll_y; ll_y = ur_y; ur_y = t; } // Normalize Ys
		
		switch (_pageAngle) // Page rotation angle (in degrees)
		{
			case 90: // 90 degree page rotation
			{
				CGPDFReal swap;
				swap = ll_y; ll_y = ll_x; ll_x = swap;
				swap = ur_y; ur_y = ur_x; ur_x = swap;
				break;
			}
				
			case 270: // 270 degree page rotation
			{
				CGPDFReal swap;
				swap = ll_y; ll_y = ll_x; ll_x = swap;
				swap = ur_y; ur_y = ur_x; ur_x = swap;
				ll_x = ((0.0f - ll_x) + _pageSize.width);
				ur_x = ((0.0f - ur_x) + _pageSize.width);
				break;
			}
				
			case 0: // 0 degree page rotation
			{
				ll_y = ((0.0f - ll_y) + _pageSize.height);
				ur_y = ((0.0f - ur_y) + _pageSize.height);
				break;
			}
		}
		
		NSInteger vr_x = ll_x; NSInteger vr_w = (ur_x - ll_x); // Integer X and width
		NSInteger vr_y = ll_y; NSInteger vr_h = (ur_y - ll_y); // Integer Y and height
		
		CGRect viewRect = CGRectMake(vr_x, vr_y, vr_w, vr_h); // View CGRect from PDFRect
		
		documentLink = [PDFReaderDocumentLink withRect:viewRect dictionary:annotationDictionary];
	}
	
	return documentLink;
}

- (void)buildAnnotationLinksList
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	_links = [NSMutableArray new]; // Links list array
	
	CGPDFArrayRef pageAnnotations = NULL; // Page annotations array
	
	CGPDFDictionaryRef pageDictionary = CGPDFPageGetDictionary(_PDFPageRef);
	
	if (CGPDFDictionaryGetArray(pageDictionary, "Annots", &pageAnnotations) == true)
	{
		NSInteger count = CGPDFArrayGetCount(pageAnnotations); // Number of annotations
		NSLog(@"no of Annots:%d",count);
		for (NSInteger index = 0; index < count; index++) // Iterate through all annotations
		{
			CGPDFDictionaryRef annotationDictionary = NULL; // PDF annotation dictionary
			
			if (CGPDFArrayGetDictionary(pageAnnotations, index, &annotationDictionary) == true)
			{
				const char *annotationSubtype = NULL; // PDF annotation subtype string
				
				if (CGPDFDictionaryGetName(annotationDictionary, "Subtype", &annotationSubtype) == true)
				{
					NSLog(@"subtype:%s",annotationSubtype);
					if (strcmp(annotationSubtype, "Link") == 0) // Found annotation subtype of 'Link'
					{
						PDFReaderDocumentLink *documentLink = [self linkFromAnnotation:annotationDictionary];
						
						if (documentLink != nil) [_links insertObject:documentLink atIndex:0]; // Add link
						
					}
				}
			}
		}
		//TODO
		[self highlightPageLinks]; // For link support debugging
	}
}

- (CGPDFArrayRef)findDestinationWithName:(const char *)destinationName inDestsTree:(CGPDFDictionaryRef)node
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	CGPDFArrayRef destinationArray = NULL;
	
	CGPDFArrayRef limitsArray = NULL; // Limits array
	
	if (CGPDFDictionaryGetArray(node, "Limits", &limitsArray) == true)
	{
		CGPDFStringRef lowerLimit = NULL; CGPDFStringRef upperLimit = NULL;
		
		if (CGPDFArrayGetString(limitsArray, 0, &lowerLimit) == true) // Lower limit
		{
			if (CGPDFArrayGetString(limitsArray, 1, &upperLimit) == true) // Upper limit
			{
				const char *ll = (const char *)CGPDFStringGetBytePtr(lowerLimit); // Lower string
				const char *ul = (const char *)CGPDFStringGetBytePtr(upperLimit); // Upper string
				
				if ((strcmp(destinationName, ll) < 0) || (strcmp(destinationName, ul) > 0))
				{
					return NULL; // Destination name is outside this node's limits
				}
			}
		}
	}
	
	CGPDFArrayRef namesArray = NULL; // Names array
	
	if (CGPDFDictionaryGetArray(node, "Names", &namesArray) == true)
	{
		NSInteger namesCount = CGPDFArrayGetCount(namesArray);
		
		for (NSInteger index = 0; index < namesCount; index += 2)
		{
			CGPDFStringRef destName; // Destination name string
			
			if (CGPDFArrayGetString(namesArray, index, &destName) == true)
			{
				const char *dn = (const char *)CGPDFStringGetBytePtr(destName);
				
				if (strcmp(dn, destinationName) == 0) // Found the destination name
				{
					if (CGPDFArrayGetArray(namesArray, (index + 1), &destinationArray) == false)
					{
						CGPDFDictionaryRef destinationDictionary = NULL; // Destination dictionary
						
						if (CGPDFArrayGetDictionary(namesArray, (index + 1), &destinationDictionary) == true)
						{
							CGPDFDictionaryGetArray(destinationDictionary, "D", &destinationArray);
						}
					}
					
					return destinationArray; // Return the destination array
				}
			}
		}
	}
	
	CGPDFArrayRef kidsArray = NULL; // Kids array
	
	if (CGPDFDictionaryGetArray(node, "Kids", &kidsArray) == true)
	{
		NSInteger kidsCount = CGPDFArrayGetCount(kidsArray);
		
		for (NSInteger index = 0; index < kidsCount; index++)
		{
			CGPDFDictionaryRef kidNode = NULL; // Kid node dictionary
			
			if (CGPDFArrayGetDictionary(kidsArray, index, &kidNode) == true) // Recurse into kid node
			{
				destinationArray = [self findDestinationWithName:destinationName inDestsTree:kidNode];
				
				if (destinationArray != NULL) return destinationArray; // Return the destination array
			}
		}
	}
	
	return NULL;
}

- (id)findLinkTarget:(CGPDFDictionaryRef)annotationDictionary
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	id linkTarget = nil; // Link target object
	
	CGPDFArrayRef destArray = NULL; CGPDFStringRef destName = NULL;
	
	CGPDFDictionaryRef actionDictionary = NULL; // Link action dictionary
	
	if (CGPDFDictionaryGetDictionary(annotationDictionary, "A", &actionDictionary) == true)
	{
		const char *actionType = NULL; // Annotation action type string
		
		if (CGPDFDictionaryGetName(actionDictionary, "S", &actionType) == true)
		{
			if (strcmp(actionType, "GoTo") == 0) // GoTo action type
			{
				if (CGPDFDictionaryGetArray(actionDictionary, "D", &destArray) == false)
				{
					CGPDFDictionaryGetString(actionDictionary, "D", &destName);
				}
			}
			else // Handle other link action type possibility
			{
				NSLog(@"actiontype:%s",actionType);
				if ((strcmp(actionType, "JavaScript") == 0)) {
					CGPDFStringRef uriString = NULL; // Action's URI string
					
					if (CGPDFDictionaryGetString(actionDictionary, "JS", &uriString) == true)
					{
						const char *uri = (const char *)CGPDFStringGetBytePtr(uriString); // Destination URI string
						
						linkTarget = [NSURL URLWithString:[NSString stringWithCString:uri encoding:NSASCIIStringEncoding]];
					}
				}
				
				if (strcmp(actionType, "URI") == 0) // URI action type
				{
					CGPDFStringRef uriString = NULL; // Action's URI string
					
					if (CGPDFDictionaryGetString(actionDictionary, "URI", &uriString) == true)
					{
						const char *uri = (const char *)CGPDFStringGetBytePtr(uriString); // Destination URI string
						//TODO
						linkTarget = [NSURL URLWithString:[NSString stringWithCString:uri encoding:NSASCIIStringEncoding]];
						
						//linkTarget = [NSURL URLWithString:[NSString stringWithCString:uri encoding:NSASCIIStringEncoding]];
					}
				}
			}
		}
	}
	else // Handle other link target possibility
	{
		if (CGPDFDictionaryGetArray(annotationDictionary, "Dest", &destArray) == false)
		{
			CGPDFDictionaryGetString(annotationDictionary, "Dest", &destName);
		}
	}
	
	if (destName != NULL) // Handle a destination name
	{
		CGPDFDictionaryRef catalogDictionary = CGPDFDocumentGetCatalog(_PDFDocRef);
		
		CGPDFDictionaryRef namesDictionary = NULL; // Destination names in the document
		
		if (CGPDFDictionaryGetDictionary(catalogDictionary, "Names", &namesDictionary) == true)
		{
			CGPDFDictionaryRef destsDictionary = NULL; // Document destinations dictionary
			
			if (CGPDFDictionaryGetDictionary(namesDictionary, "Dests", &destsDictionary) == true)
			{
				const char *destinationName = (const char *)CGPDFStringGetBytePtr(destName); // Name
				
				destArray = [self findDestinationWithName:destinationName inDestsTree:destsDictionary];
			}
		}
	}
	
	if (destArray != NULL) // Handle a destination array
	{
		NSInteger targetPageNumber = 0; // The target page number
		
		CGPDFDictionaryRef pageDictionaryFromDestArray = NULL; // Target reference
		
		if (CGPDFArrayGetDictionary(destArray, 0, &pageDictionaryFromDestArray) == true)
		{
			NSInteger pageCount = CGPDFDocumentGetNumberOfPages(_PDFDocRef);
			
			for (NSInteger pageNumber = 1; pageNumber <= pageCount; pageNumber++)
			{
				CGPDFPageRef pageRef = CGPDFDocumentGetPage(_PDFDocRef, pageNumber);
				
				CGPDFDictionaryRef pageDictionaryFromPage = CGPDFPageGetDictionary(pageRef);
				
				if (pageDictionaryFromPage == pageDictionaryFromDestArray) // Found it
				{
					targetPageNumber = pageNumber; break;
				}
			}
		}
		else // Try page number from array possibility
		{
			CGPDFInteger pageNumber = 0; // Page number in array
			
			if (CGPDFArrayGetInteger(destArray, 0, &pageNumber) == true)
			{
				targetPageNumber = (pageNumber + 1); // 1-based
			}
		}
		
		if (targetPageNumber > 0) // We have a target page number
		{
			linkTarget = [NSNumber numberWithInteger:targetPageNumber];
		}
	}
	
	return linkTarget;
}

- (id)singleTap:(UITapGestureRecognizer *)recognizer
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	id result = nil; // Tap result object
	
	if (recognizer.state == UIGestureRecognizerStateRecognized)
	{
		if (_links.count > 0) // Process the single tap
		{
			CGPoint point = [recognizer locationInView:self];
			
			for (PDFReaderDocumentLink *link in _links) // Enumerate links
			{
				if (CGRectContainsPoint(link.rect, point) == true) // Found it
				{
					result = [self findLinkTarget:link.dictionary];
					//[self parseLinksAndDrawContents:(NSURL *)result withRect:link.rect];
					break;
					
				}
			}
		}
	}
	
	return result;
}

//SMB: newly added

#pragma mark - drawMultimediaContents

-(void)parseLinksAndDrawContents:(NSURL*)urlLink withRect:(CGRect)rect{
	
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if (![urlLink isKindOfClass:[NSURL class]]) {
		return;
	}
	NSLog(@"pageTag:%d",self.tag);
	
	NSLog(@"url: %@",urlLink);
	if ([[urlLink absoluteString] isEqualToString:@"photo"]) {
	
	UIImageView *highlight = [[UIImageView alloc] initWithFrame:rect];
	highlight.tag = 672;
		[highlight setBackgroundColor:[UIColor clearColor]];
	highlight.autoresizesSubviews = YES;
	highlight.userInteractionEnabled = YES;
	highlight.clearsContextBeforeDrawing = YES;
	
	[self addSubview:highlight];
	[highlight release];
	
	}
	/*
	if (movieControllers==nil) {
		movieControllers = [[NSMutableArray alloc] init];
	}
	
	NSString *uri = [urlLink absoluteString];
	NSArray *arrayParameter = nil;
	NSString *uriType = nil;
    NSString *uriResource = nil;
    NSString *resourceFolder = [[[NSBundle mainBundle] resourcePath] stringByAppendingFormat:@"/pdfs/Multimedia1/"];
    NSString * documentPath = nil;
    
    arrayParameter = [uri componentsSeparatedByString:@"://"];
	
    uriType = [NSString stringWithFormat:@"%@", [arrayParameter objectAtIndex:0]];
	
	uriResource = [NSString stringWithFormat:@"%@", [arrayParameter objectAtIndex:1]];*/
	/*if ([uriType isEqualToString:@"http"]) {
		documentPath = [@"http://" stringByAppendingString:uriResource];
		NSLog(@"respath:%@",documentPath);
		MPMoviePlayerController* player=[[MPMoviePlayerController alloc] initWithContentURL:[NSURL URLWithString:documentPath]];
		player.view.backgroundColor = [UIColor colorWithRed:0.0f green:0.0f blue:1.0f alpha:0.15f];
		
		player.view.tag = 672;
		player.controlStyle = MPMovieControlStyleEmbedded;
		player.shouldAutoplay = YES;
		[player.view setFrame:rect];
		
		[self addSubview:player.view];
		[movieControllers addObject:player];
		
		
		player=nil;
		
	}
	else*/ /*if ([uriType isEqualToString:@"fpkv"]) {
		
		
		documentPath = [resourceFolder stringByAppendingPathComponent:uriResource];
		
		SMBMediaPlayer *medPl = [[SMBMediaPlayer alloc] initWithFrame:rect urlString:documentPath isLocal:YES];
		medPl.tag = 672;
		[self addSubview:medPl.view];
		[movieControllers addObject:medPl];
		medPl=nil;
	}
	else if ([uriType isEqualToString:@"fpky"]) {
		
		documentPath = [@"http://" stringByAppendingString:uriResource];

		SMBMediaPlayer *medPl = [[SMBMediaPlayer alloc] initWithFrame:rect urlString:documentPath isLocal:NO];
		medPl.tag = 672;
		[self addSubview:medPl.view];
		[movieControllers addObject:medPl];
		medPl=nil;

	}
	else if ([uriType isEqualToString:@"fpka"]) {
		
		documentPath = [resourceFolder stringByAppendingPathComponent:uriResource];
			
		SMBMediaPlayer *medPl = [[SMBMediaPlayer alloc] initWithFrame:rect urlString:documentPath isLocal:YES];
		medPl.tag = 672;
		[self addSubview:medPl.view];
		[movieControllers addObject:medPl];
		medPl=nil;

	}
	else if ([uriType isEqualToString:@"fpkb"]) {
		
		documentPath = [@"http://" stringByAppendingString:uriResource];
			
		SMBMediaPlayer *medPl = [[SMBMediaPlayer alloc] initWithFrame:rect urlString:documentPath isLocal:NO];
		medPl.tag = 672;
		[self addSubview:medPl.view];
		[movieControllers addObject:medPl];
		medPl=nil;

	}
	else if ([uriType isEqualToString:@"fpkh"]) {
		
		documentPath = [@"http://" stringByAppendingString:uriResource];

		
		UIView *highlight = [[UIView alloc] initWithFrame:rect];
		highlight.tag = 672;
		highlight.autoresizesSubviews = YES;
		highlight.userInteractionEnabled = YES;
		highlight.clearsContextBeforeDrawing = YES;
		UIWebView *web = [[UIWebView alloc] initWithFrame:highlight.frame];//CGRectMake(0, 0, highlight.frame.size.width, highlight.frame.size.height)];
		[web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:documentPath]]];
		web.backgroundColor = [UIColor blackColor];
		[self addSubview:web];
		[web release];
		
		[highlight release];		
	}
	else if ([uriType isEqualToString:@"fpkw"]) {
	
		documentPath = [@"http://" stringByAppendingString:uriResource];
				
		UIView *highlight = [[UIView alloc] initWithFrame:rect];
		highlight.tag = 672;
		highlight.autoresizesSubviews = YES;
		highlight.userInteractionEnabled = YES;
		highlight.clearsContextBeforeDrawing = YES;
				
		UIWebView *web = [[UIWebView alloc] initWithFrame:highlight.frame];//CGRectMake(0, 0, highlight.frame.size.width, highlight.frame.size.height)];
		[web loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:documentPath]]];
		web.backgroundColor = [UIColor blackColor];
		[self addSubview:web];
		[web release];
		
		[highlight release];
	}*/
}



#pragma mark ReaderContentPage instance methods

- (id)initWithFrame:(CGRect)frame
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	id view = nil; // UIView
	
	if (CGRectIsEmpty(frame) == false)
	{
		if ((self = [super initWithFrame:frame]))
		{
			self.autoresizesSubviews = NO;
			self.userInteractionEnabled = YES;
			self.clearsContextBeforeDrawing = NO;
			self.contentMode = UIViewContentModeRedraw;
			self.autoresizingMask = UIViewAutoresizingNone;
			self.backgroundColor = [UIColor clearColor];
			
			view = self; // Return self
			
			//SMB: TODO
			
		}
	}
	else // Handle invalid frame size
	{//TODO
		[self release];
	}
	
	return view;
}

- (id)initWithURL:(NSURL *)fileURL page:(NSInteger)page password:(NSString *)phrase
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	CGRect viewRect = CGRectZero; // View rect
	
	if (fileURL != nil) // Check for non-nil file URL
	{
		_PDFDocRef = CGPDFDocumentCreateX((CFURLRef)fileURL, phrase);
		
		if (_PDFDocRef != NULL) // Check for non-NULL CGPDFDocumentRef
		{
			if (page < 1) page = 1; // Check the lower page bounds
			
			NSInteger pages = CGPDFDocumentGetNumberOfPages(_PDFDocRef);
			
			if (page > pages) page = pages; // Check the upper page bounds
			
			_PDFPageRef = CGPDFDocumentGetPage(_PDFDocRef, page); // Get page
			
			if (_PDFPageRef != NULL) // Check for non-NULL CGPDFPageRef
			{
				CGPDFPageRetain(_PDFPageRef); // Retain the PDF page
				
				CGRect cropBoxRect = CGPDFPageGetBoxRect(_PDFPageRef, kCGPDFCropBox);
				CGRect mediaBoxRect = CGPDFPageGetBoxRect(_PDFPageRef, kCGPDFMediaBox);
				CGRect effectiveRect = CGRectIntersection(cropBoxRect, mediaBoxRect);
				
				_pageAngle = CGPDFPageGetRotationAngle(_PDFPageRef); // Angle
				
				switch (_pageAngle) // Page rotation angle (in degrees)
				{
					default: // Default case
					case 0: case 180: // 0 and 180 degrees
					{
						_pageSize.width = effectiveRect.size.width;
						_pageSize.height = effectiveRect.size.height;
						break;
					}
						
					case 90: case 270: // 90 and 270 degrees
					{
						_pageSize.height = effectiveRect.size.width;
						_pageSize.width = effectiveRect.size.height;
						break;
					}
				}
				
				NSInteger page_w = _pageSize.width; // Integer width
				NSInteger page_h = _pageSize.height; // Integer height
				
				if (page_w % 2) page_w--; if (page_h % 2) page_h--; // Even
				
				viewRect.size = CGSizeMake(page_w, page_h); // View size
			}
			else // Error out with a diagnostic
			{
				CGPDFDocumentRelease(_PDFDocRef), _PDFDocRef = NULL;
				
				NSAssert(NO, @"CGPDFPageRef == NULL");
			}
		}
		else // Error out with a diagnostic
		{
			NSAssert(NO, @"CGPDFDocumentRef == NULL");
		}
	}
	else // Error out with a diagnostic
	{
		NSAssert(NO, @"fileURL == nil");
	}
	
	id view = [self initWithFrame:viewRect]; // UIView setup
	
	if (view != nil) [self buildAnnotationLinksList]; // Links
	
	return view;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	[_links release], _links = nil;
	
	//TODO
	@synchronized(self) // Block any other threads
	{
		CGPDFPageRelease(_PDFPageRef), _PDFPageRef = NULL;
		
		CGPDFDocumentRelease(_PDFDocRef), _PDFDocRef = NULL;
	}
	
	
	if (movieControllers!=nil) {
		for(id mpCon in movieControllers) {
			[mpCon release];
		}
	}
	[movieControllers release];
	movieControllers = nil;
	[super dealloc];
}

/*
 - (void)layoutSubviews
 {
 #ifdef DEBUGX
 NSLog(@"%s", __FUNCTION__);
 #endif
 }
 */

#pragma mark CATiledLayer delegate methods

- (void)drawLayer:(CATiledLayer *)layer inContext:(CGContextRef)context
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	CGPDFPageRef drawPDFPageRef = NULL;
	
	CGPDFDocumentRef drawPDFDocRef = NULL;
	
	//TODO
	@synchronized(self) // Block any other threads
	{
		drawPDFDocRef = CGPDFDocumentRetain(_PDFDocRef);
		
		drawPDFPageRef = CGPDFPageRetain(_PDFPageRef);
	}
	
	//TODO
	CGContextSetRGBFillColor(context, 1.0f, 1.0f, 1.0f, 1.0f); // White
	
	CGContextFillRect(context, CGContextGetClipBoundingBox(context)); // Fill
	
	if (drawPDFPageRef != NULL) // Go ahead and render the PDF page into the context
	{
		CGContextTranslateCTM(context, 0.0f, self.bounds.size.height); CGContextScaleCTM(context, 1.0f, -1.0f);
		
		CGContextConcatCTM(context, CGPDFPageGetDrawingTransform(drawPDFPageRef, kCGPDFCropBox, self.bounds, 0, true));
		
		CGContextSetRenderingIntent(context, kCGRenderingIntentDefault); CGContextSetInterpolationQuality(context, kCGInterpolationDefault);
		
		CGContextDrawPDFPage(context, drawPDFPageRef); // Render the PDF page into the context
	}
	
	CGPDFPageRelease(drawPDFPageRef); CGPDFDocumentRelease(drawPDFDocRef); // Cleanup
}

@end


#pragma mark -

//
//	ReaderDocumentLink class implementation
//

@implementation PDFReaderDocumentLink

#pragma mark Properties

@synthesize rect = _rect;
@synthesize dictionary = _dictionary;

#pragma mark PDFReaderDocumentLink class methods

+ (id)withRect:(CGRect)linkRect dictionary:(CGPDFDictionaryRef)linkDictionary
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	return [[[PDFReaderDocumentLink alloc] initWithRect:linkRect dictionary:linkDictionary] autorelease];
}

#pragma mark ReaderDocumentLink instance methods

- (id)initWithRect:(CGRect)linkRect dictionary:(CGPDFDictionaryRef)linkDictionary
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	if ((self = [super init]))
	{
		_dictionary = linkDictionary;
		
		_rect = linkRect;
	}
	
	return self;
}

- (void)dealloc
{
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
	
	[super dealloc];
}


@end

