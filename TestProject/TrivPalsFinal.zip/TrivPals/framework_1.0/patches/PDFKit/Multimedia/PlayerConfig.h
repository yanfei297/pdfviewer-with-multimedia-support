/*
 *  PlayerConfig.h
 *  SMBPDFKit
 *
 *  Created by SMB on 24/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */

#define SMB_PLAYER_STOP_NOTIFICATION @"SMBPlayerStop"