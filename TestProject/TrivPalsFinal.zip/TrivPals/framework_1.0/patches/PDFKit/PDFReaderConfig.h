/*
 *  PDFReaderConfig.h
 *  TestPDF
 *
 *  Created by SMB on 10/11/11.
 *  Copyright 2011 __MyCompanyName__. All rights reserved.
 *
 */
#define READER_BACKGROUND_COLOR [UIColor scrollViewTexturedBackgroundColor]

//Toolbar background colors
//#define TOOLBAR_LIGHTCOLOR [UIColor colorWithWhite:0.92f alpha:0.8f]
//#define TOOLBAR_DARKCOLOR [UIColor colorWithWhite:0.32f alpha:0.8f]

//default
//#define TOOLBAR_LIGHTCOLOR [UIColor colorWithRed:0.039 green:0.340 blue:0.251 alpha:1.000]
//#define TOOLBAR_DARKCOLOR [UIColor colorWithRed:0.035 green:0.239 blue:0.231 alpha:1.000]
//#define PAGEBAR_COLOR [UIColor colorWithRed:0.039 green:0.534 blue:0.474 alpha:0.600]

//modified
#define TOOLBAR_LIGHTCOLOR [UIColor colorWithRed:0.278 green:0.671 blue:0.957 alpha:1.000]
#define TOOLBAR_DARKCOLOR [UIColor colorWithRed:0.000 green:0.422 blue:0.832 alpha:1.000]
#define PAGEBAR_COLOR [UIColor colorWithRed:0.435 green:0.741 blue:0.953 alpha:0.400]

#define READER_BOOKMARKS TRUE
#define READER_ENABLE_MAIL FALSE
#define READER_ENABLE_PRINT TRUE
#define READER_ENABLE_THUMBS TRUE
#define READER_DISABLE_IDLE FALSE
#define READER_SHOW_SHADOWS TRUE
#define READER_STANDALONE FALSE



//System Versioning Preprocessor Macros


#define SYSTEM_VERSION_EQUAL_TO(v)                  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedSame)
#define SYSTEM_VERSION_GREATER_THAN(v)              ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedDescending)
#define SYSTEM_VERSION_GREATER_THAN_OR_EQUAL_TO(v)  ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] != NSOrderedAscending)
#define SYSTEM_VERSION_LESS_THAN(v)                 ([[[UIDevice currentDevice] systemVersion] compare:v options:NSNumericSearch] == NSOrderedAscending)
