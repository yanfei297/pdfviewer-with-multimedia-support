// App constants

//#import "FlurryAPI.h"


#define SAVED_ARTICLES @"savedArticles"



//#define TWITTER_DOMAIN @"cbsnews.ian.dw2.treemo.com"
//#define JIFFY_LINK_DOMAIN @"http://cbsnews.ian.dw2.treemo.com"
//#define LINK_DOMAIN @"labs.ian.dw2.treemo.com/jiffy" //@"iphone.cbsnews.treemo.com" // @"cbsnews.ian.dw2.treemo.com/cbsnews" //  

#define LINK_DOMAIN  @"ricksteves.treemo.com"  //@"rwg.dw2.treemo.com" //
#define TWITTER_DOMAIN @"cbsnews.treemo.com"
#define JIFFY_LINK_DOMAIN @"http://" @"cbsnews.treemo.com" // @"http://" @"cbsnews.ian.dw2.treemo.com" 



#define VAR_TOKEN @"#QUERY_STRING#"
#define VERSION_TOKEN @"&version=1.1"





#define FLURRY_KEY_IPAD @"JZCFSH9UAVC7QSM8C9BB"
#define FLURRY_KEY_IPHONE @" UKSIY8A5RL21HXHCSV9B"



#define API_KEY @"68320d13010992b41fc6ef29c0a675d0"
#define API_PASSWORD @"Fullscreen"
#define MEDIALETS_DEFAULT_COUNT @"2"


#define DEFAULT_ACTION_SHEET_STYLE UIActionSheetStyleBlackTranslucent

#define kStdButtonWidth	106.0
#define kStdButtonHeight 40.0
#define APP_USER_TOKEN  nil

#define TopNavTintColor 0x703675



#define CAROUSEL_TEXT_SELECTED 0xFFFFFF
#define CAROUSEL_BACKGROUND @"carousel_spinner-bg.png"
#define CAROUSEL_TEXT_UNSELECTED 0x606270

#define CAROUSEL_RIGHT @"carousel_right-arrow.png"
#define CAROUSEL_LEFT @"carousel_left-arrow.png"
#define CAROUSEL_HEIGHT 39






/*

#define APPLICATION_NAME @"Treem"


#define APPLICATION_VERSION @"1.0"

#define LINK_DOMAIN @"cbsnews-test.ian.dw2.treemo.com"
//#define LINK_DOMAIN @"labs.ian.dw2.treemo.com/jiffy" //@"iphone.cbsnews.treemo.com" // @"cbsnews.ian.dw2.treemo.com/cbsnews" //   

#define JIFFY_LINK_DOMAIN @"http://cbsnews-test.ian.dw2.treemo.com"
//#define JIFFY_LINK_DOMAIN @"http://" @"cbsnews.ian.dw2.treemo.com" 

#define VAR_TOKEN @"#QUERY_STRING#"
#define VERSION_TOKEN @"&version=1.0"


#define LINK_DOMAIN_URL_STRING @"http://" LINK_DOMAIN


#define API_URL @"http://treemo:X9trAt4B@devapi.associatedcontent.com"

#define FB_SECRET_APPID @""
#define FB_API_KEY FB_SECRET_APPID @""

//#define FLURRY_KEY @"XFK8839IENLXDWCGQSCR"

#define API_KEY @"68320d13010992b41fc6ef29c0a675d0"
#define API_PASSWORD @"Fullscreen"
#define MEDIALETS_DEFAULT_COUNT @"2"
#define TWITTER_DOMAIN @"cbsnews.treemo.com"

#define DEFAULT_ACTION_SHEET_STYLE UIActionSheetStyleBlackTranslucent

#define kStdButtonWidth	106.0
#define kStdButtonHeight 40.0
#define APP_USER_TOKEN  nil

#define TopNavTintColor 0x703675
#define NEWS_STORY_BODY_STYLE  @"color:#233565;size:13px;line-height:20px;padding 8px;font-family:helvetica;"

#define CNET_NEWS_CATEGORY_NAMES @"MacFixIt:,Windows 7 Insider,MP3 Acessories Blog,Inside CNET Labs,MP3 Insider,Dialed In,Fully Equipped,Car Tech Blog,iPhone Atlas,Android Atlas,Cell Phone Accessories"
#define CNET_NEWS_CATEGORY_IDS @"1009,10355804,MP3_ACCESSORIES_BLOG_TBA,INSIDE_CNET_LABS_TBA,49,85,82,48,233,251,14"

//#define CNET_NEWS_CATEGORY_IDS @"263,10355804,MP3_ACCESSORIES_BLOG_TBA,INSIDE_CNET_LABS_TBA,49,85,82,48,233,251,14"

#define CAROUSEL_TEXT_SELECTED 0xFFFFFF
#define CAROUSEL_BACKGROUND @"carousel_spinner-bg.png"
#define CAROUSEL_TEXT_UNSELECTED 0x606270

#define CAROUSEL_RIGHT @"carousel_right-arrow.png"
#define CAROUSEL_LEFT @"carousel_left-arrow.png"


#define CATEGORIES_SEARCH @"     All News     ,     Video     ,     Images     "
#define CATEGORIES_SEARCH_IDS @"News,Video,Image"

#define AD_USER_ID @"4cab67944677e858"
#define AD_DEFAULT_SECTION_ID @"1285"



#define SAVED_ARTICLES @"savedArticles"

*/
