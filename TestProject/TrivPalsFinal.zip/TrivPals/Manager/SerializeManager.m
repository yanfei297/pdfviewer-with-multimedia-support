//
//  SerializeManager.m
//  SwamiParthSarathi
//
//  Created by Sayan on 02/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "SerializeManager.h"
#import "NSData+AES256.h"
#import "TPGlobal.h"

@interface SerializeManager(Private)
-(void) initializeSharedInstance;
@end

@implementation SerializeManager

static SerializeManager *_sharedInstance;

+ (SerializeManager *) sharedSerializer{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] init];
        [_sharedInstance initializeSharedInstance];
    }
    return _sharedInstance;
}

//Serialize to Persistence

- (BOOL) serializeInputs:(NSArray *)inputs forKeys:(NSArray *)keys{
    int i = 0;
    if ([inputs count] != [keys count]) {
        return NO;
    }
    for (id objects in inputs) {
        [userDefaults setObject:objects forKey:[keys objectAtIndex:i++]];
    }
    [userDefaults synchronize];
     return YES;
}

- (NSArray *) deserializeForKeys:(NSArray *)keys{
    NSMutableArray *toReturn = [[NSMutableArray new] autorelease];
    if ([keys count] == 0) {
        return nil;
    }
    int notFound = 0;
    for (NSString *key in keys) {
        if ([userDefaults objectForKey:key]){
            [toReturn addObject:[userDefaults objectForKey:key]];
        }
        else{
            notFound++;
        }
    }
    [userDefaults synchronize];
    if (notFound == [keys count]) {
        return nil;
    }
    return toReturn;
}

- (BOOL) removeSerializableForKeys:(NSArray *)keys{
    if ([keys count] == 0) {
        return NO;
    }
    for (NSString *key in keys) {
        [userDefaults removeObjectForKey:key];
    }
    [userDefaults synchronize];
    return YES;
}

//Serialize to File

- (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath{
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    //NSLog(@"PATH : %@",appendeFilePath);
    NSError *error = nil;
    if ([fileManager fileExistsAtPath:filePath isDirectory:NULL]) {
        if ([fileManager fileExistsAtPath:appendeFilePath]) {
            if ([fileManager removeItemAtPath:appendeFilePath error:&error]) {
                NSLog(@"File Deleted Successfully");
            }
            else{
                NSLog(@"File Not Deleted");
            }
            
        }
        return [fileManager createFileAtPath:appendeFilePath contents:fileContent attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
    }
    [fileManager createDirectoryAtPath:filePath withIntermediateDirectories:NO attributes:nil error:&error];
   return [fileManager createFileAtPath:appendeFilePath contents:fileContent  attributes:nil]; //[fileContent AES256EncryptWithKey:AES256_KEY]
}

- (NSData *) readFileAtPath:(NSString *)filePath andFileName:(NSString *)fileName{
    NSString *appendeFilePath = [NSString stringWithFormat:@"%@/%@",filePath,fileName];
    if ([fileManager isReadableFileAtPath:appendeFilePath]) {
        return [fileManager contentsAtPath:appendeFilePath];
        //[((NSData *)[fileManager contentsAtPath:appendeFilePath]) AES256DecryptWithKey:AES256_KEY];
    }
    return nil;
}

- (NSData *) readFromFile:(NSString *)file{
    
    if ([fileManager isReadableFileAtPath:file]) {
        return [fileManager contentsAtPath:file];
        //[((NSData *)[fileManager contentsAtPath:appendeFilePath]) AES256DecryptWithKey:AES256_KEY];
    }
    return nil;
}

@end

@implementation SerializeManager(Private)

-(void) initializeSharedInstance{
    userDefaults = [NSUserDefaults standardUserDefaults];
    fileManager = [NSFileManager defaultManager];
}

@end
