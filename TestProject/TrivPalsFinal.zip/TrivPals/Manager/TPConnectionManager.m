//
//  TPConnectionManager.m
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPConnectionManager.h"
#import "XMLRequester.h"
#import "TPAppManager.h"
#import "TPGlobal.h"
#import "TPUtlis.h"

@interface TPConnectionManager(Private)
- (void) initializeSharedInstance;
@end

@implementation TPConnectionManager
@synthesize delegate;
@synthesize loadingView;

static TPConnectionManager *_sharedInstance;

+ (TPConnectionManager *) defaultConnectionManager{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] init];
        [_sharedInstance initializeSharedInstance];
    }
    
    return _sharedInstance;
}

#pragma mark - ASIHTTPRequests

- (void) userDidFaceBookLoginWithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,FBLOGIN([TPAppManager defaultManager].facebookId,[TPAppManager defaultManager].deviceToken)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) userDidFaceBookLoginAnimated:(BOOL) animated{
    [self userDidFaceBookLoginWithTarget:self didFinishSelector:@selector(didFinishFaceBookLogin:) isAnimated:animated];
}

- (void) userDidChallengeFriend:(NSDictionary *)friendDetails withTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,CHALLENGE([TPAppManager defaultManager].trivpalID, [friendDetails objectForKey:@"frd_trivpal_id"])] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView setText:@"Challenging"];
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) userDidChallengeFriend:(NSDictionary *)friendDetails isAnimated:(BOOL)animated{
    [self userDidChallengeFriend:friendDetails withTarget:self didFinishSelector:@selector(userDidChallengeFriendSuccesfully:) isAnimated:YES];
}

- (void) getTurnDetails:(NSDictionary *)challengeDict isAnimated:(BOOL)animated{
    [self getTurnDetails:challengeDict withTarget:self didFinishSelector:@selector(didGetTurnDetails:) isAnimated:YES];
}

- (void) getTurnDetails:(NSDictionary *)challengeDict withTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,TURN([TPAppManager defaultManager].trivpalID, [challengeDict objectForKey:@"frd_trivpal_id"], [challengeDict objectForKey:@"challenge_id"], [challengeDict objectForKey:@"game_id"], [challengeDict objectForKey:@"mode"]) ] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [TPAppManager defaultManager].activeChallengeID = [challengeDict objectForKey:@"challenge_id"];
    [TPAppManager defaultManager].turn = [challengeDict objectForKey:@"mode"];
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) getQuestionDetailsWithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,QUESTION([TPAppManager defaultManager].activeGameId) ] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) getQuestionDetails{
    [self getQuestionDetailsWithTarget:self didFinishSelector:@selector(didGetQuestions:) isAnimated:YES];
}

- (void) getScoreDetailsForGame:(NSString *)game WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,DETAILS(game)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) getScoreDetailsForGame:(NSString *)game{
    [self getScoreDetailsForGame:game WithTarget:self didFinishSelector:@selector(didGetScores:) isAnimated:YES];
}

- (void) getAnswareDetailsForGame:(NSString *)gameID WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,ANSWAREDETAILS(gameID)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) getAnswareDetailsForGame:(NSString *)gameid{
    [self getAnswareDetailsForGame:gameid WithTarget:self didFinishSelector:@selector(didGetAnswareDetails:) isAnimated:YES];
}

- (void) UserDidResumeGame:(NSString *)gameDetails WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    /*
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,COMPLETEGAME(gameDetails)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    //ASIHTTPRequest *req = [request getASIHttpRequestWithDidFinishSelector:action];
    //[req addRequestHeader:@"JSON-DATA" value:gameDetails];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
     */
}

- (void) userDidResumeGame:(NSString *)gameDetailsJSON{
    [self UserDidResumeGame:gameDetailsJSON WithTarget:self didFinishSelector:@selector(didResumeGame:) isAnimated:YES];
}

- (void) userDidResignGame:(NSString *)gameID WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,RESIGNGAME([TPAppManager defaultManager].trivpalID, gameID)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) userDidResignGame:(NSString *)gameID{
    [self userDidResignGame:gameID WithTarget:self didFinishSelector:@selector(didResignGame:) isAnimated:YES];
}

- (void) userDidDeleteGame:(NSString *)challengID WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,DELETEGAME([TPAppManager defaultManager].trivpalID, challengID)] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    [request getASIHttpRequestWithDidFinishSelector:action];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) userDidDeleteGame:(NSString *)challengId{
    [self userDidDeleteGame:challengId WithTarget:self didFinishSelector:@selector(didDeleteGame:) isAnimated:YES];
}


- (void) userDidEndRound:(NSString *)gameDetails WithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated{
    //NSString *jsonString = [TPUtlis  urlDecodeValue:gameDetails];
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,COMPLETEGAME()] actionTarget:target];
    NSLog(@"URL : %@",request.requestURL);
    //[request getASIHttpRequestWithDidFinishSelector:action];
    //[request getASIFormDataRequestWithPostBody:[gameDetails dataUsingEncoding:NSUTF8StringEncoding] DidFinishSelector:action];
    [request getASIFormDataRequestWithPostBody:[TPUtlis urlEncodeValue:gameDetails] DidFinishSelector:action];
    //[req addRequestHeader:@"JSON-DATA" value:gameDetails];
    if (animated) {
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    }
    [request release];
}

- (void) userDidEndRound:(NSString *)gameDetailsJSON{
    [self userDidEndRound:gameDetailsJSON WithTarget:self didFinishSelector:@selector(didEndRound:) isAnimated:YES];
}

- (void) userPushSettings{
    NSString *push = [NSString stringWithFormat:@"%d",[TPAppManager defaultManager].pushEnabled];
    XMLRequester *request = [[XMLRequester alloc] initWithURL:[NSString stringWithFormat:@"%@%@",serverURL,ENABLEPUSH([TPAppManager defaultManager].trivpalID,push)] actionTarget:self];
    NSLog(@"URL : %@",request.requestURL);
    
    [request getASIHttpRequestWithDidFinishSelector:@selector(didSaveUserSettings:)];
    
    //if (animated) {
    [loadingView setText:@"Saving"];
        if (![self.loadingView isAnimating]) {
            [self.loadingView startLoading];
        }
    //}
    [request release];
}

#pragma mark - ASIHTTPRequestDelegate

-(void)requestStarted:(ASIHTTPRequest *)request{
    //NSLog(@"STATUS : %d",request.responseStatusCode);
    //NSLog(@"REQUEST URL : %@",request.originalURL);
    //NSLog(@"Request Headers: %@",request.requestHeaders);
}

- (void)request:(ASIHTTPRequest *)request didReceiveResponseHeaders:(NSDictionary *)responseHeaders{
    NSLog(@"STATUS : %d",request.responseStatusCode);
    //NSLog(@"ResponseHeaders : %@",responseHeaders);
    /*
    if (request.responseStatusCode != 200) {
        if ([self.loadingView isAnimating]) {
            [self.loadingView stopLoading];
        }
        //[[[[UIAlertView alloc] initWithTitle:@"Error!" message:request.error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease] show];
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(didEncounterWithError:)]) {
                [self.delegate didEncounterWithError:request.error.localizedDescription];
            }
        }
    }
    */
    
}

- (void)request:(ASIHTTPRequest *)request willRedirectToURL:(NSURL *)newURL{
    //NSLog(@"NEW URL : %@",newURL.absoluteString);
}

- (void)requestFailed:(ASIHTTPRequest *)request{
    //NSLog(@"Error : %@",request.error);
#ifdef DEBUGX
	NSLog(@"%s", __FUNCTION__);
#endif
    if ([self.loadingView isAnimating]) {
        [self.loadingView stopLoading];
    }
    //[[[[UIAlertView alloc] initWithTitle:@"Error!" message:request.error.localizedDescription delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil] autorelease] show];
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didEncounterWithError:)]) {
            [self.delegate didEncounterWithError:request.error.localizedDescription];
        }
    }
}

#pragma mark - didFinishSelectors

- (void)didFinishFaceBookLogin:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        [self.loadingView stopLoading];
    }
    NSLog(@"Response ; %@",request.error.localizedDescription);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didFinishFaceBookLogin:)]) {
            [self.delegate didFinishFaceBookLogin:request.responseString];
        }
    }
}

- (void) userDidChallengeFriendSuccesfully:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        [self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Response ; %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didSuccesfullyChallenge:)]) {
            [self.delegate didSuccesfullyChallenge:request.responseString];
        }
    }
}
                             
- (void) didGetTurnDetails:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didGetTurnDetails:)]) {
            [self.delegate didGetTurnDetails:request.responseString];
        }
    }
}

- (void) didGetQuestions:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didGetQuestionDetails:)]) {
           [self.delegate didGetQuestionDetails:request.responseString];
        }
    }
}

- (void) didGetScores:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didEndRoundDetails:)]) {
            [self.delegate didEndRoundDetails:request.responseString];
        }
    }
}

- (void) didGetAnswareDetails:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didGetAnswareDetailsForGame:)]) {
            [self.delegate didGetAnswareDetailsForGame:request.responseString];
        }
    }
}

- (void) didResignGame:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(userDidResignGame:)]) {
            [self.delegate userDidResignGame:request.responseString];
        }
    }
}

- (void) didDeleteGame:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
}

- (void) didResumeGame:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        [self.loadingView stopLoading];
    }
   // NSLog(@"RESPONSE : %@",request.responseString);
}

- (void) didEndRound:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    //NSLog(@"Details : %@",request.responseString);
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(didEndRoundDetails:)]) {
            [self.delegate didEndRoundDetails:request.responseString];
        }
    }
}

- (void) didSaveUserSettings:(ASIHTTPRequest *)request{
    if ([self.loadingView isAnimating]) {
        //[self.loadingView setText:@"Loading"];
        [self.loadingView stopLoading];
    }
    [loadingView setText:@"Loading"];
}
@end

@implementation TPConnectionManager(Private)

- (void) initializeSharedInstance{
    self.loadingView = [BusyIndicatorView defaultLoadingViewWithText:@"Loading...."];
}

@end