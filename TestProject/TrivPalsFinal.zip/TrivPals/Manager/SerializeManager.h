//
//  SerializeManager.h
//  SwamiParthSarathi
//
//  Created by Sayan on 02/02/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SerializeManager : NSObject{
    //serializations
    NSUserDefaults *userDefaults;
    NSFileManager *fileManager;
}

+ (SerializeManager *) sharedSerializer;

- (BOOL) serializeInputs:(NSArray *)inputs forKeys:(NSArray *)keys;
- (NSArray *) deserializeForKeys:(NSArray *)keys;
- (BOOL) removeSerializableForKeys:(NSArray *)keys;

- (BOOL) writeContent:(NSData *)fileContent ToFile:(NSString *)fileName andPath:(NSString *)filePath;
- (NSData *) readFileAtPath:(NSString *)filePath andFileName:(NSString *)fileName;
- (NSData *) readFromFile:(NSString *)file;
@end
