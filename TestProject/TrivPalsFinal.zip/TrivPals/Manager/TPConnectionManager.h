//
//  TPConnectionManager.h
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ASINetworkQueue.h"
#import "BusyIndicatorView.h"

@protocol TPConnectionManagerDelegate <NSObject>

@optional
- (void) didFinishFaceBookLogin:(NSString *)loginResponse;
- (void) didSuccesfullyChallenge:(NSString *)challengeDetails;
- (void) didGetTurnDetails:(NSString *)turnDetails;
- (void) didGetQuestionDetails:(NSString *)questionDetails;
- (void) didGetAnswareDetailsForGame:(NSString *)answareDetails;
- (void) didEndRoundDetails:(NSString *)roundDetails;
- (void) userDidResignGame:(NSString *)resignDetails;
- (void) didEncounterWithError:(NSString *)errormsg;

@end

@interface TPConnectionManager : NSObject{
    id<TPConnectionManagerDelegate> delegate;
    ASINetworkQueue *networkQueue;
    BusyIndicatorView *loadingView;
} 

@property (nonatomic,assign) id<TPConnectionManagerDelegate> delegate;
@property (nonatomic,retain) BusyIndicatorView *loadingView;
+ (TPConnectionManager *) defaultConnectionManager;
- (void) userDidFaceBookLoginWithTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated;
- (void) userDidFaceBookLoginAnimated:(BOOL) animated;

- (void) userDidChallengeFriend:(NSDictionary *)friendDetails withTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated;
- (void) userDidChallengeFriend:(NSDictionary *)friendDetails isAnimated:(BOOL)animated;

- (void) getTurnDetails:(NSDictionary *)challengeDict isAnimated:(BOOL)animated;
- (void) getTurnDetails:(NSDictionary *)challengeDict withTarget:(id)target didFinishSelector:(SEL)action isAnimated:(BOOL) animated;

- (void) getQuestionDetails;
- (void) getScoreDetailsForGame:(NSString *)game;

- (void) getAnswareDetailsForGame:(NSString *)gameid;

- (void) userDidResignGame:(NSString *)gameID;

- (void) userDidDeleteGame:(NSString *)challengId;

- (void) userDidResumeGame:(NSString *)gameDetailsJSON;

- (void) userDidEndRound:(NSString *)gameDetailsJSON;

- (void) userPushSettings;
@end
