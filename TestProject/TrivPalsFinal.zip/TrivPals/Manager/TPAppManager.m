//
//  TPAppManager.m
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPAppManager.h"
#import "SerializeManager.h"
#import "TPGlobal.h"
#import "JSONParser.h"
#import "BusyIndicatorView.h"
#import "ASIHTTPRequest.h"
#import "TPGameLogic.h"


@interface TPAppManager(Private)
- (void) initializeSharedInstance;
- (void) parseJSONForFBLogin:(NSString *)jsonString;
@end

static TPAppManager *_sharedInstance;

@implementation TPAppManager

@synthesize delegate;
@synthesize isLoogedIn;
@synthesize facebookId;
@synthesize deviceToken;
@synthesize userDidChallenge;
@synthesize trivpalID;
@synthesize turn;
@synthesize activeGameId;
@synthesize activeChallengeID;
@synthesize facebook;
@synthesize userPermissions;
@synthesize friends;
@synthesize turns;
@synthesize questions;
@synthesize isChallenged;
@synthesize isGameOver;
@synthesize pushEnabled;
@synthesize soundEnabled;

+ (TPAppManager *) defaultManager{
    if (!_sharedInstance) {
        _sharedInstance = [[self alloc] init];
        [_sharedInstance initializeSharedInstance];
    }
    
    return _sharedInstance;
}

- (void) startLoading{
    if (![[BusyIndicatorView defaultLoadingViewWithText:@"Loading"]  isAnimating]) {
        [[BusyIndicatorView defaultLoadingViewWithText:@"Loading"] startLoading];
    }
    
}


#pragma mark - ResetContainer

- (void) resetTPAppManager{
    [self.friends removeAllObjects];
    [self.questions removeAllObjects];
    [self.turns removeAllObjects];
    self.activeGameId = @"";
    self.facebookId = @"";
    self.trivpalID = @"";
    self.activeGameId = @"";
}

#pragma mark - BackgroundProcessing
/*
- (void) downloadLoginDetailsInBackground{
    [[TPConnectionManager defaultConnectionManager] userDidFaceBookLoginWithTarget:self didFinishSelector:@selector(backgroundDownloadCompletedFBLogin:) isAnimated:NO];
    [self performSelector:@selector(downloadLoginDetailsInBackground) withObject:nil afterDelay:(5 * 60)];
}
 */

#pragma mark - Save And Load TPDetails
- (void)storeTPDetails{
    [[SerializeManager sharedSerializer] serializeInputs:[NSArray arrayWithObject:self.facebookId] forKeys:[NSArray arrayWithObject:fbID]];
    [[SerializeManager sharedSerializer] serializeInputs:[NSArray arrayWithObjects:[NSString stringWithFormat:@"%d",pushEnabled], [NSString stringWithFormat:@"%d",soundEnabled],nil] forKeys:[NSArray arrayWithObjects:@"push",@"sound", nil]];
}

- (void) loadTPDeatils{
    if ([[SerializeManager sharedSerializer] deserializeForKeys:[NSArray arrayWithObject:fbID]] ) {
        self.facebookId = [[[SerializeManager sharedSerializer] deserializeForKeys:[NSArray arrayWithObject:fbID]] objectAtIndex:0];
    }
    else {
        self.facebookId = @"";
    }
    
}

- (void) storeFaceBookId{
   [[SerializeManager sharedSerializer] serializeInputs:[NSArray arrayWithObject:self.facebookId] forKeys:[NSArray arrayWithObject:fbID]];
}

- (void) removeFacebookId{
    [[SerializeManager sharedSerializer] removeSerializableForKeys:[NSArray arrayWithObject:fbID]];
}

#pragma mark - WebSerivceRequest

- (void) userDidLoginFaceBook{
    [[TPConnectionManager defaultConnectionManager] userDidFaceBookLoginAnimated:YES];
    [TPConnectionManager defaultConnectionManager].delegate = self;
}

- (void) backgroundDownloadCompletedFBLogin:(ASIHTTPRequest *)request{
    [self parseJSONForFBLogin:request.responseString];
    [[NSNotificationCenter defaultCenter] postNotificationName:homePagerefresh object:nil];
    [[NSNotificationCenter defaultCenter] postNotificationName:frindPageRefresh object:nil];
}

- (void) userDidChallengeFriend:(NSDictionary *)friendDetails{
    [[TPConnectionManager defaultConnectionManager] userDidChallengeFriend:friendDetails isAnimated:YES] ;
}

- (void) getTurnDetails:(NSDictionary *)challengeDict{
    [[TPConnectionManager defaultConnectionManager] getTurnDetails:challengeDict isAnimated:YES];
}

- (void) getQuestionsForTrivia{
    [[TPConnectionManager defaultConnectionManager] getQuestionDetails];
}

- (void) getScoreDetails:(NSString *)gameId{
    [[TPConnectionManager defaultConnectionManager] getScoreDetailsForGame:gameId];
}

- (void) userWillGetAnswareForGame:(NSString *)gameId{
    [[TPConnectionManager defaultConnectionManager] getAnswareDetailsForGame:gameId];
}

- (void) userWillResignGame:(NSString *)gameID{
    [[TPConnectionManager defaultConnectionManager] userDidResignGame:gameID];
}

- (void) userWillDeleteGame:(NSString *)challengeID{
    [[TPConnectionManager defaultConnectionManager] userDidDeleteGame:challengeID];
}

- (void) userDiResumeGame:(NSString *)resumeGame{
    [[TPConnectionManager defaultConnectionManager] userDidResumeGame:resumeGame];
}

- (void) userDiEndRound:(NSString *)endGameDetails{
    [[TPConnectionManager defaultConnectionManager] userDidEndRound:endGameDetails];
}

- (void) userPushSettings{
    [[TPConnectionManager defaultConnectionManager] userPushSettings];
}


#pragma mark - TPConnectionManagerDelegate

- (void) didFinishFaceBookLogin:(NSString *)loginResponse{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:loginResponse];
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        //NSLog(@"JSON DICT : %@",jsonDict);
        NSMutableDictionary *loginDict = [[NSMutableDictionary new] autorelease];
        [loginDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"trivpal_id"]  forKey:@"trivpal_id"];
        [loginDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"user"]  forKey:@"user"];
        [loginDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"user_avater"]  forKey:@"user_avater"];
       
        [self parseJSONForFBLogin:loginResponse];
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidLoginSuccessfullyWithDetils:)]) {
                [self.delegate userDidLoginSuccessfullyWithDetils:loginDict];
            }
        }
    }
    else{
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }
}

- (void) didSuccesfullyChallenge:(NSString *)challengeDetails{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:challengeDetails];
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(didSuccesfullyChallenge:)]) {
                NSMutableDictionary *challengeDict = [[NSMutableDictionary new] autorelease];
                [challengeDict setValue:[[jsonDict objectForKey:@"response"] objectForKey:@"msg"] forKey:@"msg"];
                [challengeDict setValue:[[jsonDict objectForKey:@"response"] objectForKey:@"game_id"] forKey:@"game_id"];
                [challengeDict setValue:[[[jsonDict objectForKey:@"response"] objectForKey:@"challenge_details"] objectForKey:@"id"] forKey:@"challenge_id"];
                [challengeDict setValue:[[[jsonDict objectForKey:@"response"] objectForKey:@"challenge_details"] objectForKey:@"opp_id"] forKey:@"frd_trivpal_id"];
                [challengeDict setValue:@"yours"  forKey:@"mode"];
                [self.delegate didSuccesfullyChallenge:challengeDict];
            }
        }
    }
    else {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }
}

- (void) didGetTurnDetails:(NSString *)turnDetails{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:turnDetails];
    self.turn = [[jsonDict objectForKey:@"request"] objectForKey:@"turn"];
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(didGetTurnDetails:)]) {
                NSArray *turnsArray = [NSArray arrayWithObjects:[[jsonDict objectForKey:@"response"] objectForKey:@"player"] ,[[jsonDict objectForKey:@"response"] objectForKey:@"opponent"] , nil];
                [self.delegate didGetTurnDetails:turnsArray];
            }
        }
    }
    else {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }

}

- (void) didGetQuestionDetails:(NSString *)questionDetails{
    //NSLog(@"STRING ; %@",questionDetails);
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:questionDetails];
    //NSMutableArray *questionSet = [[NSMutableArray new] autorelease];
    [questions removeAllObjects];
    //NSLog(@"QuesTION %@",questions);
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        int questionNo = 0;
        [TPGameLogic sharedLogic].roundName = [[jsonDict objectForKey:@"response"]objectForKey:@"round_name"] ? [[jsonDict objectForKey:@"response"]objectForKey:@"round_name"] : @"";
        for (NSDictionary *dict in [[jsonDict objectForKey:@"response"]objectForKey:@"question"]) {
            NSMutableDictionary *question = [NSMutableDictionary new];
            NSMutableDictionary *options = [NSMutableDictionary new];
            NSMutableDictionary *answare = [NSMutableDictionary new];
            [question setValue:[dict objectForKey:@"id"] forKey:@"id"];
            [question setValue:[dict objectForKey:@"name"] forKey:@"name"];
            int i = 1;
            for (NSDictionary *option in [dict objectForKey:@"option"]) {
                [options setValue:option forKey:[NSString stringWithFormat:@"%d",i++]];
                if ([[option objectForKey:@"is_right"] intValue] == 1) {
                    [answare setValue:[option objectForKey:@"id"] forKey:@"id"];
                    [answare setValue:[option objectForKey:@"name"] forKey:@"name"];
                    [answare setValue:[option objectForKey:@"is_right"] forKey:@"is_right"];
                }
            }
            [questions setValue:[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:question,options,answare, nil] forKeys:[NSArray arrayWithObjects:@"question",@"options",@"answare", nil]] forKey:[NSString stringWithFormat:@"%d",questionNo++]];
             //addObject:[NSDictionary dictionaryWithObjects:[NSArray arrayWithObjects:question,options,answare, nil] forKeys:[NSArray arrayWithObjects:@"question",@"options",@"answare", nil]]];
            [question release];
            [options release];
            [answare release];
        }
        //NSLog(@"Questions : %@",questions);
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(didGetQuestions:)]) {
                [self.delegate didGetQuestions:questions];
            }
        }
    }
    else {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }

}

- (void) didGetAnswareDetailsForGame:(NSString *)answareDetails{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:answareDetails];
    //NSMutableArray *questionSet = [[NSMutableArray new] autorelease];
    //NSLog(@"Answare %@",jsonDict);
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(didGetAnsware:)]) {
                [self.delegate didGetAnsware:[jsonDict objectForKey:@"response"] ];
            }
        }
   
    }
    else {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }
}



- (void) userDidResignGame:(NSString *)resignDetails{
    //NSLog(@"STRING ; %@",questionDetails);
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:resignDetails];
    //NSLog(@"JSON : %@",jsonDict);
    
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        NSLog(@"SUCCESS..........");
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(userDidResignGame)]) {
               [self.delegate userDidResignGame] ;
            }
        }
    }
    else {
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    }
}

- (void) didEndRoundDetails:(NSString *)roundDetails{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:roundDetails];
    if ([[[jsonDict objectForKey:@"response"] objectForKey:@"status"] intValue] == 1) {
        if (self.delegate) {
            if ([self.delegate respondsToSelector:@selector(didEndRound:)]) {
                [self.delegate didEndRound:[jsonDict objectForKey:@"response"]];
            }
        }
    }
    else{
        if ([self delegate]) {
            if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
                [self.delegate userDidEncounetrWithAnError:jsonDict];
            }
        }
    
    }
}

- (void) didEncounterWithError:(NSString *)errormsg{
    NSMutableDictionary *errorDict = [NSMutableDictionary dictionaryWithObject:errormsg forKey:@"error"];
    if (self.delegate) {
        if ([self.delegate respondsToSelector:@selector(userDidEncounetrWithAnError:)]) {
            [self.delegate userDidEncounetrWithAnError:[NSDictionary dictionaryWithObject:errorDict forKey:@"response"]];
        }
    }
}

@end

@implementation TPAppManager (Private)
- (void) initializeSharedInstance{
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] initWithCapacity:1];
    self.userPermissions = dict;
    self.friends = dict;
    self.turns = dict;
    self.questions = dict;
    [dict release];
    
    
    if ([[SerializeManager sharedSerializer] deserializeForKeys:[NSArray arrayWithObject:fbID]]) {
        self.facebookId = [[[SerializeManager sharedSerializer] deserializeForKeys:[NSArray arrayWithObject:fbID]] objectAtIndex:0];
        self.isLoogedIn = YES;
    }
    else {
        self.facebookId = @"";
        self.isLoogedIn = NO;
    }
    NSArray *arr = [[SerializeManager sharedSerializer] deserializeForKeys:[NSArray arrayWithObjects:@"push",@"sound", nil]];
    if ([arr count] > 0) {
        self.pushEnabled = [[arr objectAtIndex:0] boolValue];
        self.soundEnabled = [[arr objectAtIndex:1] boolValue];
    }
    else {
        self.pushEnabled = YES;
        self.soundEnabled = YES;
    }
    self.trivpalID = @"";
    self.activeGameId = @"";
    self.activeChallengeID = @"";
    self.deviceToken = @"";
    //[self performSelector:@selector(downloadLoginDetailsInBackground) withObject:nil afterDelay:(2 * 60)];
    self.userDidChallenge = NO;
    self.isChallenged = NO;
    self.isGameOver = NO;
}

- (void) parseJSONForFBLogin:(NSString *)jsonString{
    NSDictionary *jsonDict = [JSONParser parseJSONFromJSONString:jsonString];
    NSMutableDictionary *turnDict = [[NSMutableDictionary new] autorelease];
    if ([[jsonDict objectForKey:@"response"] objectForKey:@"yours_turn"]  ) {
         [turnDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"yours_turn"]  forKey:@"yours_turn"];
    }
    if ([[jsonDict objectForKey:@"response"] objectForKey:@"pals_turn"]) {
        [turnDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"pals_turn"]  forKey:@"pals_turn"];
    }
    if ([[jsonDict objectForKey:@"response"] objectForKey:@"game_over"]) {
        [turnDict setObject:[[jsonDict objectForKey:@"response"] objectForKey:@"game_over"]  forKey:@"game_over"];
    }
    self.turns = turnDict;
    
    NSArray *allFriends = [[jsonDict objectForKey:@"response"] objectForKey:@"friends"];
    NSMutableArray *trivpalsFriends = [NSMutableArray new];
    NSMutableArray *noTrivplasFriends = [NSMutableArray new];
    for (NSDictionary *frnd in allFriends) {
        if ([[frnd objectForKey:@"in_trivpal"] intValue] == 1) {
            [trivpalsFriends addObject:frnd];
        }
        else {
            [noTrivplasFriends addObject:frnd];
        }
    }
    [friends setObject:trivpalsFriends forKey:inTrivPal];
    [friends setObject:noTrivplasFriends forKey:notInTrivpal];
    [trivpalsFriends release];
    [noTrivplasFriends release];

}

@end
