//
//  TPAppManager.h
//  TrivPals
//
//  Created by Sayan on 14/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FBConnect.h"
#import "TPConnectionManager.h"

@protocol TPAppManagerDelegate <NSObject>

@optional

- (void) userDidEncounetrWithAnError:(NSDictionary *)errorDetails;
- (void) userDidLoginSuccessfullyWithDetils:(NSDictionary *)loginDetails;
- (void) didSuccesfullyChallenge:(NSDictionary *)challengeDetails;
- (void) didGetTurnDetails:(NSArray *)turns;
- (void) didGetQuestions:(NSDictionary *)questions;
- (void) didGetAnsware:(NSDictionary *)answare;
- (void) userDidResignGame;
- (void) didEndRound:(NSDictionary *)endRoundDetails;

@end

@interface TPAppManager : NSObject<TPConnectionManagerDelegate>{
    id<TPAppManagerDelegate> delegate;
    //facebook details
    BOOL isLoogedIn;
    BOOL userDidChallenge;
    NSString *facebookId;
    NSString *deviceToken;
    NSString *trivpalID;
    NSString *activeGameId;
    NSString *activeChallengeID;
    NSString *turn;
    NSMutableDictionary *userPermissions;
    Facebook *facebook;
    
    NSMutableDictionary *friends;
    NSMutableDictionary *turns;
    NSMutableDictionary *questions;
    BOOL isChallenged;
    BOOL isGameOver;
    BOOL pushEnabled;
    BOOL soundEnabled;
}

@property (nonatomic,assign) id<TPAppManagerDelegate> delegate;
@property (nonatomic,assign) BOOL isLoogedIn;
@property (nonatomic,assign) BOOL userDidChallenge;
@property (nonatomic, retain) NSString *facebookId;
@property (nonatomic,retain) NSString *deviceToken;
@property (nonatomic, retain) NSString *trivpalID;
@property (nonatomic, retain) NSString *activeGameId;
@property (nonatomic,retain) NSString *activeChallengeID;
@property (nonatomic,retain) NSString *turn;
@property (nonatomic, retain) NSMutableDictionary *userPermissions;
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic,retain) NSMutableDictionary *friends;
@property (nonatomic,retain) NSMutableDictionary *turns;
@property (nonatomic,retain) NSMutableDictionary *questions;
@property (nonatomic,assign) BOOL isChallenged;
@property (nonatomic,assign) BOOL isGameOver;
@property (nonatomic,assign) BOOL pushEnabled;
@property (nonatomic,assign) BOOL soundEnabled;

+ (TPAppManager *) defaultManager;
- (void) startLoading;
- (void) resetTPAppManager;
- (void)storeTPDetails;
- (void) loadTPDeatils;
- (void) storeFaceBookId;
- (void) removeFacebookId;
- (void) userDidLoginFaceBook;
- (void) userDidChallengeFriend:(NSDictionary *)friendDetails;
- (void) getTurnDetails:(NSDictionary *)challengeDict;
- (void) getQuestionsForTrivia;
- (void) getScoreDetails:(NSString *)gameId;
- (void) userWillGetAnswareForGame:(NSString *)gameId;
- (void) userWillResignGame:(NSString *)gameID;
- (void) userDiResumeGame:(NSString *)resumeGame;
- (void) userWillDeleteGame:(NSString *)challengeID;
- (void) userDiEndRound:(NSString *)endGameDetails;
- (void) userPushSettings;
@end
