//
//  TPQuestionView.h
//  TrivPals
//
//  Created by Sayan on 23/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPQuestionView : UIView{
    id actionTarget;
}
- (id)initWithFrame:(CGRect)frame andTarget:(id)target isPause:(BOOL) pause;
@end
