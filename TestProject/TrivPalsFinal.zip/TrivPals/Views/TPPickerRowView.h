//
//  TPPickerRowView.h
//  TestPickerView
//
//  Created by Sayan on 05/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPPickerRowView : UIView{
    NSDictionary *rowDetails;
    UIImageView *playerImage;
    UIImageView *opponentImage;
    UILabel *playerScore;
    UILabel *opponentScore;
    UILabel *questionNo;
}

@property (nonatomic,retain) NSDictionary *rowDetails;
@property (nonatomic,retain) UIImageView *playerImage;
@property (nonatomic,retain) UIImageView *opponentImage;
@property (nonatomic,retain) UILabel *playerScore;
@property (nonatomic,retain) UILabel *opponentScore;
@property (nonatomic,retain) UILabel *questionNo;

- (id)initWithFrame:(CGRect)frame andRowDetails:(NSDictionary *)details;
@end
