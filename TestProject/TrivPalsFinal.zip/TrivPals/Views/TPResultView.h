//
//  TPResultView.h
//  TrivPals
//
//  Created by Sayan on 30/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

#define HEIGHT 180.0
#define WIDTH 140.0

@interface TPResultView : UIView
- (id)initWithFrame:(CGRect)frame andResultDetails:(NSDictionary *)resultDetails;
@end
