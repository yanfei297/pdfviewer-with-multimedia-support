//
//  TPSettingsView.h
//  TrivPals
//
//  Created by Sayan on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPSettingsView : UIView{
    //id actionTarget;
}

//@property (nonatomic,assign) id actionTarget;

- (id)initWithFrame:(CGRect)frame userDetails:(NSDictionary *)deatils andTarget:(id)target;
@end
