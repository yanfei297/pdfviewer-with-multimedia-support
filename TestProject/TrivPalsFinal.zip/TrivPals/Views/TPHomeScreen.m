//
//  TPHomeScreen.m
//  TrivPals
//
//  Created by Sayan on 16/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPHomeScreen.h"
#import "TPViewController.h"
#import "TPAppManager.h"
#import "AsyncImageView.h"
#import "TPUtlis.h"
#import "TPGlobal.h"
#import "TPGameLogic.h"

#define ADJUST_TABLE_SECTION_SPACING 2.0f

@implementation TPHomeScreen

@synthesize actionTarget;
@synthesize challengeDetails;

- (id)initWithFrame:(CGRect)frame andTarget:(id)target
{
    self = [super initWithFrame:frame style:UITableViewStylePlain];
    if (self) {
        // Initialization code
        self.dataSource = self;
        self.delegate = self;
        self.backgroundColor = [UIColor clearColor];
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        //self.separatorColor = [UIColor clearColor];
        //self.separatorStyle = UITableViewCellSeparatorStyleNone;
        self.actionTarget = target;
        if (_refreshHeaderView == nil) {
            
            EGORefreshTableHeaderView *view = [[EGORefreshTableHeaderView alloc] initWithFrame:CGRectMake(0.0f, 0.0f - self.bounds.size.height, self.frame.size.width, self.bounds.size.height)];
            view.delegate = self;
            [self addSubview:view];
            _refreshHeaderView = view;
            [view release];
            
            //NSLog(@"TURNS : %@",[TPAppManager defaultManager].turns);
            
        }
        //  update the last update date
        [_refreshHeaderView refreshLastUpdatedDate];
        //NSLog(@"TURNS : %@",[TPAppManager defaultManager].turns);
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (NSString *) allignTextForTime:(NSString *)str{
    NSArray *strArr = [str componentsSeparatedByString:@" "];
    //NSLog(@" %@",strArr);
    if ([str rangeOfString:@"days"].location != NSNotFound) {
        return str;
    }
    NSString *toReturn = @"";
    if ([strArr count] == 0) {
        return toReturn;
    }
    if ([[strArr objectAtIndex:0] intValue] == 0) {
        if([[strArr objectAtIndex:2] intValue] == 0){
            toReturn = [toReturn stringByAppendingFormat:@"%@ %@",[strArr objectAtIndex:4],[strArr objectAtIndex:5]];
        }
        else{
            toReturn = [toReturn stringByAppendingFormat:@"%@ %@",[strArr objectAtIndex:2],[strArr objectAtIndex:3]];
        }
    }
    else if([[strArr objectAtIndex:2] intValue] == 0){
        toReturn = [toReturn stringByAppendingFormat:@"%@ %@",[strArr objectAtIndex:4],[strArr objectAtIndex:5]];
    }
    else {
        toReturn = [toReturn stringByAppendingFormat:@"%@ %@ and %@ %@",[strArr objectAtIndex:0],[strArr objectAtIndex:1],[strArr objectAtIndex:2],[strArr objectAtIndex:3]];
    }
   //NSLog(@"TIME : %@",toReturn);
    return toReturn;
}

#pragma mark -
#pragma mark Data Source Loading / Reloading Methods

- (void)reloadTableViewDataSource{
	
	//  should be calling your tableviews data source model to reload
	//  put here just for demo
	_reloading = YES;
    [[TPAppManager defaultManager] userDidLoginFaceBook];
    [TPAppManager defaultManager].delegate = actionTarget;
    
	
}

- (void)doneLoadingTableViewData{
	
	//  model should call this when its done loading
	_reloading = NO;
	[_refreshHeaderView egoRefreshScrollViewDataSourceDidFinishedLoading:self];
	
}

#pragma mark -
#pragma mark EGORefreshTableHeaderDelegate Methods

- (void)egoRefreshTableHeaderDidTriggerRefresh:(EGORefreshTableHeaderView*)view{
	
	[self reloadTableViewDataSource];
	//[self performSelector:@selector(doneLoadingTableViewData) withObject:nil afterDelay:3.0];
	
}

- (BOOL)egoRefreshTableHeaderDataSourceIsLoading:(EGORefreshTableHeaderView*)view{
	
	return _reloading; // should return if data source model is reloading
	
}

- (NSDate*)egoRefreshTableHeaderDataSourceLastUpdated:(EGORefreshTableHeaderView*)view{
	
	return [NSDate date]; // should return date data source was last changed
	
}

#pragma mark - UIAlertViewDelegate

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if (buttonIndex == 0) {
        [[TPAppManager defaultManager] getTurnDetails:challengeDetails];
        [TPAppManager defaultManager].activeGameId = [challengeDetails objectForKey:@"game_id"];
        [TPAppManager defaultManager].delegate = actionTarget;
    }
    if (buttonIndex == 1) {
        [TPAppManager defaultManager].activeGameId = [challengeDetails objectForKey:@"game_id"];
        [[TPAppManager defaultManager] userWillResignGame:[challengeDetails objectForKey:@"challenge_id"]];
        [TPAppManager defaultManager].delegate = actionTarget;
    } 
}

#pragma mark -
#pragma mark UIScrollViewDelegate Methods

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{	
	
	[_refreshHeaderView egoRefreshScrollViewDidScroll:scrollView];
    
}

- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate{
	
	[_refreshHeaderView egoRefreshScrollViewDidEndDragging:scrollView];
    [self reloadData];
	
}


#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    int rows = 1;
    if (section == 1) {
        if ([[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] count] > 0) {
            rows = [[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] count];
        }
        else {
            rows = 0;
        }
    }
    if (section == 2) {
        if ([[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] count] > 0) {
            rows = [[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] count];
        }
        else {
            rows = 0;
        }
    }
    if (section == 3) {
        if ([[[TPAppManager defaultManager].turns objectForKey:@"game_over"] count] > 0) {
            rows = [[[TPAppManager defaultManager].turns objectForKey:@"game_over"] count];
        }
        else {
            rows = 0;
        }
    }
    return rows;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    int sections = 3;
    if ([[[TPAppManager defaultManager].turns objectForKey:@"game_over"] count] > 0) {
        sections = 4;
    }
    return sections;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    static NSString *cellIdentifier = @"cell";
    static NSString *nilCellIdentifier = @"nil";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	NSString *title = @"";
    NSString *msg = @"";
    NSString *time = @"";
    NSString *image = @"";
    
	if (cell == nil) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nilCellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
	}
    else{
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
		cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
		cell.selectionStyle = UITableViewCellSelectionStyleBlue;
    }
    if (indexPath.section == 0) {
        //cell.textLabel.text = @"Start A New Game";
        UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"startnewgame.png"]];
        image.frame = CGRectMake(-2, 0, 304, 90);
        [cell.contentView addSubview:image];
        cell.backgroundColor = [UIColor clearColor];
        [image release];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        cell.accessoryType = UITableViewCellAccessoryNone;
        //cell.backgroundView = [UIImageView ]
    }
    else {
        if (indexPath.section == 1) {
            //cell.textLabel.text = @"Your Turn";
            if ([[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] count] > 0) {
                title = [[[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] objectAtIndex:indexPath.row] objectForKey:@"title"];
                msg = [[[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] objectAtIndex:indexPath.row] objectForKey:@"msg"];
                time = [[[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] objectAtIndex:indexPath.row] objectForKey:@"waiting"];
                image = [[[[TPAppManager defaultManager].turns objectForKey:@"yours_turn"] objectAtIndex:indexPath.row] objectForKey:@"avater"];
            }
            
        }
        if (indexPath.section == 2) {
            //cell.textLabel.text = @"Pal's Turn";
            if ([[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] count] > 0) {
                title = [[[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] objectAtIndex:indexPath.row] objectForKey:@"title"];
                msg = [[[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] objectAtIndex:indexPath.row] objectForKey:@"msg"];
                time = [[[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] objectAtIndex:indexPath.row] objectForKey:@"waiting"];
                image = [[[[TPAppManager defaultManager].turns objectForKey:@"pals_turn"] objectAtIndex:indexPath.row] objectForKey:@"avater"];
            }
        }
        if (indexPath.section == 3) {
            //cell.textLabel.text = @"Pal's Turn";
            if ([[[TPAppManager defaultManager].turns objectForKey:@"game_over"] count] > 0) {
                //NSLog(@"RECENT GAMES : %@",[[TPAppManager defaultManager].turns objectForKey:@"game_over"] );
                //NSString *key = [NSString stringWithFormat:@"%d",indexPath.row];
                title = [[[[TPAppManager defaultManager].turns objectForKey:@"game_over"] objectAtIndex:indexPath.row] objectForKey:@"title"];
                
                msg = [[[[TPAppManager defaultManager].turns objectForKey:@"game_over"] objectAtIndex:indexPath.row] objectForKey:@"msg"];
                time = [[[[TPAppManager defaultManager].turns objectForKey:@"game_over"] objectAtIndex:indexPath.row] objectForKey:@"waiting"];
                image = [[[[TPAppManager defaultManager].turns objectForKey:@"game_over"] objectAtIndex:indexPath.row] objectForKey:@"avater"];
                 
            }
            //cell.backgroundColor = [UIColor whiteColor];
        }
        
        //dynamic height for Lables
        float delHeightTitle = [TPUtlis getHeightForString:title forFontName:@"Helvetica"  adnSize:14.0];
        float delHeightMsg = [TPUtlis getHeightForString:msg forFontName:@"Helvetica"  adnSize:12.0];
        float delHeightTime = [TPUtlis getHeightForString:time forFontName:@"Helvetica"  adnSize:10.0];
        float totalHeight = delHeightTitle + delHeightMsg + delHeightTime;
        float startY = (100.0 - 10.0 - totalHeight) / 2;
        UILabel *titleLab = [TPUtlis labelWithFrame:CGRectMake(70, startY, 210, delHeightTitle) text:title textColor:[UIColor blackColor] fontName:MYRIAD_PRO fontSize:14.0];
        titleLab.minimumFontSize = 12.0;
        titleLab.numberOfLines = 0;
        titleLab.adjustsFontSizeToFitWidth = YES;
        //titleLab.backgroundColor = [UIColor redColor];
        [cell.contentView addSubview:titleLab];
        
        UILabel *msgLab = [TPUtlis labelWithFrame:CGRectMake(70, startY + delHeightTitle, 210, delHeightMsg) text:msg textColor:[UIColor blackColor] fontName:MYRIAD_PRO fontSize:12.0];
        msgLab.minimumFontSize = 10.0;
        msgLab.numberOfLines = 0;
        titleLab.adjustsFontSizeToFitWidth = YES;
        //msgLab.backgroundColor = [UIColor greenColor];
        [cell.contentView addSubview:msgLab];
        
        UILabel *timeLab = [TPUtlis labelWithFrame:CGRectMake(70, startY + delHeightTitle + delHeightMsg, 210, delHeightTime) text:[NSString stringWithFormat:@"%@ ago.",[self allignTextForTime:time]] textColor:[UIColor blackColor] fontName:MYRIAD_PRO fontSize:10.0];
        timeLab.minimumFontSize = 8.0;
        timeLab.numberOfLines = 0;
        titleLab.adjustsFontSizeToFitWidth = YES;
        //timeLab.backgroundColor = [UIColor yellowColor];
        [cell.contentView addSubview:timeLab];
        
        AsyncImageView *imageView = [[[AsyncImageView alloc]init] autorelease];
        [imageView loadImageFromURL:[NSURL URLWithString:image]];
        imageView.frame = CGRectMake(5, 20, 60, 60);
        [TPUtlis getRoundedCornerFroView:imageView withCornerRadius:5.0f];
        [cell.contentView addSubview:imageView];
        if (indexPath.section == 2) {
            titleLab.frame = CGRectMake(5, startY, 210, delHeightTitle);
            msgLab.frame = CGRectMake(5, startY + delHeightTitle, 210, delHeightMsg);
            timeLab.frame = CGRectMake(5, startY + delHeightTitle + delHeightMsg, 210, delHeightTime);
            imageView.frame = CGRectMake(220, 20, 60, 60);
        }
    }
    
    return cell;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 3) {
        if ([[TPAppManager defaultManager].turns objectForKey:@"game_over"]) {
           [[TPAppManager defaultManager] userWillDeleteGame:[[[[TPAppManager defaultManager].turns objectForKey:@"game_over"] objectAtIndex:indexPath.row]objectForKey:@"challenge_id"]];
            
            NSMutableArray *recentGames = [NSMutableArray arrayWithArray:[[TPAppManager defaultManager].turns objectForKey:@"game_over"]];
            [recentGames removeObjectAtIndex:indexPath.row];
            [[TPAppManager defaultManager].turns setValue:recentGames forKey:@"game_over"];
            [self reloadData];
        }
    }
    
    
}

#pragma mark - UITableViewDelegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section != 0) {
        cell.backgroundColor = [UIColor whiteColor];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    int height = 90.0;
    if (indexPath.section != 0) {
        height = 100.0;
    }
    return height;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    if (section == 0) {
        return 0.0;
    }
    return 35.0 + ADJUST_TABLE_SECTION_SPACING;
}


- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    UIView *headerView = [[[UIView alloc] initWithFrame:CGRectMake(0, 0, 300, 35 /*+ ADJUST_TABLE_SECTION_SPACING*/)] autorelease];
    //headerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"background.png"]];
    
    UIImageView *backImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];
    backImage.frame = CGRectMake(0, 0 , 300, 35 /*+ ADJUST_TABLE_SECTION_SPACING*/);
    //[headerView addSubview:backImage];
    [backImage release];
    
    UIImageView *image = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"orangebar.png"]];
    image.frame = CGRectMake(0, 0/*ADJUST_TABLE_SECTION_SPACING*/ , 300, 35);
    [headerView addSubview:image];
    [image release];
    //headerView.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"orangebar.png"]];
    if (section == 0) {
        return nil;
    }
    else {
        NSString *headerText = @"";
        if (section == 1) {
            headerText = @"YOUR TURN";
        }
        if (section == 2) {
            headerText = @"PAL'S TURN";
        }
        if (section == 3) {
            headerText = @"RECENT GAMES";
        }
        UILabel *headerLab = [[UILabel alloc] initWithFrame:CGRectMake(20, 0/*ADJUST_TABLE_SECTION_SPACING*/, 260, 35)];
        headerLab.text = headerText;
        headerLab.backgroundColor = [UIColor clearColor];
        [headerView addSubview:headerLab];
        headerLab.textColor = [UIColor whiteColor];
        headerLab.font = [UIFont fontWithName:@"AppleCasual" size:20.0]; 
        [headerLab release];
        headerView.backgroundColor = [UIColor clearColor];
        return headerView ;
    }
}
 

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    if (indexPath.section == 0) {
        [[TPGameLogic sharedLogic] playMusicFileForType:OPTION_PRESS];
        [((TPViewController *)actionTarget) pushFreindPage];
    }
    //else if(indexPath.section == 3){
        
    //}
    else {
        NSString *mode = @"yours";
        NSString *key = @"yours_turn";
        if (indexPath.section == 2 ) {
            mode = @"pals";
            key = @"pals_turn";
        }
        if (indexPath.section == 3 ) {
            mode = @"pals";
            key = @"game_over";
            [TPAppManager defaultManager].isGameOver = YES; 
        }
              
        if ([[[TPAppManager defaultManager].turns objectForKey:key] count] > 0) {
            NSMutableDictionary *challengeDict = [NSMutableDictionary dictionaryWithDictionary:[[[TPAppManager defaultManager].turns objectForKey:key] objectAtIndex:indexPath.row]];
            [challengeDict setValue:mode forKey:@"mode"];
            NSLog(@"Challeng Dict : %@",challengeDict);
            if ([challengeDict objectForKey:@"challenge_start"]) {
                if ([[challengeDict objectForKey:@"challenge_start"] intValue] == 0) {
                    if (challengeDetails) {
                        RELEASE_SAFELY(challengeDetails);
                    }
                    self.challengeDetails = challengeDict;
                    [[[[UIAlertView alloc] initWithTitle:@"New Challenge" message:[NSString stringWithFormat:@"%@ has challenged you to play. Would you like to accept?",[challengeDict objectForKey:@"challenge_from"]] delegate:self cancelButtonTitle:@"Yes" otherButtonTitles:@"No", nil] autorelease] show];
                }
            }
            else {
                [[TPAppManager defaultManager] getTurnDetails:challengeDict];
                [TPAppManager defaultManager].activeGameId = [challengeDict objectForKey:@"game_id"];
                [TPAppManager defaultManager].delegate = actionTarget;
            }
//            [[TPAppManager defaultManager] getTurnDetails:challengeDict];
//            [TPAppManager defaultManager].activeGameId = [challengeDict objectForKey:@"game_id"];
//            [TPAppManager defaultManager].delegate = actionTarget;
        }
    }
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section == 3) {
        return UITableViewCellEditingStyleDelete;
    }
    return UITableViewCellAccessoryNone;
}

/*
- (NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath{
    
}
*/
 
- (BOOL)tableView:(UITableView *)tableView shouldIndentWhileEditingRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}

#pragma mark - Memory

- (void) dealloc{
       
    [_refreshHeaderView release];
    self.challengeDetails = nil;
    [super dealloc];
}

@end
