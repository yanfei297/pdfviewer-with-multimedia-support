//
//  TPTutorialView.h
//  TrivPals
//
//  Created by Sayan on 26/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPTutorialView : UIView

- (id)initWithFrame:(CGRect)frame andTarget:(id)target;
@end
