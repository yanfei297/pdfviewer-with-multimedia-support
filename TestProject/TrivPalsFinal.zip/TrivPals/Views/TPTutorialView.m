//
//  TPTutorialView.m
//  TrivPals
//
//  Created by Sayan on 26/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPTutorialView.h"
#import "TPUtlis.h"

@implementation TPTutorialView

- (id)initWithFrame:(CGRect)frame andTarget:(id)target
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.4];
        UIImageView *backview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];
        backview.frame = self.frame;//CGRectMake(0, 0, 320, 416);
        [self addSubview:backview];
        [backview release];
        
        UIImageView *backImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"howtoplaybox.png"]];
        backImage.frame = CGRectMake(25, 30, 275, 317);
        [self addSubview:backImage];
        
//        UILabel *settingsLab = [TPUtlis labelWithFrame:CGRectMake(30, 30, 260, 30) text:@"HOW TO PLAY" textColor:[UIColor whiteColor] fontName:@"AppleCasual" fontSize:24.0];
//        settingsLab.textAlignment = UITextAlignmentCenter;
//        //settingsLab.backgroundColor = [UIColor redColor];
//        [self addSubview:settingsLab];
        
        
        UIImageView *tutorial = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 263, 773)];
        tutorial.image = [UIImage imageNamed:@"contenttext.png"];
        
        UIScrollView *tutorialScroller = [[UIScrollView alloc] initWithFrame:CGRectMake(31 , 72, 263, 267)];
        [tutorialScroller addSubview:tutorial];
        [tutorial release];
        tutorialScroller.backgroundColor = [UIColor clearColor];
        [tutorialScroller flashScrollIndicators];
        tutorialScroller.contentSize = CGSizeMake(263, 775);
        [self addSubview:tutorialScroller];
        [tutorialScroller release];
        
        UIButton *closeButton = [TPUtlis buttonWithTitle:@"CLOSE!" target:target selector:@selector(closeSettings) frame:CGRectMake((320 - 105) / 2, 365, 105, 35) image:[UIImage imageNamed:@"blank_inactive.png"] imagePressed:[UIImage imageNamed:@"blank_active.png"] darkTextColor:NO];
        //[TPUtlis buttonWithTitle:@"CLOSE!" target:target selec0tor:@selector(closeSettings) frame:CGRectMake((320 - 105) / 2, 365, 105, 35) image:[UIImage imageNamed:@"blank_inactive.png"] imagePressed:[UIImage imageNamed:@"blank_active.png"] darkTextColor:NO];
        closeButton.titleLabel.font = [UIFont fontWithName:@"AppleCasual" size:24.0];
        [self addSubview:closeButton];
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
