//
//  TPHomeScreen.h
//  TrivPals
//
//  Created by Sayan on 16/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "TPAppManager.h"
#import "EGORefreshTableHeaderView.h"

@interface TPHomeScreen : UITableView<UITableViewDelegate,UITableViewDataSource,EGORefreshTableHeaderDelegate>{
    id actionTarget;
    EGORefreshTableHeaderView *_refreshHeaderView;
    BOOL _reloading;
    NSDictionary *challengeDetails;
}

@property (nonatomic,assign) id actionTarget;
@property (nonatomic,retain) NSDictionary *challengeDetails;

- (id)initWithFrame:(CGRect)frame andTarget:(id)target;
- (void)reloadTableViewDataSource;
- (void)doneLoadingTableViewData;
@end
