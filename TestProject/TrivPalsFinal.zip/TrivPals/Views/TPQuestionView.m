//
//  TPQuestionView.m
//  TrivPals
//
//  Created by Sayan on 23/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPQuestionView.h"
#import "TPUtlis.h"
#import "TPGameLogic.h"
#import "TPQuestionScreenViewController.h"

@implementation TPQuestionView

- (id)initWithFrame:(CGRect)frame andTarget:(id)target isPause:(BOOL) pause
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        actionTarget = target;
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.3];
        if (pause) {
            [self addNavigationButtons];
        }
        else {
            [self addGameOverScreen];
        }
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) addGameOverScreen{
    //[self performSelector:@selector(addNavigationButtons) withObject:nil afterDelay:1.0];
    int centerX = self.frame.size.width / 2;
    int centerY = self.frame.size.height / 2;
    UIImageView *backImage = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"blacklayer.png"]]autorelease];
    backImage.frame = self.frame;
    [self addSubview:backImage];
    backImage.alpha = 0.0;
   
    UIImageView *timeUp = [[[UIImageView alloc] initWithImage:[UIImage imageNamed:@"roundover.png"]] autorelease];
    timeUp.frame = CGRectMake((320 - 230) / 2, -138, 230, 138);
    [self addSubview:timeUp];
    
    [UIView animateWithDuration:3.0 animations:^{
        backImage.alpha = 0.3;
        timeUp.frame = CGRectMake((320 - 230) / 2, (416 - 138) / 2, 230, 138);
    }completion:^(BOOL finsihed){
        [NSThread sleepForTimeInterval:2.0];
        [UIView animateWithDuration:3.0 animations:^{
            timeUp.frame = CGRectMake((320 - 230) / 2, (416 + 138) , 230, 138);
            backImage.alpha = 0.0;
        }completion:^(BOOL finsihed){
            [actionTarget roundOver];
            [self removeFromSuperview];
        }];
    }];
    //[self addSubview:[TPUtlis buttonWithFrame:CGRectMake(centerX - 50 , centerY + 60, 100, 50) label:@"Done" actionTarget:actionTarget onTap:@selector(roundOver)]];
}

- (void) addNavigationButtons{
   // [[self viewWithTag:101] removeFromSuperview];
    UILabel *gameOverLabel = [TPUtlis labelWithFrame:CGRectMake( 50, 50, 220, 50) text:@"Game Paused" textColor:[UIColor grayColor] fontName:@"Marker-Felt" fontSize:16.0];
    gameOverLabel.textColor = [UIColor whiteColor];
    gameOverLabel.tag = 201;
    [self addSubview:gameOverLabel];
    [self addSubview:[TPUtlis buttonWithFrame:CGRectMake(110, 110, 100, 50) label:@"Resume" actionTarget:self onTap:@selector(resumeGame)]];
    [self addSubview:[TPUtlis buttonWithFrame:CGRectMake(110, 170, 100, 50) label:@"Main Menu" actionTarget:actionTarget onTap:@selector(goToMainMenu)]];
    [self addSubview:[TPUtlis buttonWithFrame:CGRectMake(110, 230, 100, 50) label:@"End Round" actionTarget:actionTarget onTap:@selector(endThisRound)]];
    [self addSubview:[TPUtlis buttonWithFrame:CGRectMake(110, 290, 100, 50) label:@"Resign" actionTarget:actionTarget onTap:@selector(resign)]];
}

- (void) resumeGame{
    [self removeFromSuperview];
    [[TPGameLogic sharedLogic] resumeGame];
    ((TPQuestionScreenViewController *)actionTarget).navigationItem.rightBarButtonItem.enabled = NO;
}

#pragma mark - Memory

- (void) dealloc{
    [super dealloc];
}

@end
