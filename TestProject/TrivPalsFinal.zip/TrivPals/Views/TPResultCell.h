//
//  TPResultCell.h
//  TrivPals
//
//  Created by Sayan on 28/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TPResultCell : UITableViewCell
@property (retain, nonatomic)  UILabel *player;
@property (retain, nonatomic)  UILabel *round;
@property (retain, nonatomic)  UILabel *opponent;
@end
