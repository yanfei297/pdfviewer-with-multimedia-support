//
//  TPSettingsView.m
//  TrivPals
//
//  Created by Sayan on 04/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPSettingsView.h"
#import "TPUtlis.h"
#import "TPGlobal.h"
#import "TPAppManager.h"

@implementation TPSettingsView

//@synthesize actionTarget;

- (id)initWithFrame:(CGRect)frame userDetails:(NSDictionary *)deatils andTarget:(id)target
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        //
        self.backgroundColor = [UIColor colorWithRed:0.0 green:0.0 blue:0.0 alpha:0.4];
        UIImageView *backview = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"background.png"]];
        backview.frame = self.frame;//CGRectMake(0, 0, 320, 416);
        [self addSubview:backview];
        [backview release];
        
        UIImageView *backImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"settingsbox.png"]];
        backImage.frame = CGRectMake(25, 30, 275, 317);
        [self addSubview:backImage];
        
        //UILabel *settingsLab = [TPUtlis labelWithFrame:CGRectMake(30, 30, 260, 30) text:@"SETTINGS" textColor:[UIColor whiteColor] fontName:@"AppleCasual" fontSize:24.0];
        //settingsLab.textAlignment = UITextAlignmentCenter;
        //settingsLab.backgroundColor = [UIColor redColor];
        //[self addSubview:settingsLab];
        
        UIImageView *pushImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pushtext.png"]];
        pushImage.frame = CGRectMake(40, 80, 151, 63);
        [self addSubview:pushImage];
        [pushImage release];
        
        //[self addSubview:[TPUtlis labelWithFrame:CGRectMake(80, 130, 80, 25) text:@"Enable Push" textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:12.0]];
        UISwitch *push = [[UISwitch alloc] initWithFrame:CGRectMake(195, 80, 80, 25)];
        push.on = [TPAppManager defaultManager].pushEnabled;
        [push addTarget:self action:@selector(enablePush:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:push];
        [push release];
        
        //[self addSubview:[TPUtlis labelWithFrame:CGRectMake(80, 165, 80, 25) text:@"Enable Sound" textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:12.0]];
        
        UIImageView *soundImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"soundtext.png"]];
        soundImage.frame = CGRectMake(40, 170, 137, 63);
        [self addSubview:soundImage];
        [soundImage release];
        
        UISwitch *sound = [[UISwitch alloc] initWithFrame:CGRectMake(195, 170, 80, 25)];
        sound.on = [TPAppManager defaultManager].soundEnabled;
        [sound addTarget:self action:@selector(enableSound:) forControlEvents:UIControlEventValueChanged];
        [self addSubview:sound];
        [sound release];
        
        
        UIImageView *accountImage = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"acsettings.png"]];
        accountImage.frame = CGRectMake(40, 260, 130, 17);
        [self addSubview:accountImage];
        [accountImage release];
        
        UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(40, 285, 50, 50)];
        [TPUtlis getRoundedCornerFroView:image withCornerRadius:5.0];
        image.image = [UIImage imageWithData:[deatils objectForKey:@"avater"]];
        [self addSubview:image];
        [image release];
        
        UILabel *nameLabel = [TPUtlis labelWithFrame:CGRectMake(100, 285, 125, 20) text:@"" textColor:[UIColor blueColor] fontName:MYRIAD_PRO fontSize:14.0];
        nameLabel.numberOfLines = 0;
        nameLabel.backgroundColor = [UIColor clearColor];
        nameLabel.textColor = [UIColor grayColor];
        NSString *name = [[NSString stringWithFormat:@"%@",[[deatils objectForKey:@"name"] substringFromIndex:7]]capitalizedString];
        nameLabel.text = name;
        nameLabel.lineBreakMode = UILineBreakModeWordWrap;
        [self addSubview:nameLabel];
        //[nameLabel release];
        
        [self addSubview:[TPUtlis buttonWithNormalImageNamed:@"fb_logout_inactive.png" pressedImageName:@"fb_logout_active.png" actionTarget:target selector:@selector(logout) x:100 y:305]];
                        
        UIButton *closeButton = [TPUtlis buttonWithTitle:@"CLOSE!" target:target selector:@selector(closeSettings) frame:CGRectMake((320 - 105) / 2, 365, 105, 35) image:[UIImage imageNamed:@"blank_inactive.png"] imagePressed:[UIImage imageNamed:@"blank_active.png"] darkTextColor:NO];
        //closeButton.titleLabel.textColor = [UIColor whiteColor];
        closeButton.titleLabel.font = [UIFont fontWithName:@"AppleCasual" size:24.0];
        [self addSubview:closeButton];
        
             
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (IBAction)enablePush:(id)sender{
    [TPAppManager defaultManager].pushEnabled =((UISwitch *)sender).isOn;
    [[TPAppManager defaultManager] userPushSettings];
}

- (IBAction) enableSound:(id)sender{
    [TPAppManager defaultManager].soundEnabled =((UISwitch *)sender).isOn;
}

- (void) dealloc{
    [super dealloc];
}

@end
