//
//  TPResultCell.m
//  TrivPals
//
//  Created by Sayan on 28/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPResultCell.h"
#import "TPGlobal.h"

@implementation TPResultCell
@synthesize player;
@synthesize round;
@synthesize opponent;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
        //[[NSBundle mainBundle] loadNibNamed:@"TPResultCell" owner:self options:nil];
        self.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        self.autoresizesSubviews = YES;
        
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(20, 5, 100, 34)];
        self.player = label;
        label.textAlignment = UITextAlignmentCenter;
        label.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        label.autoresizesSubviews = YES;
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont fontWithName:MYRIAD_PRO size:16.0];
        [self addSubview:label];
        [label release],label = nil;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(120, 5, 80, 34)];
        self.round = label;
        label.textAlignment = UITextAlignmentCenter;
        label.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont fontWithName:MYRIAD_PRO size:16.0];
        label.autoresizesSubviews = YES;
        [self addSubview:label];
        [label release],label = nil;
        
        label = [[UILabel alloc] initWithFrame:CGRectMake(200, 5, 100, 34)];
        self.opponent = label;
        label.textAlignment = UITextAlignmentCenter;
        label.autoresizingMask = UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleRightMargin | UIViewAutoresizingFlexibleLeftMargin | UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
        label.autoresizesSubviews = YES;
        label.backgroundColor = [UIColor clearColor];
        label.font = [UIFont fontWithName:MYRIAD_PRO size:16.0];
        [self addSubview:label];
        [label release],label = nil;
        
        player.textColor = [UIColor blackColor];
        //[UIColor colorWithRed:25.0 / 255.0 green:161.0 / 255.0 blue:79.0 / 255.0 alpha:1.0];
        round.textColor = [UIColor colorWithRed:96.0 / 255.0 green:49.0 / 255.0 blue:40.0 / 255.0 alpha:1.0];
        opponent.textColor = [UIColor blackColor];
        //[UIColor colorWithRed:255.0 / 255.0 green:0.0 / 255.0 blue:6.0 / 255.0 alpha:1.0];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

- (void)dealloc {
    [player release];
    [round release];
    [opponent release];
    [super dealloc];
}
@end
