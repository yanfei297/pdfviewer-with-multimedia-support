//
//  TPPickerRowView.m
//  TestPickerView
//
//  Created by Sayan on 05/04/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPPickerRowView.h"


@implementation TPPickerRowView

@synthesize rowDetails;
@synthesize playerImage;
@synthesize opponentImage;
@synthesize playerScore;
@synthesize opponentScore;
@synthesize questionNo;

- (id)initWithFrame:(CGRect)frame andRowDetails:(NSDictionary *)details
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        self.rowDetails = details;
        self.backgroundColor = [UIColor clearColor];
        self.userInteractionEnabled = NO;
        UIImageView *pImage = [[UIImageView alloc] initWithFrame:CGRectMake(15, 15, 80, 14)];
        pImage.backgroundColor = [UIColor clearColor];
        [self addSubview:pImage];
        self.playerImage = pImage;
        [pImage release];
        
        UILabel *pScore = [[UILabel alloc] initWithFrame:CGRectMake(40, 7, 40, 30)];
        pScore.backgroundColor = [UIColor clearColor];
        pScore.textAlignment = UITextAlignmentCenter;
        [self addSubview:pScore];
        //self.playerScore = pScore;
        [pScore release];
        
        UILabel *question = [[UILabel alloc] initWithFrame:CGRectMake(105, 7, 90, 30)];
        question.backgroundColor = [UIColor clearColor];
        question.textAlignment = UITextAlignmentCenter;
        question.font = [UIFont fontWithName:@"AppleCasual" size:20.0];
        [self addSubview:question];
        self.questionNo = question;
        [question release];
        
        UIImageView *oImage = [[UIImageView alloc] initWithFrame:CGRectMake(205, 15, 80, 14)];
        oImage.backgroundColor = [UIColor clearColor];
        [self addSubview:oImage];
        self.opponentImage = oImage;
        [oImage release];
        
        UILabel *oScore = [[UILabel alloc] initWithFrame:CGRectMake(265, 7, 30, 30)];
        oScore.backgroundColor = [UIColor clearColor];
        oScore.textAlignment = UITextAlignmentCenter;
        [self addSubview:oScore];
       // self.opponentScore = oScore;
        [oScore release];
        
        if ([[details objectForKey:@"player_status"] isEqualToString:@"right"]) {
            self.playerImage.image = [UIImage imageNamed:@"correct_2.png"];
        }
        else if([[details objectForKey:@"player_status"] isEqualToString:@"wrong"]){
            self.playerImage.image = [UIImage imageNamed:@"wrong_2.png"];
        }
        
        if ([[details objectForKey:@"opponent_status"] isEqualToString:@"right"]) {
            self.opponentImage.image = [UIImage imageNamed:@"correct_2.png"];
        }
        else if([[details objectForKey:@"opponent_status"] isEqualToString:@"wrong"]){
            self.opponentImage.image = [UIImage imageNamed:@"wrong_2.png"];
        }
        
        if (((NSString *)[details objectForKey:@"player_score"]).length > 0) {
            self.playerScore.text = [details objectForKey:@"player_score"];
        }
        
        if (((NSString *)[details objectForKey:@"opp_score"]).length > 0) {
            self.opponentScore.text = [details objectForKey:@"opp_score"];
        }
        
        if (((NSString *)[details objectForKey:@"question"]).length > 0) {
            self.questionNo.text = [details objectForKey:@"question"];
        }
        
    }
    return self;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

- (void) dealloc{
    self.rowDetails = nil;
    self.playerImage = nil;
    self.opponentImage = nil;
    self.playerScore = nil;
    self.opponentScore = nil;
    self.questionNo = nil;
    [super dealloc];
}

@end
