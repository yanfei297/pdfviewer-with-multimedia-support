//
//  TPResultView.m
//  TrivPals
//
//  Created by Sayan on 30/03/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "TPResultView.h"
#import "TPUtlis.h"

@implementation TPResultView

- (id)initWithFrame:(CGRect)frame andResultDetails:(NSDictionary *)resultDetails
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
        
        //int centerX = self.frame.size.width / 2;
        //int centerY = self.frame.size.height / 2;
        
        //NSLog(@"Results ; %@",resultDetails);
        
        int textWidth = 100;
        int pointsWidth = 25;
        int labHeight = 30;
        int delWidth = 5;
        int delHeight = 10;
        
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight, textWidth, labHeight) text:@"Total Question Attened " textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        NSString *msg = @"N/A";
        if (((NSString *)[resultDetails objectForKey:@"total_question"]).length > 0 ) {
            msg = [resultDetails objectForKey:@"total_question"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight , pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight + labHeight + delHeight, textWidth, labHeight) text:@"Correct Answared " textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        msg = @"N/A";
        if (((NSString *)[resultDetails objectForKey:@"correct_answer"]).length > 0 ) {
            msg = [resultDetails objectForKey:@"correct_answer"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight + labHeight + delHeight, pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight + labHeight + delHeight + labHeight + delHeight, textWidth, labHeight) text:@"Wrong Answared" textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        msg = @"N/A";
        if (((NSString *)[resultDetails objectForKey:@"wrong_answer"]).length > 0 ) {
            msg = [resultDetails objectForKey:@"wrong_answer"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight + labHeight + delHeight + labHeight + delHeight, pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, textWidth, labHeight) text:@"Passed " textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        msg = @"N/A";
        if (((NSString *)[resultDetails objectForKey:@"pass"]).length > 0 ) {
            msg = [resultDetails objectForKey:@"pass"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, textWidth, labHeight) text:@"10 pts Scored " textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        
        if ([[resultDetails objectForKey:@"tenpts"] isKindOfClass:[NSDecimalNumber class]]) {
            msg = [[resultDetails objectForKey:@"tenpts"] stringValue];
            if (msg.length < 1) {
                msg = @"N/A";
            }
        } 
        else{
            msg = [resultDetails objectForKey:@"tenpts"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
       
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, textWidth, labHeight) text:@"15 pts Scored " textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
        if ([[resultDetails objectForKey:@"fifteenpts"] isKindOfClass:[NSDecimalNumber class]]) {
            msg = [[resultDetails objectForKey:@"fifteenpts"] stringValue];
            if (msg.length < 1) {
                msg = @"N/A";
            }
        } 
        else{
            msg = [resultDetails objectForKey:@"fifteenpts"] ;
        }
        [self addSubview:[TPUtlis labelWithFrame:CGRectMake(delWidth + textWidth + delWidth, delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight + labHeight + delHeight, pointsWidth, labHeight) text:msg textColor:[UIColor blueColor] fontName:@"Helvetica" fontSize:14.0]];
    }
    return self;
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect
 {
 // Drawing code
 }
 */

@end
